<?php
/**
 * Setup wizard global — stepper horizontal de configuracion.
 *
 * V2.5.13.
 *
 * Renderiza un stepper compacto arriba de cada pagina del plugin admin
 * mostrando qué pasos faltan para tener todo configurado. Los pasos se
 * adaptan al CRM activo:
 *
 *   1. CRM destino elegido (cualquiera)
 *   2. Credenciales del CRM activo (especifico)
 *   3. Catalogos sincronizados (especifico — N/A para Webhook)
 *   4. Al menos un form mapeado
 *   5. Primer lead enviado exitosamente (queue.status = sent)
 *
 * Al llegar al 100% se reduce a un mini-badge persistente "✓ Setup
 * completo" colapsable. Click expande el detalle.
 *
 * Hookeado en `admin_notices` solo en pantallas del plugin
 * (toplevel_page_wppe-bridge* y subpages).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Setup wizard helper.
 */
final class WPPE_Bridge_Setup_Wizard {

	/**
	 * Bootstrap: registra el render en admin_notices.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_notices', array( self::class, 'maybe_render' ) );
	}

	/**
	 * Hook callback. Solo renderiza si estamos en una pantalla del plugin.
	 *
	 * @return void
	 */
	public static function maybe_render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( ! self::is_plugin_admin_screen() ) {
			return;
		}
		echo self::render(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render() emite HTML estatico construido internamente con esc_attr/esc_html donde aplica.
	}

	/**
	 * True si la pantalla actual es del plugin (Inicio / Configuracion /
	 * Mapeo / Modulos / Logs / etc.). Detecta via `get_current_screen()`.
	 *
	 * @return bool
	 */
	private static function is_plugin_admin_screen(): bool {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}
		$screen = get_current_screen();
		if ( null === $screen || ! isset( $screen->id ) ) {
			return false;
		}
		// Toplevel: `toplevel_page_wppe-bridge`. Subpages:
		// `wppe-bridge_page_wppe-bridge-{slug}`.
		$id = (string) $screen->id;
		return false !== strpos( $id, 'wppe-bridge' );
	}

	/**
	 * Define los pasos del wizard para un CRM dado.
	 *
	 * Cada paso es un array:
	 *   id    string  Identificador snake_case.
	 *   label string  Label visible al admin.
	 *   url   string  URL a la pagina donde se completa el paso.
	 *   done  bool    True si el paso esta completado.
	 *
	 * @param string $crm_slug Slug del CRM activo. Vacio para fresh install.
	 * @return array<int,array{id:string,label:string,url:string,done:bool}>
	 */
	public static function steps_for( string $crm_slug ): array {
		$steps = array();

		// 1. CRM elegido — comun a todos los CRMs.
		$steps[] = array(
			'id'    => 'crm_destination',
			'label' => __( 'Elegir CRM destino', 'wppe-bridge' ),
			'url'   => self::admin_url( 'admin.php?page=wppe-bridge-config' ),
			'done'  => class_exists( 'WPPE_Bridge_Destination_Factory' )
				&& WPPE_Bridge_Destination_Factory::is_configured(),
		);

		// 2. Credenciales — depende del CRM activo.
		// 3. Catalogos — idem.
		switch ( $crm_slug ) {
			case 'sperant':
				$steps[] = array(
					'id'    => 'sperant_token',
					'label' => __( 'Configurar token Sperant', 'wppe-bridge' ),
					'url'   => self::admin_url( 'admin.php?page=wppe-bridge-config' ),
					'done'  => '' !== (string) get_option( 'wppe_bridge_api_token', '' ),
				);
				$steps[] = array(
					'id'    => 'sperant_catalogs',
					'label' => __( 'Sincronizar catalogos Sperant', 'wppe-bridge' ),
					'url'   => self::admin_url( 'admin.php?page=wppe-bridge-config' ),
					'done'  => self::has_catalogs( 'wppe_bridge_catalogs' ),
				);
				break;

			case 'ghl':
				$steps[] = array(
					'id'    => 'ghl_token',
					'label' => __( 'Configurar token GoHighLevel', 'wppe-bridge' ),
					'url'   => self::admin_url( 'admin.php?page=wppe-bridge-ghl-config' ),
					'done'  => '' !== (string) get_option( 'wppe_bridge_ghl_token', '' )
						&& '' !== (string) get_option( 'wppe_bridge_ghl_location_id', '' ),
				);
				$steps[] = array(
					'id'    => 'ghl_catalogs',
					'label' => __( 'Sincronizar catalogos GHL', 'wppe-bridge' ),
					'url'   => self::admin_url( 'admin.php?page=wppe-bridge-ghl-mapping' ),
					'done'  => self::has_catalogs( 'wppe_bridge_ghl_catalogs' ),
				);
				break;

			case 'odoo':
				$steps[] = array(
					'id'    => 'odoo_credentials',
					'label' => __( 'Configurar credenciales Odoo', 'wppe-bridge' ),
					'url'   => self::admin_url( 'admin.php?page=wppe-bridge-odoo-config' ),
					'done'  => self::all_options_set(
						array(
							'wppe_bridge_odoo_base_url',
							'wppe_bridge_odoo_db',
							'wppe_bridge_odoo_login',
							'wppe_bridge_odoo_api_key',
						)
					),
				);
				$steps[] = array(
					'id'    => 'odoo_catalogs',
					'label' => __( 'Sincronizar catalogos Odoo', 'wppe-bridge' ),
					'url'   => self::admin_url( 'admin.php?page=wppe-bridge-odoo-mapping' ),
					'done'  => self::has_catalogs( 'wppe_bridge_odoo_catalogs' ),
				);
				break;

			case 'hubspot':
				$steps[] = array(
					'id'    => 'hubspot_token',
					'label' => __( 'Configurar Private App access token HubSpot', 'wppe-bridge' ),
					'url'   => self::admin_url( 'admin.php?page=wppe-bridge-hubspot-config' ),
					'done'  => '' !== (string) get_option( 'wppe_bridge_hubspot_access_token', '' ),
				);
				$steps[] = array(
					'id'    => 'hubspot_catalogs',
					'label' => __( 'Sincronizar catalogos HubSpot', 'wppe-bridge' ),
					'url'   => self::admin_url( 'admin.php?page=wppe-bridge-hubspot-mapping' ),
					'done'  => self::has_catalogs( 'wppe_bridge_hubspot_catalogs' ),
				);
				break;

			case 'webhook':
				$steps[] = array(
					'id'    => 'webhook_url',
					'label' => __( 'Configurar Webhook URL', 'wppe-bridge' ),
					'url'   => self::admin_url( 'admin.php?page=wppe-bridge-webhook-config' ),
					'done'  => '' !== (string) get_option( 'wppe_bridge_webhook_url', '' ),
				);
				// Webhook NO tiene catalogos — saltamos ese paso.
				break;

			default:
				// CRM no elegido todavia (slug vacio) — no agregamos pasos
				// CRM-specific. El paso 1 sigue marcando "elegir CRM".
				break;
		}

		// 4. Form mapping — comun. Al menos 1 form mapeado en
		// `wppe_bridge_field_mapping` (estructura: { form_plugin: {
		// form_id: { field_mapping_data } } }).
		$mapping         = get_option( 'wppe_bridge_field_mapping', array() );
		$has_any_mapping = false;
		if ( is_array( $mapping ) ) {
			foreach ( $mapping as $form_plugin_data ) {
				if ( is_array( $form_plugin_data ) && ! empty( $form_plugin_data ) ) {
					$has_any_mapping = true;
					break;
				}
			}
		}
		$steps[] = array(
			'id'    => 'form_mapping',
			'label' => __( 'Mapear al menos un form', 'wppe-bridge' ),
			'url'   => self::resolve_mapping_url( $crm_slug ),
			'done'  => $has_any_mapping,
		);

		// 5. Primer lead enviado exitosamente. Query optimizada: SELECT
		// 1 LIMIT 1 desde wppebridge_queue WHERE status='sent'. Cero
		// false positives.
		$steps[] = array(
			'id'    => 'first_lead_sent',
			'label' => __( 'Recibir y enviar un primer lead exitosamente', 'wppe-bridge' ),
			'url'   => self::admin_url( 'admin.php?page=wppe-bridge-logs' ),
			'done'  => self::has_at_least_one_sent_lead(),
		);

		return $steps;
	}

	/**
	 * Resuelve la URL de la pagina de mapeo correspondiente al CRM.
	 *
	 * @param string $crm_slug Slug del CRM activo.
	 * @return string URL.
	 */
	private static function resolve_mapping_url( string $crm_slug ): string {
		switch ( $crm_slug ) {
			case 'ghl':
				return self::admin_url( 'admin.php?page=wppe-bridge-ghl-mapping' );
			case 'odoo':
				return self::admin_url( 'admin.php?page=wppe-bridge-odoo-mapping' );
			case 'hubspot':
				return self::admin_url( 'admin.php?page=wppe-bridge-hubspot-mapping' );
			case 'sperant':
			case 'webhook':
			default:
				return self::admin_url( 'admin.php?page=wppe-bridge-mapping' );
		}
	}

	/**
	 * True si TODOS los option keys tienen valor no vacio. Helper para
	 * step "credenciales" cuando se requieren N options.
	 *
	 * @param string[] $option_keys Lista de keys.
	 * @return bool
	 */
	private static function all_options_set( array $option_keys ): bool {
		foreach ( $option_keys as $key ) {
			$value = get_option( $key, '' );
			if ( '' === (string) $value ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * True si el option de catalogos tiene al menos un catalogo poblado.
	 * Util porque algunos catalogos pueden venir vacios sin que sea fallo
	 * (ej. sources Sperant 404).
	 *
	 * @param string $option_key Key del option de catalogos.
	 * @return bool
	 */
	private static function has_catalogs( string $option_key ): bool {
		$catalogs = get_option( $option_key, array() );
		if ( ! is_array( $catalogs ) ) {
			return false;
		}
		foreach ( $catalogs as $k => $entries ) {
			if ( '_errors' === $k || '_sources' === $k || '_synced_at' === $k ) {
				continue; // Metadata, no es un catalogo real.
			}
			if ( is_array( $entries ) && ! empty( $entries ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * True si hay al menos un lead enviado exitosamente. Query directa
	 * a wp_wppebridge_queue.
	 *
	 * @return bool
	 */
	private static function has_at_least_one_sent_lead(): bool {
		global $wpdb;
		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
			return false;
		}
		$table = $wpdb->prefix . 'wppebridge_queue';
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- table name de $wpdb->prefix; query liviana de 1 row.
		$found = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1 FROM {$table} WHERE status = %s LIMIT 1",
				'sent'
			)
		);
		// phpcs:enable
		return ! empty( $found );
	}

	/**
	 * Wrapper de `admin_url` para que tests con stubs no rompan.
	 *
	 * @param string $path Path relativo (ej. 'admin.php?page=...').
	 * @return string
	 */
	private static function admin_url( string $path ): string {
		if ( function_exists( 'admin_url' ) ) {
			return admin_url( $path );
		}
		return '/wp-admin/' . ltrim( $path, '/' );
	}

	/**
	 * Resumen del progreso. Util para tests + para la vista.
	 *
	 * @return array{steps:array,done:int,total:int,all_done:bool,active_crm:string}
	 */
	public static function summarize(): array {
		$active_crm = class_exists( 'WPPE_Bridge_Destination_Factory' )
			? WPPE_Bridge_Destination_Factory::active_slug()
			: '';
		$steps      = self::steps_for( $active_crm );

		$done = 0;
		foreach ( $steps as $step ) {
			if ( ! empty( $step['done'] ) ) {
				++$done;
			}
		}

		return array(
			'steps'      => $steps,
			'done'       => $done,
			'total'      => count( $steps ),
			'all_done'   => count( $steps ) > 0 && count( $steps ) === $done,
			'active_crm' => $active_crm,
		);
	}

	/**
	 * Renderiza el HTML del stepper.
	 *
	 * Estados:
	 *  - all_done=true: mini-badge colapsado "✓ Configuracion completa".
	 *  - all_done=false: stepper horizontal con cada paso.
	 *
	 * @return string HTML.
	 */
	public static function render(): string {
		$summary = self::summarize();
		if ( 0 === $summary['total'] ) {
			return '';
		}

		// Si todo esta configurado, mini-badge colapsado.
		if ( $summary['all_done'] ) {
			return self::render_mini_badge( $summary );
		}

		return self::render_stepper( $summary );
	}

	/**
	 * Mini-badge para estado all_done. Stepper expandible al click.
	 *
	 * @param array $summary Output de summarize().
	 * @return string HTML.
	 */
	private static function render_mini_badge( array $summary ): string {
		ob_start();
		?>
		<div class="wppe-bridge-wizard wppe-bridge-wizard--mini" data-wppe-wizard-state="all-done">
			<button type="button" class="wppe-bridge-wizard__toggle" aria-expanded="false">
				<span class="wppe-bridge-wizard__check">✓</span>
				<span class="wppe-bridge-wizard__title">
					<?php esc_html_e( 'Configuracion completa', 'wppe-bridge' ); ?>
				</span>
				<span class="wppe-bridge-wizard__count">
					<?php
					printf(
						/* translators: %d: total de pasos. */
						esc_html__( '%d pasos', 'wppe-bridge' ),
						(int) $summary['total']
					);
					?>
				</span>
				<span class="wppe-bridge-wizard__arrow" aria-hidden="true">▾</span>
			</button>
			<div class="wppe-bridge-wizard__detail" hidden>
				<?php echo self::render_steps_list( $summary['steps'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML construido internamente. ?>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Stepper horizontal — estado all_done=false.
	 *
	 * @param array $summary Output de summarize().
	 * @return string HTML.
	 */
	private static function render_stepper( array $summary ): string {
		ob_start();
		?>
		<div class="wppe-bridge-wizard wppe-bridge-wizard--expanded" data-wppe-wizard-state="in-progress">
			<div class="wppe-bridge-wizard__header">
				<strong class="wppe-bridge-wizard__title">
					<?php esc_html_e( 'Configuracion del plugin', 'wppe-bridge' ); ?>
				</strong>
				<span class="wppe-bridge-wizard__progress">
					<?php
					printf(
						/* translators: 1: pasos completados, 2: total. */
						esc_html__( '%1$d de %2$d pasos completos', 'wppe-bridge' ),
						(int) $summary['done'],
						(int) $summary['total']
					);
					?>
				</span>
			</div>
			<ol class="wppe-bridge-wizard__steps">
				<?php
				$index = 0;
				foreach ( $summary['steps'] as $step ) {
					++$index;
					$classes   = array( 'wppe-bridge-wizard__step' );
					$classes[] = ! empty( $step['done'] ) ? 'is-done' : 'is-pending';
					?>
					<li class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
						<a href="<?php echo esc_url( (string) $step['url'] ); ?>" class="wppe-bridge-wizard__step-link">
							<span class="wppe-bridge-wizard__step-number" aria-hidden="true">
								<?php
								if ( ! empty( $step['done'] ) ) {
									echo '<span class="wppe-bridge-wizard__step-check">✓</span>';
								} else {
									echo (int) $index;
								}
								?>
							</span>
							<span class="wppe-bridge-wizard__step-label">
								<?php echo esc_html( (string) $step['label'] ); ?>
							</span>
						</a>
					</li>
					<?php
				}
				?>
			</ol>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Lista compacta de pasos para el detalle del mini-badge.
	 *
	 * @param array $steps Lista de steps.
	 * @return string HTML.
	 */
	private static function render_steps_list( array $steps ): string {
		ob_start();
		?>
		<ul class="wppe-bridge-wizard__steps-list">
			<?php foreach ( $steps as $step ) : ?>
				<li>
					<a href="<?php echo esc_url( (string) $step['url'] ); ?>">
						<span class="wppe-bridge-wizard__check">✓</span>
						<?php echo esc_html( (string) $step['label'] ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
		return (string) ob_get_clean();
	}
}
