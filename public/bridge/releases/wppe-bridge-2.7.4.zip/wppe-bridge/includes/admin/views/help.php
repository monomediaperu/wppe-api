<?php
/**
 * Vista de la pagina admin "Inicio".
 *
 * @var array<int,array<string,mixed>> $generic_steps Pasos genericos.
 * @var array<int,array<string,mixed>> $crm_steps     Pasos del CRM activo.
 * @var array<int,array<string,mixed>> $env_cards     Cards de diagnostico de entorno.
 * @var string                          $active_label  Label del CRM activo.
 * @var array<string,mixed>             $update_status Status del Updater (current/remote/has_update/last_check/error/changelog_url).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

$wppe_bridge_status_icons = array(
	WPPE_Bridge_Help_Page::STATUS_DONE     => '✅',
	WPPE_Bridge_Help_Page::STATUS_PENDING  => '⚠️',
	WPPE_Bridge_Help_Page::STATUS_OPTIONAL => '⬜',
	WPPE_Bridge_Help_Page::STATUS_WARN     => '⚠️',
);

$wppe_bridge_status_colors = array(
	WPPE_Bridge_Help_Page::STATUS_DONE     => '#46b450',
	WPPE_Bridge_Help_Page::STATUS_PENDING  => '#dba617',
	WPPE_Bridge_Help_Page::STATUS_OPTIONAL => '#888',
	WPPE_Bridge_Help_Page::STATUS_WARN     => '#dba617',
);

$wppe_bridge_destination_url = admin_url( 'admin.php?page=' . WPPE_Bridge_Admin_Menu::SLUG . '-config' );

// Conteo de progreso (DONE / total) para el header.
$wppe_bridge_done_count = 0;
$wppe_bridge_total      = count( $generic_steps );
foreach ( $generic_steps as $wppe_bridge_st ) {
	if ( WPPE_Bridge_Help_Page::STATUS_DONE === ( $wppe_bridge_st['status'] ?? '' ) ) {
		++$wppe_bridge_done_count;
	}
}

$wppe_bridge_kses_inline = array(
	'a'      => array(
		'href'   => array(),
		'target' => array(),
		'rel'    => array(),
	),
	'br'     => array(),
	'code'   => array(),
	'strong' => array(),
	'em'     => array(),
);
?>
<style>
	.wppe-bridge-grid {
		display: grid;
		grid-template-columns: repeat(2, minmax(0, 1fr));
		gap: 12px;
		max-width: 1200px;
	}
	@media (max-width: 900px) {
		.wppe-bridge-grid {
			grid-template-columns: 1fr;
		}
	}
	.wppe-bridge-card {
		border: 1px solid #ccd0d4;
		background: #fff;
		padding: 14px 18px;
		border-left: 4px solid #888;
		display: flex;
		gap: 14px;
		align-items: flex-start;
	}
	.wppe-bridge-card.is-done.is-compact {
		padding: 10px 14px;
	}
	.wppe-bridge-card .wppe-bridge-card-icon {
		font-size: 22px;
		line-height: 1;
		padding-top: 2px;
	}
	.wppe-bridge-card.is-done.is-compact .wppe-bridge-card-icon {
		font-size: 16px;
	}
	.wppe-bridge-card .wppe-bridge-card-body {
		flex: 1;
		min-width: 0;
	}
	.wppe-bridge-card h3 {
		margin: 0 0 6px;
		font-size: 16px;
	}
	.wppe-bridge-card.is-done.is-compact h3 {
		font-size: 14px;
		margin-bottom: 2px;
	}
	.wppe-bridge-card-desc {
		margin: 0 0 8px;
		color: #444;
	}
	.wppe-bridge-card-detail {
		margin: 0 0 6px;
		font-size: 13px;
	}
	.wppe-bridge-card.is-done.is-compact .wppe-bridge-card-detail {
		font-size: 12px;
		margin-bottom: 0;
	}
	.wppe-bridge-card-action {
		margin: 8px 0 0;
	}
	.wppe-bridge-help-header {
		background: #fff;
		border: 1px solid #ccd0d4;
		padding: 14px 18px;
		margin: 16px 0;
		display: flex;
		justify-content: space-between;
		align-items: center;
		flex-wrap: wrap;
		gap: 12px;
		max-width: 1200px;
	}
</style>

<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Inicio', 'wppe-bridge' ); ?></h1>

	<div class="wppe-bridge-help-header">
		<div>
			<strong><?php esc_html_e( 'CRM destino activo:', 'wppe-bridge' ); ?></strong>
			🔌 <?php echo esc_html( $active_label ); ?>
		</div>
		<div>
			<strong><?php esc_html_e( 'Progreso:', 'wppe-bridge' ); ?></strong>
			<?php
			printf(
				/* translators: 1: pasos completos, 2: total */
				esc_html__( '%1$d/%2$d pasos genericos completos', 'wppe-bridge' ),
				(int) $wppe_bridge_done_count,
				(int) $wppe_bridge_total
			);
			?>
			<a href="<?php echo esc_url( $wppe_bridge_destination_url ); ?>" style="margin-left:14px"><?php esc_html_e( 'Cambiar destino →', 'wppe-bridge' ); ?></a>
		</div>
	</div>

	<?php
	// Strip de version del plugin (v2.5.x) — muestra version actual,
	// version remota disponible (cache 12h o forzar refresh con el
	// boton), y CTA al boton nativo de WP "Update now" cuando hay
	// actualizacion. Si no hay catalogo cacheado todavia, get_status()
	// hace un fetch transparente. Si el manifest endpoint esta caido,
	// muestra mensaje claro sin romper la pagina.
	$wppe_bridge_us_current    = (string) ( $update_status['current'] ?? '' );
	$wppe_bridge_us_remote     = $update_status['remote'] ?? null;
	$wppe_bridge_us_has_update = ! empty( $update_status['has_update'] );
	$wppe_bridge_us_ahead      = ! empty( $update_status['ahead'] );
	$wppe_bridge_us_last_check = $update_status['last_check'] ?? null;
	$wppe_bridge_us_error      = $update_status['error'] ?? null;
	$wppe_bridge_us_changelog  = (string) ( $update_status['changelog_url'] ?? '' );

	if ( $wppe_bridge_us_has_update ) {
		$wppe_bridge_us_state_color = '#dba617';
		$wppe_bridge_us_state_icon  = '🔔';
	} elseif ( null !== $wppe_bridge_us_error ) {
		$wppe_bridge_us_state_color = '#dc3232';
		$wppe_bridge_us_state_icon  = '⚠️';
	} elseif ( $wppe_bridge_us_ahead ) {
		// v2.5.5: caso "instalacion adelantada al manifest cacheado".
		// No es error, pero "Estas al dia" seria enganoso. Color neutro.
		$wppe_bridge_us_state_color = '#72aee6';
		$wppe_bridge_us_state_icon  = 'ℹ️';
	} else {
		$wppe_bridge_us_state_color = '#46b450';
		$wppe_bridge_us_state_icon  = '✅';
	}

	$wppe_bridge_us_last_check_label = '';
	if ( is_int( $wppe_bridge_us_last_check ) && $wppe_bridge_us_last_check > 0 ) {
		$wppe_bridge_us_diff = max( 0, time() - $wppe_bridge_us_last_check );
		if ( $wppe_bridge_us_diff < 60 ) {
			$wppe_bridge_us_last_check_label = __( 'consultado recien', 'wppe-bridge' );
		} elseif ( function_exists( 'human_time_diff' ) ) {
			$wppe_bridge_us_last_check_label = sprintf(
				/* translators: %s: tiempo legible (ej. "3 horas"). */
				__( 'consultado hace %s', 'wppe-bridge' ),
				human_time_diff( $wppe_bridge_us_last_check, time() )
			);
		}
	}

	$wppe_bridge_us_plugins_url = function_exists( 'admin_url' ) ? admin_url( 'plugins.php' ) : 'plugins.php';
	?>
	<div class="wppe-bridge-version-strip" style="background:#fff;border-left:6px solid <?php echo esc_attr( $wppe_bridge_us_state_color ); ?>;padding:12px 18px;margin:14px 0;border-radius:4px;box-shadow:0 1px 1px rgba(0,0,0,.04);max-width:1200px;display:flex;flex-wrap:wrap;align-items:center;gap:18px;">
		<div style="font-size:14px;display:flex;align-items:center;gap:8px;">
			<span style="font-size:22px;line-height:1"><?php echo esc_html( $wppe_bridge_us_state_icon ); ?></span>
			<span>
				<strong><?php esc_html_e( 'Versión instalada:', 'wppe-bridge' ); ?></strong>
				<code style="background:#f0f0f1;padding:2px 6px;border-radius:3px;font-size:13px;" id="wppe-bridge-version-current"><?php echo esc_html( $wppe_bridge_us_current ); ?></code>
			</span>
		</div>

		<div style="flex:1;min-width:240px;font-size:13px;color:#333" id="wppe-bridge-version-status-text">
			<?php if ( $wppe_bridge_us_has_update ) : ?>
				<strong style="color:<?php echo esc_attr( $wppe_bridge_us_state_color ); ?>"><?php esc_html_e( 'Hay una actualización disponible:', 'wppe-bridge' ); ?></strong>
				<code style="background:#fff7e0;padding:2px 6px;border-radius:3px;font-size:13px;" id="wppe-bridge-version-remote"><?php echo esc_html( (string) $wppe_bridge_us_remote ); ?></code>
				<?php if ( '' !== $wppe_bridge_us_changelog ) : ?>
					<a href="<?php echo esc_url( $wppe_bridge_us_changelog ); ?>" target="_blank" rel="noopener" style="margin-left:6px"><?php esc_html_e( 'Ver changelog', 'wppe-bridge' ); ?> ↗</a>
				<?php endif; ?>
			<?php elseif ( null !== $wppe_bridge_us_error ) : ?>
				<span style="color:#dc3232"><?php echo esc_html( (string) $wppe_bridge_us_error ); ?></span>
			<?php elseif ( $wppe_bridge_us_ahead ) : ?>
				<strong style="color:<?php echo esc_attr( $wppe_bridge_us_state_color ); ?>"><?php esc_html_e( 'Tu instalación está adelantada al manifest cacheado.', 'wppe-bridge' ); ?></strong>
				<span style="color:#555;margin-left:6px">
					<?php esc_html_e( 'Manifest dice:', 'wppe-bridge' ); ?>
					<code style="background:transparent;padding:0;font-size:13px;" id="wppe-bridge-version-remote"><?php echo esc_html( (string) $wppe_bridge_us_remote ); ?></code>.
					<?php esc_html_e( 'Probablemente el cache local de 12h está desactualizado. Click "Buscar actualizaciones" para forzar refresh.', 'wppe-bridge' ); ?>
				</span>
			<?php elseif ( null !== $wppe_bridge_us_remote ) : ?>
				<span style="color:#46b450"><?php esc_html_e( 'Estás al día.', 'wppe-bridge' ); ?></span>
				<span style="color:#888;margin-left:6px">(<?php esc_html_e( 'última versión publicada:', 'wppe-bridge' ); ?> <code style="background:transparent;padding:0;font-size:13px;" id="wppe-bridge-version-remote"><?php echo esc_html( (string) $wppe_bridge_us_remote ); ?></code>)</span>
			<?php else : ?>
				<span style="color:#888"><?php esc_html_e( 'Sin información todavía. Click "Buscar ahora" para consultar.', 'wppe-bridge' ); ?></span>
			<?php endif; ?>
			<?php if ( '' !== $wppe_bridge_us_last_check_label ) : ?>
				<br>
				<span style="color:#999;font-size:12px;" id="wppe-bridge-version-last-check"><?php echo esc_html( $wppe_bridge_us_last_check_label ); ?></span>
			<?php endif; ?>
		</div>

		<div style="display:flex;align-items:center;gap:10px">
			<button type="button"
				class="button"
				id="wppe-bridge-check-updates-btn"
				data-nonce="<?php echo esc_attr( wp_create_nonce( WPPE_Bridge_Admin_Ajax::NONCE_ACTION ) ); ?>"
				data-plugins-url="<?php echo esc_attr( $wppe_bridge_us_plugins_url ); ?>">
				<span class="dashicons dashicons-update" aria-hidden="true" style="margin-top:3px;line-height:1.2"></span>
				<?php esc_html_e( 'Buscar actualizaciones', 'wppe-bridge' ); ?>
			</button>
			<?php if ( $wppe_bridge_us_has_update ) : ?>
				<a class="button button-primary" href="<?php echo esc_url( $wppe_bridge_us_plugins_url ); ?>">
					<?php esc_html_e( 'Ir a Plugins → Actualizar', 'wppe-bridge' ); ?>
				</a>
			<?php endif; ?>
		</div>
	</div>

	<?php
	// Banner de estado operativo (v1.2.6) — resumen ejecutivo arriba
	// de todo. El operador ve OPERATIVO/PARCIAL/NO OPERATIVO de un
	// vistazo en lugar de tener que sumar 7 cards.
	if ( class_exists( 'WPPE_Bridge_Operational_Status' ) ) :
		$wppe_bridge_op = WPPE_Bridge_Operational_Status::evaluate();
		switch ( $wppe_bridge_op['state'] ) {
			case WPPE_Bridge_Operational_Status::STATE_OPERATIONAL:
				$wppe_bridge_op_color = '#46b450';
				$wppe_bridge_op_icon  = '✅';
				$wppe_bridge_op_label = __( 'OPERATIVO', 'wppe-bridge' );
				break;
			case WPPE_Bridge_Operational_Status::STATE_PARTIAL:
				$wppe_bridge_op_color = '#ffb900';
				$wppe_bridge_op_icon  = '⚠';
				$wppe_bridge_op_label = __( 'PARCIAL', 'wppe-bridge' );
				break;
			default:
				$wppe_bridge_op_color = '#dc3232';
				$wppe_bridge_op_icon  = '🔴';
				$wppe_bridge_op_label = __( 'NO OPERATIVO', 'wppe-bridge' );
				break;
		}
		?>
		<details class="wppe-bridge-op-banner" style="background:#fff;border-left:6px solid <?php echo esc_attr( $wppe_bridge_op_color ); ?>;padding:14px 18px;margin:14px 0;border-radius:4px;box-shadow:0 1px 1px rgba(0,0,0,.04);max-width:1200px;" <?php echo WPPE_Bridge_Operational_Status::STATE_OPERATIONAL === $wppe_bridge_op['state'] ? '' : 'open'; ?>>
			<summary style="cursor:pointer;list-style:none;display:flex;align-items:center;gap:14px;outline:none;">
				<span style="font-size:28px;line-height:1;"><?php echo esc_html( $wppe_bridge_op_icon ); ?></span>
				<span style="flex:1">
					<strong style="font-size:15px;color:<?php echo esc_attr( $wppe_bridge_op_color ); ?>;">
						<?php esc_html_e( 'Estado del plugin:', 'wppe-bridge' ); ?>
						<?php echo esc_html( $wppe_bridge_op_label ); ?>
					</strong>
					<br>
					<span style="color:#555">
						<?php echo esc_html( $wppe_bridge_op['summary'] ); ?>
					</span>
				</span>
				<span style="color:#999;font-size:12px"><?php esc_html_e( 'click para detalle', 'wppe-bridge' ); ?></span>
			</summary>
			<table class="widefat striped" style="margin-top:14px">
				<thead>
					<tr>
						<th style="width:30px"></th>
						<th><?php esc_html_e( 'Requisito', 'wppe-bridge' ); ?></th>
						<th><?php esc_html_e( 'Estado', 'wppe-bridge' ); ?></th>
						<th><?php esc_html_e( 'Tipo', 'wppe-bridge' ); ?></th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach ( $wppe_bridge_op['checks'] as $wppe_bridge_chk ) :
						$wppe_bridge_chk_passed   = ! empty( $wppe_bridge_chk['passed'] );
						$wppe_bridge_chk_critical = ! empty( $wppe_bridge_chk['critical'] );
						$wppe_bridge_chk_icon     = $wppe_bridge_chk_passed ? '✅' : ( $wppe_bridge_chk_critical ? '🔴' : '⚠' );
						?>
						<tr>
							<td><?php echo esc_html( $wppe_bridge_chk_icon ); ?></td>
							<td><?php echo esc_html( (string) $wppe_bridge_chk['label'] ); ?></td>
							<td>
								<?php
								echo wp_kses(
									(string) ( $wppe_bridge_chk['message'] ?? '' ),
									$wppe_bridge_kses_inline
								);
								?>
							</td>
							<td>
								<?php
								// "indispensable" en lugar de "critico" (v1.2.7) — operadores
								// reportaron que "critico" suena a problema en lugar de
								// requisito.
								echo $wppe_bridge_chk_critical
									? '<span style="color:#dc3232">' . esc_html__( 'indispensable', 'wppe-bridge' ) . '</span>'
									: '<span style="color:#999">' . esc_html__( 'recomendado', 'wppe-bridge' ) . '</span>';
								?>
							</td>
							<td>
								<?php if ( ! $wppe_bridge_chk_passed && ! empty( $wppe_bridge_chk['cta_url'] ) && ! empty( $wppe_bridge_chk['cta_label'] ) ) : ?>
									<a href="<?php echo esc_url( (string) $wppe_bridge_chk['cta_url'] ); ?>" class="button button-small">
										<?php echo esc_html( (string) $wppe_bridge_chk['cta_label'] ); ?>
									</a>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</details>
	<?php endif; ?>

	<?php if ( ! empty( $env_cards ) ) : ?>
		<h2><?php esc_html_e( 'Diagnostico del entorno', 'wppe-bridge' ); ?></h2>
		<p style="max-width:1200px;color:#666">
			<?php esc_html_e( 'Verificacion del stack que corre este sitio. El plugin funciona en cualquier entorno; estas cards son recomendaciones de Mono Media para lograr la mejor performance del sitio del cliente.', 'wppe-bridge' ); ?>
		</p>

		<div class="wppe-bridge-grid">
			<?php foreach ( $env_cards as $wppe_bridge_env_card ) : ?>
				<?php
				$wppe_bridge_env_status     = (string) ( $wppe_bridge_env_card['status'] ?? '' );
				$wppe_bridge_env_color      = $wppe_bridge_status_colors[ $wppe_bridge_env_status ] ?? '#888';
				$wppe_bridge_env_icon       = (string) ( $wppe_bridge_env_card['icon'] ?? '🛠' );
				$wppe_bridge_env_action_url = $wppe_bridge_env_card['action_url'] ?? null;
				$wppe_bridge_env_action_lbl = $wppe_bridge_env_card['action_label'] ?? null;
				$wppe_bridge_env_is_done    = WPPE_Bridge_Help_Page::STATUS_DONE === $wppe_bridge_env_status;
				$wppe_bridge_env_classes    = 'wppe-bridge-card wppe-bridge-env-card' . ( $wppe_bridge_env_is_done ? ' is-done is-compact' : '' );
				?>
				<div class="<?php echo esc_attr( $wppe_bridge_env_classes ); ?>" style="border-left-color:<?php echo esc_attr( $wppe_bridge_env_color ); ?>;">
					<div class="wppe-bridge-card-icon"><?php echo esc_html( $wppe_bridge_env_icon ); ?></div>
					<div class="wppe-bridge-card-body">
						<h3><?php echo esc_html( (string) ( $wppe_bridge_env_card['title'] ?? '' ) ); ?></h3>
						<?php if ( ! $wppe_bridge_env_is_done ) : ?>
							<p class="wppe-bridge-card-desc">
								<?php
								echo wp_kses(
									(string) ( $wppe_bridge_env_card['description'] ?? '' ),
									$wppe_bridge_kses_inline
								);
								?>
							</p>
						<?php endif; ?>
						<?php if ( ! empty( $wppe_bridge_env_card['detail'] ) ) : ?>
							<p class="wppe-bridge-card-detail" style="color:<?php echo esc_attr( $wppe_bridge_env_color ); ?>;">
								<?php
								echo wp_kses(
									(string) $wppe_bridge_env_card['detail'],
									$wppe_bridge_kses_inline
								);
								?>
							</p>
						<?php endif; ?>
						<?php if ( ! $wppe_bridge_env_is_done && $wppe_bridge_env_action_url && $wppe_bridge_env_action_lbl ) : ?>
							<p class="wppe-bridge-card-action">
								<a href="<?php echo esc_url( (string) $wppe_bridge_env_action_url ); ?>" class="button button-secondary" target="_blank" rel="noopener">
									<?php echo esc_html( (string) $wppe_bridge_env_action_lbl ); ?>
								</a>
							</p>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>

		<hr/>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Pasos de instalacion', 'wppe-bridge' ); ?></h2>
	<p style="max-width:1200px;color:#666">
		<?php esc_html_e( 'Pasos que el equipo Mono Media completa al instalar el plugin en el WordPress del cliente. Las cards completadas se compactan automaticamente.', 'wppe-bridge' ); ?>
	</p>

	<div class="wppe-bridge-grid">
		<?php foreach ( $generic_steps as $wppe_bridge_step ) : ?>
			<?php
			$wppe_bridge_st_status     = (string) ( $wppe_bridge_step['status'] ?? '' );
			$wppe_bridge_st_color      = $wppe_bridge_status_colors[ $wppe_bridge_st_status ] ?? '#888';
			$wppe_bridge_st_icon       = $wppe_bridge_status_icons[ $wppe_bridge_st_status ] ?? '⬜';
			$wppe_bridge_st_action_url = $wppe_bridge_step['action_url'] ?? null;
			$wppe_bridge_st_action_lbl = $wppe_bridge_step['action_label'] ?? null;
			$wppe_bridge_st_is_done    = WPPE_Bridge_Help_Page::STATUS_DONE === $wppe_bridge_st_status;
			$wppe_bridge_st_classes    = 'wppe-bridge-card wppe-bridge-step-card' . ( $wppe_bridge_st_is_done ? ' is-done is-compact' : '' );
			?>
			<div class="<?php echo esc_attr( $wppe_bridge_st_classes ); ?>" style="border-left-color:<?php echo esc_attr( $wppe_bridge_st_color ); ?>;">
				<div class="wppe-bridge-card-icon"><?php echo esc_html( $wppe_bridge_st_icon ); ?></div>
				<div class="wppe-bridge-card-body">
					<h3>
						<?php echo (int) ( $wppe_bridge_step['number'] ?? 0 ); ?>.
						<?php echo esc_html( (string) ( $wppe_bridge_step['title'] ?? '' ) ); ?>
					</h3>
					<?php if ( ! $wppe_bridge_st_is_done ) : ?>
						<p class="wppe-bridge-card-desc">
							<?php
							echo wp_kses(
								(string) ( $wppe_bridge_step['description'] ?? '' ),
								$wppe_bridge_kses_inline
							);
							?>
						</p>
					<?php endif; ?>
					<?php if ( ! empty( $wppe_bridge_step['detail'] ) ) : ?>
						<p class="wppe-bridge-card-detail" style="color:<?php echo esc_attr( $wppe_bridge_st_color ); ?>;">
							<?php echo esc_html( (string) $wppe_bridge_step['detail'] ); ?>
						</p>
					<?php endif; ?>
					<?php if ( ! $wppe_bridge_st_is_done && $wppe_bridge_st_action_url && $wppe_bridge_st_action_lbl ) : ?>
						<p class="wppe-bridge-card-action">
							<a href="<?php echo esc_url( (string) $wppe_bridge_st_action_url ); ?>" class="button button-secondary">
								<?php echo esc_html( (string) $wppe_bridge_st_action_lbl ); ?>
							</a>
						</p>
					<?php endif; ?>
				</div>
			</div>
		<?php endforeach; ?>
	</div>

	<?php if ( ! empty( $crm_steps ) ) : ?>
		<hr/>
		<h2>
			<?php
			printf(
				/* translators: %s = label del CRM activo */
				esc_html__( 'Guia especifica — %s', 'wppe-bridge' ),
				esc_html( $active_label )
			);
			?>
		</h2>

		<div class="wppe-bridge-grid">
			<?php foreach ( $crm_steps as $wppe_bridge_crm_step ) : ?>
				<?php
				$wppe_bridge_crm_action_url = $wppe_bridge_crm_step['action_url'] ?? null;
				$wppe_bridge_crm_action_lbl = $wppe_bridge_crm_step['action_label'] ?? null;
				?>
				<div class="wppe-bridge-card wppe-bridge-help-card" style="border-left-color:#2271b1;">
					<div class="wppe-bridge-card-icon">📖</div>
					<div class="wppe-bridge-card-body">
						<h3><?php echo esc_html( (string) ( $wppe_bridge_crm_step['title'] ?? '' ) ); ?></h3>
						<p class="wppe-bridge-card-desc">
							<?php
							echo wp_kses(
								(string) ( $wppe_bridge_crm_step['description'] ?? '' ),
								$wppe_bridge_kses_inline
							);
							?>
						</p>
						<?php if ( $wppe_bridge_crm_action_url && $wppe_bridge_crm_action_lbl ) : ?>
							<p class="wppe-bridge-card-action">
								<a href="<?php echo esc_url( (string) $wppe_bridge_crm_action_url ); ?>" class="button button-secondary">
									<?php echo esc_html( (string) $wppe_bridge_crm_action_lbl ); ?>
								</a>
							</p>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<hr/>

	<h2><?php esc_html_e( 'Soporte', 'wppe-bridge' ); ?></h2>
	<div style="max-width:1200px;background:#f6f7f7;padding:14px 18px;border:1px solid #ccd0d4;">
		<p style="margin-top:0;">
			<?php esc_html_e( '¿Necesitas ayuda con la configuracion, agregar tu dominio a la whitelist, troubleshooting o sugerencias de nuevos CRMs?', 'wppe-bridge' ); ?>
		</p>
		<ul style="list-style:disc;margin-left:25px">
			<li>
				📧 <strong><?php esc_html_e( 'Soporte WP.pe Bridge (Mono Media):', 'wppe-bridge' ); ?></strong>
				<a href="mailto:soporte@mono.media">soporte@mono.media</a>
				<br/>
				<em style="color:#666;font-size:13px"><?php esc_html_e( 'Configuracion, whitelist, troubleshooting, sugerencias.', 'wppe-bridge' ); ?></em>
			</li>
			<li>
				📧 <strong><?php esc_html_e( 'Soporte Sperant API:', 'wppe-bridge' ); ?></strong>
				<a href="mailto:soporte@sperant.com">soporte@sperant.com</a>
				<br/>
				<em style="color:#666;font-size:13px"><?php esc_html_e( 'Solo issues de la API de Sperant (no del plugin). Tiempo de respuesta lento.', 'wppe-bridge' ); ?></em>
			</li>
		</ul>
	</div>
</div>
