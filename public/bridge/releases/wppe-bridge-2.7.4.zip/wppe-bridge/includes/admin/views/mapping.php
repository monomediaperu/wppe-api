<?php
/**
 * Vista de la pagina admin "Mapeo de campos".
 *
 * Variables disponibles (de WPPE_Bridge_Mapping_Page::render):
 *
 * @var array       $discovered          ['fluent' => [...], 'gravity' => [...]]
 * @var array       $catalogs            wp_options['wppe_bridge_catalogs']
 * @var array       $mapping             wp_options['wppe_bridge_field_mapping']
 * @var string      $selected_plugin     'fluent' | 'gravity'
 * @var string      $selected_form       form_id seleccionado (o '').
 * @var array|null  $selected_form_data  Form descubierto (o null).
 * @var array       $existing_mapping    {fields, defaults} ya guardado.
 * @var bool        $catalogs_present    True si hay catalogos sincronizados.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

$wppe_bridge_flash     = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$wppe_bridge_has_forms = ! empty( $discovered['fluent'] ) || ! empty( $discovered['gravity'] );
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Mapeo de campos', 'wppe-bridge' ); ?></h1>

	<?php if ( 'saved' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-success is-dismissible" role="status"><p><?php esc_html_e( 'Mapeo guardado.', 'wppe-bridge' ); ?></p></div>
	<?php elseif ( 'error_missing_form' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-error is-dismissible" role="alert"><p><?php esc_html_e( 'Falta seleccionar plugin o form.', 'wppe-bridge' ); ?></p></div>
	<?php elseif ( 'error_required' === $wppe_bridge_flash ) : ?>
		<?php
		$wppe_bridge_missing_raw = isset( $_GET['missing'] ) ? sanitize_text_field( wp_unslash( $_GET['missing'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$wppe_bridge_missing     = '' === $wppe_bridge_missing_raw ? array() : explode( ',', $wppe_bridge_missing_raw );
		$wppe_bridge_missing_lbl = array(
			'fname'            => __( 'Mapear al menos un campo del form a "fname" (nombre del cliente)', 'wppe-bridge' ),
			'input_channel_id' => __( 'Default "Canal de entrada" O mapear field → input_channel_id', 'wppe-bridge' ),
			'interest_type_id' => __( 'Default "Tipo de interes" O mapear field → interest_type_id', 'wppe-bridge' ),
			'source_id'        => __( 'Default "Fuente" O mapear field → source_id', 'wppe-bridge' ),
			'project_id'       => __( 'Default "Proyecto" O mapear dropdown → project_id', 'wppe-bridge' ),
		);
		?>
		<div class="notice notice-error is-dismissible" role="alert">
			<p><strong><?php esc_html_e( 'No se guardo el mapeo. Faltan campos obligatorios:', 'wppe-bridge' ); ?></strong></p>
			<ul style="list-style:disc;margin-left:25px">
				<?php foreach ( $wppe_bridge_missing as $wppe_bridge_mkey ) : ?>
					<li><?php echo esc_html( $wppe_bridge_missing_lbl[ $wppe_bridge_mkey ] ?? $wppe_bridge_mkey ); ?></li>
				<?php endforeach; ?>
			</ul>
			<p style="margin:12px 0 0;">
				<em>
					<?php esc_html_e( 'Sperant rechaza con error 422 los leads que no traen estos campos. Tienes 3 opciones:', 'wppe-bridge' ); ?>
				</em>
			</p>
			<ul style="list-style:disc;margin-left:25px;margin-top:8px;">
				<li><strong><?php esc_html_e( 'Opcion A (Monoproyecto):', 'wppe-bridge' ); ?></strong> <?php esc_html_e( 'anda a "Defaults" abajo y selecciona los valores fijos.', 'wppe-bridge' ); ?></li>
				<li><strong><?php esc_html_e( 'Opcion B (Multiproyecto):', 'wppe-bridge' ); ?></strong> <?php esc_html_e( 'mapea un dropdown del form arriba en "Campos del form" como "Campo custom" → project_id.', 'wppe-bridge' ); ?></li>
				<li><strong><?php esc_html_e( 'Opcion C (Hibrido):', 'wppe-bridge' ); ?></strong> <?php esc_html_e( 'configura AMBOS: defaults + mapeo de field (gana el field si elige, sino el default).', 'wppe-bridge' ); ?></li>
			</ul>
		</div>
	<?php endif; ?>

	<?php if ( ! $catalogs_present ) : ?>
		<div class="notice notice-warning" role="status">
			<p>
				<?php esc_html_e( 'Aun no has sincronizado catalogos de Sperant. Hacelo primero desde Configuracion para poder seleccionar input_channel_id, source_id, etc.', 'wppe-bridge' ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . WPPE_Bridge_Admin_Menu::SLUG . '-config' ) ); ?>">
					<?php esc_html_e( 'Ir a Configuracion', 'wppe-bridge' ); ?>
				</a>
			</p>
		</div>
	<?php endif; ?>

	<?php if ( ! $wppe_bridge_has_forms ) : ?>
		<div class="notice notice-info" role="status">
			<p>
				<?php esc_html_e( 'No se detectaron forms de Fluent Forms ni Gravity Forms en este sitio. Detalle:', 'wppe-bridge' ); ?>
			</p>
			<ul style="list-style:disc;margin-left:25px">
				<?php
				$wppe_bridge_reason_labels = array(
					WPPE_Bridge_Form_Discovery::REASON_PLUGIN_INACTIVE => __( 'plugin no activo', 'wppe-bridge' ),
					WPPE_Bridge_Form_Discovery::REASON_TABLE_MISSING => __( 'plugin activo pero tabla DB no encontrada', 'wppe-bridge' ),
					WPPE_Bridge_Form_Discovery::REASON_API_MISSING => __( 'plugin activo pero API publica (GFAPI) no disponible', 'wppe-bridge' ),
					WPPE_Bridge_Form_Discovery::REASON_NO_FORMS => __( 'plugin activo pero sin forms creados', 'wppe-bridge' ),
					WPPE_Bridge_Form_Discovery::REASON_OK => __( 'OK', 'wppe-bridge' ),
				);
				$wppe_bridge_plugin_labels = array(
					'fluent'  => 'Fluent Forms',
					'gravity' => 'Gravity Forms',
				);
				foreach ( $discovery_reasons as $wppe_bridge_plugin_slug => $wppe_bridge_reason ) :
					$wppe_bridge_plugin_label = $wppe_bridge_plugin_labels[ $wppe_bridge_plugin_slug ] ?? $wppe_bridge_plugin_slug;
					$wppe_bridge_reason_label = $wppe_bridge_reason_labels[ $wppe_bridge_reason ] ?? $wppe_bridge_reason;
					?>
					<li>
						<strong><?php echo esc_html( $wppe_bridge_plugin_label ); ?>:</strong>
						<?php echo esc_html( $wppe_bridge_reason_label ); ?>
					</li>
				<?php endforeach; ?>
			</ul>
			<p>
				<?php esc_html_e( 'Crea un form en alguno de los plugins detectados y vuelve aqui.', 'wppe-bridge' ); ?>
			</p>
		</div>
		<p><em><?php esc_html_e( 'Si necesitas configurar mapping antes de instalar el plugin de forms, podes editar wp_options[\'wppe_bridge_field_mapping\'] manualmente con WP-CLI:', 'wppe-bridge' ); ?></em></p>
		<pre style="background:#f6f7f7;padding:10px;border-radius:4px;max-width:700px;overflow:auto"><code>wp option update --format=json wppe_bridge_field_mapping '{
	"fluent": {
	"5": {
		"fields": {"email_field": "email", "phone_field": "phone"},
		"defaults": {"input_channel_id": 1, "source_id": 10}
	}
	}
}'</code></pre>
		<?php return; ?>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Seleccionar form', 'wppe-bridge' ); ?></h2>
	<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" style="margin-bottom:20px">
		<input type="hidden" name="page" value="<?php echo esc_attr( WPPE_Bridge_Admin_Menu::SLUG . '-mapping' ); ?>"/>
		<select name="plugin" onchange="this.form.submit()">
			<?php
			$wppe_bridge_plugins = array(
				'fluent'  => __( 'Fluent Forms', 'wppe-bridge' ),
				'gravity' => __( 'Gravity Forms', 'wppe-bridge' ),
			);
			foreach ( $wppe_bridge_plugins as $wppe_bridge_pkey => $wppe_bridge_plabel ) :
				$wppe_bridge_pcount = isset( $discovered[ $wppe_bridge_pkey ] ) ? count( $discovered[ $wppe_bridge_pkey ] ) : 0;
				?>
				<option value="<?php echo esc_attr( $wppe_bridge_pkey ); ?>" <?php selected( $selected_plugin, $wppe_bridge_pkey ); ?>>
					<?php echo esc_html( $wppe_bridge_plabel ); ?> (<?php echo (int) $wppe_bridge_pcount; ?>)
				</option>
			<?php endforeach; ?>
		</select>

		<select name="form">
			<option value=""><?php esc_html_e( '— Selecciona un form —', 'wppe-bridge' ); ?></option>
			<?php foreach ( $discovered[ $selected_plugin ] as $wppe_bridge_form ) : ?>
				<option value="<?php echo esc_attr( $wppe_bridge_form['id'] ); ?>" <?php selected( $selected_form, (string) $wppe_bridge_form['id'] ); ?>>
					<?php echo esc_html( $wppe_bridge_form['title'] ); ?> (#<?php echo esc_html( $wppe_bridge_form['id'] ); ?>)
				</option>
			<?php endforeach; ?>
		</select>

		<button type="submit" class="button"><?php esc_html_e( 'Cargar', 'wppe-bridge' ); ?></button>
	</form>

	<?php if ( null === $selected_form_data ) : ?>
		<p><em><?php esc_html_e( 'Selecciona un form para configurar el mapeo.', 'wppe-bridge' ); ?></em></p>
		<?php return; ?>
	<?php endif; ?>

	<hr/>

	<h2>
		<?php
		printf(
			/* translators: %s = titulo del form. */
			esc_html__( 'Mapeo del form: %s', 'wppe-bridge' ),
			esc_html( $selected_form_data['title'] )
		);
		?>
	</h2>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="wppe-bridge-mapping-form">
		<input type="hidden" name="action" value="<?php echo esc_attr( WPPE_Bridge_Mapping_Page::ACTION_SAVE ); ?>"/>
		<input type="hidden" name="plugin" value="<?php echo esc_attr( $selected_plugin ); ?>"/>
		<input type="hidden" name="form" value="<?php echo esc_attr( (string) $selected_form_data['id'] ); ?>"/>
		<?php wp_nonce_field( WPPE_Bridge_Mapping_Page::NONCE_ACTION ); ?>

		<div style="background:#f0f6fc;border:1px solid #72aee6;border-radius:4px;padding:16px;margin-bottom:24px;max-width:900px;">
			<h3 style="margin-top:0;color:#1d3557;">📋 <?php esc_html_e( 'Empecemos por lo basico: Proyecto', 'wppe-bridge' ); ?></h3>
			<p style="margin:0 0 12px;">
				<?php esc_html_e( '¿Como funciona el proyecto en este form?', 'wppe-bridge' ); ?>
			</p>
			<ul style="margin:0;padding:0;list-style:none;">
				<li style="margin-bottom:10px;padding:8px;background:white;border-left:3px solid #06a77d;border-radius:2px;">
					<strong style="color:#06a77d;">🏢 <?php esc_html_e( 'Monoproyecto', 'wppe-bridge' ); ?></strong>
					<br/>
					<?php esc_html_e( 'Es siempre el mismo proyecto (ej. todos los leads van a Vanguardia).', 'wppe-bridge' ); ?>
					<br/>
					<em style="color:#646970;"><?php esc_html_e( 'Configuracion: Anda abajo a "Defaults" → selecciona "Proyecto" → elige Vanguardia. Listo.', 'wppe-bridge' ); ?></em>
				</li>
				<li style="margin-bottom:0;padding:8px;background:white;border-left:3px solid #f05a28;border-radius:2px;">
					<strong style="color:#f05a28;">🏢🏢 <?php esc_html_e( 'Multiproyecto', 'wppe-bridge' ); ?></strong>
					<br/>
					<?php esc_html_e( 'El visitante elige en un dropdown (ej. "¿Que proyecto te interesa?").', 'wppe-bridge' ); ?>
					<br/>
					<em style="color:#646970;"><?php esc_html_e( 'Configuracion: Mapea el dropdown aqui abajo en "Campos del form" como "Campo custom" → project_id. En "Defaults" dejalo vacio.', 'wppe-bridge' ); ?></em>
				</li>
			</ul>
		</div>

		<h3><?php esc_html_e( 'Campos del form', 'wppe-bridge' ); ?></h3>
		<p class="description">
			<?php
			printf(
				/* translators: %s = HTML del asterisco */
				esc_html__( 'Al menos un campo del form debe mapear a %s (nombre del cliente, obligatorio en Sperant). Tambien recomendamos mapear "email" para nurturing.', 'wppe-bridge' ),
				'<code>fname</code> <span style="color:#dc3232">*</span>'
			);
			?>
		</p>
		<details class="wppe-bridge-mapping-hint" style="max-width:900px;margin:0 0 12px;padding:8px 12px;background:#f6f7f7;border-left:3px solid #2271b1;">
			<summary style="cursor:pointer;font-weight:600;">
				<?php esc_html_e( '¿Cómo mapeo el campo Proyecto? (3 casos)', 'wppe-bridge' ); ?>
			</summary>
			<ul style="margin:8px 0 4px 20px;list-style:disc;">
				<li>
					<strong><?php esc_html_e( 'Landing de proyecto específico', 'wppe-bridge' ); ?></strong> —
					<?php esc_html_e( 'el form no tiene dropdown de proyecto. Dejá el ID fijo abajo en la sección "Defaults" → Proyecto.', 'wppe-bridge' ); ?>
				</li>
				<li>
					<strong><?php esc_html_e( 'Form con dropdown de proyecto', 'wppe-bridge' ); ?></strong> —
					<?php esc_html_e( 'el visitante elige. Mapeá el campo del form como "Campo custom" con valor', 'wppe-bridge' ); ?>
					<code>project_id</code>
					<?php esc_html_e( 'y dejá el default vacío.', 'wppe-bridge' ); ?>
					<strong style="color:#d63638;"><?php esc_html_e( 'Importante:', 'wppe-bridge' ); ?></strong>
					<?php esc_html_e( 'el value de cada option del dropdown tiene que ser el ID numérico de Sperant (ej. <option value="7">Vanguardia</option>), no el nombre del proyecto.', 'wppe-bridge' ); ?>
				</li>
				<li>
					<strong><?php esc_html_e( 'Híbrido', 'wppe-bridge' ); ?></strong> —
					<?php esc_html_e( 'field + default como fallback. Si el visitante eligió → gana el field; si no → cae en el default.', 'wppe-bridge' ); ?>
				</li>
			</ul>
			<p style="margin:6px 0 0;color:#646970;">
				<?php
				printf(
					/* translators: %s = "OPERATIONS.md §1.1" */
					esc_html__( 'Mismo patrón aplica a Canal, Fuente, Tipo de interés. Detalle completo: %s.', 'wppe-bridge' ),
					'<code>OPERATIONS.md §1.1</code>'
				);
				?>
			</p>
		</details>
		<?php if ( empty( $selected_form_data['fields'] ) ) : ?>
			<p><em><?php esc_html_e( 'El form no tiene campos detectables.', 'wppe-bridge' ); ?></em></p>
		<?php else : ?>
			<table class="widefat striped" style="max-width:900px">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Campo del form', 'wppe-bridge' ); ?></th>
						<th><?php esc_html_e( 'Mapear a (campo Sperant)', 'wppe-bridge' ); ?></th>
						<th><?php esc_html_e( 'Custom (si "campo custom")', 'wppe-bridge' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach ( $selected_form_data['fields'] as $wppe_bridge_field ) :
						$wppe_bridge_fname     = $wppe_bridge_field['name'];
						$wppe_bridge_flabel    = $wppe_bridge_field['label'];
						$wppe_bridge_current   = isset( $existing_mapping['fields'][ $wppe_bridge_fname ] ) ? (string) $existing_mapping['fields'][ $wppe_bridge_fname ] : '';
						$wppe_bridge_is_custom = '' !== $wppe_bridge_current && ! in_array( $wppe_bridge_current, WPPE_Bridge_Mapping_Page::PAYLOAD_KEYS, true );
						?>
						<tr>
							<td>
								<strong><?php echo esc_html( $wppe_bridge_flabel ); ?></strong><br/>
								<code><?php echo esc_html( $wppe_bridge_fname ); ?></code>
							</td>
							<td>
								<select name="field_map[<?php echo esc_attr( $wppe_bridge_fname ); ?>]" class="wppe-bridge-field-map">
									<option value=""><?php esc_html_e( '— No mapear —', 'wppe-bridge' ); ?></option>
									<?php foreach ( WPPE_Bridge_Mapping_Page::PAYLOAD_KEYS as $wppe_bridge_pkey ) : ?>
										<option value="<?php echo esc_attr( $wppe_bridge_pkey ); ?>" <?php selected( $wppe_bridge_current, $wppe_bridge_pkey ); ?>>
											<?php echo esc_html( $wppe_bridge_pkey ); ?>
										</option>
									<?php endforeach; ?>
									<option value="custom" <?php selected( $wppe_bridge_is_custom, true ); ?>>
										<?php esc_html_e( '— Campo custom —', 'wppe-bridge' ); ?>
									</option>
								</select>
							</td>
							<td>
								<input
									type="text"
									name="custom_payload_key[<?php echo esc_attr( $wppe_bridge_fname ); ?>]"
									value="<?php echo $wppe_bridge_is_custom ? esc_attr( $wppe_bridge_current ) : ''; ?>"
									placeholder="ej: secondary_phone"
									class="regular-text"
								/>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<h3><?php esc_html_e( 'Defaults', 'wppe-bridge' ); ?></h3>
		<p class="description">
			<?php
			printf(
				/* translators: 1-4 = HTML de los campos obligatorios */
				esc_html__( 'Estos valores se agregan al payload de cada lead. Obligatorios: %1$s, %2$s, %3$s y %4$s. Mono Media exige los cuatro para asegurar reporting de canal, fuente, interes y proyecto en Sperant.', 'wppe-bridge' ),
				'<code>input_channel_id</code> <span style="color:#dc3232">*</span>',
				'<code>source_id</code> <span style="color:#dc3232">*</span>',
				'<code>interest_type_id</code> <span style="color:#dc3232">*</span>',
				'<code>project_id</code> <span style="color:#dc3232">*</span>'
			);
			?>
		</p>
		<table class="form-table" role="presentation">
			<tbody>
				<?php
				$wppe_bridge_default_labels    = array(
					'input_channel_id' => __( 'Canal de entrada', 'wppe-bridge' ),
					'source_id'        => __( 'Fuente', 'wppe-bridge' ),
					'interest_type_id' => __( 'Tipo de interes', 'wppe-bridge' ),
					'project_id'       => __( 'Proyecto', 'wppe-bridge' ),
				);
				$wppe_bridge_required_defaults = WPPE_Bridge_Mapping_Page::REQUIRED_DEFAULTS;
				foreach ( WPPE_Bridge_Mapping_Page::DEFAULT_KEYS as $wppe_bridge_dkey => $wppe_bridge_catkey ) :
					$wppe_bridge_options         = isset( $catalogs[ $wppe_bridge_catkey ] ) && is_array( $catalogs[ $wppe_bridge_catkey ] ) ? $catalogs[ $wppe_bridge_catkey ] : array();
					$wppe_bridge_current_default = isset( $existing_mapping['defaults'][ $wppe_bridge_dkey ] ) ? (int) $existing_mapping['defaults'][ $wppe_bridge_dkey ] : 0;
					$wppe_bridge_catalog_error   = isset( $catalogs_errors[ $wppe_bridge_catkey ] ) ? (string) $catalogs_errors[ $wppe_bridge_catkey ] : '';
					$wppe_bridge_in_catalog      = false;
					if ( $wppe_bridge_current_default > 0 ) {
						foreach ( $wppe_bridge_options as $wppe_bridge_opt_check ) {
							if ( is_array( $wppe_bridge_opt_check ) && isset( $wppe_bridge_opt_check['id'] ) && (int) $wppe_bridge_opt_check['id'] === $wppe_bridge_current_default ) {
								$wppe_bridge_in_catalog = true;
								break;
							}
						}
					}
					// Si el default actual NO esta en el catalogo (vino
					// como ingreso manual, o el catalogo cambio), lo
					// pre-cargamos en el input manual.
					$wppe_bridge_manual_value = ( $wppe_bridge_current_default > 0 && ! $wppe_bridge_in_catalog ) ? $wppe_bridge_current_default : 0;
					?>
					<tr>
						<th scope="row">
							<label for="default-<?php echo esc_attr( $wppe_bridge_dkey ); ?>">
								<?php echo esc_html( $wppe_bridge_default_labels[ $wppe_bridge_dkey ] ?? $wppe_bridge_dkey ); ?>
								<?php if ( in_array( $wppe_bridge_dkey, $wppe_bridge_required_defaults, true ) ) : ?>
									<span style="color:#dc3232" title="<?php esc_attr_e( 'Obligatorio', 'wppe-bridge' ); ?>">*</span>
								<?php endif; ?>
							</label>
						</th>
						<td>
							<select id="default-<?php echo esc_attr( $wppe_bridge_dkey ); ?>" name="defaults[<?php echo esc_attr( $wppe_bridge_dkey ); ?>]">
								<option value="0"><?php esc_html_e( '— Sin default —', 'wppe-bridge' ); ?></option>
								<?php
								foreach ( $wppe_bridge_options as $wppe_bridge_opt ) :
									if ( ! is_array( $wppe_bridge_opt ) || ! isset( $wppe_bridge_opt['id'] ) ) {
										continue;
									}
									$wppe_bridge_oid   = (int) $wppe_bridge_opt['id'];
									$wppe_bridge_oname = isset( $wppe_bridge_opt['name'] ) ? (string) $wppe_bridge_opt['name'] : (string) $wppe_bridge_oid;
									?>
									<option value="<?php echo esc_attr( (string) $wppe_bridge_oid ); ?>" <?php selected( $wppe_bridge_in_catalog ? $wppe_bridge_current_default : 0, $wppe_bridge_oid ); ?>>
										<?php echo esc_html( $wppe_bridge_oname ); ?> (#<?php echo (int) $wppe_bridge_oid; ?>)
									</option>
								<?php endforeach; ?>
							</select>
							<span style="margin:0 8px;color:#888;"><?php esc_html_e( 'o ID manual:', 'wppe-bridge' ); ?></span>
							<input
								type="number"
								name="defaults_manual[<?php echo esc_attr( $wppe_bridge_dkey ); ?>]"
								value="<?php echo $wppe_bridge_manual_value > 0 ? esc_attr( (string) $wppe_bridge_manual_value ) : ''; ?>"
								min="1"
								class="small-text"
								placeholder="<?php esc_attr_e( 'ej: 46', 'wppe-bridge' ); ?>"
							/>
							<?php if ( '' !== $wppe_bridge_catalog_error ) : ?>
								<p class="description" style="color:#dba617">
									⚠
									<?php
									printf(
										/* translators: 1: catalog key, 2: error code */
										esc_html__( 'Catalogo "%1$s" no disponible (%2$s). Ingresa el ID manualmente desde tu panel Sperant.', 'wppe-bridge' ),
										esc_html( $wppe_bridge_catkey ),
										esc_html( $wppe_bridge_catalog_error )
									);
									?>
								</p>
							<?php elseif ( empty( $wppe_bridge_options ) ) : ?>
								<p class="description">
									<?php esc_html_e( 'Catalogo vacio. Podes ingresar el ID manualmente si conoces alguno valido.', 'wppe-bridge' ); ?>
								</p>
							<?php else : ?>
								<p class="description">
									<?php esc_html_e( 'Si llenas el ID manual, sobrescribe la seleccion del dropdown.', 'wppe-bridge' ); ?>
								</p>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<?php submit_button( __( 'Guardar mapeo', 'wppe-bridge' ) ); ?>
	</form>

	<hr style="margin:3em 0"/>

	<!-- ============================================================ -->
	<!-- v2.5.1: Mapeo global utm_source -> Canal Sperant              -->
	<!-- ============================================================ -->
	<h2><?php esc_html_e( 'Mapeo de UTM Source → Canal Sperant', 'wppe-bridge' ); ?></h2>
	<p class="description" style="max-width:800px">
		<?php
		esc_html_e(
			'Configura aqui que canal Sperant (input_channel_id) se asigna a cada lead segun su `utm_source`. Aplica a TODOS los forms del sitio (es configuracion global, no por-form). Sin entradas en esta tabla, los leads van con el default del Mapeo por-form de mas arriba (tipicamente "Pagina Web"). Con entradas, el lead que trae `utm_source=google` va al canal "Google Ads", el que trae `utm_source=facebook` va a "Facebook Ads", etc.',
			'wppe-bridge'
		);
		?>
	</p>

	<?php
	$wppe_bridge_utm_flash = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( 'utm_channel_saved' === $wppe_bridge_utm_flash ) :
		?>
		<div class="notice notice-success is-dismissible" role="status" style="max-width:800px"><p><?php esc_html_e( 'Mapeo utm_source → canal guardado.', 'wppe-bridge' ); ?></p></div>
	<?php endif; ?>

	<?php if ( empty( $input_channels_for_dropdown ) ) : ?>
		<div class="notice notice-warning inline" role="status" style="max-width:800px;margin-top:1em">
			<p>
				<?php esc_html_e( 'Sin catalogo de input_channels sincronizado. Sincroniza los catalogos Sperant en Configuracion primero — sin eso, el dropdown de canales queda vacio.', 'wppe-bridge' ); ?>
			</p>
		</div>
	<?php else : ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="wppe-bridge-utm-channel-form">
		<input type="hidden" name="action" value="<?php echo esc_attr( WPPE_Bridge_Mapping_Page::ACTION_SAVE_UTM_CHANNEL ); ?>"/>
		<?php wp_nonce_field( WPPE_Bridge_Mapping_Page::NONCE_UTM_CHANNEL ); ?>

		<table class="widefat striped" style="max-width:800px;margin-top:1em" id="wppe-bridge-utm-channel-table">
			<thead>
				<tr>
					<th style="width:40%"><?php esc_html_e( 'utm_source del visitante', 'wppe-bridge' ); ?></th>
					<th style="width:40%"><?php esc_html_e( 'Canal Sperant (input_channel_id)', 'wppe-bridge' ); ?></th>
					<th style="width:20%"></th>
				</tr>
			</thead>
			<tbody>
				<?php
				$wppe_bridge_rows_to_render = ! empty( $utm_channel_map ) ? $utm_channel_map : array(
					// Una fila vacia inicial para mostrar el form aunque no haya nada configurado.
					array(
						'utm_source'       => '',
						'input_channel_id' => 0,
					),
				);
				foreach ( $wppe_bridge_rows_to_render as $wppe_bridge_idx => $wppe_bridge_row ) :
					$wppe_bridge_row_source = isset( $wppe_bridge_row['utm_source'] ) ? (string) $wppe_bridge_row['utm_source'] : '';
					$wppe_bridge_row_id     = isset( $wppe_bridge_row['input_channel_id'] ) ? (int) $wppe_bridge_row['input_channel_id'] : 0;
					?>
					<tr class="wppe-bridge-utm-channel-row">
						<td>
							<input
								type="text"
								name="utm_channel_map[<?php echo esc_attr( (string) $wppe_bridge_idx ); ?>][utm_source]"
								value="<?php echo esc_attr( $wppe_bridge_row_source ); ?>"
								placeholder="google, facebook, instagram, tiktok, ..."
								class="regular-text"
							/>
						</td>
						<td>
							<select name="utm_channel_map[<?php echo esc_attr( (string) $wppe_bridge_idx ); ?>][input_channel_id]">
								<option value="0"><?php esc_html_e( '(seleccionar canal)', 'wppe-bridge' ); ?></option>
								<?php foreach ( $input_channels_for_dropdown as $wppe_bridge_channel ) : ?>
									<option
										value="<?php echo esc_attr( (string) ( $wppe_bridge_channel['id'] ?? '' ) ); ?>"
										<?php selected( $wppe_bridge_row_id, (int) ( $wppe_bridge_channel['id'] ?? 0 ) ); ?>
									>
										<?php echo esc_html( (string) ( $wppe_bridge_channel['name'] ?? '' ) ); ?>
										(<?php echo esc_html( (string) ( $wppe_bridge_channel['id'] ?? '' ) ); ?>)
									</option>
								<?php endforeach; ?>
							</select>
						</td>
						<td>
							<button type="button" class="button-link wppe-bridge-remove-utm-row" style="color:#dc3232">
								<?php esc_html_e( 'Eliminar', 'wppe-bridge' ); ?>
							</button>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<p style="margin-top:0.5em">
			<button type="button" class="button" id="wppe-bridge-add-utm-row">
				+ <?php esc_html_e( 'Agregar regla', 'wppe-bridge' ); ?>
			</button>
		</p>

		<p class="description" style="max-width:800px;color:#666;margin-top:1em">
			<strong><?php esc_html_e( 'Notas:', 'wppe-bridge' ); ?></strong>
			<?php
			esc_html_e(
				'(1) Match case-insensitive con trim — "google" / "Google" / "  GOOGLE " matchean a la misma regla. (2) Si el visitante no trae `utm_source` o no matchea ninguna regla, el lead conserva el `input_channel_id` default del Mapeo por-form de arriba. (3) Filas con utm_source vacio o canal sin elegir se descartan al guardar. (4) Si hay duplicados de utm_source, gana la ultima entrada.',
				'wppe-bridge'
			);
			?>
		</p>

		<?php submit_button( __( 'Guardar mapeo UTM → Canal', 'wppe-bridge' ) ); ?>
	</form>

	<script>
	(function () {
		// Manejo de filas dinamicas: agregar / eliminar. No requiere
		// wp_localize_script — el form se serializa con FormData estandar
		// y el handler PHP itera el array `utm_channel_map[idx]`.
		var table  = document.getElementById( 'wppe-bridge-utm-channel-table' );
		var addBtn = document.getElementById( 'wppe-bridge-add-utm-row' );
		if ( ! table || ! addBtn ) {
			return;
		}

		function renumber() {
			// Renombra los inputs para que `idx` sea consecutivo —
			// previene huecos cuando el usuario elimina una fila intermedia.
			var rows = table.querySelectorAll( '.wppe-bridge-utm-channel-row' );
			for ( var i = 0; i < rows.length; i++ ) {
				var inputs = rows[i].querySelectorAll( 'input, select' );
				for ( var j = 0; j < inputs.length; j++ ) {
					var name = inputs[j].getAttribute( 'name' );
					if ( ! name ) { continue; }
					inputs[j].setAttribute(
						'name',
						name.replace( /utm_channel_map\[\d+\]/, 'utm_channel_map[' + i + ']' )
					);
				}
			}
		}

		addBtn.addEventListener( 'click', function () {
			var firstRow = table.querySelector( '.wppe-bridge-utm-channel-row' );
			if ( ! firstRow ) { return; }
			var clone = firstRow.cloneNode( true );
			// Limpiar valores en el clon.
			var src = clone.querySelector( 'input[type="text"]' );
			if ( src ) { src.value = ''; }
			var sel = clone.querySelector( 'select' );
			if ( sel ) { sel.value = '0'; }
			firstRow.parentNode.appendChild( clone );
			renumber();
		} );

		table.addEventListener( 'click', function ( e ) {
			if ( ! e.target.classList.contains( 'wppe-bridge-remove-utm-row' ) ) {
				return;
			}
			var rows = table.querySelectorAll( '.wppe-bridge-utm-channel-row' );
			if ( rows.length <= 1 ) {
				// Mantener al menos 1 fila visible para que el form
				// pueda renderizar.
				var row = e.target.closest( '.wppe-bridge-utm-channel-row' );
				if ( row ) {
					row.querySelector( 'input[type="text"]' ).value = '';
					row.querySelector( 'select' ).value = '0';
				}
				return;
			}
			var row = e.target.closest( '.wppe-bridge-utm-channel-row' );
			if ( row ) {
				row.parentNode.removeChild( row );
				renumber();
			}
		} );
	})();
	</script>

	<?php endif; ?>
</div>
