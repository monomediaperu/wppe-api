<?php
/**
 * Vista de la pagina admin "Configuracion HubSpot".
 *
 * Variables disponibles (provistas por WPPE_Bridge_Hubspot_Settings_Page::render):
 *
 * @var bool                $has_token       True si hay access token guardado.
 * @var string              $lifecyclestage  Lifecyclestage default (vacio si no configurado).
 * @var string              $owner_id        Owner ID default (vacio si no configurado).
 * @var array<int,string>   $lifecycle_opts  Whitelist de lifecyclestages.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Configuracion HubSpot', 'wppe-bridge' ); ?></h1>

	<div class="notice notice-info inline" role="status" style="margin-top:1em">
		<p>
			<?php
			echo wp_kses(
				sprintf(
					/* translators: %s: URL a Configuracion general */
					__( 'Esta sub-pagina configura solo los campos especificos de HubSpot. Para cambiar de CRM, dedup TTL, country code o la zona de peligro, ir a <a href="%s">Configuracion</a>.', 'wppe-bridge' ),
					esc_url( admin_url( 'admin.php?page=wppe-bridge-config' ) )
				),
				array( 'a' => array( 'href' => true ) )
			);
			?>
		</p>
	</div>

	<form method="post" action="options.php">
		<?php settings_fields( WPPE_Bridge_Hubspot_Settings_Page::OPTION_GROUP ); ?>

		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row">
						<label for="wppe_bridge_hubspot_access_token">
							<?php esc_html_e( 'Private App access token', 'wppe-bridge' ); ?>
							<span style="color:#dc3232" title="<?php esc_attr_e( 'Obligatorio', 'wppe-bridge' ); ?>">*</span>
						</label>
					</th>
					<td>
						<input
							type="password"
							name="wppe_bridge_hubspot_access_token"
							id="wppe_bridge_hubspot_access_token"
							class="regular-text"
							autocomplete="new-password"
							placeholder="<?php echo $has_token ? esc_attr__( '(token configurado — dejar vacio para conservar)', 'wppe-bridge' ) : esc_attr__( '(sin configurar) — obligatorio', 'wppe-bridge' ); ?>"
							<?php echo $has_token ? '' : 'required'; ?>
						/>
						<p class="description">
							<?php
							if ( $has_token ) {
								echo '<span class="dashicons dashicons-yes-alt" aria-hidden="true" style="color:#46b450"></span> ';
								esc_html_e( 'Token configurado. Dejar el campo vacio para conservar el actual.', 'wppe-bridge' );
							} else {
								esc_html_e( 'Generalo en HubSpot: Settings (engranaje) → Integrations → Private Apps → Create a private app. Scopes minimos: crm.objects.contacts.read, crm.objects.contacts.write, crm.schemas.contacts.read. El token solo se muestra una vez al crearlo — guardalo en 1Password antes de pegarlo aqui.', 'wppe-bridge' );
							}
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe_bridge_hubspot_default_lifecyclestage">
							<?php esc_html_e( 'Lifecyclestage default', 'wppe-bridge' ); ?>
						</label>
					</th>
					<td>
						<select
							name="wppe_bridge_hubspot_default_lifecyclestage"
							id="wppe_bridge_hubspot_default_lifecyclestage"
						>
							<option value=""<?php selected( '' === $lifecyclestage ); ?>>
								<?php esc_html_e( '— No inyectar (usar default del portal HubSpot) —', 'wppe-bridge' ); ?>
							</option>
							<?php foreach ( $lifecycle_opts as $wppe_bridge_opt ) : ?>
								<option value="<?php echo esc_attr( $wppe_bridge_opt ); ?>"<?php selected( $lifecyclestage, $wppe_bridge_opt ); ?>>
									<?php echo esc_html( $wppe_bridge_opt ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description">
							<?php esc_html_e( 'Cuando un visitante llena un form, su contact en HubSpot se crea con este lifecyclestage. "lead" es lo apropiado para la mayoria de los casos. Si dejas "no inyectar", HubSpot aplica el default que tiene configurado en el portal.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe_bridge_hubspot_default_owner_id">
							<?php esc_html_e( 'Owner ID default (opcional)', 'wppe-bridge' ); ?>
						</label>
					</th>
					<td>
						<input
							type="text"
							name="wppe_bridge_hubspot_default_owner_id"
							id="wppe_bridge_hubspot_default_owner_id"
							class="regular-text"
							value="<?php echo esc_attr( $owner_id ); ?>"
							placeholder="12345"
							pattern="[0-9]+"
						/>
						<p class="description">
							<?php esc_html_e( 'ID numerico del usuario al que se asignan todos los leads del web. Lo encuentras en HubSpot: Settings → Users & Teams → click en el usuario → el ID aparece en la URL como ?user_id=... Si lo dejas vacio, HubSpot aplica las reglas de assignment del portal (round-robin, territorio, etc).', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
			</tbody>
		</table>

		<?php submit_button( __( 'Guardar configuracion HubSpot', 'wppe-bridge' ) ); ?>
	</form>
</div>
