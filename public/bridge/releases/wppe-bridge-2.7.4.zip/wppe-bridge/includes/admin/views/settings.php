<?php
/**
 * Vista de la pagina admin "Configuracion".
 *
 * Variables disponibles (provistas por WPPE_Bridge_Settings_Page::render):
 *
 * @var bool                                                                         $has_token                       True si hay token guardado.
 * @var string                                                                       $base_url                        URL base de la API.
 * @var int                                                                          $dedup_ttl                       TTL del dedup en segundos.
 * @var string                                                                       $country_code                    Codigo de pais default.
 * @var array                                                                        $catalogs                        Catalogos sincronizados.
 * @var bool                                                                         $catalogs_present                True si hay catalogos.
 * @var string                                                                       $active_destination              Slug del destino activo (vacio si fresh install).
 * @var array<string,string>                                                         $available_destinations          Map slug => label.
 * @var string                                                                       $panel_subdomain                 Subdomain del panel Sperant.
 * @var bool                                                                         $delete_data_uninstall           True si esta activado el toggle de zona de peligro.
 * @var array<string,string>                                                         $api_environments                Map URL → label de entornos API.
 * @var string                                                                       $active_destination_label        Label del CRM activo.
 * @var string                                                                       $active_destination_config_url   URL sub-pagina del CRM activo (vacio si Sperant).
 * @var array<string,array{label:string,config_url:string}>                          $destination_meta                Map slug => {label, config_url}.
 * @var array<string,array{description:string,dashicon:string,brand_color:string}>   $destination_card_data           Visual meta per CRM para el selector.
 * @var bool                                                                         $wppe_bridge_destination_is_configured  True si el user ya eligio un destino valido.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Configuracion', 'wppe-bridge' ); ?></h1>

	<form method="post" action="options.php">
		<?php settings_fields( WPPE_Bridge_Settings_Page::OPTION_GROUP ); ?>

		<!-- v2.5.6: selector visual de CRM (cards en grid), reemplaza el
			dropdown legacy. Inspirado en FluentSMTP. El input que persiste
			es un <input type="hidden"> que JS sincroniza al hacer click
			en una card. Mantiene compatibilidad con WP Settings API
			(mismo `name` que el select anterior). -->
		<h2 style="margin-top:0;font-size:15px;color:#333"><?php esc_html_e( 'CRM destino', 'wppe-bridge' ); ?></h2>
		<p style="margin-top:0;color:#666;font-size:13px;max-width:760px">
			<?php esc_html_e( 'CRM al que se envian los leads. La arquitectura del plugin es multi-CRM. Si necesitas otro CRM, escribinos a soporte@mono.media.', 'wppe-bridge' ); ?>
		</p>
		<?php if ( ! $wppe_bridge_destination_is_configured ) : ?>
			<!-- v2.5.6: banner mostrado solo en fresh install (sin destino
				elegido todavia). Se oculta via JS al elegir una card. -->
			<div data-wppe-bridge-empty-state class="notice notice-info inline" role="status" style="margin:12px 0;max-width:1100px">
				<p style="margin:8px 0">
					<strong><?php esc_html_e( 'Selecciona el CRM destino para empezar.', 'wppe-bridge' ); ?></strong>
					<span style="color:#666">
						<?php esc_html_e( 'Hasta que elijas un CRM, los leads que lleguen quedan en cola sin enviarse (no se pierden). En cuanto configures uno, la cola arranca a procesarse automaticamente.', 'wppe-bridge' ); ?>
					</span>
				</p>
			</div>
		<?php endif; ?>
		<input
			type="hidden"
			name="<?php echo esc_attr( WPPE_Bridge_Destination_Factory::OPTION_ACTIVE ); ?>"
			id="<?php echo esc_attr( WPPE_Bridge_Destination_Factory::OPTION_ACTIVE ); ?>"
			value="<?php echo esc_attr( $active_destination ); ?>"
		/>
		<div class="wppe-bridge-crm-selector" role="radiogroup" aria-label="<?php esc_attr_e( 'CRM destino', 'wppe-bridge' ); ?>">
			<?php foreach ( $available_destinations as $wppe_bridge_slug => $wppe_bridge_label ) : ?>
				<?php
				$wppe_bridge_is_coming_soon = 0 === strpos( (string) $wppe_bridge_slug, '_coming_' );
				$wppe_bridge_meta           = isset( $destination_meta[ $wppe_bridge_slug ] ) ? $destination_meta[ $wppe_bridge_slug ] : array(
					'label'      => (string) $wppe_bridge_label,
					'config_url' => '',
				);
				$wppe_bridge_card           = isset( $destination_card_data[ $wppe_bridge_slug ] ) ? $destination_card_data[ $wppe_bridge_slug ] : array(
					'description' => '',
					'dashicon'    => 'dashicons-admin-generic',
					'brand_color' => '#666666',
				);
				$wppe_bridge_is_selected    = ( $active_destination === $wppe_bridge_slug );
				$wppe_bridge_card_classes   = array( 'wppe-bridge-crm-card' );
				if ( $wppe_bridge_is_selected ) {
					$wppe_bridge_card_classes[] = 'is-selected';
				}
				if ( $wppe_bridge_is_coming_soon ) {
					$wppe_bridge_card_classes[] = 'is-coming-soon';
				}
				?>
				<div
					class="<?php echo esc_attr( implode( ' ', $wppe_bridge_card_classes ) ); ?>"
					data-slug="<?php echo esc_attr( $wppe_bridge_slug ); ?>"
					data-config-label="<?php echo esc_attr( $wppe_bridge_meta['label'] ); ?>"
					data-config-url="<?php echo esc_attr( $wppe_bridge_meta['config_url'] ); ?>"
					data-coming-soon="<?php echo $wppe_bridge_is_coming_soon ? '1' : '0'; ?>"
					role="radio"
					aria-checked="<?php echo $wppe_bridge_is_selected ? 'true' : 'false'; ?>"
					aria-disabled="<?php echo $wppe_bridge_is_coming_soon ? 'true' : 'false'; ?>"
					tabindex="<?php echo $wppe_bridge_is_coming_soon ? '-1' : '0'; ?>"
				>
					<div class="wppe-bridge-crm-card-icon" style="background:<?php echo esc_attr( $wppe_bridge_card['brand_color'] ); ?>">
						<span class="dashicons <?php echo esc_attr( $wppe_bridge_card['dashicon'] ); ?>" aria-hidden="true"></span>
					</div>
					<div class="wppe-bridge-crm-card-body">
						<div class="wppe-bridge-crm-card-label"><?php echo esc_html( $wppe_bridge_label ); ?></div>
						<?php if ( '' !== $wppe_bridge_card['description'] ) : ?>
							<div class="wppe-bridge-crm-card-desc"><?php echo esc_html( $wppe_bridge_card['description'] ); ?></div>
						<?php endif; ?>
					</div>
					<div class="wppe-bridge-crm-card-check" aria-hidden="true">
						<span class="dashicons dashicons-yes-alt" aria-hidden="true"></span>
					</div>
				</div>
			<?php endforeach; ?>
		</div>

		<table class="form-table" role="presentation">
			<tbody>
				<?php
				// v2.5.5: rendering condicional reemplazado por "rendering
				// siempre + display:none + JS toggle al cambiar el dropdown".
				// v2.5.6: tercer estado — fresh install sin destino elegido.
				// En ese caso ocultamos AMBOS bloques (sperant y non-sperant)
				// y mostramos solo el banner "Selecciona un CRM". El user
				// elige una card y JS aplica el toggle apropiado.
				$wppe_bridge_is_sperant_active   = ( 'sperant' === $active_destination );
				$wppe_bridge_show_sperant_fields = $wppe_bridge_destination_is_configured && $wppe_bridge_is_sperant_active;
				$wppe_bridge_show_nonsperant_msg = $wppe_bridge_destination_is_configured && ! $wppe_bridge_is_sperant_active;
				?>
				<tr data-sperant-block="1" <?php echo $wppe_bridge_show_sperant_fields ? '' : 'style="display:none"'; ?>>
					<th scope="row">
						<label for="wppe_bridge_api_token">
							<?php esc_html_e( 'Token Sperant', 'wppe-bridge' ); ?>
							<span style="color:#dc3232" title="<?php esc_attr_e( 'Obligatorio', 'wppe-bridge' ); ?>">*</span>
						</label>
					</th>
					<td>
						<input
							type="password"
							<?php echo $wppe_bridge_is_sperant_active ? 'name="wppe_bridge_api_token"' : ''; ?>
							data-original-name="wppe_bridge_api_token"
							id="wppe_bridge_api_token"
							class="regular-text"
							autocomplete="new-password"
							placeholder="<?php echo $has_token ? esc_attr__( '(token configurado — dejar vacio para conservar)', 'wppe-bridge' ) : esc_attr__( '(sin configurar) — obligatorio', 'wppe-bridge' ); ?>"
							<?php echo ( $wppe_bridge_is_sperant_active && ! $has_token ) ? 'required' : ''; ?>
							data-original-required="<?php echo $has_token ? '0' : '1'; ?>"
						/>
						<p class="description">
							<?php
							if ( $has_token ) {
								echo '<span class="dashicons dashicons-yes-alt" aria-hidden="true" style="color:#46b450"></span> ';
								esc_html_e( 'Token configurado. Dejar el campo vacio para conservar el actual.', 'wppe-bridge' );
							} else {
								echo '<span class="dashicons dashicons-warning" aria-hidden="true" style="color:#dc3232"></span> ';
								esc_html_e( 'No hay token configurado. La integracion no funcionara hasta que ingreses uno.', 'wppe-bridge' );
							}
							?>
						</p>
					</td>
				</tr>
				<tr data-sperant-block="1" <?php echo $wppe_bridge_show_sperant_fields ? '' : 'style="display:none"'; ?>>
					<th scope="row">
						<label for="wppe_bridge_api_base_url"><?php esc_html_e( 'Entorno API Sperant', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<select
							<?php echo $wppe_bridge_is_sperant_active ? 'name="wppe_bridge_api_base_url"' : ''; ?>
							data-original-name="wppe_bridge_api_base_url"
							id="wppe_bridge_api_base_url"
						>
							<?php foreach ( $api_environments as $wppe_bridge_env_url => $wppe_bridge_env_label ) : ?>
								<option value="<?php echo esc_attr( $wppe_bridge_env_url ); ?>" <?php selected( $base_url, $wppe_bridge_env_url ); ?>>
									<?php echo esc_html( $wppe_bridge_env_label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description">
							<?php esc_html_e( 'Selecciona el entorno donde corre tu cuenta Sperant. Para desarrollo local con mock server, los devs pueden override via el filter `wppe_bridge_api_base_url`.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
				<!-- v2.5.5: aviso "non-sperant" siempre renderizado, oculto
					cuando active=sperant. JS rellena el label+href al
					cambiar el dropdown (via data-config-label/url en cada
					<option>). -->
				<tr data-non-sperant-block="1" <?php echo $wppe_bridge_show_nonsperant_msg ? '' : 'style="display:none"'; ?>>
					<td colspan="2" style="padding:0">
						<div class="notice notice-info inline" role="status" style="margin:0">
							<p data-wppe-noncrm-msg>
								<?php
								$wppe_bridge_label   = '' !== $active_destination_label ? $active_destination_label : ucfirst( (string) $active_destination );
								$wppe_bridge_msg_url = $active_destination_config_url;
								if ( '' !== $wppe_bridge_msg_url ) {
									echo wp_kses(
										sprintf(
											/* translators: 1: label del CRM activo (ej. "Odoo"). 2: URL a la sub-pagina de configuracion. 3: label del CRM activo (repetido para el texto del link). */
											__( 'Los campos especificos de <strong>%1$s</strong> (credenciales, URL, etc.) se configuran en su sub-pagina dedicada: <a href="%2$s">Configuracion %3$s</a>. En esta pantalla solo se administran ajustes globales (TTL deduplicacion, codigo de pais).', 'wppe-bridge' ),
											esc_html( $wppe_bridge_label ),
											esc_url( $wppe_bridge_msg_url ),
											esc_html( $wppe_bridge_label )
										),
										array(
											'a'      => array( 'href' => true ),
											'strong' => array(),
										)
									);
								} else {
									echo wp_kses(
										sprintf(
											/* translators: %s: label del CRM activo. */
											__( 'Los campos especificos de <strong>%s</strong> se configuran en su sub-pagina dedicada (ver menu lateral). En esta pantalla solo se administran ajustes globales.', 'wppe-bridge' ),
											esc_html( $wppe_bridge_label )
										),
										array( 'strong' => array() )
									);
								}
								?>
							</p>
						</div>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe_bridge_dedup_ttl_seconds"><?php esc_html_e( 'TTL deduplicacion', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input
							type="number"
							name="wppe_bridge_dedup_ttl_seconds"
							id="wppe_bridge_dedup_ttl_seconds"
							min="1"
							value="<?php echo esc_attr( (string) $dedup_ttl ); ?>"
						/>
						<span><?php esc_html_e( 'segundos', 'wppe-bridge' ); ?></span>
						<p class="description">
							<?php esc_html_e( 'Ventana en la que se descartan submissions duplicadas. Default: 60s.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
				<tr data-sperant-block="1" <?php echo $wppe_bridge_show_sperant_fields ? '' : 'style="display:none"'; ?>>
					<th scope="row">
						<label for="wppe_bridge_panel_subdomain"><?php esc_html_e( 'Subdomain del panel Sperant', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input
							type="text"
							<?php echo $wppe_bridge_is_sperant_active ? 'name="wppe_bridge_panel_subdomain"' : ''; ?>
							data-original-name="wppe_bridge_panel_subdomain"
							id="wppe_bridge_panel_subdomain"
							class="regular-text"
							value="<?php echo esc_attr( $panel_subdomain ); ?>"
							placeholder="andeninversiones"
							data-panel-domain="<?php echo esc_attr( WPPE_Bridge_Settings_Page::PANEL_DOMAIN ); ?>"
						/>
						<span style="color:#666">.<?php echo esc_html( WPPE_Bridge_Settings_Page::PANEL_DOMAIN ); ?></span>
						<span id="wppe-bridge-subdomain-feedback" style="margin-left:10px;font-size:13px;"></span>
						<p class="description">
							<?php esc_html_e( 'Subdomain de tu panel web de Sperant (ej. para https://andeninversiones.sperant.com el subdomain es "andeninversiones"). Cuando lo configures, las URLs de "Importar catalogos manualmente" se vuelven clickeables y abren directamente el JSON correspondiente del panel. Acepta tambien el host completo o URL completa — extrae el subdomain automaticamente.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe_bridge_default_country_code"><?php esc_html_e( 'Codigo de pais default', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input
							type="text"
							name="wppe_bridge_default_country_code"
							id="wppe_bridge_default_country_code"
							class="small-text"
							pattern="\+\d{1,3}"
							value="<?php echo esc_attr( $country_code ); ?>"
						/>
						<p class="description">
							<?php esc_html_e( 'Para telefonos sin prefijo internacional. Default: +51 (Peru).', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
			</tbody>
		</table>

		<?php submit_button(); ?>
	</form>

	<!-- v2.5.3/v2.5.5: secciones "Catalogos Sperant" + "Importar catalogos
		manualmente" solo aplican cuando el destino activo es Sperant.
		Los demas CRMs tienen su propia sub-pagina de Mapeo con su sync
		button dedicado. v2.5.5: ahora siempre renderizadas y ocultas
		con display:none cuando active != sperant, para que JS pueda
		mostrarlas en vivo al cambiar el dropdown. -->
	<div data-sperant-block="1" <?php echo $wppe_bridge_show_sperant_fields ? '' : 'style="display:none"'; ?>>

	<hr/>

	<h2><?php esc_html_e( 'Catalogos Sperant', 'wppe-bridge' ); ?></h2>
	<p>
		<?php esc_html_e( 'Sincroniza los catalogos (input_channels, sources, interest_types, projects) desde tu instancia de Sperant. Necesario antes de configurar mapeos de formularios.', 'wppe-bridge' ); ?>
	</p>

	<p>
		<button
			type="button"
			class="button button-secondary"
			id="wppe-bridge-sync-catalogs"
			<?php disabled( ! $has_token ); ?>
		>
			<span class="dashicons dashicons-update" aria-hidden="true" style="margin-top:4px"></span>
			<?php esc_html_e( 'Sincronizar catalogos', 'wppe-bridge' ); ?>
		</button>
		<span id="wppe-bridge-sync-status" style="margin-left:10px"></span>
	</p>

		<?php
		$wppe_bridge_catalog_errors  = isset( $catalogs['_errors'] ) && is_array( $catalogs['_errors'] ) ? $catalogs['_errors'] : array();
		$wppe_bridge_catalog_sources = isset( $catalogs['_sources'] ) && is_array( $catalogs['_sources'] ) ? $catalogs['_sources'] : array();
		$wppe_bridge_labels          = array(
			'input_channels' => __( 'Canales de entrada', 'wppe-bridge' ),
			'sources'        => __( 'Fuentes', 'wppe-bridge' ),
			'interest_types' => __( 'Tipos de interes', 'wppe-bridge' ),
			'projects'       => __( 'Proyectos', 'wppe-bridge' ),
		);
		?>
		<?php if ( $catalogs_present ) : ?>
		<table class="widefat striped" style="max-width:800px">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Catalogo', 'wppe-bridge' ); ?></th>
					<th><?php esc_html_e( 'Entradas', 'wppe-bridge' ); ?></th>
					<th><?php esc_html_e( 'Origen', 'wppe-bridge' ); ?></th>
					<th><?php esc_html_e( 'Estado', 'wppe-bridge' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $wppe_bridge_labels as $wppe_bridge_key => $wppe_bridge_label ) :
					$wppe_bridge_count  = isset( $catalogs[ $wppe_bridge_key ] ) && is_array( $catalogs[ $wppe_bridge_key ] ) ? count( $catalogs[ $wppe_bridge_key ] ) : 0;
					$wppe_bridge_error  = isset( $wppe_bridge_catalog_errors[ $wppe_bridge_key ] ) ? (string) $wppe_bridge_catalog_errors[ $wppe_bridge_key ] : '';
					$wppe_bridge_source = isset( $wppe_bridge_catalog_sources[ $wppe_bridge_key ] ) ? (string) $wppe_bridge_catalog_sources[ $wppe_bridge_key ] : 'api';
					?>
					<tr>
						<td><?php echo esc_html( $wppe_bridge_label ); ?></td>
						<td><?php echo esc_html( (string) $wppe_bridge_count ); ?></td>
						<td>
							<?php if ( 'manual' === $wppe_bridge_source ) : ?>
								<span style="color:#2271b1">✋ <?php esc_html_e( 'Manual', 'wppe-bridge' ); ?></span>
							<?php else : ?>
								<span style="color:#666">🔄 <?php esc_html_e( 'API', 'wppe-bridge' ); ?></span>
							<?php endif; ?>
						</td>
						<td>
							<?php if ( '' !== $wppe_bridge_error ) : ?>
								<span style="color:#dba617" title="<?php esc_attr_e( 'Endpoint no disponible. Usa import manual abajo.', 'wppe-bridge' ); ?>">
									⚠ <?php echo esc_html( $wppe_bridge_error ); ?>
								</span>
							<?php elseif ( $wppe_bridge_count > 0 ) : ?>
								<span style="color:#46b450">✓ <?php esc_html_e( 'Disponible', 'wppe-bridge' ); ?></span>
							<?php else : ?>
								<span style="color:#888"><?php esc_html_e( 'Vacio', 'wppe-bridge' ); ?></span>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php else : ?>
		<p><em><?php esc_html_e( 'Aun no se han sincronizado catalogos.', 'wppe-bridge' ); ?></em></p>
	<?php endif; ?>

	<hr/>

	<h2><?php esc_html_e( 'Importar catalogos manualmente', 'wppe-bridge' ); ?></h2>
	<p class="description">
		<?php esc_html_e( 'Util cuando un endpoint publico no esta disponible (ej. /v3/sources retorna 404 en algunas instancias). Abre la URL del panel de tu cliente Sperant en otro tab, copia el JSON completo, y pegalo aqui. La data manual sobrescribe el sync via API y se preserva en re-syncs futuros.', 'wppe-bridge' ); ?>
	</p>
		<?php if ( '' === $panel_subdomain ) : ?>
		<p class="description" style="color:#dba617;">
			<span class="dashicons dashicons-info" aria-hidden="true" style="color:#dba617"></span>
			<?php
			printf(
				/* translators: 1: open <a>, 2: close </a> */
				esc_html__( 'Tip: configura el %1$ssubdomain del panel Sperant%2$s arriba para que las URLs de cada catalogo se vuelvan clickeables.', 'wppe-bridge' ),
				'<a href="#wppe_bridge_panel_subdomain">',
				'</a>'
			);
			?>
		</p>
	<?php endif; ?>

		<?php
		$wppe_bridge_panel_endpoints = array(
			'input_channels' => 'input_channels.json',
			'sources'        => 'sources.json',
			'interest_types' => 'interest_types.json',
			'projects'       => 'api_eternia/projects.json',
		);
		?>

	<div id="wppe-bridge-import-sections" style="max-width:900px">
		<?php foreach ( $wppe_bridge_labels as $wppe_bridge_ckey => $wppe_bridge_clabel ) : ?>
			<?php
			$wppe_bridge_endpoint = $wppe_bridge_panel_endpoints[ $wppe_bridge_ckey ] ?? $wppe_bridge_ckey . '.json';
			$wppe_bridge_full_url = WPPE_Bridge_Settings_Page::panel_url( $wppe_bridge_endpoint );
			$wppe_bridge_has_url  = '' !== $wppe_bridge_full_url;
			?>
			<div
				class="wppe-bridge-import-card"
				style="border:1px solid #ccd0d4;background:#fff;padding:14px 16px;margin-bottom:14px;"
				data-catalog="<?php echo esc_attr( $wppe_bridge_ckey ); ?>"
			>
				<h3 style="margin-top:0;display:flex;justify-content:space-between;align-items:center;">
					<span><?php echo esc_html( $wppe_bridge_clabel ); ?></span>
					<span class="wppe-bridge-panel-url-wrap" style="font-size:13px;color:#666;font-weight:normal;" data-endpoint="<?php echo esc_attr( $wppe_bridge_endpoint ); ?>">
						<span class="wppe-bridge-panel-url-label"><?php esc_html_e( 'URL panel:', 'wppe-bridge' ); ?></span>
						<a
							href="<?php echo esc_url( $wppe_bridge_has_url ? $wppe_bridge_full_url : '#' ); ?>"
							target="_blank"
							rel="noopener"
							class="wppe-bridge-panel-link"
							title="<?php esc_attr_e( 'Abrir en otro tab. Debes estar logueado al panel Sperant.', 'wppe-bridge' ); ?>"
							style="<?php echo $wppe_bridge_has_url ? '' : 'display:none;'; ?>"
						>
							<code class="wppe-bridge-panel-link-code" style="background:#f0f6fc;color:#2271b1;"><?php echo esc_html( $wppe_bridge_full_url ); ?></code>
							<span class="dashicons dashicons-external" aria-hidden="true" style="font-size:14px;height:14px;width:14px;vertical-align:text-bottom;"></span>
						</a>
						<span class="wppe-bridge-panel-placeholder" style="<?php echo $wppe_bridge_has_url ? 'display:none;' : ''; ?>">
							<code>&lt;subdomain&gt;.sperant.com/<?php echo esc_html( $wppe_bridge_endpoint ); ?></code>
						</span>
					</span>
				</h3>
				<ol style="margin:8px 0 12px 18px;padding:0;font-size:13px;color:#555;line-height:1.6">
					<li>
						<?php
						printf(
							/* translators: %s = enlace "URL panel" */
							esc_html__( 'Abri el %s del catalogo en otro tab del navegador (debes estar logueado al panel Sperant).', 'wppe-bridge' ),
							'<strong>' . esc_html__( 'URL panel', 'wppe-bridge' ) . '</strong>'
						);
						?>
					</li>
					<li><?php esc_html_e( 'Selecciona TODO el contenido del JSON (Ctrl+A o Cmd+A) y copialo (Ctrl+C o Cmd+C).', 'wppe-bridge' ); ?></li>
					<li><?php esc_html_e( 'Pegalo en el textarea de abajo (Ctrl+V o Cmd+V).', 'wppe-bridge' ); ?></li>
					<li>
						<?php
						printf(
							/* translators: %s = boton "Importar" */
							esc_html__( 'Click en %s. Si el JSON es valido, los items quedan disponibles en el dropdown de Mapeo.', 'wppe-bridge' ),
							'<strong>' . esc_html__( 'Importar', 'wppe-bridge' ) . '</strong>'
						);
						?>
					</li>
				</ol>
				<label style="display:block;font-size:12px;color:#666;margin-bottom:4px;">
					<?php
					printf(
						/* translators: %s = nombre del catalogo */
						esc_html__( 'Pega aqui el JSON completo de %s:', 'wppe-bridge' ),
						'<strong>' . esc_html( $wppe_bridge_clabel ) . '</strong>'
					);
					?>
				</label>
				<textarea
					name="wppe-bridge-import-json-<?php echo esc_attr( $wppe_bridge_ckey ); ?>"
					rows="4"
					style="width:100%;font-family:Menlo,Monaco,Courier,monospace;font-size:12px;"
					placeholder='[{"id":1,"name":"..."}, {"id":2,"name":"..."}]'
				></textarea>
				<p style="margin-top:8px;display:flex;align-items:center;gap:10px;">
					<button
						type="button"
						class="button button-secondary wppe-bridge-import-btn"
						data-catalog="<?php echo esc_attr( $wppe_bridge_ckey ); ?>"
					>
						<?php esc_html_e( 'Importar', 'wppe-bridge' ); ?>
					</button>
					<span class="wppe-bridge-import-status" data-catalog="<?php echo esc_attr( $wppe_bridge_ckey ); ?>"></span>
				</p>
			</div>
		<?php endforeach; ?>
	</div>

	</div><!-- /[data-sperant-block] catalogos + import manual -->


	<details style="margin-top:40px;max-width:900px;background:#fafafa;border:1px solid #e5e5e5;border-radius:4px;padding:0;">
		<summary style="padding:10px 14px;cursor:pointer;font-size:13px;color:#888;list-style:revert;">
			<?php esc_html_e( 'Opciones avanzadas (zona de peligro)', 'wppe-bridge' ); ?>
		</summary>
		<div style="padding:14px 18px;border-top:1px solid #e5e5e5;">
			<form method="post" action="options.php">
				<?php settings_fields( WPPE_Bridge_Settings_Page::OPTION_GROUP_DANGER ); ?>

				<p style="color:#666;font-size:13px;margin-top:0">
					<strong style="color:#dc3232">⚠ <?php esc_html_e( 'Solo para descontinuar el plugin permanentemente.', 'wppe-bridge' ); ?></strong>
					<?php esc_html_e( 'Por default, al desinstalar el plugin se preservan token, mapeos, catalogos, logs y queue. Si activas esta opcion y luego eliminas el plugin, todo se borra.', 'wppe-bridge' ); ?>
				</p>

				<p>
					<label>
						<input
							type="checkbox"
							name="wppe_bridge_delete_data_on_uninstall"
							id="wppe_bridge_delete_data_on_uninstall"
							value="1"
							<?php checked( $delete_data_uninstall, true ); ?>
						/>
						<?php esc_html_e( 'Borrar todos los datos del plugin al desinstalar', 'wppe-bridge' ); ?>
					</label>
				</p>

				<p style="font-size:12px;color:#999;margin:8px 0 12px;">
					<em><?php esc_html_e( 'Tip: para actualizar el plugin sin perder mapeos, sube el ZIP nuevo encima del existente (WordPress reemplaza archivos sin desinstalar).', 'wppe-bridge' ); ?></em>
				</p>

				<?php submit_button( __( 'Guardar zona de peligro', 'wppe-bridge' ), 'secondary', 'submit', false ); ?>
			</form>
		</div>
	</details>
</div>
