<?php
/**
 * Vista de la pagina admin "Mapeo Odoo".
 *
 * Variables disponibles (provistas por WPPE_Bridge_Odoo_Mapping_Page::render):
 *
 * @var array  $discovered          Forms detectados por plugin.
 * @var array  $discovery_reasons   Razones por las que algunos forms no se detectaron.
 * @var array  $catalogs            Catalogos Odoo sincronizados.
 * @var array  $catalogs_errors     Errores parciales del ultimo sync.
 * @var int    $synced_at           Timestamp del ultimo sync (0 si nunca).
 * @var array  $mapping             Mapeo persistido por plugin->form->{fields,tags,type}.
 * @var string $default_team_id     Team default (`team_id`).
 * @var string $default_user_id     Salesperson default (`user_id`).
 * @var array  $default_tags        Lista de tag names default.
 * @var string $selected_plugin     Plugin slug seleccionado en URL.
 * @var string $selected_form       Form ID seleccionado en URL.
 * @var ?array $selected_form_data  Data del form seleccionado (null si no hay).
 * @var array  $existing_mapping    Mapeo persistido del form seleccionado.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

$wppe_bridge_flash   = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$wppe_bridge_missing = isset( $_GET['missing'] ) ? array_filter( array_map( 'sanitize_key', explode( ',', sanitize_text_field( wp_unslash( $_GET['missing'] ) ) ) ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

$wppe_bridge_teams       = isset( $catalogs['teams'] ) && is_array( $catalogs['teams'] ) ? $catalogs['teams'] : array();
$wppe_bridge_users       = isset( $catalogs['users'] ) && is_array( $catalogs['users'] ) ? $catalogs['users'] : array();
$wppe_bridge_tags        = isset( $catalogs['tags'] ) && is_array( $catalogs['tags'] ) ? $catalogs['tags'] : array();
$wppe_bridge_utm_sources = isset( $catalogs['utm_sources'] ) && is_array( $catalogs['utm_sources'] ) ? $catalogs['utm_sources'] : array();
$wppe_bridge_utm_mediums = isset( $catalogs['utm_mediums'] ) && is_array( $catalogs['utm_mediums'] ) ? $catalogs['utm_mediums'] : array();
$wppe_bridge_utm_camps   = isset( $catalogs['utm_campaigns'] ) && is_array( $catalogs['utm_campaigns'] ) ? $catalogs['utm_campaigns'] : array();
$wppe_bridge_countries   = isset( $catalogs['countries'] ) && is_array( $catalogs['countries'] ) ? $catalogs['countries'] : array();
$wppe_bridge_has_synced  = $synced_at > 0;
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Mapeo Odoo', 'wppe-bridge' ); ?></h1>

	<?php if ( 'saved' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-success is-dismissible" role="status"><p><?php esc_html_e( 'Mapeo del formulario guardado.', 'wppe-bridge' ); ?></p></div>
	<?php elseif ( 'global_saved' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-success is-dismissible" role="status"><p><?php esc_html_e( 'Configuracion global guardada.', 'wppe-bridge' ); ?></p></div>
	<?php elseif ( 'error_required' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-error" role="alert"><p>
			<?php esc_html_e( 'Falta mapear al menos un campo de identidad. Mapea AL MENOS UNO de:', 'wppe-bridge' ); ?>
			<code><?php echo esc_html( implode( ', ', $wppe_bridge_missing ) ); ?></code>.
			<?php esc_html_e( 'Sin un dato de identidad (nombre, email o telefono), el lead se crea pero ningun vendedor puede actuar sobre el.', 'wppe-bridge' ); ?>
		</p></div>
	<?php elseif ( 'error_missing_form' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-error" role="alert"><p><?php esc_html_e( 'Falta plugin o form ID en el POST.', 'wppe-bridge' ); ?></p></div>
	<?php endif; ?>

	<div class="notice notice-info inline" role="status" style="margin-top:1em">
		<p>
			<strong><?php esc_html_e( 'Aviso:', 'wppe-bridge' ); ?></strong>
			<?php esc_html_e( 'Esta sub-pagina persiste la configuracion pero la inyeccion al payload `crm.lead` (team_id, user_id, tag_ids, source_id/medium_id/campaign_id, country_id) llega en v2.5.0 (PR-3). Hasta entonces, los leads se crean solo con los campos de identidad mapeados + name + type.', 'wppe-bridge' ); ?>
		</p>
	</div>


	<!-- ========================================================== -->
	<!-- Bloque 1: Sincronizacion de catalogos                       -->
	<!-- ========================================================== -->
	<h2><?php esc_html_e( 'Sincronizacion de catalogos', 'wppe-bridge' ); ?></h2>
	<p>
		<?php esc_html_e( 'Sincroniza los 7 catalogos Odoo via search_read sobre crm.team, res.users (active=true), utm.source/medium/campaign, crm.tag y res.country. Sin sync, los selectores de abajo aparecen vacios.', 'wppe-bridge' ); ?>
	</p>

	<table class="form-table" role="presentation">
		<tbody>
			<tr>
				<th scope="row"><?php esc_html_e( 'Estado', 'wppe-bridge' ); ?></th>
				<td>
					<?php if ( $wppe_bridge_has_synced ) : ?>
						<p>
							<span class="dashicons dashicons-yes-alt" aria-hidden="true" style="color:#46b450"></span>
							<?php
							echo esc_html(
								sprintf(
									/* translators: %s: human-readable time diff */
									__( 'Ultima sincronizacion: hace %s', 'wppe-bridge' ),
									human_time_diff( $synced_at, time() )
								)
							);
							?>
						</p>
						<ul style="list-style:disc;margin-left:2em">
							<?php
							$wppe_bridge_catalog_rows = array(
								array( 'teams', __( 'Equipos de venta (crm.team)', 'wppe-bridge' ), $wppe_bridge_teams ),
								array( 'users', __( 'Vendedores (res.users active)', 'wppe-bridge' ), $wppe_bridge_users ),
								array( 'utm_sources', __( 'UTM source (utm.source)', 'wppe-bridge' ), $wppe_bridge_utm_sources ),
								array( 'utm_mediums', __( 'UTM medium (utm.medium)', 'wppe-bridge' ), $wppe_bridge_utm_mediums ),
								array( 'utm_campaigns', __( 'UTM campaign (utm.campaign)', 'wppe-bridge' ), $wppe_bridge_utm_camps ),
								array( 'tags', __( 'Tags (crm.tag)', 'wppe-bridge' ), $wppe_bridge_tags ),
								array( 'countries', __( 'Paises (res.country)', 'wppe-bridge' ), $wppe_bridge_countries ),
							);
							foreach ( $wppe_bridge_catalog_rows as $wppe_bridge_row ) :
								$wppe_bridge_row_key  = $wppe_bridge_row[0];
								$wppe_bridge_row_lbl  = $wppe_bridge_row[1];
								$wppe_bridge_row_data = $wppe_bridge_row[2];
								?>
								<li>
									<strong><?php echo esc_html( $wppe_bridge_row_lbl ); ?>:</strong>
									<?php echo (int) count( $wppe_bridge_row_data ); ?>
									<?php if ( isset( $catalogs_errors[ $wppe_bridge_row_key ] ) ) : ?>
										<span style="color:#dc3232">— <?php echo esc_html( $catalogs_errors[ $wppe_bridge_row_key ] ); ?></span>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php else : ?>
						<p>
							<span class="dashicons dashicons-warning" aria-hidden="true" style="color:#dc3232"></span>
							<?php esc_html_e( 'No hay sincronizacion previa. Pulsa "Sincronizar catalogos" abajo.', 'wppe-bridge' ); ?>
						</p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Sincronizar', 'wppe-bridge' ); ?></th>
				<td>
					<button
						type="button"
						class="button button-primary"
						id="wppe-bridge-odoo-sync-btn"
						data-nonce="<?php echo esc_attr( wp_create_nonce( WPPE_Bridge_Admin_Ajax::NONCE_ACTION ) ); ?>"
					>
						<?php esc_html_e( 'Sincronizar catalogos Odoo', 'wppe-bridge' ); ?>
					</button>
					<span id="wppe-bridge-odoo-sync-status" style="margin-left:1em"></span>
					<p class="description">
						<?php esc_html_e( 'Hace 7 calls JSON-RPC search_read. Si el cliente no tiene el modulo `utm` instalado, los catalogos utm.* fallan con AccessError pero los demas siguen sincronizando. Lo mismo si no tiene `crm` (improbable — todos lo tienen).', 'wppe-bridge' ); ?>
					</p>
				</td>
			</tr>
		</tbody>
	</table>

	<hr/>

	<!-- ========================================================== -->
	<!-- Bloque 2: Configuracion global                              -->
	<!-- ========================================================== -->
	<h2><?php esc_html_e( 'Configuracion global', 'wppe-bridge' ); ?></h2>
	<p class="description">
		<?php esc_html_e( 'Ajustes que aplican a TODOS los forms. Cada form puede agregar tags adicionales y override del type en su mapeo individual mas abajo.', 'wppe-bridge' ); ?>
	</p>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="<?php echo esc_attr( WPPE_Bridge_Odoo_Mapping_Page::ACTION_SAVE_GLOBAL_CONFIG ); ?>"/>
		<?php wp_nonce_field( WPPE_Bridge_Odoo_Mapping_Page::NONCE_GLOBAL_CONFIG ); ?>

		<table class="form-table" role="presentation">
			<tbody>
				<!-- Default team -->
				<tr>
					<th scope="row">
						<label for="default_team_id"><?php esc_html_e( 'Equipo de venta default', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<select name="default_team_id" id="default_team_id">
							<option value=""><?php esc_html_e( '(sin equipo — Odoo asigna por defecto)', 'wppe-bridge' ); ?></option>
							<?php foreach ( $wppe_bridge_teams as $wppe_bridge_team ) : ?>
								<option
									value="<?php echo esc_attr( (string) ( $wppe_bridge_team['id'] ?? '' ) ); ?>"
									<?php selected( $default_team_id, (string) ( $wppe_bridge_team['id'] ?? '' ) ); ?>
								>
									<?php echo esc_html( $wppe_bridge_team['name'] ?? '' ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'team_id que se inyecta a cada lead. Si dejas vacio, Odoo aplica su propia logica (Sales Team default de la cuenta o vacio).', 'wppe-bridge' ); ?></p>
					</td>
				</tr>

				<!-- Default user -->
				<tr>
					<th scope="row">
						<label for="default_user_id"><?php esc_html_e( 'Vendedor asignado default', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<select name="default_user_id" id="default_user_id">
							<option value=""><?php esc_html_e( '(sin asignar — round-robin del equipo)', 'wppe-bridge' ); ?></option>
							<?php foreach ( $wppe_bridge_users as $wppe_bridge_user ) : ?>
								<option
									value="<?php echo esc_attr( (string) ( $wppe_bridge_user['id'] ?? '' ) ); ?>"
									<?php selected( $default_user_id, (string) ( $wppe_bridge_user['id'] ?? '' ) ); ?>
								>
									<?php echo esc_html( ( $wppe_bridge_user['name'] ?? '' ) . ' (' . ( $wppe_bridge_user['login'] ?? '' ) . ')' ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'user_id (salesperson) al que se asigna el lead. Lo recomendable es dejarlo vacio para que Odoo haga round-robin del Sales Team — asi el trabajo se distribuye automatico.', 'wppe-bridge' ); ?></p>
					</td>
				</tr>

				<!-- Default tags -->
				<tr>
					<th scope="row">
						<label for="default_tags"><?php esc_html_e( 'Tags default (globales)', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input
							type="text"
							name="default_tags"
							id="default_tags"
							class="regular-text"
							value="<?php echo esc_attr( implode( ', ', $default_tags ) ); ?>"
							placeholder="lead-web, wppe-bridge"
							list="wppe-bridge-odoo-tags-suggest"
						/>
						<datalist id="wppe-bridge-odoo-tags-suggest">
							<?php foreach ( $wppe_bridge_tags as $wppe_bridge_tag ) : ?>
								<option value="<?php echo esc_attr( $wppe_bridge_tag['name'] ?? '' ); ?>"></option>
							<?php endforeach; ?>
						</datalist>
						<p class="description">
							<?php esc_html_e( 'Tags separados por coma. Aplican a todo lead creado por el bridge. Cada form puede agregar tags adicionales en su mapeo individual mas abajo. Match por nombre case-insensitive contra crm.tag — si no existe en Odoo, el bridge lo crea automaticamente al primer envio (PR-3).', 'wppe-bridge' ); ?>
							<?php
							if ( ! empty( $wppe_bridge_tags ) ) {
								echo ' ' . esc_html(
									sprintf(
										/* translators: %d: count of tags suggested */
										__( 'Autocomplete con %d tags existentes en Odoo.', 'wppe-bridge' ),
										count( $wppe_bridge_tags )
									)
								);
							}
							?>
						</p>
					</td>
				</tr>
			</tbody>
		</table>

		<?php submit_button( __( 'Guardar configuracion global Odoo', 'wppe-bridge' ) ); ?>
	</form>

	<hr/>

	<!-- ========================================================== -->
	<!-- Bloque 3: Mapeo de campos por form                          -->
	<!-- ========================================================== -->
	<h2><?php esc_html_e( 'Mapeo de campos por formulario', 'wppe-bridge' ); ?></h2>

	<?php if ( null !== $selected_form_data ) : ?>
		<p>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . WPPE_Bridge_Odoo_Mapping_Page::PAGE_SLUG ) ); ?>">
				&larr; <?php esc_html_e( 'Volver a la lista de formularios', 'wppe-bridge' ); ?>
			</a>
		</p>
		<p>
			<strong><?php esc_html_e( 'Plugin', 'wppe-bridge' ); ?>:</strong> <?php echo esc_html( $selected_plugin ); ?>
			&nbsp;|&nbsp;
			<strong><?php esc_html_e( 'Form', 'wppe-bridge' ); ?>:</strong>
			<?php echo esc_html( $selected_form_data['title'] ?? $selected_form ); ?>
			(ID: <code><?php echo esc_html( $selected_form ); ?></code>)
		</p>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( WPPE_Bridge_Odoo_Mapping_Page::ACTION_SAVE_FORM_MAPPING ); ?>"/>
			<input type="hidden" name="plugin" value="<?php echo esc_attr( $selected_plugin ); ?>"/>
			<input type="hidden" name="form" value="<?php echo esc_attr( $selected_form ); ?>"/>
			<?php wp_nonce_field( WPPE_Bridge_Odoo_Mapping_Page::NONCE_FORM_MAPPING ); ?>

			<table class="widefat striped" style="max-width:800px">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Campo del formulario', 'wppe-bridge' ); ?></th>
						<th><?php esc_html_e( 'Campo Odoo (crm.lead)', 'wppe-bridge' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					$wppe_bridge_form_fields = isset( $selected_form_data['fields'] ) && is_array( $selected_form_data['fields'] ) ? $selected_form_data['fields'] : array();
					$wppe_bridge_existing_f  = isset( $existing_mapping['fields'] ) && is_array( $existing_mapping['fields'] ) ? $existing_mapping['fields'] : array();
					foreach ( $wppe_bridge_form_fields as $wppe_bridge_field ) :
						$wppe_bridge_field_key   = is_array( $wppe_bridge_field ) ? (string) ( $wppe_bridge_field['key'] ?? '' ) : (string) $wppe_bridge_field;
						$wppe_bridge_field_label = is_array( $wppe_bridge_field ) ? (string) ( $wppe_bridge_field['label'] ?? $wppe_bridge_field_key ) : $wppe_bridge_field_key;
						$wppe_bridge_current     = (string) ( $wppe_bridge_existing_f[ $wppe_bridge_field_key ] ?? '' );
						?>
						<tr>
							<td>
								<code><?php echo esc_html( $wppe_bridge_field_key ); ?></code>
								<?php if ( $wppe_bridge_field_label !== $wppe_bridge_field_key ) : ?>
									<br/><span class="description"><?php echo esc_html( $wppe_bridge_field_label ); ?></span>
								<?php endif; ?>
							</td>
							<td>
								<select name="field_map[<?php echo esc_attr( $wppe_bridge_field_key ); ?>]">
									<option value=""><?php esc_html_e( '(no mapear)', 'wppe-bridge' ); ?></option>
									<?php foreach ( WPPE_Bridge_Odoo_Mapping_Page::PAYLOAD_KEYS as $wppe_bridge_pk ) : ?>
										<option
											value="<?php echo esc_attr( $wppe_bridge_pk ); ?>"
											<?php selected( $wppe_bridge_current, $wppe_bridge_pk ); ?>
										>
											<?php echo esc_html( $wppe_bridge_pk ); ?>
											<?php if ( in_array( $wppe_bridge_pk, WPPE_Bridge_Odoo_Mapping_Page::IDENTITY_KEYS, true ) ) : ?>
												*
											<?php endif; ?>
										</option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description" style="margin-top:0.5em">
				<?php esc_html_e( '* Campo de identidad. Al menos uno de (contact_name, email_from, phone, name) debe estar mapeado para que el lead sea utilizable por vendedores.', 'wppe-bridge' ); ?>
			</p>

			<h3 style="margin-top:2em"><?php esc_html_e( 'Override per-form', 'wppe-bridge' ); ?></h3>

			<table class="form-table" role="presentation">
				<tbody>
					<!-- Type override -->
					<tr>
						<th scope="row">
							<label for="form_type"><?php esc_html_e( 'Tipo del registro', 'wppe-bridge' ); ?></label>
						</th>
						<td>
							<?php $wppe_bridge_form_type = (string) ( $existing_mapping['type'] ?? 'inherit' ); ?>
							<select name="form_type" id="form_type">
								<option value="inherit" <?php selected( $wppe_bridge_form_type, 'inherit' ); ?>>
									<?php esc_html_e( 'Heredar del default global (Configuracion Odoo)', 'wppe-bridge' ); ?>
								</option>
								<option value="opportunity" <?php selected( $wppe_bridge_form_type, 'opportunity' ); ?>>
									<?php esc_html_e( 'Opportunity (forzar — aparece en Pipeline)', 'wppe-bridge' ); ?>
								</option>
								<option value="lead" <?php selected( $wppe_bridge_form_type, 'lead' ); ?>>
									<?php esc_html_e( 'Lead (forzar — paso de qualification)', 'wppe-bridge' ); ?>
								</option>
							</select>
							<p class="description">
								<?php esc_html_e( 'D-Odoo-8: por default heredamos del global. Override util si tienes un form de "auditoria gratis" que querias que pase por SDR (lead) aunque el global este en opportunity.', 'wppe-bridge' ); ?>
							</p>
						</td>
					</tr>

					<!-- Per-form tags -->
					<tr>
						<th scope="row">
							<label for="form_tags"><?php esc_html_e( 'Tags adicionales para este form', 'wppe-bridge' ); ?></label>
						</th>
						<td>
							<?php
							$wppe_bridge_form_tags = isset( $existing_mapping['tags'] ) && is_array( $existing_mapping['tags'] ) ? $existing_mapping['tags'] : array();
							?>
							<input
								type="text"
								name="form_tags"
								id="form_tags"
								class="regular-text"
								value="<?php echo esc_attr( implode( ', ', $wppe_bridge_form_tags ) ); ?>"
								placeholder="contacto-rapido, evento-2026"
								list="wppe-bridge-odoo-tags-suggest"
							/>
							<p class="description">
								<?php esc_html_e( 'Se concatenan a los tags default globales (deduplicado). Util para distinguir leads de "Contacto" vs "Cotizador" vs "Auditoria".', 'wppe-bridge' ); ?>
							</p>
						</td>
					</tr>
				</tbody>
			</table>

			<?php submit_button( __( 'Guardar mapeo de este form', 'wppe-bridge' ) ); ?>
		</form>

	<?php else : ?>

		<p><?php esc_html_e( 'Selecciona un formulario para mapear sus campos.', 'wppe-bridge' ); ?></p>

		<?php
		$wppe_bridge_has_any_form = false;
		foreach ( $discovered as $wppe_bridge_plugin_slug => $wppe_bridge_forms_list ) {
			if ( ! empty( $wppe_bridge_forms_list ) ) {
				$wppe_bridge_has_any_form = true;
				break;
			}
		}
		?>

		<?php if ( ! $wppe_bridge_has_any_form ) : ?>
			<div class="notice notice-warning inline" role="status"><p>
				<?php esc_html_e( 'No se detectaron formularios. Razones posibles:', 'wppe-bridge' ); ?>
				<ul style="list-style:disc;margin-left:2em">
					<?php foreach ( $discovery_reasons as $wppe_bridge_pl => $wppe_bridge_reason ) : ?>
						<li><strong><?php echo esc_html( $wppe_bridge_pl ); ?>:</strong> <?php echo esc_html( $wppe_bridge_reason ); ?></li>
					<?php endforeach; ?>
				</ul>
			</p></div>
		<?php else : ?>
			<?php foreach ( $discovered as $wppe_bridge_plugin_slug => $wppe_bridge_forms_list ) : ?>
				<?php
				if ( empty( $wppe_bridge_forms_list ) ) {
					continue; }
				?>
				<h3><?php echo esc_html( $wppe_bridge_plugin_slug ); ?></h3>
				<ul style="list-style:disc;margin-left:2em">
					<?php foreach ( $wppe_bridge_forms_list as $wppe_bridge_form ) : ?>
						<li>
							<a href="
							<?php
							echo esc_url(
								add_query_arg(
									array(
										'page'   => WPPE_Bridge_Odoo_Mapping_Page::PAGE_SLUG,
										'plugin' => $wppe_bridge_plugin_slug,
										'form'   => $wppe_bridge_form['id'] ?? '',
									),
									admin_url( 'admin.php' )
								)
							);
							?>
							">
								<?php echo esc_html( $wppe_bridge_form['title'] ?? $wppe_bridge_form['id'] ?? '' ); ?>
							</a>
							<code><?php echo esc_html( (string) ( $wppe_bridge_form['id'] ?? '' ) ); ?></code>
							<?php
							$wppe_bridge_has_mapping = isset( $mapping[ $wppe_bridge_plugin_slug ][ (string) ( $wppe_bridge_form['id'] ?? '' ) ] );
							if ( $wppe_bridge_has_mapping ) {
								echo ' <span style="color:#46b450">' . esc_html__( '(mapeado)', 'wppe-bridge' ) . '</span>';
							}
							?>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endforeach; ?>
		<?php endif; ?>
	<?php endif; ?>
</div>
