<?php
/**
 * Vista de la pagina admin "Mapeo HubSpot".
 *
 * Variables disponibles (provistas por WPPE_Bridge_Hubspot_Mapping_Page::render):
 *
 * @var array  $discovered                Forms detectados por plugin.
 * @var array  $catalogs                  Catalogos HubSpot sincronizados.
 * @var array  $catalogs_errors           Errores parciales del ultimo sync.
 * @var int    $synced_at                 Timestamp del ultimo sync (0 si nunca).
 * @var int    $owners_count              Count de owners sincronizados.
 * @var int    $properties_count          Count de contact properties.
 * @var array  $lifecycle_options         Lista de {label,value,displayOrder}.
 * @var int    $lifecycle_options_count   Count del enum dinamico.
 * @var array  $payload_keys              Lista combinada de payload_keys (catalogo + fallback).
 * @var array  $mapping                   Mapeo persistido por plugin->form->{fields,lifecyclestage}.
 * @var string $default_owner_id          Owner default (de Settings_Page).
 * @var bool   $owner_id_in_catalog       Si el owner default existe en el catalogo.
 * @var string $default_lifecyclestage    Lifecyclestage default (de Settings_Page).
 * @var bool   $lifecyclestage_in_catalog Si el lifecyclestage default existe en el enum.
 * @var string $selected_plugin           Plugin slug seleccionado en URL.
 * @var string $selected_form             Form ID seleccionado en URL.
 * @var ?array $selected_form_data        Data del form seleccionado.
 * @var array  $existing_mapping          Mapeo persistido del form seleccionado.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

$wppe_bridge_flash   = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$wppe_bridge_missing = isset( $_GET['missing'] ) ? array_filter( array_map( 'sanitize_key', explode( ',', sanitize_text_field( wp_unslash( $_GET['missing'] ) ) ) ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

$wppe_bridge_has_synced        = $synced_at > 0;
$wppe_bridge_settings_url      = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=' . WPPE_Bridge_Hubspot_Settings_Page::PAGE_SLUG ) : '';
$wppe_bridge_lifecycle_choices = WPPE_Bridge_Hubspot_Mapping_Page::available_lifecyclestage_choices( $catalogs );
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Mapeo HubSpot', 'wppe-bridge' ); ?></h1>

	<?php if ( 'saved' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-success is-dismissible" role="status"><p><?php esc_html_e( 'Mapeo del formulario guardado.', 'wppe-bridge' ); ?></p></div>
	<?php elseif ( 'error_required' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-error" role="alert"><p>
			<?php esc_html_e( 'Falta mapear el campo de identidad. HubSpot necesita `email` mapeado para hacer upsert (idProperty=email).', 'wppe-bridge' ); ?>
		</p></div>
	<?php elseif ( 'error_missing_form' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-error" role="alert"><p><?php esc_html_e( 'Falta plugin o form ID en el POST.', 'wppe-bridge' ); ?></p></div>
	<?php endif; ?>

	<div class="notice notice-info inline" role="status" style="margin-top:1em">
		<p>
			<strong><?php esc_html_e( 'Aviso:', 'wppe-bridge' ); ?></strong>
			<?php esc_html_e( 'Esta sub-pagina persiste el field mapping y el override per-form de lifecyclestage, pero la inyeccion al payload llega en v2.6.0 (PR-3). Hasta entonces, los leads se crean solo con el lifecyclestage default (Configuracion HubSpot) y las properties que el adapter ya sabe pasar (firstname, lastname, email, phone si vienen del payload normalizado del bridge).', 'wppe-bridge' ); ?>
		</p>
	</div>

	<!-- ========================================================== -->
	<!-- Bloque 1: Sincronizacion de catalogos                       -->
	<!-- ========================================================== -->
	<h2><?php esc_html_e( 'Sincronizacion de catalogos', 'wppe-bridge' ); ?></h2>
	<p>
		<?php esc_html_e( 'Sincroniza 2 catalogos HubSpot: owners (vendedores con seat asignado) y contact_properties (propiedades native + custom). Del segundo derivamos el enum dinamico de lifecyclestage (incluyendo custom stages si el portal los agrego).', 'wppe-bridge' ); ?>
	</p>

	<table class="form-table" role="presentation">
		<tbody>
			<tr>
				<th scope="row"><?php esc_html_e( 'Estado', 'wppe-bridge' ); ?></th>
				<td>
					<?php if ( $wppe_bridge_has_synced ) : ?>
						<p>
							<span class="dashicons dashicons-yes-alt" aria-hidden="true" style="color:#46b450"></span>
							<?php
							echo esc_html(
								sprintf(
									/* translators: %s: human-readable time diff */
									__( 'Ultima sincronizacion: hace %s', 'wppe-bridge' ),
									human_time_diff( $synced_at, time() )
								)
							);
							?>
						</p>
						<ul style="list-style:disc;margin-left:2em">
							<li>
								<strong><?php esc_html_e( 'Owners (vendedores)', 'wppe-bridge' ); ?>:</strong>
								<?php echo (int) $owners_count; ?>
								<?php if ( isset( $catalogs_errors['owners'] ) ) : ?>
									<span style="color:#dc3232">— <?php echo esc_html( $catalogs_errors['owners'] ); ?></span>
								<?php endif; ?>
							</li>
							<li>
								<strong><?php esc_html_e( 'Contact properties', 'wppe-bridge' ); ?>:</strong>
								<?php echo (int) $properties_count; ?>
								<?php if ( isset( $catalogs_errors['contact_properties'] ) ) : ?>
									<span style="color:#dc3232">— <?php echo esc_html( $catalogs_errors['contact_properties'] ); ?></span>
								<?php endif; ?>
							</li>
							<li>
								<strong><?php esc_html_e( 'Lifecyclestage options (enum)', 'wppe-bridge' ); ?>:</strong>
								<?php echo (int) $lifecycle_options_count; ?>
							</li>
						</ul>
					<?php else : ?>
						<p>
							<span class="dashicons dashicons-warning" aria-hidden="true" style="color:#dc3232"></span>
							<?php esc_html_e( 'No hay sincronizacion previa. Pulsa "Sincronizar catalogos" abajo.', 'wppe-bridge' ); ?>
						</p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Sincronizar', 'wppe-bridge' ); ?></th>
				<td>
					<button
						type="button"
						class="button button-primary"
						id="wppe-bridge-hubspot-sync-btn"
						data-nonce="<?php echo esc_attr( wp_create_nonce( WPPE_Bridge_Admin_Ajax::NONCE_ACTION ) ); ?>"
					>
						<?php esc_html_e( 'Sincronizar catalogos HubSpot', 'wppe-bridge' ); ?>
					</button>
					<span id="wppe-bridge-hubspot-sync-status" style="margin-left:1em"></span>
					<p class="description">
						<?php esc_html_e( 'Hace 2 calls GET (`/crm/v3/owners`, `/crm/v3/properties/contacts`). En cuenta HubSpot Free, /crm/v3/owners puede fallar con 403 — el catalogo de properties se sincroniza igual y el plugin sigue funcionando, solo que el dropdown de "Owner default" queda vacio.', 'wppe-bridge' ); ?>
					</p>
				</td>
			</tr>
		</tbody>
	</table>

	<hr/>

	<!-- ========================================================== -->
	<!-- Bloque 2: Validacion suave del config global                -->
	<!-- ========================================================== -->
	<h2><?php esc_html_e( 'Configuracion global (referencia)', 'wppe-bridge' ); ?></h2>
	<p class="description">
		<?php
		echo wp_kses(
			sprintf(
				/* translators: %s: URL a Configuracion HubSpot */
				__( 'El owner default y el lifecyclestage default se configuran en <a href="%s">Configuracion HubSpot</a>. Aqui solo validamos que sigan siendo coherentes con el catalogo sincronizado.', 'wppe-bridge' ),
				esc_url( $wppe_bridge_settings_url )
			),
			array( 'a' => array( 'href' => true ) )
		);
		?>
	</p>

	<table class="widefat striped" style="max-width:800px;margin-top:1em">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Campo', 'wppe-bridge' ); ?></th>
				<th><?php esc_html_e( 'Valor configurado', 'wppe-bridge' ); ?></th>
				<th><?php esc_html_e( 'Estado', 'wppe-bridge' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td><strong><?php esc_html_e( 'Owner default (hubspot_owner_id)', 'wppe-bridge' ); ?></strong></td>
				<td>
					<?php
					if ( '' === $default_owner_id ) {
						echo '<em>' . esc_html__( '(sin configurar — round-robin del portal)', 'wppe-bridge' ) . '</em>';
					} else {
						echo '<code>' . esc_html( $default_owner_id ) . '</code>';
					}
					?>
				</td>
				<td>
					<?php if ( '' === $default_owner_id ) : ?>
						<span style="color:#888"><?php esc_html_e( '— (no aplica)', 'wppe-bridge' ); ?></span>
					<?php elseif ( ! $wppe_bridge_has_synced ) : ?>
						<span style="color:#dba617">
							<span class="dashicons dashicons-warning" aria-hidden="true"></span>
							<?php esc_html_e( 'Sin sync — no se puede validar', 'wppe-bridge' ); ?>
						</span>
					<?php elseif ( $owner_id_in_catalog ) : ?>
						<span style="color:#46b450">
							<span class="dashicons dashicons-yes-alt" aria-hidden="true"></span>
							<?php esc_html_e( 'Existe en el catalogo', 'wppe-bridge' ); ?>
						</span>
					<?php else : ?>
						<span style="color:#dc3232">
							<span class="dashicons dashicons-warning" aria-hidden="true"></span>
							<?php esc_html_e( 'No existe en el catalogo de owners — los leads van a fallar. Re-configurar en Configuracion HubSpot o re-sincronizar.', 'wppe-bridge' ); ?>
						</span>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<td><strong><?php esc_html_e( 'Lifecyclestage default', 'wppe-bridge' ); ?></strong></td>
				<td>
					<?php
					if ( '' === $default_lifecyclestage ) {
						echo '<em>' . esc_html__( '(sin configurar — default del portal)', 'wppe-bridge' ) . '</em>';
					} else {
						echo '<code>' . esc_html( $default_lifecyclestage ) . '</code>';
					}
					?>
				</td>
				<td>
					<?php if ( '' === $default_lifecyclestage ) : ?>
						<span style="color:#888"><?php esc_html_e( '— (no aplica)', 'wppe-bridge' ); ?></span>
					<?php elseif ( ! $wppe_bridge_has_synced ) : ?>
						<span style="color:#dba617">
							<span class="dashicons dashicons-warning" aria-hidden="true"></span>
							<?php esc_html_e( 'Sin sync — no se puede validar', 'wppe-bridge' ); ?>
						</span>
					<?php elseif ( $lifecyclestage_in_catalog ) : ?>
						<span style="color:#46b450">
							<span class="dashicons dashicons-yes-alt" aria-hidden="true"></span>
							<?php esc_html_e( 'Existe en el enum del portal', 'wppe-bridge' ); ?>
						</span>
					<?php else : ?>
						<span style="color:#dc3232">
							<span class="dashicons dashicons-warning" aria-hidden="true"></span>
							<?php esc_html_e( 'No existe en el enum — el portal pudo haber borrado este stage. Re-configurar en Configuracion HubSpot.', 'wppe-bridge' ); ?>
						</span>
					<?php endif; ?>
				</td>
			</tr>
		</tbody>
	</table>

	<hr/>

	<!-- ========================================================== -->
	<!-- Bloque 3: Mapeo de campos por form                          -->
	<!-- ========================================================== -->
	<h2><?php esc_html_e( 'Mapeo de campos por formulario', 'wppe-bridge' ); ?></h2>

	<?php if ( null !== $selected_form_data ) : ?>
		<p>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . WPPE_Bridge_Hubspot_Mapping_Page::PAGE_SLUG ) ); ?>">
				&larr; <?php esc_html_e( 'Volver a la lista de formularios', 'wppe-bridge' ); ?>
			</a>
		</p>
		<p>
			<strong><?php esc_html_e( 'Plugin', 'wppe-bridge' ); ?>:</strong> <?php echo esc_html( $selected_plugin ); ?>
			&nbsp;|&nbsp;
			<strong><?php esc_html_e( 'Form', 'wppe-bridge' ); ?>:</strong>
			<?php echo esc_html( $selected_form_data['title'] ?? $selected_form ); ?>
			(ID: <code><?php echo esc_html( $selected_form ); ?></code>)
		</p>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( WPPE_Bridge_Hubspot_Mapping_Page::ACTION_SAVE_FORM_MAPPING ); ?>"/>
			<input type="hidden" name="plugin" value="<?php echo esc_attr( $selected_plugin ); ?>"/>
			<input type="hidden" name="form" value="<?php echo esc_attr( $selected_form ); ?>"/>
			<?php wp_nonce_field( WPPE_Bridge_Hubspot_Mapping_Page::NONCE_FORM_MAPPING ); ?>

			<table class="widefat striped" style="max-width:800px">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Campo del formulario', 'wppe-bridge' ); ?></th>
						<th><?php esc_html_e( 'Property HubSpot', 'wppe-bridge' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					$wppe_bridge_form_fields = isset( $selected_form_data['fields'] ) && is_array( $selected_form_data['fields'] ) ? $selected_form_data['fields'] : array();
					$wppe_bridge_existing_f  = isset( $existing_mapping['fields'] ) && is_array( $existing_mapping['fields'] ) ? $existing_mapping['fields'] : array();
					foreach ( $wppe_bridge_form_fields as $wppe_bridge_field ) :
						$wppe_bridge_field_key   = is_array( $wppe_bridge_field ) ? (string) ( $wppe_bridge_field['key'] ?? '' ) : (string) $wppe_bridge_field;
						$wppe_bridge_field_label = is_array( $wppe_bridge_field ) ? (string) ( $wppe_bridge_field['label'] ?? $wppe_bridge_field_key ) : $wppe_bridge_field_key;
						$wppe_bridge_current     = (string) ( $wppe_bridge_existing_f[ $wppe_bridge_field_key ] ?? '' );
						?>
						<tr>
							<td>
								<code><?php echo esc_html( $wppe_bridge_field_key ); ?></code>
								<?php if ( $wppe_bridge_field_label !== $wppe_bridge_field_key ) : ?>
									<br/><span class="description"><?php echo esc_html( $wppe_bridge_field_label ); ?></span>
								<?php endif; ?>
							</td>
							<td>
								<select name="field_map[<?php echo esc_attr( $wppe_bridge_field_key ); ?>]">
									<option value=""><?php esc_html_e( '(no mapear)', 'wppe-bridge' ); ?></option>
									<?php foreach ( $payload_keys as $wppe_bridge_pk ) : ?>
										<option
											value="<?php echo esc_attr( $wppe_bridge_pk ); ?>"
											<?php selected( $wppe_bridge_current, $wppe_bridge_pk ); ?>
										>
											<?php echo esc_html( $wppe_bridge_pk ); ?>
											<?php if ( in_array( $wppe_bridge_pk, WPPE_Bridge_Hubspot_Mapping_Page::IDENTITY_KEYS, true ) ) : ?>
												*
											<?php endif; ?>
										</option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description" style="margin-top:0.5em">
				<?php esc_html_e( '* email es obligatorio. HubSpot lo usa como idProperty para el upsert — sin email mapeado, los leads no se pueden enviar.', 'wppe-bridge' ); ?>
			</p>

			<h3 style="margin-top:2em"><?php esc_html_e( 'Override per-form', 'wppe-bridge' ); ?></h3>

			<table class="form-table" role="presentation">
				<tbody>
					<tr>
						<th scope="row">
							<label for="form_lifecyclestage"><?php esc_html_e( 'Lifecyclestage para este form', 'wppe-bridge' ); ?></label>
						</th>
						<td>
							<select name="form_lifecyclestage" id="form_lifecyclestage">
								<?php foreach ( $wppe_bridge_lifecycle_choices as $wppe_bridge_choice ) : ?>
									<option
										value="<?php echo esc_attr( $wppe_bridge_choice ); ?>"
										<?php selected( $existing_mapping['lifecyclestage'] ?? '', $wppe_bridge_choice ); ?>
									>
										<?php
										if ( WPPE_Bridge_Hubspot_Mapping_Page::LIFECYCLESTAGE_INHERIT === $wppe_bridge_choice ) {
											esc_html_e( 'Heredar del default global', 'wppe-bridge' );
										} else {
											echo esc_html( $wppe_bridge_choice );
										}
										?>
									</option>
								<?php endforeach; ?>
							</select>
							<p class="description">
								<?php esc_html_e( 'Caso de uso: el global esta en `lead`, pero un form de "auditoria gratis" lo seteas como `marketingqualifiedlead` para saltar la etapa de qualification del SDR.', 'wppe-bridge' ); ?>
							</p>
						</td>
					</tr>
				</tbody>
			</table>

			<?php submit_button( __( 'Guardar mapeo de este form', 'wppe-bridge' ) ); ?>
		</form>
	<?php else : ?>
		<!-- Lista de forms detectados -->
		<p>
			<?php esc_html_e( 'Selecciona un formulario para configurar su mapeo individual.', 'wppe-bridge' ); ?>
		</p>
		<table class="widefat striped" style="max-width:800px">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Plugin', 'wppe-bridge' ); ?></th>
					<th><?php esc_html_e( 'Form', 'wppe-bridge' ); ?></th>
					<th><?php esc_html_e( 'Mapeo', 'wppe-bridge' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php
				$wppe_bridge_total_rows = 0;
				foreach ( $discovered as $wppe_bridge_plugin_slug => $wppe_bridge_forms ) :
					if ( ! is_array( $wppe_bridge_forms ) ) {
						continue;
					}
					foreach ( $wppe_bridge_forms as $wppe_bridge_form_item ) :
						++$wppe_bridge_total_rows;
						$wppe_bridge_fid         = (string) ( $wppe_bridge_form_item['id'] ?? '' );
						$wppe_bridge_ftitle      = (string) ( $wppe_bridge_form_item['title'] ?? $wppe_bridge_fid );
						$wppe_bridge_url         = add_query_arg(
							array(
								'page'   => WPPE_Bridge_Hubspot_Mapping_Page::PAGE_SLUG,
								'plugin' => $wppe_bridge_plugin_slug,
								'form'   => $wppe_bridge_fid,
							),
							admin_url( 'admin.php' )
						);
						$wppe_bridge_has_mapping = isset( $mapping[ $wppe_bridge_plugin_slug ][ $wppe_bridge_fid ] );
						?>
						<tr>
							<td><code><?php echo esc_html( $wppe_bridge_plugin_slug ); ?></code></td>
							<td>
								<a href="<?php echo esc_url( $wppe_bridge_url ); ?>">
									<?php echo esc_html( $wppe_bridge_ftitle ); ?>
								</a>
								<br/><span class="description">ID: <code><?php echo esc_html( $wppe_bridge_fid ); ?></code></span>
							</td>
							<td>
								<?php if ( $wppe_bridge_has_mapping ) : ?>
									<span style="color:#46b450">
										<span class="dashicons dashicons-yes-alt" aria-hidden="true"></span>
										<?php esc_html_e( 'Configurado', 'wppe-bridge' ); ?>
									</span>
								<?php else : ?>
									<span style="color:#888"><?php esc_html_e( 'Sin mapeo', 'wppe-bridge' ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
						<?php
					endforeach;
endforeach;
				?>
				<?php if ( 0 === $wppe_bridge_total_rows ) : ?>
					<tr>
						<td colspan="3"><em><?php esc_html_e( 'No se detectaron forms. Activa Fluent Forms / Gravity Forms / Elementor y crea al menos un form.', 'wppe-bridge' ); ?></em></td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>
