<?php
/**
 * Vista de la pagina admin "Configuracion GHL".
 *
 * Variables disponibles (provistas por WPPE_Bridge_Ghl_Settings_Page::render):
 *
 * @var bool   $has_token          True si hay PIT guardado.
 * @var string $location_id        Location ID actual (string vacio si no configurado).
 * @var bool   $create_opportunity Toggle "Crear Opportunity" (default ON, D-GHL-2).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Configuracion GoHighLevel', 'wppe-bridge' ); ?></h1>

	<div class="notice notice-info inline" role="status" style="margin-top:1em">
		<p>
			<?php
			echo wp_kses(
				sprintf(
					/* translators: %s: URL a Configuracion general */
					__( 'Esta sub-pagina configura solo los campos especificos de GoHighLevel. Para cambiar de CRM, dedup TTL, country code o la zona de peligro, ir a <a href="%s">Configuracion</a>.', 'wppe-bridge' ),
					esc_url( admin_url( 'admin.php?page=wppe-bridge-config' ) )
				),
				array( 'a' => array( 'href' => true ) )
			);
			?>
		</p>
	</div>

	<form method="post" action="options.php">
		<?php settings_fields( WPPE_Bridge_Ghl_Settings_Page::OPTION_GROUP ); ?>

		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row">
						<label for="wppe_bridge_ghl_token">
							<?php esc_html_e( 'Private Integration Token (PIT)', 'wppe-bridge' ); ?>
							<span style="color:#dc3232" title="<?php esc_attr_e( 'Obligatorio', 'wppe-bridge' ); ?>">*</span>
						</label>
					</th>
					<td>
						<input
							type="password"
							name="wppe_bridge_ghl_token"
							id="wppe_bridge_ghl_token"
							class="regular-text"
							autocomplete="new-password"
							placeholder="<?php echo $has_token ? esc_attr__( '(PIT configurado — dejar vacio para conservar)', 'wppe-bridge' ) : esc_attr__( '(sin configurar) — obligatorio', 'wppe-bridge' ); ?>"
							<?php echo $has_token ? '' : 'required'; ?>
						/>
						<p class="description">
							<?php
							if ( $has_token ) {
								echo '<span class="dashicons dashicons-yes-alt" aria-hidden="true" style="color:#46b450"></span> ';
								esc_html_e( 'PIT configurado. Dejar el campo vacio para conservar el actual.', 'wppe-bridge' );
							} else {
								esc_html_e( 'Generalo en GHL: Settings &rarr; Private Integrations &rarr; Create New Integration. Scopes minimos: contacts.write, contacts.readonly, locations.readonly, opportunities.write, opportunities.readonly. Los scopes NO se pueden agregar despues — hay que regenerar el token.', 'wppe-bridge' );
							}
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe_bridge_ghl_location_id">
							<?php esc_html_e( 'Location ID', 'wppe-bridge' ); ?>
							<span style="color:#dc3232" title="<?php esc_attr_e( 'Obligatorio', 'wppe-bridge' ); ?>">*</span>
						</label>
					</th>
					<td>
						<input
							type="text"
							name="wppe_bridge_ghl_location_id"
							id="wppe_bridge_ghl_location_id"
							class="regular-text"
							value="<?php echo esc_attr( $location_id ); ?>"
							placeholder="ve9EPM428h8vShlRW1KT"
							pattern="[a-zA-Z0-9]{8,64}"
						/>
						<p class="description">
							<?php esc_html_e( 'String alfanumerico de ~24 caracteres. Lo encontras en la URL del panel GHL (app.gohighlevel.com/v2/location/<LOCATION_ID>/...) o en Settings → Business Profile.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<?php esc_html_e( 'Crear Opportunity', 'wppe-bridge' ); ?>
					</th>
					<td>
						<label>
							<input
								type="checkbox"
								name="wppe_bridge_ghl_create_opportunity"
								value="1"
								<?php checked( $create_opportunity ); ?>
							/>
							<?php esc_html_e( 'Cuando llega un lead, crear tambien una Opportunity en el pipeline default', 'wppe-bridge' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'ON por default. Si lo activas, configura el pipeline + stage default en Mapeo GHL. Si activas el toggle pero no hay pipeline configurado, el contacto se crea normalmente y la Opportunity se omite (con warning en Logs).', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
			</tbody>
		</table>

		<?php submit_button( __( 'Guardar configuracion GHL', 'wppe-bridge' ) ); ?>
	</form>
</div>
