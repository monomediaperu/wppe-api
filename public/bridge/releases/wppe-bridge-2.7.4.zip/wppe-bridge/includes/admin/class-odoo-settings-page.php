<?php
/**
 * Pagina admin de configuracion Odoo.
 *
 * Sub-pagina especifica del destino Odoo (mismo patron que la
 * sub-pagina GHL: solo aparece en el menu cuando active = 'odoo'
 * via Admin_Menu). Persiste 5 options:
 *   - wppe_bridge_odoo_base_url     : URL base (ej. https://mycompany.odoo.com)
 *   - wppe_bridge_odoo_db           : nombre de la database
 *   - wppe_bridge_odoo_login        : email del usuario Odoo
 *   - wppe_bridge_odoo_api_key      : API key (sensible, password input)
 *   - wppe_bridge_odoo_default_type : 'opportunity' (default) | 'lead' (D-Odoo-8)
 *
 * NO persiste password — D-Odoo-9: solo API key, las keys se revocan
 * independiente desde Account Security.
 *
 * El uid resultante de la primera autenticacion se cachea en
 * `wppe_bridge_odoo_uid_cache` desde el OdooClient — esta pagina lo
 * INVALIDA cada vez que cualquiera de los 4 campos de auth cambia
 * (base_url/db/login/api_key), via `clear_uid_cache()`. Asi un cambio
 * de cuenta no queda usando el uid viejo.
 *
 * **Scope PR-1:** persistencia + invalidacion de cache. Test-connection
 * button llega en PR-2 cuando agreguemos el sync de catalogos (puede
 * usar el endpoint `/web/session/get_session_info` o un read trivial
 * sobre `res.users` como ping).
 *
 * Naming sec 4.3 CLAUDE.md: clase con prefijo `WPPE_Bridge_*` (no
 * `WPPE_Odoo_*`) — siguiendo el mismo criterio que las admin pages
 * GHL (`WPPE_Bridge_Ghl_Settings_Page`): admin pages son infra del
 * bridge que hospeda config CRM-especifica.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pagina admin de configuracion especifica de Odoo.
 */
final class WPPE_Bridge_Odoo_Settings_Page {

	/**
	 * Slug de la sub-pagina admin.
	 */
	public const PAGE_SLUG = 'wppe-bridge-odoo-config';

	/**
	 * Slug del settings group de WP Settings API.
	 */
	public const OPTION_GROUP = 'wppe_bridge_odoo_settings';

	/**
	 * Slug de la seccion principal.
	 */
	public const SECTION_GENERAL = 'wppe_bridge_odoo_section_general';

	/**
	 * Lista de option keys que registramos para WP Settings API,
	 * mapeadas a su sanitizer.
	 *
	 * @var array<string,string>
	 */
	public const OPTIONS = array(
		'wppe_bridge_odoo_base_url'     => 'sanitize_base_url',
		'wppe_bridge_odoo_db'           => 'sanitize_db',
		'wppe_bridge_odoo_login'        => 'sanitize_login',
		'wppe_bridge_odoo_api_key'      => 'sanitize_api_key',
		'wppe_bridge_odoo_default_type' => 'sanitize_default_type',
	);

	/**
	 * Subset de options cuyo cambio invalida el uid cache (cualquier
	 * cambio en credenciales o destino implica re-autenticar).
	 *
	 * @var array<int,string>
	 */
	private const AUTH_OPTIONS = array(
		'wppe_bridge_odoo_base_url',
		'wppe_bridge_odoo_db',
		'wppe_bridge_odoo_login',
		'wppe_bridge_odoo_api_key',
	);

	/**
	 * Bootstrap: registra hooks de Settings API. Llamado desde
	 * Plugin::register_hooks via admin_init.
	 *
	 * @return void
	 */
	public static function register_settings(): void {
		foreach ( self::OPTIONS as $option_key => $sanitize_cb ) {
			register_setting(
				self::OPTION_GROUP,
				$option_key,
				array(
					'sanitize_callback' => array( self::class, $sanitize_cb ),
				)
			);
		}
	}

	/**
	 * Renderiza la pagina de Settings Odoo.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$base_url     = (string) get_option( 'wppe_bridge_odoo_base_url', '' );
		$db           = (string) get_option( 'wppe_bridge_odoo_db', '' );
		$login        = (string) get_option( 'wppe_bridge_odoo_login', '' );
		$has_api_key  = '' !== (string) get_option( 'wppe_bridge_odoo_api_key', '' );
		$default_type = WPPE_Odoo_Destination::resolve_default_type();
		$uid_cached   = (int) get_option( 'wppe_bridge_odoo_uid_cache', 0 );

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/odoo-settings.php';
	}

	// ---------- sanitizers ----------

	/**
	 * Sanitiza la URL base. Trim + validacion scheme http/https. Si
	 * invalida o vacia, conserva el valor previo (mismo patron que
	 * GHL/Sperant).
	 *
	 * Si cambia respecto al valor previo, invalida el uid cache —
	 * cuenta distinta = uid distinto.
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_base_url( $value ): string {
		$new      = is_string( $value ) ? trim( $value ) : '';
		$previous = (string) get_option( 'wppe_bridge_odoo_base_url', '' );

		if ( '' === $new ) {
			if ( '' === $previous && function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_odoo_base_url',
					'wppe_bridge_odoo_base_url_required',
					__( 'La URL base de Odoo es obligatoria. Ej: https://mycompany.odoo.com', 'wppe-bridge' )
				);
			}
			return $previous;
		}

		// Quitar trailing slashes (el client los re-quita igual, pero
		// guardamos limpio).
		$new = rtrim( $new, '/' );

		// v2.5.10 — Validacion anti-SSRF (sec PR-2). Mismo helper que
		// Webhook destination: bloquea IPs internas (RFC1918, loopback,
		// link-local), IPv6 ULA, hostnames internos (.local, .internal,
		// localhost). Devs Odoo locales: filter `wppe_bridge_allow_internal_urls`.
		$check = WPPE_Bridge_Url_Validator::is_safe_outbound_url( $new );
		if ( ! $check['ok'] ) {
			if ( function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_odoo_base_url',
					'wppe_bridge_odoo_base_url_' . $check['reason'],
					sprintf(
						/* translators: %s = motivo del rechazo (private_ip, blocked_hostname, etc.). */
						__( 'La URL base de Odoo es invalida o no permitida (%s). Debe ser una URL https publica externa (ej. https://mycompany.odoo.com) — no se aceptan IPs internas ni hostnames de red privada.', 'wppe-bridge' ),
						esc_html( $check['reason'] )
					)
				);
			}
			return $previous;
		}

		if ( $new !== $previous ) {
			self::invalidate_uid_cache_on_credential_change();
		}

		return $new;
	}

	/**
	 * Sanitiza el nombre de la database. Trim. Aceptamos
	 * `[a-zA-Z0-9_-]` (subset Odoo + underscores). Min 1 char (no
	 * imponemos length max porque self-hosted puede tener nombres largos).
	 *
	 * Si invalida, conserva valor previo.
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_db( $value ): string {
		$new      = is_string( $value ) ? trim( $value ) : '';
		$previous = (string) get_option( 'wppe_bridge_odoo_db', '' );

		if ( '' === $new ) {
			if ( '' === $previous && function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_odoo_db',
					'wppe_bridge_odoo_db_required',
					__( 'El nombre de la database (db) es obligatorio. Para Odoo Online es el subdominio (mycompany de mycompany.odoo.com).', 'wppe-bridge' )
				);
			}
			return $previous;
		}

		if ( ! preg_match( '/^[a-zA-Z0-9_\-]{1,64}$/', $new ) ) {
			if ( function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_odoo_db',
					'wppe_bridge_odoo_db_invalid',
					__( 'El db solo puede contener letras, numeros, guiones y underscores. Maximo 64 caracteres.', 'wppe-bridge' )
				);
			}
			return $previous;
		}

		if ( $new !== $previous ) {
			self::invalidate_uid_cache_on_credential_change();
		}

		return $new;
	}

	/**
	 * Sanitiza el login. Trim + validacion email (Odoo siempre usa
	 * email como login en SaaS, y la mayoria de self-hosted tambien).
	 *
	 * Si invalida, conserva valor previo.
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_login( $value ): string {
		$new      = is_string( $value ) ? trim( $value ) : '';
		$previous = (string) get_option( 'wppe_bridge_odoo_login', '' );

		if ( '' === $new ) {
			if ( '' === $previous && function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_odoo_login',
					'wppe_bridge_odoo_login_required',
					__( 'El login (email del usuario Odoo) es obligatorio.', 'wppe-bridge' )
				);
			}
			return $previous;
		}

		if ( ! is_email( $new ) ) {
			if ( function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_odoo_login',
					'wppe_bridge_odoo_login_invalid',
					__( 'El login debe ser un email valido (ej. ventas@miempresa.com).', 'wppe-bridge' )
				);
			}
			return $previous;
		}

		if ( $new !== $previous ) {
			self::invalidate_uid_cache_on_credential_change();
		}

		return $new;
	}

	/**
	 * Sanitiza la API key. Trim. Si llega vacio, conserva el valor
	 * previo (mismo patron que tokens GHL/Sperant: no permitimos
	 * borrarla accidentalmente desde la UI; para borrar via WP-CLI:
	 * `wp option delete wppe_bridge_odoo_api_key`).
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_api_key( $value ): string {
		$new      = is_string( $value ) ? trim( $value ) : '';
		$previous = (string) get_option( 'wppe_bridge_odoo_api_key', '' );

		if ( '' === $new ) {
			if ( '' === $previous && function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_odoo_api_key',
					'wppe_bridge_odoo_api_key_required',
					__( 'La API Key de Odoo es obligatoria. Generarla en Preferences &rarr; Account Security &rarr; New API Key.', 'wppe-bridge' )
				);
			}
			return $previous;
		}

		if ( $new !== $previous ) {
			self::invalidate_uid_cache_on_credential_change();
		}

		return $new;
	}

	/**
	 * Sanitiza el `default_type`. Whitelist estricta contra
	 * `WPPE_Odoo_Destination::ALLOWED_TYPES`. Default 'opportunity'
	 * (D-Odoo-8). NO invalida uid cache — es config de mapeo, no
	 * credencial.
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_default_type( $value ): string {
		$new = is_string( $value ) ? trim( $value ) : '';
		if ( in_array( $new, WPPE_Odoo_Destination::ALLOWED_TYPES, true ) ) {
			return $new;
		}
		return WPPE_Odoo_Destination::DEFAULT_TYPE;
	}

	/**
	 * Limpia el uid cache cuando alguno de los 4 campos de credenciales
	 * cambio. Llamado desde los sanitizers afectados.
	 *
	 * Aislado para que sea facil testearlo y para que el OdooClient siga
	 * siendo el unico responsable de la mecanica del cache (esta clase
	 * solo dispara la invalidacion).
	 *
	 * @return void
	 */
	private static function invalidate_uid_cache_on_credential_change(): void {
		if ( class_exists( 'WPPE_Odoo_Client' ) ) {
			WPPE_Odoo_Client::clear_uid_cache();
		}
	}

	/**
	 * Helper publico: lista de option keys que invalidan el cache.
	 * Util para tests y para que un hipotetico admin tool externo sepa
	 * que cambios disparan re-auth.
	 *
	 * @return array<int,string>
	 */
	public static function get_auth_option_keys(): array {
		return self::AUTH_OPTIONS;
	}
}
