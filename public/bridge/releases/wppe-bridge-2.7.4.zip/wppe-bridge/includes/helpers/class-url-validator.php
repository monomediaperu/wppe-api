<?php
/**
 * URL validator anti-SSRF (v2.5.10, sec PR-2).
 *
 * Bloquea URLs que apunten a redes privadas / loopback / link-local /
 * IPv6 ULA. Aplicado a inputs de usuario que terminan en `wp_remote_*`
 * (Webhook destination URL, Odoo base URL).
 *
 * Sin esto, un admin (`manage_options`) puede usar el plugin para hacer
 * SSRF contra:
 * - `http://127.0.0.1:8080/internal-api` (servicios internos).
 * - `http://169.254.169.254/latest/meta-data/` (AWS / GCP metadata).
 * - `http://10.0.0.x` (LAN privada).
 *
 * Defensa en profundidad — el riesgo principal viene de un admin
 * comprometido o un fix de WP-core que escale privilegios.
 *
 * NOTA sobre DNS rebinding: validamos AL GUARDAR (sanitizer) y AL ENVIAR
 * (runtime). El segundo check defiende contra atacantes que sirven una
 * IP buena al validate y una mala al fetch real.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Helper estatico para validar URLs outbound.
 */
final class WPPE_Bridge_Url_Validator {

	/**
	 * Filter para devs/tests que necesitan apuntar a localhost (mock
	 * server, dev local). Si retorna true, `is_safe_outbound_url()`
	 * permite cualquier URL.
	 *
	 * Uso: en mu-plugin de dev o en `tests/bootstrap.php`:
	 *   add_filter( 'wppe_bridge_allow_internal_urls', '__return_true' );
	 */
	public const FILTER_ALLOW_INTERNAL = 'wppe_bridge_allow_internal_urls';

	/**
	 * Valida que una URL apunte a un host externo seguro.
	 *
	 * Reglas (todas deben pasar):
	 * 1. Tiene scheme `http` o `https` (no `file`, `gopher`, `dict`, etc.).
	 * 2. Tiene host no vacio.
	 * 3. El host NO matchea hostnames sospechosos (localhost, *.local, etc.).
	 * 4. Si el host es una IP literal, NO esta en rangos privados.
	 * 5. Si el host es nombre, NINGUNA de sus IPs resueltas esta en
	 *    rangos privados (defensa contra `app.example.com → 127.0.0.1`
	 *    y DNS rebinding parcial).
	 *
	 * @param string $url URL a validar.
	 * @return array{ok:bool,reason:string} `ok` true si segura; `reason`
	 *                                       describe por que falla si no.
	 */
	public static function is_safe_outbound_url( string $url ): array {
		// Validaciones de forma — SIEMPRE se aplican, incluso con
		// el filter de override (que solo bypassa el chequeo de IP
		// interna). Esto garantiza que javascript:/file:/etc.
		// se rechazen siempre, sin importar el environment.
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || empty( $parts['scheme'] ) ) {
			return array(
				'ok'     => false,
				'reason' => 'invalid_url',
			);
		}

		// Scheme se chequea ANTES de host — schemes como `javascript:`,
		// `file:`, `data:` no traen host pero queremos rechazarlos
		// explicitamente con `invalid_scheme` (mensaje mas util al
		// operador que "invalid_url").
		$scheme = strtolower( (string) $parts['scheme'] );
		if ( ! in_array( $scheme, array( 'http', 'https' ), true ) ) {
			return array(
				'ok'     => false,
				'reason' => 'invalid_scheme',
			);
		}

		if ( empty( $parts['host'] ) ) {
			return array(
				'ok'     => false,
				'reason' => 'invalid_url',
			);
		}

		// Override para devs / mock servers / tests. Bypassa SOLO el
		// chequeo de IP interna; el resto de validaciones siguen.
		$allow_internal = function_exists( 'apply_filters' )
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- constante con valor `wppe_bridge_allow_internal_urls`, prefijo correcto.
			&& (bool) apply_filters( self::FILTER_ALLOW_INTERNAL, false );

		$host = strtolower( (string) $parts['host'] );

		// Hostnames sospechosos por nombre — vetar incluso con override
		// si NO es "localhost" exacto (esos los mantenemos prohibidos en
		// prod absolutamente; los devs locales usan filter + 127.0.0.1
		// directo si necesitan apuntar a mock server).
		if ( ! $allow_internal && in_array( $host, self::blocked_hostnames(), true ) ) {
			return array(
				'ok'     => false,
				'reason' => 'blocked_hostname',
			);
		}
		if ( ! $allow_internal ) {
			foreach ( self::blocked_tlds() as $tld ) {
				if ( self::ends_with( $host, $tld ) ) {
					return array(
						'ok'     => false,
						'reason' => 'blocked_tld',
					);
				}
			}
		}

		// Si filter de override esta activo, ya pasamos scheme + form
		// minima — saltamos chequeo de IP interna. Retornamos OK con
		// reason que aclara que fue bypass de filter (telemetria util).
		if ( $allow_internal ) {
			return array(
				'ok'     => true,
				'reason' => 'filter_override',
			);
		}

		// Si el host es IP literal, validar directamente.
		if ( false !== filter_var( $host, FILTER_VALIDATE_IP ) ) {
			if ( self::is_private_ip( $host ) ) {
				return array(
					'ok'     => false,
					'reason' => 'private_ip',
				);
			}
			return array(
				'ok'     => true,
				'reason' => 'ok',
			);
		}

		// Es un hostname — resolver y validar todas las IPs.
		$ips = self::resolve_host( $host );
		if ( empty( $ips ) ) {
			// No pudo resolver. Conservador: rechazamos. Si el operador
			// pega una URL valida pero el DNS server falla momentaneamente,
			// puede reintentar — preferimos eso a permitir un host que
			// despues resuelve a 127.0.0.1.
			return array(
				'ok'     => false,
				'reason' => 'dns_resolve_failed',
			);
		}
		foreach ( $ips as $ip ) {
			if ( self::is_private_ip( $ip ) ) {
				return array(
					'ok'     => false,
					'reason' => 'resolves_to_private_ip',
				);
			}
		}

		return array(
			'ok'     => true,
			'reason' => 'ok',
		);
	}

	/**
	 * Lista de hostnames literales bloqueados (case-insensitive).
	 *
	 * @return string[]
	 */
	private static function blocked_hostnames(): array {
		return array(
			'localhost',
			'ip6-localhost',
			'ip6-loopback',
			'broadcasthost',
		);
	}

	/**
	 * Lista de TLDs / sufijos bloqueados (case-insensitive, sin punto inicial).
	 * Cubren convenciones comunes de redes internas y mDNS.
	 *
	 * @return string[]
	 */
	private static function blocked_tlds(): array {
		return array(
			'.local',
			'.localhost',
			'.internal',
			'.intranet',
			'.lan',
			'.test',
			'.invalid',
		);
	}

	/**
	 * True si la IP esta en rangos privados / link-local / loopback /
	 * documentation / IPv6 ULA o multicast.
	 *
	 * Usa el filter de PHP que cubre IANA reserved + private + RFC1918.
	 * Agrega manualmente link-local (169.254.0.0/16) y bloque 0.0.0.0/8
	 * que el filter NO bloquea por default.
	 *
	 * @param string $ip IP literal v4 o v6.
	 * @return bool
	 */
	public static function is_private_ip( string $ip ): bool {
		// FILTER_VALIDATE_IP con flags = devuelve false si la IP esta
		// en private / reserved range. Equivalente a "es una IP PUBLICA
		// y NO esta reservada".
		$public = filter_var(
			$ip,
			FILTER_VALIDATE_IP,
			FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
		);
		if ( false === $public ) {
			return true;
		}

		// Defensa extra: el filter de PHP no bloquea 0.0.0.0/8 ni
		// algunos rangos modernos. Chequeo manual.
		$packed = inet_pton( $ip );
		if ( false === $packed ) {
			return true; // No parseable -> rechazar conservador.
		}

		// IPv4.
		if ( strlen( $packed ) === 4 ) {
			$long = ip2long( $ip );
			if ( false === $long ) {
				return true;
			}
			// 0.0.0.0/8 — el filter NO bloquea.
			if ( ( $long & 0xff000000 ) === 0 ) {
				return true;
			}
			return false;
		}

		// IPv6 — el filter de PHP cubre ::1, fc00::/7, fe80::/10.
		// Chequeo manual de ff00::/8 (multicast) y rangos discovery.
		$first_byte = ord( $packed[0] );
		if ( 0xff === $first_byte ) {
			return true; // multicast.
		}

		return false;
	}

	/**
	 * Resuelve un hostname a todas sus IPs (v4 y v6).
	 *
	 * @param string $host Hostname.
	 * @return string[]
	 */
	private static function resolve_host( string $host ): array {
		$out = array();

		// A records (IPv4).
		if ( function_exists( 'gethostbynamel' ) ) {
			$v4 = gethostbynamel( $host );
			if ( is_array( $v4 ) ) {
				$out = array_merge( $out, $v4 );
			}
		}

		// AAAA records (IPv6) — gethostbynamel solo v4. Si dns_get_record
		// esta disponible, lo usamos para IPv6.
		if ( function_exists( 'dns_get_record' ) ) {
			$records = @dns_get_record( $host, DNS_AAAA ); // phpcs:ignore WordPress.PHP.NoSilencedErrors -- DNS lookups pueden fallar silenciosamente, no queremos warnings al log.
			if ( is_array( $records ) ) {
				foreach ( $records as $r ) {
					if ( isset( $r['ipv6'] ) ) {
						$out[] = (string) $r['ipv6'];
					}
				}
			}
		}

		return array_unique( $out );
	}

	/**
	 * Helper compat PHP 7.x — `str_ends_with` solo existe desde 8.0.
	 * En tests con stubs y matrix 8.1+ deberiamos poder usar la builtin,
	 * pero algunos environments WP corren PHP 8.0 todavia.
	 *
	 * @param string $haystack Cadena.
	 * @param string $needle   Sufijo.
	 * @return bool
	 */
	private static function ends_with( string $haystack, string $needle ): bool {
		if ( function_exists( 'str_ends_with' ) ) {
			return str_ends_with( $haystack, $needle );
		}
		$len = strlen( $needle );
		if ( 0 === $len ) {
			return true;
		}
		return substr( $haystack, -$len ) === $needle;
	}
}
