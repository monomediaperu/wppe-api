<?php
/**
 * Destino: HubSpot CRM (objeto `Contacts`).
 *
 * Envuelve `WPPE_Hubspot_Client::upsert_contact()` (capa HTTP) y
 * traduce su retorno al `Destination_Result` uniforme.
 *
 * **Scope v2.6.0 PR-1 (D-HS-1/2/3):** mapeo minimo. Inyecta:
 *  - `lifecyclestage` desde la option global (default 'lead' por
 *    convencion HubSpot, override per-form llega en PR-3).
 *  - `hubspot_owner_id` desde la option global (string id del owner).
 *  - `email` (obligatorio en HubSpot para upsert via `idProperty`).
 *
 * Strippea keys upstream de otros destinos (fname/lname/source_id/...
 * de Sperant, locationId/pipelineId/... de GHL, type/team_id/... de
 * Odoo) para que HubSpot no reciba properties que no entiende. HubSpot
 * es relativamente permisivo (acepta custom properties que no existen
 * todavia, las crea on-the-fly), pero por higiene mantenemos el strip.
 *
 * Catalogos (owners, pipelines, lifecyclestage enum, custom properties)
 * y mapeo per-form son scope de PR-2/PR-3.
 *
 * Naming sec 4.3 CLAUDE.md: clase `WPPE_Hubspot_Destination` (no
 * `WPPE_Bridge_Hubspot_Destination`) — mismo patron que
 * `WPPE_Ghl_Destination` y `WPPE_Odoo_Destination`.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Destination que envia leads a HubSpot CRM via Contacts API v3.
 */
final class WPPE_Hubspot_Destination implements WPPE_Bridge_Destination_Interface {

	public const SLUG  = 'hubspot';
	public const LABEL = 'HubSpot';

	/**
	 * Lifecyclestage default cuando el cliente no configuro la option.
	 * 'lead' es el siguiente estado despues de 'subscriber' en el funnel
	 * estandar de HubSpot — apropiado para alguien que llena un form
	 * pero todavia no esta calificado.
	 */
	public const DEFAULT_LIFECYCLESTAGE = 'lead';

	/**
	 * Whitelist de lifecyclestage values aceptados por HubSpot.
	 * Validado contra docs HubSpot 2026-05.
	 *
	 * @var array<int,string>
	 */
	public const ALLOWED_LIFECYCLESTAGES = array(
		'subscriber',
		'lead',
		'marketingqualifiedlead',
		'salesqualifiedlead',
		'opportunity',
		'customer',
		'evangelist',
		'other',
	);

	/**
	 * Slug unico del destino.
	 *
	 * @return string
	 */
	public static function slug(): string {
		return self::SLUG;
	}

	/**
	 * Label legible del destino para el dropdown admin.
	 *
	 * @return string
	 */
	public static function label(): string {
		return self::LABEL;
	}

	/**
	 * Envia el lead a HubSpot via `WPPE_Hubspot_Client::upsert_contact`.
	 *
	 * @param array $payload Payload ya normalizado por el adapter.
	 * @return WPPE_Bridge_Destination_Result
	 */
	public function send( array $payload ): WPPE_Bridge_Destination_Result {
		// v2.6.0 PR-3: per-form field_map + lifecyclestage override.
		// Leemos el plugin + form id de las meta keys del bridge para
		// buscar el mapeo correspondiente. Si no hay mapeo guardado para
		// este form, `map_payload_to_properties` cae al fallback (sin
		// rename de keys, solo defaults globales).
		$form_plugin = isset( $payload['_form_plugin'] ) ? (string) $payload['_form_plugin'] : '';
		$form_id     = isset( $payload['_form_id'] ) ? (string) $payload['_form_id'] : '';

		$properties = self::map_payload_to_properties( $payload, $form_plugin, $form_id );

		// HubSpot requiere `email` para upsert (lo usamos como idProperty).
		// Si no llega, fallar permanente — Worker no reintentara, alerta
		// al admin para que ajuste el field mapping.
		if ( ! isset( $properties['email'] ) || '' === trim( (string) $properties['email'] ) ) {
			return new WPPE_Bridge_Destination_Result(
				false,
				0,
				array(),
				__( 'HubSpot requiere `email` en el payload (se usa como id natural para upsert). Mapea un campo del form a `email` en Mapeo HubSpot.', 'wppe-bridge' ),
				true
			);
		}

		$response = WPPE_Hubspot_Client::upsert_contact( $properties );

		$success   = WPPE_Hubspot_Client::ERROR_CLASS_SUCCESS === $response['error_class'];
		$permanent = WPPE_Hubspot_Client::ERROR_CLASS_PERMANENT === $response['error_class'];
		$error     = $success ? null : self::error_message_from_response( $response );

		return new WPPE_Bridge_Destination_Result(
			$success,
			(int) $response['status'],
			is_array( $response['body'] ) ? $response['body'] : array(),
			$error,
			$permanent
		);
	}

	/**
	 * Mapea el payload normalizado del bridge al shape de HubSpot
	 * Contacts (`{properties: {firstname, lastname, email, phone, ...}}`).
	 *
	 * V2.6.0 PR-3: agregado field_map per-form + lifecyclestage override
	 * per-form + UTMs hibridos (custom utm_* + best-effort hs_analytics_source).
	 *
	 * Pasos:
	 *  1. Aplicar field_map del form (si existe en
	 *     `wppe_bridge_hubspot_field_mapping[plugin][form_id].fields`):
	 *     renombra keys del payload segun mapeo del cliente. Ej.
	 *     `your_name` (raw del form) -> `firstname` (HubSpot property).
	 *  2. Mapeo Sperant-shape (`fname`/`lname`) -> HubSpot-shape
	 *     (`firstname`/`lastname`) si el adapter o el field_map no
	 *     lo hicieron ya.
	 *  3. Inyectar UTMs como custom properties (utm_source, utm_medium,
	 *     etc.) — HubSpot las crea on-the-fly. Adicionalmente, best-effort
	 *     match para `hs_analytics_source` enum (PAID_SEARCH / SOCIAL_MEDIA /
	 *     EMAIL_MARKETING / etc). Si match falla, solo van las custom.
	 *  4. Strip de keys que HubSpot no entiende (Sperant/GHL/Odoo-specific,
	 *     meta bridge).
	 *  5. Inyectar defaults globales: lifecyclestage (con override per-form
	 *     si configurado), `hubspot_owner_id`.
	 *
	 * Properties HubSpot que sobreviven: `email`, `firstname`, `lastname`,
	 * `phone`, `mobilephone`, `company`, `website`, `jobtitle`, `address`,
	 * `city`, `state`, `zip`, `country`, `message`, + custom utm_*, gclid,
	 * fbclid, + hs_analytics_source si hay match.
	 *
	 * @param array  $payload     Payload pre-clean.
	 * @param string $form_plugin Slug del form plugin (`fluent`/`gravity`/`elementor`).
	 *                            Vacio = no aplicar field_map per-form.
	 * @param string $form_id     ID del form. Vacio = no aplicar field_map per-form.
	 * @return array<string,mixed>
	 */
	public static function map_payload_to_properties( array $payload, string $form_plugin = '', string $form_id = '' ): array {
		// PR-3 step 1: aplicar field_map per-form si existe.
		$payload = self::apply_form_field_map( $payload, $form_plugin, $form_id );

		// PR-3 step 3 (parcial): inyectar match heuristico de
		// `hs_analytics_source` ANTES del strip, porque usamos las UTMs
		// originales para calcularlo. El strip las saca, pero las dejamos
		// como custom properties luego (ver mas abajo).
		$analytics_source = self::resolve_hs_analytics_source( $payload );

		// PR-3 step 3 (custom): UTMs como custom properties con nombre
		// estandar de industria. HubSpot las crea on-the-fly.
		$utms_custom = self::extract_utms_as_custom_properties( $payload );

		// Step 4: strip de keys que HubSpot no entiende.
		$values = self::strip_internal_and_other_destination_keys( $payload );

		// Re-inyectar UTMs como custom (las strippeamos arriba pero las
		// queremos mandar con su nombre original).
		foreach ( $utms_custom as $key => $value ) {
			if ( ! isset( $values[ $key ] ) ) {
				$values[ $key ] = $value;
			}
		}

		// hs_analytics_source si hubo match.
		if ( '' !== $analytics_source && ! isset( $values['hs_analytics_source'] ) ) {
			$values['hs_analytics_source'] = $analytics_source;
		}

		// Step 2: mapeo Sperant-shape -> HubSpot-shape (defensivo).
		if ( isset( $payload['fname'] ) && ! isset( $values['firstname'] ) ) {
			$values['firstname'] = trim( (string) $payload['fname'] );
		}
		if ( isset( $payload['lname'] ) && ! isset( $values['lastname'] ) ) {
			$values['lastname'] = trim( (string) $payload['lname'] );
		}

		// Step 5: defaults globales. Lifecyclestage tiene override
		// per-form — leemos el entry guardado y si trae value distinto
		// a 'inherit', tiene prioridad sobre el global.
		$lifecyclestage = self::resolve_form_lifecyclestage( $form_plugin, $form_id );
		if ( '' !== $lifecyclestage && ! isset( $values['lifecyclestage'] ) ) {
			$values['lifecyclestage'] = $lifecyclestage;
		}

		$owner_id = (string) get_option( 'wppe_bridge_hubspot_default_owner_id', '' );
		if ( '' !== $owner_id && ! isset( $values['hubspot_owner_id'] ) ) {
			$values['hubspot_owner_id'] = $owner_id;
		}

		return $values;
	}

	/**
	 * V2.6.0 PR-3: aplica el field_map guardado en
	 * `wppe_bridge_hubspot_field_mapping[plugin][form_id].fields`.
	 *
	 * Renombra keys del payload `raw form field name -> HubSpot property`.
	 * Las keys NO-mapeadas pasan tal cual al output. Las keys mapeadas a
	 * un value nuevo se renombran y la original se descarta (para evitar
	 * duplicacion).
	 *
	 * Ejemplo: payload tiene `your-email`. field_map dice
	 * `your-email => email`. Output: `email` con el value original.
	 *
	 * @param array  $payload     Payload original.
	 * @param string $form_plugin Slug del form plugin.
	 * @param string $form_id     ID del form.
	 * @return array Payload con keys renombradas.
	 */
	public static function apply_form_field_map( array $payload, string $form_plugin, string $form_id ): array {
		if ( '' === $form_plugin || '' === $form_id ) {
			return $payload;
		}
		$mapping = get_option( 'wppe_bridge_hubspot_field_mapping', array() );
		if ( ! is_array( $mapping ) ) {
			return $payload;
		}
		$entry = $mapping[ $form_plugin ][ $form_id ] ?? null;
		if ( ! is_array( $entry ) || ! isset( $entry['fields'] ) || ! is_array( $entry['fields'] ) ) {
			return $payload;
		}

		$fields = $entry['fields'];
		$out    = $payload;

		foreach ( $fields as $form_field => $hs_property ) {
			$form_field  = (string) $form_field;
			$hs_property = (string) $hs_property;
			if ( '' === $form_field || '' === $hs_property ) {
				continue;
			}
			if ( ! isset( $out[ $form_field ] ) ) {
				continue;
			}
			// No sobreescribir si el target ya esta seteado upstream
			// (el adapter puede haber mapeado fname -> firstname antes).
			if ( ! isset( $out[ $hs_property ] ) ) {
				$out[ $hs_property ] = $out[ $form_field ];
			}
			// Descartar la key original solo si renombramos (no si era
			// la misma key — ej. el form ya tenia `email` y el mapeo
			// dice `email -> email`, no descartar).
			if ( $form_field !== $hs_property ) {
				unset( $out[ $form_field ] );
			}
		}

		return $out;
	}

	/**
	 * V2.6.0 PR-3: resuelve el lifecyclestage para un form especifico.
	 *
	 * Lee el entry guardado en
	 * `wppe_bridge_hubspot_field_mapping[plugin][form_id].lifecyclestage`.
	 * Si el value es `inherit` (default), cae al global. Si es un value
	 * valido del enum, tiene prioridad.
	 *
	 * @param string $form_plugin Slug del form plugin.
	 * @param string $form_id     ID del form.
	 * @return string Lifecyclestage value, o vacio si no hay nada que inyectar.
	 */
	public static function resolve_form_lifecyclestage( string $form_plugin, string $form_id ): string {
		if ( '' === $form_plugin || '' === $form_id ) {
			return self::resolve_default_lifecyclestage();
		}
		$mapping = get_option( 'wppe_bridge_hubspot_field_mapping', array() );
		if ( ! is_array( $mapping ) ) {
			return self::resolve_default_lifecyclestage();
		}
		$entry = $mapping[ $form_plugin ][ $form_id ] ?? null;
		if ( ! is_array( $entry ) ) {
			return self::resolve_default_lifecyclestage();
		}
		$value = isset( $entry['lifecyclestage'] ) ? (string) $entry['lifecyclestage'] : '';
		if ( '' === $value || 'inherit' === $value ) {
			return self::resolve_default_lifecyclestage();
		}
		// Aceptamos cualquier value no-inherit como override — el sanitizer
		// del mapping page ya valida contra el enum dinamico.
		// Defensa adicional: si por alguna razon el value quedo invalido
		// (ej. catalogo cambio), caer al default.
		if ( in_array( $value, self::ALLOWED_LIFECYCLESTAGES, true ) ) {
			return $value;
		}
		// Aceptamos tambien values custom del enum dinamico del cliente
		// (HubSpot permite custom values en lifecyclestage para portals
		// con configuracion avanzada). Si llego aqui, asumimos valido
		// porque el sanitizer del mapping ya filtro contra el catalogo.
		return $value;
	}

	/**
	 * V2.6.0 PR-3: extrae UTMs del payload como custom properties.
	 * Mantiene los nombres estandar de industria (`utm_source`,
	 * `utm_medium`, `utm_campaign`, `utm_term`, `utm_content`, `gclid`,
	 * `fbclid`). HubSpot las crea on-the-fly como contact properties.
	 *
	 * No incluye `fbp` ni `landing_url` — esos son meta del Bridge para
	 * Meta CAPI, no UTMs propiamente.
	 *
	 * @param array $payload Payload original.
	 * @return array<string,string>
	 */
	public static function extract_utms_as_custom_properties( array $payload ): array {
		$out  = array();
		$keys = array( 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'gclid', 'fbclid' );
		foreach ( $keys as $k ) {
			if ( isset( $payload[ $k ] ) && '' !== trim( (string) $payload[ $k ] ) ) {
				$out[ $k ] = (string) $payload[ $k ];
			}
		}
		return $out;
	}

	/**
	 * V2.6.0 PR-3: best-effort matching de UTMs a `hs_analytics_source` enum.
	 *
	 * HubSpot tiene un property interno `hs_analytics_source` con enum
	 * controlado: ORGANIC_SEARCH / PAID_SEARCH / PAID_SOCIAL / SOCIAL_MEDIA /
	 * EMAIL_MARKETING / REFERRALS / OTHER_CAMPAIGNS / DIRECT_TRAFFIC / OFFLINE.
	 * No acepta values arbitrarios — un POST con `hs_analytics_source=google`
	 * fallaria. Por eso aplicamos heuristica para mapear el `utm_source` +
	 * `utm_medium` del visitante al enum.
	 *
	 * Heuristica (orden de prioridad):
	 *  - `utm_medium` contiene "email"/"newsletter" -> EMAIL_MARKETING.
	 *  - `utm_medium` contiene "referral" -> REFERRALS.
	 *  - `utm_source` "direct" -> DIRECT_TRAFFIC.
	 *  - `utm_source` "google" + `utm_medium` "cpc"/"paid"/"ads" -> PAID_SEARCH.
	 *  - `utm_source` "google" sin medium o organic -> ORGANIC_SEARCH.
	 *  - `utm_source` "facebook"/"fb"/"instagram"/"ig" + medium paid -> PAID_SOCIAL.
	 *  - `utm_source` social conocido (facebook/instagram/linkedin/twitter/x/tiktok) -> SOCIAL_MEDIA.
	 *  - Si hay alguna UTM pero ninguna regla matchea -> OTHER_CAMPAIGNS.
	 *  - Si no hay UTMs -> vacio (NO inyectar — HubSpot usa su tracking
	 *    nativo).
	 *
	 * @param array $payload Payload original con utm_* keys.
	 * @return string Value del enum o vacio si no hay match.
	 */
	public static function resolve_hs_analytics_source( array $payload ): string {
		$source = strtolower( trim( (string) ( $payload['utm_source'] ?? '' ) ) );
		$medium = strtolower( trim( (string) ( $payload['utm_medium'] ?? '' ) ) );

		if ( '' === $source && '' === $medium ) {
			return ''; // No hay UTMs — HubSpot usa tracking nativo.
		}

		// Email marketing — el medium suele ser explicito.
		if ( '' !== $medium && ( false !== strpos( $medium, 'email' ) || false !== strpos( $medium, 'newsletter' ) ) ) {
			return 'EMAIL_MARKETING';
		}

		// Referrals.
		if ( '' !== $medium && false !== strpos( $medium, 'referral' ) ) {
			return 'REFERRALS';
		}

		// Direct traffic — source == 'direct' o vacio con medium 'direct'.
		if ( 'direct' === $source || 'direct' === $medium || '(direct)' === $source ) {
			return 'DIRECT_TRAFFIC';
		}

		// Paid search vs organic — clasico Google.
		$is_paid_medium = ( '' !== $medium )
			&& ( false !== strpos( $medium, 'cpc' )
				|| false !== strpos( $medium, 'paid' )
				|| false !== strpos( $medium, 'ads' )
				|| false !== strpos( $medium, 'ppc' )
				|| false !== strpos( $medium, 'sem' ) );

		$is_search_engine = in_array( $source, array( 'google', 'bing', 'yahoo', 'duckduckgo', 'yandex', 'baidu' ), true );
		if ( $is_search_engine ) {
			if ( $is_paid_medium ) {
				return 'PAID_SEARCH';
			}
			return 'ORGANIC_SEARCH';
		}

		// Social — distinguir paid vs organic.
		$social_sources = array( 'facebook', 'fb', 'instagram', 'ig', 'linkedin', 'twitter', 'x', 'x.com', 'tiktok', 'youtube', 'pinterest', 'reddit', 'snapchat' );
		if ( in_array( $source, $social_sources, true ) ) {
			if ( $is_paid_medium ) {
				return 'PAID_SOCIAL';
			}
			return 'SOCIAL_MEDIA';
		}

		// Fallback: hay UTMs pero no matchearon a un canal especifico.
		return 'OTHER_CAMPAIGNS';
	}

	/**
	 * Lee la option `wppe_bridge_hubspot_default_lifecyclestage` con
	 * whitelist. Default 'lead'. Cualquier valor fuera de
	 * `ALLOWED_LIFECYCLESTAGES` cae al default — defensivo.
	 *
	 * Caso especial: si la option esta vacia (admin no la configuro
	 * todavia), NO inyectamos lifecyclestage — HubSpot lo deja en su
	 * default de la portal config. Esto es distinto a Odoo donde
	 * SIEMPRE inyectamos `type`.
	 *
	 * @return string Vacio si no hay configuracion; un value valido si si.
	 */
	public static function resolve_default_lifecyclestage(): string {
		$value = (string) get_option( 'wppe_bridge_hubspot_default_lifecyclestage', '' );
		if ( '' === $value ) {
			return '';
		}
		if ( in_array( $value, self::ALLOWED_LIFECYCLESTAGES, true ) ) {
			return $value;
		}
		return self::DEFAULT_LIFECYCLESTAGE;
	}

	/**
	 * Lista de keys que HubSpot NO entiende y que llegan al payload
	 * porque otros destinos las usan o porque son meta del bridge.
	 * Categorias:
	 *  - Meta keys del bridge (`_form_*`, `_submission_id`).
	 *  - Sperant-specific (input_channel_id, source_id, interest_type_id,
	 *    project_id, fname, lname, document).
	 *  - GHL-specific (locationId, pipelineId, customFields, tags).
	 *  - Odoo-specific (contact_name, partner_name, type, team_id,
	 *    user_id, tag_ids, source_id, medium_id, campaign_id, country_id,
	 *    function, email_from, description, street).
	 *  - Meta CAPI-only (client_ip, client_user_agent, fbp, fbclid,
	 *    landing_url, gclid).
	 *  - UTM flat — PR-3 las inyectara como `hs_analytics_*` properties.
	 *    En PR-1 las strippeamos.
	 *
	 * Las que se preservan (van al shape `properties` HubSpot):
	 *  email, firstname, lastname, phone, mobilephone, company,
	 *  website, jobtitle, address, city, state, zip, country, message,
	 *  lifecyclestage, hubspot_owner_id, hs_lead_status.
	 *
	 * @return array<int,string>
	 */
	public static function get_strippable_keys(): array {
		return array(
			// Meta keys del bridge.
			'_form_plugin',
			'_form_id',
			'_submission_id',
			// Sperant-specific.
			'input_channel_id',
			'source_id',
			'interest_type_id',
			'project_id',
			'fname',
			'lname',
			'document',
			// GHL-specific.
			'locationId',
			'pipelineId',
			'pipelineStageId',
			'customFields',
			'tags',
			// Odoo-specific.
			'type',
			'team_id',
			'user_id',
			'tag_ids',
			'medium_id',
			'campaign_id',
			'country_id',
			'function',
			'email_from',
			'contact_name',
			'partner_name',
			'description',
			'street',
			// UTMs: v2.6.0 PR-3 las mantenemos como custom properties
			// (HubSpot las crea on-the-fly). Adicionalmente PR-3 las usa
			// para resolver `hs_analytics_source` con heuristica.
			// Strippeamos solo `fbp` y `landing_url` que son meta Bridge
			// (Meta CAPI) y no aportan a HubSpot.
			'fbp',
			'landing_url',
			// Meta CAPI-only.
			'client_ip',
			'client_user_agent',
		);
	}

	/**
	 * Quita las keys de `get_strippable_keys()` del payload.
	 *
	 * @param array $payload Payload pre-clean.
	 * @return array
	 */
	private static function strip_internal_and_other_destination_keys( array $payload ): array {
		foreach ( self::get_strippable_keys() as $key ) {
			unset( $payload[ $key ] );
		}
		return $payload;
	}

	/**
	 * Pasos de setup especificos de HubSpot para la pagina "Inicio".
	 *
	 * @return array<int,array{key:string,title:string,description:string,action_url:?string,action_label:?string}>
	 */
	public static function setup_guide(): array {
		$config_url = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=wppe-bridge-hubspot-config' ) : '';
		return array(
			array(
				'key'          => 'hubspot_private_app',
				'title'        => __( 'Como crear el Private App access token', 'wppe-bridge' ),
				'description'  => __( 'En el panel HubSpot del cliente: <strong>Settings (icono engranaje) &rarr; Integrations &rarr; Private Apps &rarr; Create a private app</strong>. Asignar un nombre descriptivo (ej. "WP.pe Bridge"). Scopes minimos: <code>crm.objects.contacts.read</code>, <code>crm.objects.contacts.write</code>, <code>crm.schemas.contacts.read</code>. Crear y copiar el access token (se muestra solo una vez — Mono Media lo guarda en 1Password antes de pegarlo aqui, D9 CLAUDE.md).', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Ir a Configuracion HubSpot', 'wppe-bridge' ),
			),
			array(
				'key'          => 'hubspot_lifecyclestage',
				'title'        => __( 'Configurar lifecyclestage default', 'wppe-bridge' ),
				'description'  => __( 'Cuando un visitante llena un form, su contact en HubSpot se crea con el lifecyclestage que configures aqui. <code>lead</code> es lo apropiado para la mayoria de los casos (alguien interesado pero no calificado todavia). Para campanas mas avanzadas pueden usarse <code>marketingqualifiedlead</code> o <code>salesqualifiedlead</code> directamente. Override per-form llegara en una version futura.', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Ir a Configuracion HubSpot', 'wppe-bridge' ),
			),
			array(
				'key'          => 'hubspot_owner_id',
				'title'        => __( 'Asignar un Owner por default (opcional)', 'wppe-bridge' ),
				'description'  => __( 'Si quieres que todos los leads del web caigan asignados a un vendedor especifico, ingresa su <strong>Owner ID</strong> aqui. Se obtiene de <strong>Settings &rarr; Users &amp; Teams &rarr; Users</strong> (el ID aparece en la URL al editar el usuario). Si lo dejas vacio, HubSpot aplica las reglas de assignment configuradas en el portal (round-robin, territorio, etc).', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Ir a Configuracion HubSpot', 'wppe-bridge' ),
			),
			array(
				'key'          => 'hubspot_verify_lead',
				'title'        => __( 'Como verificar un lead en el panel HubSpot', 'wppe-bridge' ),
				'description'  => __( 'Despues de un lead de prueba con prefijo <code>__BRIDGE_TEST__</code>:<br><br>1. Login al panel HubSpot del cliente.<br>2. Ir a <strong>Contacts &rarr; All contacts</strong>.<br>3. Buscar por email <code>bridge-test-*@mono.media</code>.<br>4. Verificar que el contact aparezca con email, firstname, lastname, phone correctos, y lifecyclestage = lead.<br><br>HubSpot dedupea automaticamente por email (gracias a `idProperty=email` en el upsert) — un mismo email reenviado 5 veces resulta en UN contact con la ultima data, no 5 contacts.', 'wppe-bridge' ),
				'action_url'   => null,
				'action_label' => null,
			),
		);
	}

	/**
	 * Construye un mensaje legible a partir del response (solo cuando
	 * fallo). HubSpot retorna errores con shape:
	 *   { status: "error", category: "VALIDATION_ERROR", message: "...", correlationId: "..." }
	 * Preferimos `message` para mostrar al admin, fallback a `category`,
	 * fallback a HTTP status.
	 *
	 * Caso especial: el batch endpoint puede retornar 200/207 con
	 * `errors[].message` cuando algun input fallo. Lo manejamos tambien.
	 *
	 * @param array $response Response uniforme del HubspotClient.
	 * @return string
	 */
	private static function error_message_from_response( array $response ): string {
		$body = is_array( $response['body'] ?? null ) ? $response['body'] : array();

		// Errores top-level (4xx clasicos).
		if ( isset( $body['message'] ) && is_string( $body['message'] ) && '' !== $body['message'] ) {
			return $body['message'];
		}

		// Errores parciales del batch endpoint.
		if ( isset( $body['errors'] ) && is_array( $body['errors'] ) && ! empty( $body['errors'] ) ) {
			$first = $body['errors'][0];
			if ( is_array( $first ) && isset( $first['message'] ) && is_string( $first['message'] ) ) {
				return $first['message'];
			}
		}

		// Fallback a category.
		if ( isset( $body['category'] ) && is_string( $body['category'] ) && '' !== $body['category'] ) {
			return $body['category'];
		}

		$status = (int) ( $response['status'] ?? 0 );
		if ( 0 === $status ) {
			return 'Network error or timeout';
		}
		return sprintf( 'HTTP %d', $status );
	}
}
