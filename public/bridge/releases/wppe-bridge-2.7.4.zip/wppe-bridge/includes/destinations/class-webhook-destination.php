<?php
/**
 * Destino: Webhook generico.
 *
 * Hace `POST $url` con un JSON estructurado del lead. El cliente del
 * lado del CRM/tool decide como procesar ese payload — puede ser:
 *  - Odoo v17+: Automation Rule con trigger "On Webhook" que crea
 *    `crm.lead` mapeando los campos del payload.
 *  - HubSpot / Pipedrive / Salesforce: workflows con webhook trigger.
 *  - Make / Zapier / n8n: catch hook que ramifica a el destino final.
 *  - CRM custom: receiver propio con la logica de negocio.
 *
 * Cero acoplamiento al schema de cada CRM concreto. El precio es que
 * los errores del lado del receiver no son visibles al plugin (el
 * receiver suele responder 200 al recibir y procesar async).
 *
 * **Estructura del JSON** (D-Webhook-3): flat, con keys compatibles
 * con `crm.lead` de Odoo para que el mapping del lado server sea
 * trivial (`name`, `contact_name`, `email_from`, `phone`, `description`,
 * `type`, `utm_*`, `tags[]`). UTMs flat (no `attribution_source.*`).
 * Tambien incluye meta del bridge (`form_plugin`, `form_id`,
 * `bridge_version`) para que tools como Make/Zapier puedan ramificar
 * por origen.
 *
 * **Headers custom** (D-Webhook-1): el admin puede configurar headers
 * arbitrarios en `wppe_bridge_webhook_headers` (textarea con lineas
 * `Header: Value`). Util para Bearer auth, X-API-Key, etc. Sanitizadas
 * upstream — sin newlines en values, sin headers reservados.
 *
 * **Reintentos** (D-Webhook-2): heredamos D5 del Worker. 4xx (excepto
 * 429) -> permanent. 429/5xx/network -> transient. 2xx -> success.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Destination que hace POST $url con JSON del lead.
 */
final class WPPE_Bridge_Webhook_Destination implements WPPE_Bridge_Destination_Interface {

	public const SLUG  = 'webhook';
	public const LABEL = 'Webhook generico';

	/**
	 * Timeout HTTP en segundos. Generoso para tolerar receivers que
	 * procesan sincronicamente del lado server (ej. Odoo Automation
	 * Rule que crea record dentro del request).
	 */
	public const HTTP_TIMEOUT_SECONDS = 15;

	/**
	 * Slug unico del destino.
	 *
	 * @return string
	 */
	public static function slug(): string {
		return self::SLUG;
	}

	/**
	 * Label legible del destino para el dropdown admin.
	 *
	 * @return string
	 */
	public static function label(): string {
		return self::LABEL;
	}

	/**
	 * Envia el lead al webhook configurado.
	 *
	 * @param array $payload Payload normalizado upstream.
	 * @return WPPE_Bridge_Destination_Result
	 */
	public function send( array $payload ): WPPE_Bridge_Destination_Result {
		$url = (string) get_option( 'wppe_bridge_webhook_url', '' );
		if ( '' === $url ) {
			return new WPPE_Bridge_Destination_Result(
				false,
				0,
				array(),
				'Webhook URL no configurado. Ir a Configuracion Webhook y guardar la URL antes de activar este destino.',
				true
			);
		}

		// v2.5.10 — Re-validacion anti-SSRF en runtime (sec PR-2). Defiende
		// contra DNS rebinding: el sanitizer valido al guardar, pero el DNS
		// pudo cambiar entre eso y el fetch real. Resolvemos de nuevo.
		// Permanent error (no reintentar) — la URL no va a "volverse externa".
		$check = WPPE_Bridge_Url_Validator::is_safe_outbound_url( $url );
		if ( ! $check['ok'] ) {
			return new WPPE_Bridge_Destination_Result(
				false,
				0,
				array(),
				sprintf( 'Webhook URL no es externa segura (%s). Bloqueado por anti-SSRF.', $check['reason'] ),
				true
			);
		}

		$body = self::build_body( $payload );

		// v2.5.10 — Serializar UNA vez. Si hay HMAC configurado, lo
		// calculamos sobre este mismo string. Si serializaramos en
		// build_headers() y de nuevo aqui, dos `wp_json_encode` con
		// el mismo input PHP retornan el mismo string (deterministico
		// por key insertion order), pero hacerlo una sola vez evita
		// cualquier riesgo de drift + es marginalmente mas rapido.
		$body_json = (string) wp_json_encode( $body );
		$headers   = self::build_headers( $body_json );

		$response = wp_remote_post(
			$url,
			array(
				'method'  => 'POST',
				'timeout' => self::HTTP_TIMEOUT_SECONDS,
				'headers' => $headers,
				'body'    => $body_json,
			)
		);

		return self::parse_response( $response );
	}

	/**
	 * Construye el body JSON flat con keys compatibles `crm.lead` Odoo.
	 *
	 * Incluye:
	 *  - Campos directos del payload mapeados a nombres Odoo:
	 *    firstName -> first_name, lastName -> last_name, etc.
	 *    Tambien `contact_name` (fname + lname) y `name` (subject del
	 *    lead, default "Web lead — {contact_name}") para facilitar el
	 *    mapping en Odoo Automation Rules.
	 *  - UTMs flat (utm_source, utm_medium, ...).
	 *  - tags[] (default global + override por-form, leidos de las
	 *    options de webhook si estan).
	 *  - Meta del bridge (bridge_version, form_plugin, form_id) para
	 *    que el receiver pueda ramificar por origen.
	 *
	 * @param array $payload Payload normalizado upstream.
	 * @return array
	 */
	public static function build_body( array $payload ): array {
		$first_name = isset( $payload['firstName'] ) ? (string) $payload['firstName'] : '';
		$last_name  = isset( $payload['lastName'] ) ? (string) $payload['lastName'] : '';
		// Sperant pipeline usa fname/lname — tambien soportar.
		if ( '' === $first_name && isset( $payload['fname'] ) ) {
			$first_name = (string) $payload['fname'];
		}
		if ( '' === $last_name && isset( $payload['lname'] ) ) {
			$last_name = (string) $payload['lname'];
		}

		$contact_name = trim( $first_name . ' ' . $last_name );
		$email        = isset( $payload['email'] ) ? (string) $payload['email'] : '';
		$phone        = isset( $payload['phone'] ) ? (string) $payload['phone'] : '';

		// "name" es el subject del lead en Odoo. Si no esta provisto,
		// generar uno descriptivo.
		$lead_subject = isset( $payload['name'] ) && '' !== (string) $payload['name']
			? (string) $payload['name']
			: ( '' !== $contact_name ? 'Web lead — ' . $contact_name : 'Web lead' );

		$type = (string) get_option( 'wppe_bridge_webhook_default_type', 'opportunity' );
		$tags = self::resolve_tags( $payload );

		$body = array(
			// Compat directa con Odoo crm.lead.
			'name'              => $lead_subject,
			'contact_name'      => $contact_name,
			'first_name'        => $first_name,
			'last_name'         => $last_name,
			'email_from'        => $email,
			'phone'             => $phone,
			'description'       => isset( $payload['message'] ) ? (string) $payload['message'] : '',
			'type'              => $type,

			// UTMs flat.
			'utm_source'        => $payload['utm_source'] ?? '',
			'utm_medium'        => $payload['utm_medium'] ?? '',
			'utm_campaign'      => $payload['utm_campaign'] ?? '',
			'utm_content'       => $payload['utm_content'] ?? '',
			'utm_term'          => $payload['utm_term'] ?? '',
			'gclid'             => $payload['gclid'] ?? '',
			'fbclid'            => $payload['fbclid'] ?? '',
			'landing_url'       => $payload['landing_url'] ?? '',

			// Tags como array de strings (el receiver decide como
			// resolverlos a IDs en su CRM).
			'tags'              => $tags,

			// Meta del bridge para que el receiver pueda ramificar.
			'source'            => 'wppe-bridge',
			'bridge_version'    => defined( 'WPPE_BRIDGE_VERSION' ) ? (string) WPPE_BRIDGE_VERSION : '0.0.0',
			'form_plugin'       => isset( $payload['_form_plugin'] ) ? (string) $payload['_form_plugin'] : '',
			'form_id'           => isset( $payload['_form_id'] ) ? (string) $payload['_form_id'] : '',
			'submission_id'     => isset( $payload['_submission_id'] ) ? (string) $payload['_submission_id'] : '',
			'client_ip'         => $payload['client_ip'] ?? '',
			'client_user_agent' => $payload['client_user_agent'] ?? '',
		);

		/**
		 * Permite modificar el body del webhook antes de enviarlo. Util
		 * para clientes que necesiten campos adicionales especificos
		 * (mapeo a CRM custom).
		 *
		 * @param array $body    Body construido.
		 * @param array $payload Payload original normalizado.
		 */
		if ( function_exists( 'apply_filters' ) ) {
			$body = (array) apply_filters( 'wppe_bridge_webhook_body', $body, $payload );
		}

		return $body;
	}

	/**
	 * Resuelve los tags finales: default global + override por-form
	 * deduplicados. Mismo patron que GHL D-GHL-5.
	 *
	 * @param array $payload Payload con `_form_plugin` y `_form_id`.
	 * @return array<int,string>
	 */
	public static function resolve_tags( array $payload ): array {
		$tags = array();

		// 1. Default global.
		$default = get_option( 'wppe_bridge_webhook_default_tags', array() );
		if ( is_array( $default ) ) {
			foreach ( $default as $tag ) {
				if ( is_string( $tag ) && '' !== trim( $tag ) ) {
					$tags[] = trim( $tag );
				}
			}
		}

		// 2. Override por-form.
		$plugin  = isset( $payload['_form_plugin'] ) ? (string) $payload['_form_plugin'] : '';
		$form_id = isset( $payload['_form_id'] ) ? (string) $payload['_form_id'] : '';
		if ( '' !== $plugin && '' !== $form_id ) {
			$mapping   = get_option( 'wppe_bridge_webhook_field_mapping', array() );
			$form_tags = $mapping[ $plugin ][ $form_id ]['tags'] ?? array();
			if ( is_array( $form_tags ) ) {
				foreach ( $form_tags as $tag ) {
					if ( is_string( $tag ) && '' !== trim( $tag ) ) {
						$tags[] = trim( $tag );
					}
				}
			}
		}

		return array_values( array_unique( $tags ) );
	}

	/**
	 * Construye los headers HTTP del POST.
	 *
	 * Content-Type fijo + headers custom del admin (option
	 * `wppe_bridge_webhook_headers`, array de pares `name => value`
	 * persistidos por el sanitizer).
	 *
	 * V2.5.10 — Si la option `wppe_bridge_webhook_signing_secret` esta
	 * seteada, agrega headers HMAC-SHA256 anti-tampering + anti-replay:
	 *   X-Wppe-Timestamp: <unix-ts>
	 *   X-Wppe-Signature: t=<unix-ts>,v1=<hex-hmac>
	 * El receiver verifica:
	 *   1. Timestamp dentro de tolerancia (ej. ±5 min).
	 *   2. HMAC = hash_hmac('sha256', "$ts.$body_json", $secret) con
	 *      compare_digest (timing-safe).
	 *
	 * @param string $body_json JSON-encoded body. Necesario para HMAC.
	 *                          Si vacio, no se firma (caso interno).
	 * @return array<string,string>
	 */
	public static function build_headers( string $body_json = '' ): array {
		$base = array(
			'Content-Type' => 'application/json',
			'Accept'       => 'application/json',
			'User-Agent'   => sprintf(
				'WPPE-Bridge-Webhook/%s',
				defined( 'WPPE_BRIDGE_VERSION' ) ? WPPE_BRIDGE_VERSION : '0.0.0'
			),
		);

		$custom = get_option( 'wppe_bridge_webhook_headers', array() );
		if ( is_array( $custom ) ) {
			foreach ( $custom as $name => $value ) {
				if ( ! is_string( $name ) || ! is_string( $value ) ) {
					continue;
				}
				$name = trim( $name );
				if ( '' === $name ) {
					continue;
				}
				// No sobreescribir headers reservados — el sanitizer ya
				// los rechaza, esto es defensa adicional. Lista en sync
				// con WPPE_Bridge_Webhook_Settings_Page::RESERVED_HEADERS.
				if ( in_array(
					strtolower( $name ),
					array( 'content-type', 'accept', 'host', 'content-length', 'x-wppe-signature', 'x-wppe-timestamp' ),
					true
				) ) {
					continue;
				}
				$base[ $name ] = $value;
			}
		}

		// v2.5.10 — HMAC opcional. Si secret esta seteado y tenemos
		// el body JSON, firmar y agregar headers de timestamp + signature.
		// El receiver debe verificar timestamp dentro de window (±300s) +
		// hmac con compare_digest (timing-safe).
		$secret = (string) get_option( 'wppe_bridge_webhook_signing_secret', '' );
		if ( '' !== $secret && '' !== $body_json ) {
			$ts                       = (string) time();
			$signature                = hash_hmac( 'sha256', $ts . '.' . $body_json, $secret );
			$base['X-Wppe-Timestamp'] = $ts;
			$base['X-Wppe-Signature'] = 't=' . $ts . ',v1=' . $signature;
		}

		return $base;
	}

	/**
	 * Mapea la respuesta de wp_remote_post al Destination_Result
	 * uniforme. Politica D5:
	 *  - 2xx -> success.
	 *  - 429/5xx/network -> transient (reintento con backoff).
	 *  - 4xx (excepto 429) -> permanent (no reintentar).
	 *
	 * @param mixed $response Lo que devolvio wp_remote_post.
	 * @return WPPE_Bridge_Destination_Result
	 */
	private static function parse_response( $response ): WPPE_Bridge_Destination_Result {
		if ( is_wp_error( $response ) ) {
			return new WPPE_Bridge_Destination_Result(
				false,
				0,
				array(),
				'Network error: ' . $response->get_error_message(),
				false
			);
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$raw    = (string) wp_remote_retrieve_body( $response );
		$body   = array();
		if ( '' !== $raw ) {
			$decoded = json_decode( $raw, true );
			if ( is_array( $decoded ) ) {
				$body = $decoded;
			}
		}

		if ( $status >= 200 && $status < 300 ) {
			return new WPPE_Bridge_Destination_Result( true, $status, $body, null, false );
		}

		$is_transient = ( 429 === $status ) || ( $status >= 500 && $status < 600 );

		return new WPPE_Bridge_Destination_Result(
			false,
			$status,
			$body,
			sprintf( 'HTTP %d', $status ),
			! $is_transient
		);
	}

	/**
	 * Pasos de setup especificos del webhook generico.
	 *
	 * @return array<int,array{key:string,title:string,description:string,action_url:?string,action_label:?string}>
	 */
	public static function setup_guide(): array {
		$config_url = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=wppe-bridge-webhook-config' ) : '';
		return array(
			array(
				'key'          => 'webhook_url',
				'title'        => __( 'Configurar URL del webhook', 'wppe-bridge' ),
				'description'  => __( 'En Configuracion Webhook, pega el URL del receiver. Tipicamente la URL la genera el destino: Odoo (Automation Rule "On Webhook"), HubSpot (workflow webhook), Make/Zapier/n8n (catch hook), o un endpoint propio.', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Ir a Configuracion Webhook', 'wppe-bridge' ),
			),
			array(
				'key'          => 'webhook_odoo_recipe',
				'title'        => __( 'Receta: Odoo v17+ via Automation Rule', 'wppe-bridge' ),
				'description'  => __( 'En Odoo: <strong>Settings &rarr; Technical &rarr; Automation Rules &rarr; New</strong>. Trigger: <code>On Webhook</code>. Modelo: <code>CRM Lead</code>. Copiar la URL secreta que genera Odoo y pegarla en el plugin. Agregar action <code>Update Record</code> que mapee los campos del payload (<code>name</code>, <code>email_from</code>, <code>phone</code>, <code>contact_name</code>, <code>type</code>, <code>utm_source</code>, etc.) al record creado. El plugin envia tags como array de strings — usar una accion adicional para resolverlos via name_create. Para Odoo v15/16 (sin Automation Rules), ver <code>docs/odoo-webhook-receiver.py</code> en el repo del plugin.', 'wppe-bridge' ),
				'action_url'   => null,
				'action_label' => null,
			),
			array(
				'key'          => 'webhook_make_zapier_recipe',
				'title'        => __( 'Receta: Make / Zapier / n8n', 'wppe-bridge' ),
				'description'  => __( 'Crear un nuevo scenario/zap con trigger <code>Webhook &rarr; Catch hook</code>. Copiar la URL generada y pegarla en el plugin. Mandar un lead de prueba para que la herramienta capture el shape del JSON. Despues agregar steps al CRM final (Pipedrive, HubSpot, Salesforce, etc.) mapeando los campos.', 'wppe-bridge' ),
				'action_url'   => null,
				'action_label' => null,
			),
			array(
				'key'          => 'webhook_payload_shape',
				'title'        => __( 'Estructura del JSON enviado', 'wppe-bridge' ),
				'description'  => __( 'El plugin envia un JSON flat con keys compatibles Odoo crm.lead: <code>name</code>, <code>contact_name</code>, <code>first_name</code>, <code>last_name</code>, <code>email_from</code>, <code>phone</code>, <code>description</code>, <code>type</code> (lead/opportunity), <code>utm_source/medium/campaign/content/term</code>, <code>gclid</code>, <code>fbclid</code>, <code>tags[]</code>, <code>landing_url</code>. Mas meta: <code>source</code> = "wppe-bridge", <code>bridge_version</code>, <code>form_plugin</code>, <code>form_id</code>. Para modificar este shape, hookear el filter <code>wppe_bridge_webhook_body</code>.', 'wppe-bridge' ),
				'action_url'   => null,
				'action_label' => null,
			),
			array(
				'key'          => 'webhook_security',
				'title'        => __( 'Headers custom para auth (opcional)', 'wppe-bridge' ),
				'description'  => __( 'Si el webhook receiver requiere autenticacion, configurar headers custom en Configuracion Webhook. Tipicamente: <code>Authorization: Bearer &lt;token&gt;</code> o <code>X-API-Key: &lt;key&gt;</code>. Permite revocar acceso del lado receiver sin tocar el plugin.', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Ir a Configuracion Webhook', 'wppe-bridge' ),
			),
		);
	}
}
