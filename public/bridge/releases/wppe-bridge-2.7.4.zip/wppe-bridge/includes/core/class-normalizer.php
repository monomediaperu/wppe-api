<?php
/**
 * Normalizador de payloads antes del POST a Sperant.
 *
 * Decision D6 del CLAUDE.md: la dedup nativa de Sperant falla con
 * variaciones de mayusculas o whitespace, asi que normalizamos
 * agresivamente.
 *
 * El codigo de pais default para telefonos sin prefijo es +51 (Peru),
 * pero se puede sobreescribir desde el panel admin
 * (wp_options['wppe_bridge_default_country_code']) para clientes
 * de otros paises. Tambien se expone el filter
 * `wppe_bridge_normalize_phone` para reemplazar la implementacion
 * con libphonenumber u otra alternativa sin tocar el plugin.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Normaliza email, telefono, documento y strings antes del envio.
 */
final class WPPE_Bridge_Normalizer {

	/**
	 * Codigo de pais default cuando no hay opcion configurada.
	 */
	public const DEFAULT_COUNTRY_CODE = '+51';

	/**
	 * Campos de payload que se normalizan como nombre (titlecase).
	 */
	private const NAME_FIELDS = array( 'fname', 'lname' );

	/**
	 * Campos de payload que se normalizan como email.
	 */
	private const EMAIL_FIELDS = array( 'email' );

	/**
	 * Campos de payload que se normalizan como telefono.
	 */
	private const PHONE_FIELDS = array( 'phone' );

	/**
	 * Campos de payload que se normalizan como documento (solo digitos).
	 */
	private const DOCUMENT_FIELDS = array( 'document' );

	/**
	 * Campos de payload que se normalizan como tipo de persona Sperant.
	 *
	 * Sperant guarda "tipo de persona" (natural/juridica) en la ficha
	 * del cliente — equivale a la dimension comercial detras del tipo
	 * de documento (DNI/CE/Pasaporte = persona natural; RUC = juridica).
	 */
	private const TYPE_OF_PERSON_FIELDS = array( 'type_of_person' );

	/**
	 * Normaliza un payload completo. Aplica reglas por tipo de campo
	 * y trim a todos los strings restantes.
	 *
	 * Los campos ausentes se dejan ausentes (no se inicializan a
	 * cadena vacia) para no enviar a Sperant claves que el adapter
	 * no proveyo.
	 *
	 * @param array $payload Payload crudo del adapter.
	 * @return array
	 */
	public static function normalize( array $payload ): array {
		foreach ( self::EMAIL_FIELDS as $field ) {
			if ( array_key_exists( $field, $payload ) && is_string( $payload[ $field ] ) ) {
				$payload[ $field ] = self::normalize_email( $payload[ $field ] );
			}
		}
		foreach ( self::PHONE_FIELDS as $field ) {
			if ( array_key_exists( $field, $payload ) && is_string( $payload[ $field ] ) ) {
				$payload[ $field ] = self::normalize_phone_e164( $payload[ $field ] );
			}
		}
		foreach ( self::DOCUMENT_FIELDS as $field ) {
			if ( array_key_exists( $field, $payload ) && is_string( $payload[ $field ] ) ) {
				$payload[ $field ] = self::normalize_document( $payload[ $field ] );
			}
		}
		foreach ( self::TYPE_OF_PERSON_FIELDS as $field ) {
			if ( array_key_exists( $field, $payload ) && is_string( $payload[ $field ] ) ) {
				$translated = self::normalize_type_of_person( $payload[ $field ] );
				if ( '' === $translated ) {
					// Valor no reconocido: lo descartamos para no enviar
					// basura a Sperant. Mejor sin campo que con uno invalido.
					unset( $payload[ $field ] );
				} else {
					$payload[ $field ] = $translated;
				}
			}
		}
		foreach ( self::NAME_FIELDS as $field ) {
			if ( array_key_exists( $field, $payload ) && is_string( $payload[ $field ] ) ) {
				$payload[ $field ] = self::normalize_name( $payload[ $field ] );
			}
		}
		// Trim general en strings restantes.
		foreach ( $payload as $key => $value ) {
			if ( is_string( $value ) ) {
				$payload[ $key ] = trim( $value );
			}
		}
		return $payload;
	}

	/**
	 * Normaliza un email: trim + lowercase.
	 *
	 * @param string $email Email crudo.
	 * @return string
	 */
	public static function normalize_email( string $email ): string {
		return strtolower( trim( $email ) );
	}

	/**
	 * Normaliza un telefono a E.164. Reglas:
	 * - Si la entrada esta vacia, retorna ''.
	 * - Strip de todo lo que no sea digito.
	 * - Si la entrada original empezaba con `+`, conserva ese prefijo.
	 * - Si no, antepone el codigo de pais default leido de wp_options
	 *   o, en su defecto, DEFAULT_COUNTRY_CODE.
	 * - Aplica filter `wppe_bridge_normalize_phone` antes del return
	 *   para permitir reemplazos via libphonenumber u otros.
	 *
	 * @param string $phone Telefono crudo.
	 * @return string
	 */
	public static function normalize_phone_e164( string $phone ): string {
		$trimmed = trim( $phone );
		if ( '' === $trimmed ) {
			return apply_filters( 'wppe_bridge_normalize_phone', '', $phone );
		}

		// Detectar prefijo internacional: hay `+` ANTES del primer digito.
		// Cubre "+51...", "(+51)...", " +51 999".
		$first_digit_pos = strcspn( $trimmed, '0123456789' );
		$first_plus_pos  = strpos( $trimmed, '+' );
		$has_plus_prefix = false !== $first_plus_pos && $first_plus_pos < $first_digit_pos;

		$digits = preg_replace( '/\D/', '', $trimmed );
		if ( null === $digits ) {
			$digits = '';
		}

		if ( '' === $digits ) {
			return apply_filters( 'wppe_bridge_normalize_phone', '', $phone );
		}

		if ( $has_plus_prefix ) {
			$normalized = '+' . $digits;
		} else {
			$normalized = self::default_country_code() . $digits;
		}

		return apply_filters( 'wppe_bridge_normalize_phone', $normalized, $phone );
	}

	/**
	 * Normaliza un documento de identidad: solo digitos. Stripea
	 * espacios, guiones, puntos. NO valida longitud (DNI=8, RUC=11,
	 * CE=variable). Esa validacion la hace el adapter / Sperant.
	 *
	 * NOTA (v2.7.1): pasaporte es alfanumerico. La regla actual de
	 * "solo digitos" (D6 CLAUDE.md) lo rompe (ej. "PA1234567" →
	 * "1234567"). Cambiar D6 para preservar alfanumerico cuando el
	 * type_of_person sea pasaporte es pendiente — requiere aprobacion
	 * explicita porque toca decision tecnica documentada.
	 *
	 * @param string $doc Documento crudo.
	 * @return string
	 */
	public static function normalize_document( string $doc ): string {
		$clean = preg_replace( '/\D/', '', $doc );
		return null === $clean ? '' : $clean;
	}

	/**
	 * Traduce el valor crudo de `type_of_person` (lo que el visitante
	 * eligio en el dropdown del form) al vocabulario que Sperant
	 * espera: "natural" o "juridica" (sin tilde, ver CHANGELOG v2.7.1).
	 *
	 * Aliases reconocidos:
	 *   - "DNI", "CE", "Carnet", "Carnet de extranjeria", "Pasaporte",
	 *     "Passport", "natural" → "natural"
	 *   - "RUC", "juridica", "juridica" (con tilde), "persona juridica"
	 *     → "juridica"
	 *
	 * Valores no reconocidos retornan '' (el normalize() los descarta).
	 * Comparacion case-insensitive y tolerante a tildes.
	 *
	 * @param string $value Valor crudo del payload.
	 * @return string "natural", "juridica", o '' si no reconocido.
	 */
	public static function normalize_type_of_person( string $value ): string {
		$trimmed = trim( $value );
		if ( '' === $trimmed ) {
			return '';
		}
		// Normalizacion para matching: lowercase + strip de tildes
		// y colapso de espacios.
		$lower     = mb_strtolower( $trimmed, 'UTF-8' );
		$stripped  = strtr(
			$lower,
			array(
				'á' => 'a',
				'é' => 'e',
				'í' => 'i',
				'ó' => 'o',
				'ú' => 'u',
				'ü' => 'u',
				'ñ' => 'n',
			)
		);
		$collapsed = preg_replace( '/\s+/u', ' ', $stripped );
		if ( null === $collapsed ) {
			$collapsed = $stripped;
		}

		$natural_aliases  = array(
			'dni',
			'ce',
			'carnet',
			'carnet de extranjeria',
			'pasaporte',
			'passport',
			'natural',
			'persona natural',
		);
		$juridica_aliases = array(
			'ruc',
			'juridica',
			'persona juridica',
		);

		if ( in_array( $collapsed, $natural_aliases, true ) ) {
			return 'natural';
		}
		if ( in_array( $collapsed, $juridica_aliases, true ) ) {
			return 'juridica';
		}
		return '';
	}

	/**
	 * Normaliza un nombre: trim + titlecase preservando acentos.
	 * Convierte "JUAN PEREZ" en "Juan Perez", "maria" en "Maria".
	 *
	 * @param string $name Nombre crudo.
	 * @return string
	 */
	public static function normalize_name( string $name ): string {
		$trimmed = trim( $name );
		if ( '' === $trimmed ) {
			return '';
		}
		// Colapsar espacios internos multiples.
		$collapsed = preg_replace( '/\s+/u', ' ', $trimmed );
		if ( null === $collapsed ) {
			$collapsed = $trimmed;
		}
		$lower = mb_strtolower( $collapsed, 'UTF-8' );
		return mb_convert_case( $lower, MB_CASE_TITLE, 'UTF-8' );
	}

	/**
	 * Lee el codigo de pais default desde wp_options con fallback a
	 * DEFAULT_COUNTRY_CODE. Valida que empiece con `+` y tenga al
	 * menos 2 caracteres; sino, fallback.
	 *
	 * @return string
	 */
	private static function default_country_code(): string {
		$opt = get_option( 'wppe_bridge_default_country_code', self::DEFAULT_COUNTRY_CODE );
		if ( ! is_string( $opt ) || strlen( $opt ) < 2 || '+' !== $opt[0] ) {
			return self::DEFAULT_COUNTRY_CODE;
		}
		return $opt;
	}
}
