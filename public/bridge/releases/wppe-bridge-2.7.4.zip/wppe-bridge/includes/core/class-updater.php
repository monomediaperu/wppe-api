<?php
/**
 * Updater nativo de WordPress para WP.pe Bridge.
 *
 * Hookea los filters del sistema de updates de WP para que el plugin
 * (instalado fuera de wordpress.org) reciba el badge "Update available"
 * en la pagina de Plugins, y el cliente pueda actualizar con un click
 * — mismo UX que cualquier plugin de wordpress.org.
 *
 * **Como funciona:**
 *
 * 1. WordPress chequea updates 2 veces al dia (cron `wp_version_check`).
 *    En cada chequeo dispara `pre_set_site_transient_update_plugins` con
 *    un objeto `$transient` que tiene `->checked[plugin_basename]` =
 *    version actual de cada plugin instalado. Nuestro filter detecta si
 *    nuestro plugin esta en `->checked`, consulta el manifest remoto,
 *    compara versiones, y si hay update inyecta una entrada en
 *    `$transient->response[plugin_basename]` con `new_version`,
 *    `package`, `url`, etc. WordPress despues renderiza el badge.
 *
 * 2. Cuando el usuario clickea "View details" del plugin en wp-admin,
 *    WP llama `plugins_api()` con `action='plugin_information'`. Si el
 *    slug coincide con el nuestro, servimos un objeto con `name`,
 *    `version`, `author`, `sections` (description/changelog/installation)
 *    para que la modal lo renderice.
 *
 * **Cache:** D-PR4-3. Transient `wppe_bridge_updater_manifest` con TTL
 * 12h. Coincide con el ciclo natural de chequeo de WP. Si el admin
 * quiere forzar un check, va a Plugins -> "Check again" (eso invalida
 * el transient `update_plugins` de WP, que dispara nuestro filter, que
 * respeta el transient propio — para forzar tambien el nuestro hay un
 * filter de bypass `wppe_bridge_updater_force_refresh`).
 *
 * **Fail-safe:** D-PR4-4. Si el endpoint esta caido o el JSON es
 * malformado, fallamos silencioso (return $transient sin tocar) y
 * loggeamos un warning. WordPress nunca debe romperse por un updater.
 *
 * **Auth:** D-PR4-2. Endpoint publico. La proteccion real esta en la
 * whitelist del plugin — el zip descargado ya pasa por install_package
 * de WP que verifica el header del plugin. La info del manifest es
 * publica (mismo nivel que un release page de GitHub).
 *
 * **Auto-update:** D-PR4-8. NO forzamos auto-updates. El cliente
 * decide via toggle "Enable auto-updates" en wp-admin -> Plugins.
 * Default WP es manual click — respetamos eso.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Updater nativo de WordPress integrado al plugin.
 */
final class WPPE_Bridge_Updater {

	/**
	 * URL del manifest publico generado por el workflow auto-mirror.
	 * Estructura esperada:
	 *   {
	 *     "version": "2.2.0",
	 *     "released_at": "2026-05-05T17:05:57Z",
	 *     "zip_url": "https://api.wp.pe/bridge/releases/wppe-bridge-2.2.0.zip",
	 *     "changelog_url": "https://github.com/.../releases/tag/v2.2.0",
	 *     "minimum_php": "8.1",
	 *     "minimum_wordpress": "6.4",
	 *     "tested": "6.7",        // PR-4: agregado al workflow
	 *     "last_updated": "..."   // PR-4: alias de released_at
	 *   }
	 */
	public const MANIFEST_URL = 'https://api.wp.pe/bridge/latest.json';

	/**
	 * Transient key que cachea la respuesta del manifest. TTL 12h.
	 * Si el admin quiere forzar refresh, puede borrarlo via WP-CLI:
	 *   wp transient delete wppe_bridge_updater_manifest
	 */
	public const TRANSIENT_KEY = 'wppe_bridge_updater_manifest';

	/**
	 * TTL del transient cache (1 hora). v2.5.6: bajado de 12h a 1h
	 * para que un release nuevo se refleje en wp-admin en a lo sumo
	 * 1 hora sin requerir click manual a "Buscar actualizaciones".
	 * El cron de WordPress de check_for_update corre ~12h, asi que
	 * combinado con eso, el primer admin que entre tras el TTL ve el
	 * upgrade aunque WP no haya checkeado todavia.
	 */
	public const TRANSIENT_TTL_SECONDS = HOUR_IN_SECONDS;

	/**
	 * Timeout HTTP del fetch del manifest. Generoso porque api.wp.pe
	 * pasa por Coolify y tiene cold starts ocasionales.
	 */
	public const HTTP_TIMEOUT_SECONDS = 8;

	/**
	 * Slug del plugin (= nombre de la carpeta en wp-content/plugins/).
	 * D-PR4-7.
	 */
	public const PLUGIN_SLUG = 'wppe-bridge';

	/**
	 * Version maxima de WP testeada (fallback cuando el manifest no
	 * trae `tested`). Actualizar al subir esta cifra en el header del
	 * plugin tambien.
	 */
	public const FALLBACK_TESTED_WP = '6.7';

	/**
	 * Bootstrap: registra los 2 filters en WP. Llamado desde
	 * Plugin::register_hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_filter( 'pre_set_site_transient_update_plugins', array( self::class, 'check_for_update' ) );
		add_filter( 'plugins_api', array( self::class, 'plugin_information' ), 10, 3 );

		// v2.5.11 — Sec PR-3: integrity check del zip antes de instalarlo.
		// Hookeamos `upgrader_pre_download` para interceptar el download,
		// validar sha256 contra el manifest, y abortar si no coincide.
		// Esto cierra el hallazgo H3 del audit: confianza solo en TLS de
		// api.wp.pe no es suficiente — un compromise supply chain podria
		// inyectar zip malicioso. Con sha256 verificacion, aunque api.wp.pe
		// sea comprometido, el cliente solo instalara un zip cuyo hash
		// coincida con el publicado en el manifest (que tambien viaja por
		// la misma fuente — defensa primaria es TLS + hash). Si el atacante
		// controla el manifest puede poner el hash de su zip malicioso —
		// pero ahi entra defensa en profundidad: el manifest puede
		// firmarse en futuras versiones con GPG. Por ahora `sha256` es
		// guardrail contra MITM en transit + corruption + zip-swap.
		add_filter( 'upgrader_pre_download', array( self::class, 'verify_zip_integrity' ), 10, 3 );
	}

	/**
	 * Filter `pre_set_site_transient_update_plugins`.
	 *
	 * Inyecta una entrada en `$transient->response` si hay version nueva.
	 * WordPress despues compara `->response` vs `->checked` para mostrar
	 * el badge en la pagina de Plugins.
	 *
	 * Si nuestro plugin no esta en `->checked` (caso raro: WP corrio el
	 * filter antes de que el plugin estuviera activo), no hacemos nada.
	 *
	 * @param mixed $transient Site transient object.
	 * @return mixed
	 */
	public static function check_for_update( $transient ) {
		// Defensivo: en algunos contextos (tests, instalacion fresca) el
		// transient puede ser null en vez de objeto.
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$plugin_basename = self::plugin_basename();
		$current_version = self::current_version();

		$manifest = self::get_manifest();
		if ( null === $manifest ) {
			// Endpoint caido / network error / JSON invalido.
			// Fallamos silencioso (D-PR4-4) — no inyectamos nada.
			return $transient;
		}

		$remote_version = isset( $manifest['version'] ) ? (string) $manifest['version'] : '';
		if ( '' === $remote_version ) {
			return $transient;
		}

		// Comparacion semver. Solo notificamos si la remota es ESTRICTAMENTE
		// mayor — downgrades los ignoramos para no proponerle al admin
		// "instalar v2.0.5" cuando ya tiene v2.1.0.
		if ( version_compare( $remote_version, $current_version, '<=' ) ) {
			return $transient;
		}

		// Hay update. Construir el objeto que WP espera.
		$update_data = (object) array(
			'id'           => self::PLUGIN_SLUG,
			'slug'         => self::PLUGIN_SLUG,
			'plugin'       => $plugin_basename,
			'new_version'  => $remote_version,
			'url'          => isset( $manifest['changelog_url'] ) ? (string) $manifest['changelog_url'] : 'https://wp.pe/bridge',
			'package'      => isset( $manifest['zip_url'] ) ? (string) $manifest['zip_url'] : '',
			'tested'       => isset( $manifest['tested'] ) ? (string) $manifest['tested'] : self::FALLBACK_TESTED_WP,
			'requires_php' => isset( $manifest['minimum_php'] ) ? (string) $manifest['minimum_php'] : '8.1',
			'icons'        => array(),
			'banners'      => array(),
			'banners_rtl'  => array(),
		);

		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}
		$transient->response[ $plugin_basename ] = $update_data;

		// Tambien limpiar de `no_update` si estaba ahi (caso raro pero
		// posible si WP ya habia cacheado "sin updates").
		if ( isset( $transient->no_update[ $plugin_basename ] ) ) {
			unset( $transient->no_update[ $plugin_basename ] );
		}

		return $transient;
	}

	/**
	 * Filter `plugins_api`.
	 *
	 * Sirve metadatos del plugin cuando el usuario clickea "View details"
	 * en wp-admin. WP llama este filter con `$action='plugin_information'`
	 * y `$args->slug` = slug del plugin. Si coincide con el nuestro,
	 * retornamos un objeto con `sections` (description/changelog/install).
	 *
	 * Si NO es nuestro plugin, retornamos `$default` sin tocar (otro
	 * filter o el sistema default lo maneja).
	 *
	 * @param mixed  $default_value Default que viene del filter (puede ser false, WP_Error, o objeto).
	 * @param string $action        Accion solicitada ('plugin_information' principalmente).
	 * @param object $args          Args del request.
	 * @return mixed
	 */
	public static function plugin_information( $default_value, $action, $args ) {
		if ( 'plugin_information' !== $action ) {
			return $default_value;
		}
		if ( ! is_object( $args ) || ! isset( $args->slug ) || self::PLUGIN_SLUG !== $args->slug ) {
			return $default_value;
		}

		$manifest = self::get_manifest();
		if ( null === $manifest ) {
			return $default_value;
		}

		$remote_version = isset( $manifest['version'] ) ? (string) $manifest['version'] : '';
		$changelog_url  = isset( $manifest['changelog_url'] ) ? (string) $manifest['changelog_url'] : '';

		return (object) array(
			'name'          => 'WP.pe Bridge',
			'slug'          => self::PLUGIN_SLUG,
			'version'       => $remote_version,
			'author'        => '<a href="https://mono.media">Mono Media SAC</a>',
			'homepage'      => 'https://wp.pe/bridge',
			'requires'      => isset( $manifest['minimum_wordpress'] ) ? (string) $manifest['minimum_wordpress'] : '6.4',
			'tested'        => isset( $manifest['tested'] ) ? (string) $manifest['tested'] : self::FALLBACK_TESTED_WP,
			'requires_php'  => isset( $manifest['minimum_php'] ) ? (string) $manifest['minimum_php'] : '8.1',
			'last_updated'  => isset( $manifest['last_updated'] ) ? (string) $manifest['last_updated'] : ( $manifest['released_at'] ?? '' ),
			'download_link' => isset( $manifest['zip_url'] ) ? (string) $manifest['zip_url'] : '',
			'sections'      => self::sections( $changelog_url ),
		);
	}

	/**
	 * Construye las "sections" para la modal "View details" de wp-admin.
	 *
	 * D-PR4-1: hibrido. `description` e `installation` son texto fijo
	 * (raramente cambian). `changelog` es link al GitHub Release porque
	 * mantener changelog HTML local seria duplicacion innecesaria — el
	 * cliente clickea y ve el changelog completo en GitHub.
	 *
	 * @param string $changelog_url URL al GitHub Release de la version remota.
	 * @return array<string,string>
	 */
	private static function sections( string $changelog_url ): array {
		$changelog_link = '' !== $changelog_url
			? sprintf(
				'<p><a href="%s" target="_blank" rel="noopener">%s</a></p>',
				esc_url( $changelog_url ),
				esc_html__( 'Ver changelog completo en GitHub', 'wppe-bridge' )
			)
			: '<p>' . esc_html__( 'Changelog no disponible.', 'wppe-bridge' ) . '</p>';

		return array(
			'description'  => '<p>' . esc_html__( 'WP.pe Bridge integra formularios web (Fluent Forms, Gravity Forms, Elementor) con CRMs inmobiliarios. Soporta Sperant, GoHighLevel, Odoo, HubSpot y Webhook generico via arquitectura Destination interface, con queue async, dedup, manejo de errores diferenciado y modulos opcionales (UTM Capture, Meta CAPI, Submit Lock, Thank You Pixel). Producto interno de Mono Media para WP.pe.', 'wppe-bridge' ) . '</p>',
			'installation' => '<p>' . esc_html__( 'WP.pe Bridge se instala automaticamente en cuentas de WP.pe. Para clientes que actualizan desde versiones anteriores: el badge "Update available" en la pagina de Plugins permite actualizar con un click. La instalacion preserva configuracion existente — no hace falta reconfigurar token, mapeo o catalogos.', 'wppe-bridge' ) . '</p>',
			'changelog'    => $changelog_link,
		);
	}

	/**
	 * Lee el manifest remoto con cache transient.
	 *
	 * Si el transient esta poblado, retorna esos datos sin hacer HTTP.
	 * Si no, hace `wp_remote_get`, parsea el JSON, persiste en transient
	 * y retorna los datos. Si la request falla o el JSON es invalido,
	 * retorna `null` (D-PR4-4: fail-safe).
	 *
	 * Filter `wppe_bridge_updater_force_refresh` permite bypassear el
	 * cache para tests / debugging.
	 *
	 * @return array|null Manifest decodificado o null si error.
	 */
	public static function get_manifest(): ?array {
		$force_refresh = false;
		if ( function_exists( 'apply_filters' ) ) {
			$force_refresh = (bool) apply_filters( 'wppe_bridge_updater_force_refresh', false );
		}

		if ( ! $force_refresh ) {
			$cached = get_transient( self::TRANSIENT_KEY );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$url = self::MANIFEST_URL;
		if ( function_exists( 'apply_filters' ) ) {
			$url = (string) apply_filters( 'wppe_bridge_updater_manifest_url', $url );
		}

		// v2.5.6: cache-bust HTTP. Sin esto, Cloudflare/proxies podian
		// servir un manifest viejo cacheado (cache-control: max-age=300)
		// haciendo que el boton "Buscar actualizaciones" pareciera no
		// funcionar — borraba el transient local pero re-fetcheaba la
		// misma version cacheada por el edge.
		$url_with_cb = $url . ( false === strpos( $url, '?' ) ? '?' : '&' ) . 'cb=' . time();

		$response = wp_remote_get(
			$url_with_cb,
			array(
				'timeout' => self::HTTP_TIMEOUT_SECONDS,
				'headers' => array(
					'Accept'        => 'application/json',
					'User-Agent'    => self::user_agent(),
					'Cache-Control' => 'no-cache, no-store, must-revalidate',
					'Pragma'        => 'no-cache',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			self::log_warning(
				'manifest_fetch_failed',
				array( 'error' => $response->get_error_message() )
			);
			return null;
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		if ( $status < 200 || $status >= 300 ) {
			self::log_warning(
				'manifest_http_error',
				array( 'status' => $status )
			);
			return null;
		}

		$raw     = (string) wp_remote_retrieve_body( $response );
		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) ) {
			self::log_warning(
				'manifest_json_invalid',
				array( 'raw_excerpt' => substr( $raw, 0, 200 ) )
			);
			return null;
		}

		set_transient( self::TRANSIENT_KEY, $decoded, self::TRANSIENT_TTL_SECONDS );
		// Persistimos timestamp paralelo para que la UI pueda mostrar
		// "consultado hace X horas". El transient API no expone la
		// fecha de creacion del cache.
		update_option( self::OPTION_LAST_CHECK, time(), false );
		return $decoded;
	}

	/**
	 * Fuerza un refresh del manifest, invalidando ambos caches:
	 *  - El transient propio (`wppe_bridge_updater_manifest`) — para
	 *    que la proxima llamada a `get_manifest()` haga HTTP.
	 *  - El site transient `update_plugins` de WP — para que el
	 *    proximo render de wp-admin -> Plugins re-dispare nuestro
	 *    `check_for_update` filter con datos frescos.
	 *
	 * Usado por la card "Estado del plugin" en Inicio cuando el admin
	 * clickea "Buscar actualizaciones ahora", y por WP-CLI / debugging.
	 *
	 * Retorna el manifest fresco (o `null` si el endpoint fallo).
	 *
	 * @return array|null
	 */
	public static function force_refresh(): ?array {
		delete_transient( self::TRANSIENT_KEY );
		// `delete_site_transient` es necesario en multisite; en single-site
		// `update_plugins` vive como site transient regardless.
		if ( function_exists( 'delete_site_transient' ) ) {
			delete_site_transient( 'update_plugins' );
		}
		return self::get_manifest();
	}

	/**
	 * Resumen del estado de actualizacion para la UI de Inicio.
	 *
	 * Construye una vista lista-para-renderizar combinando:
	 *  - `current`: version actual (`WPPE_BRIDGE_VERSION`).
	 *  - `remote`: version remota del manifest, o `null` si no se pudo
	 *    consultar (sin forzar HTTP — usa cache existente).
	 *  - `has_update`: `true` si remote > current.
	 *  - `ahead`: `true` si current > remote (instalacion adelantada al
	 *    manifest cacheado — pasa cuando se actualiza el plugin sin
	 *    refrescar el cache de 12h del Updater, o cuando el dev corre
	 *    una build local mas nueva que la publicada).
	 *  - `last_check`: unix timestamp de cuando se cacheo el manifest, o
	 *    `null` si no hay cache. Sirve para mostrar "consultado hace X".
	 *  - `error`: string con mensaje legible si el manifest no esta
	 *    cacheado y get_manifest fallo.
	 *  - `changelog_url`: link al GitHub Release de la version remota.
	 *  - `zip_url`: URL del zip remoto (no la usamos directamente — la usa
	 *    WP cuando hace `install_package`, pero la exponemos para debug).
	 *
	 * No fuerza HTTP. Si el cache esta vacio, hace UN HTTP fetch
	 * (mismo que get_manifest haria normalmente). El boton "Buscar
	 * ahora" llama a `force_refresh` que SI invalida el cache.
	 *
	 * @return array{current:string,remote:?string,has_update:bool,ahead:bool,last_check:?int,error:?string,changelog_url:string,zip_url:string}
	 */
	public static function get_status(): array {
		$current = self::current_version();
		$status  = array(
			'current'       => $current,
			'remote'        => null,
			'has_update'    => false,
			'ahead'         => false,
			'last_check'    => null,
			'error'         => null,
			'changelog_url' => '',
			'zip_url'       => '',
		);

		// Detectar si hay cache (sin tocar HTTP innecesariamente). El
		// transient API no expone "fecha de creacion" directamente, asi
		// que persistimos un timestamp paralelo cuando seteamos el cache.
		$last_check = get_option( self::OPTION_LAST_CHECK, 0 );
		if ( is_numeric( $last_check ) && (int) $last_check > 0 ) {
			$status['last_check'] = (int) $last_check;
		}

		$manifest = self::get_manifest();
		if ( null === $manifest ) {
			$status['error'] = __( 'No se pudo consultar el servidor de actualizaciones (manifest caido o problema de red). Reintentar en unos minutos.', 'wppe-bridge' );
			return $status;
		}

		$remote = isset( $manifest['version'] ) ? (string) $manifest['version'] : '';
		if ( '' === $remote ) {
			$status['error'] = __( 'El servidor de actualizaciones devolvio una respuesta sin version. Contactar a soporte.', 'wppe-bridge' );
			return $status;
		}

		$status['remote']        = $remote;
		$status['has_update']    = version_compare( $remote, $current, '>' );
		$status['ahead']         = version_compare( $current, $remote, '>' );
		$status['changelog_url'] = isset( $manifest['changelog_url'] ) ? (string) $manifest['changelog_url'] : '';
		$status['zip_url']       = isset( $manifest['zip_url'] ) ? (string) $manifest['zip_url'] : '';
		return $status;
	}

	/**
	 * Option key donde persistimos el timestamp del ultimo fetch
	 * exitoso del manifest. El transient TTL es 12h y no expone su
	 * fecha de creacion via API, asi que mantenemos esto en paralelo
	 * para que la UI pueda decir "consultado hace X horas" con
	 * precision.
	 */
	public const OPTION_LAST_CHECK = 'wppe_bridge_updater_last_check';

	/**
	 * Plugin basename (path relativo desde wp-content/plugins/), ej.
	 * `wppe-bridge/wppe-bridge.php`. Aislado en metodo para que tests
	 * lo puedan stubear.
	 *
	 * @return string
	 */
	public static function plugin_basename(): string {
		// Si la constante esta disponible, usar plugin_basename() de WP
		// que respeta installs raros. Si no (tests), construir manual.
		if ( defined( 'WPPE_BRIDGE_PLUGIN_FILE' ) && function_exists( 'plugin_basename' ) ) {
			return plugin_basename( WPPE_BRIDGE_PLUGIN_FILE );
		}
		return self::PLUGIN_SLUG . '/' . self::PLUGIN_SLUG . '.php';
	}

	/**
	 * Version actual del plugin instalado. Aislado para que tests lo
	 * puedan stubear.
	 *
	 * @return string
	 */
	public static function current_version(): string {
		if ( defined( 'WPPE_BRIDGE_VERSION' ) ) {
			return (string) WPPE_BRIDGE_VERSION;
		}
		return '0.0.0';
	}

	/**
	 * User-Agent del fetch (para que api.wp.pe identifique el origen).
	 *
	 * @return string
	 */
	private static function user_agent(): string {
		$version = self::current_version();
		return sprintf( 'WPPE-Bridge-Updater/%s', $version );
	}

	/**
	 * Loggea un warning sin romper si el Logger no esta cargado.
	 *
	 * @param string $code    Codigo de error (snake_case).
	 * @param array  $context Contexto adicional.
	 * @return void
	 */
	private static function log_warning( string $code, array $context ): void {
		if ( class_exists( 'WPPE_Bridge_Logger' ) ) {
			WPPE_Bridge_Logger::warn( 'updater_' . $code, $context );
		}
	}

	/**
	 * Loggea info sin romper si el Logger no esta cargado.
	 *
	 * @param string $code    Codigo (snake_case).
	 * @param array  $context Contexto adicional.
	 * @return void
	 */
	private static function log_info( string $code, array $context ): void {
		if ( class_exists( 'WPPE_Bridge_Logger' ) ) {
			WPPE_Bridge_Logger::info( 'updater_' . $code, $context );
		}
	}

	/**
	 * V2.5.11 (Sec PR-3): integrity check del zip antes de instalarlo.
	 *
	 * Filter callback de `upgrader_pre_download( $reply, $package, $upgrader )`.
	 * WordPress llama esto antes de descargar el zip. Comportamiento:
	 *  - Si `$reply !== false`: otro plugin ya intercepto el download —
	 *    NO tocamos, retornamos $reply.
	 *  - Si el package URL NO es nuestro: NO interceptamos.
	 *  - Si es nuestro: descargamos a archivo temporal, calculamos
	 *    sha256, comparamos contra el `sha256` del manifest cacheado.
	 *  - Match → retornamos el path local del archivo (WP lo usa en
	 *    lugar de re-descargar).
	 *  - Mismatch → retornamos WP_Error con codigo `wppe_bridge_sha256_mismatch`.
	 *    WP aborta el upgrade y muestra el error al admin.
	 *  - Manifest sin `sha256` (compat con manifests viejos) → log info y
	 *    retornamos $reply original (= WP descarga normalmente sin
	 *    verificacion). Esto preserva la cadena de actualizacion para
	 *    instalaciones que apuntan a un mirror sin sha256.
	 *
	 * @param mixed                   $reply    Default `false` — si retorna
	 *                                          non-false WP usa eso.
	 * @param string                  $package  URL del zip a descargar.
	 * @param object|WP_Upgrader|null $upgrader Instancia del Upgrader.
	 * @return mixed `false` (no interceptamos) | string (path local) | WP_Error.
	 */
	public static function verify_zip_integrity( $reply, $package, $upgrader = null ) {
		unset( $upgrader ); // No usado directamente — la signatura es del filter de WP.

		// Si otro plugin ya respondio (caso raro pero posible), respetar.
		if ( false !== $reply ) {
			return $reply;
		}

		// Solo interceptar URLs de nuestro mirror.
		if ( ! is_string( $package ) || ! self::is_our_package_url( $package ) ) {
			return $reply;
		}

		$manifest = self::get_manifest();
		if ( ! is_array( $manifest ) ) {
			self::log_warning(
				'integrity_no_manifest',
				array( 'package' => $package )
			);
			return $reply; // Sin manifest no podemos verificar — fallback a WP core.
		}

		$expected_sha256 = isset( $manifest['sha256'] ) ? strtolower( trim( (string) $manifest['sha256'] ) ) : '';

		if ( '' === $expected_sha256 ) {
			// Manifest sin sha256 — compat con releases pre-v2.5.11 que
			// no escribian el hash. Loggear info para diagnostico, dejar
			// que WP descargue sin verificacion.
			self::log_info(
				'integrity_skipped_manifest_missing_sha256',
				array( 'package' => $package )
			);
			return $reply;
		}

		// Sha256 estricto: 64 hex chars. Si trae otra cosa, abortar para
		// no fail-open silencioso.
		if ( ! preg_match( '/^[a-f0-9]{64}$/', $expected_sha256 ) ) {
			self::log_warning(
				'integrity_invalid_sha256_format',
				array( 'package' => $package )
			);
			return new WP_Error(
				'wppe_bridge_sha256_invalid_format',
				__( 'El manifest del Updater trajo un sha256 con formato invalido. Update abortado.', 'wppe-bridge' )
			);
		}

		// Descargar a archivo temporal — WP::download_url() retorna el
		// path local o WP_Error. Timeout generoso porque el zip puede
		// ser grande y api.wp.pe pasa por Cloudflare + Coolify.
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = download_url( $package, self::DOWNLOAD_TIMEOUT_SECONDS );
		if ( is_wp_error( $tmp ) ) {
			self::log_warning(
				'integrity_download_failed',
				array(
					'package' => $package,
					'error'   => $tmp->get_error_message(),
				)
			);
			return $tmp;
		}

		$actual_sha256 = strtolower( (string) hash_file( 'sha256', $tmp ) );
		if ( ! hash_equals( $expected_sha256, $actual_sha256 ) ) {
			// Mismatch: borrar el zip descargado (no queremos dejar
			// archivos no validados en /tmp) + retornar WP_Error.
			if ( function_exists( 'wp_delete_file' ) ) {
				wp_delete_file( $tmp );
			} else {
				// Fallback en tests (sin wp-admin/includes/file.php cargado). Best-effort.
				@unlink( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink, WordPress.PHP.NoSilencedErrors -- fallback test/CLI.
			}
			self::log_warning(
				'integrity_mismatch',
				array(
					'package'  => $package,
					'expected' => $expected_sha256,
					'actual'   => $actual_sha256,
				)
			);
			return new WP_Error(
				'wppe_bridge_sha256_mismatch',
				sprintf(
					/* translators: 1: sha256 esperado, 2: sha256 obtenido */
					__( 'El zip descargado no coincide con el sha256 del manifest (esperado: %1$s, obtenido: %2$s). Update abortado — posible MITM o supply chain compromise. Reintentar en unos minutos; si persiste, contactar a soporte@mono.media.', 'wppe-bridge' ),
					substr( $expected_sha256, 0, 12 ) . '...',
					substr( $actual_sha256, 0, 12 ) . '...'
				)
			);
		}

		self::log_info(
			'integrity_verified',
			array(
				'package' => $package,
				'sha256'  => substr( $expected_sha256, 0, 12 ) . '...',
			)
		);

		// Match: retornar el path local al WP_Upgrader para que use
		// nuestro download verificado en lugar de re-descargar.
		return $tmp;
	}

	/**
	 * True si la URL es de nuestro mirror oficial. Defensa estricta —
	 * solo aceptamos `api.wp.pe/bridge/releases/wppe-bridge-X.Y.Z.zip`.
	 *
	 * @param string $url URL a chequear.
	 * @return bool
	 */
	public static function is_our_package_url( string $url ): bool {
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) ) {
			return false;
		}
		$scheme = isset( $parts['scheme'] ) ? strtolower( (string) $parts['scheme'] ) : '';
		$host   = isset( $parts['host'] ) ? strtolower( (string) $parts['host'] ) : '';
		$path   = isset( $parts['path'] ) ? (string) $parts['path'] : '';

		if ( 'https' !== $scheme ) {
			return false;
		}
		if ( 'api.wp.pe' !== $host ) {
			return false;
		}
		// Path debe empezar con `/bridge/releases/wppe-bridge-` y terminar en `.zip`.
		if ( 0 !== strpos( $path, '/bridge/releases/wppe-bridge-' ) ) {
			return false;
		}
		if ( ! self::ends_with_zip( $path ) ) {
			return false;
		}
		return true;
	}

	/**
	 * Helper: termina en `.zip` (compat PHP 7.x sin str_ends_with).
	 *
	 * @param string $s Cadena.
	 * @return bool
	 */
	private static function ends_with_zip( string $s ): bool {
		if ( function_exists( 'str_ends_with' ) ) {
			return str_ends_with( $s, '.zip' );
		}
		return '.zip' === substr( $s, -4 );
	}

	/**
	 * Timeout HTTP para `download_url` en verify_zip_integrity. 5 min —
	 * el zip puede ser de varios MB y pasar por CDN con cold starts.
	 */
	public const DOWNLOAD_TIMEOUT_SECONDS = 300;
}
