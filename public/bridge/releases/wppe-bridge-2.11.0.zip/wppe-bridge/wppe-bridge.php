<?php
/**
 * Plugin Name:       WP.pe Bridge
 * Plugin URI:        https://wp.pe/bridge
 * Description:       Integra formularios web (Fluent Forms, Gravity Forms, Elementor, CF7) y un Widget de Contacto propio (WhatsApp + llamada con pre-captura) con CRMs: Sperant, GoHighLevel, Odoo, HubSpot y Webhook generico (Make/Zapier/n8n). Producto interno de Mono Media para WP.pe.
 * Version:           2.11.0
 * Requires at least: 6.4
 * Tested up to:      7.0
 * Requires PHP:      8.1
 * Author:            Mono Media SAC
 * Author URI:        https://mono.media
 * License:           GPL-3.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:       wppe-bridge
 * Domain Path:       /languages
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

// Constantes globales del plugin.
define( 'WPPE_BRIDGE_VERSION', '2.11.0' );
define( 'WPPE_BRIDGE_DB_VERSION', '2' );
define( 'WPPE_BRIDGE_PLUGIN_FILE', __FILE__ );
define( 'WPPE_BRIDGE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPPE_BRIDGE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WPPE_BRIDGE_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// Carga del singleton principal (autoload manual, sin Composer en runtime).
require_once WPPE_BRIDGE_PLUGIN_DIR . 'includes/class-plugin.php';

// Hooks de activación / desactivación / uninstall.
register_activation_hook( __FILE__, array( 'WPPE_Bridge_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WPPE_Bridge_Deactivator', 'deactivate' ) );

// Carga inicial del plugin.
add_action( 'plugins_loaded', array( 'WPPE_Bridge_Plugin', 'instance' ) );
