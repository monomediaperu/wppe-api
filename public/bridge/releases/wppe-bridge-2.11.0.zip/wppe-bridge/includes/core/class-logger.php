<?php
/**
 * Logger interno del plugin.
 *
 * Persiste a la tabla wp_wppebridge_logs. Aplica masking automatico
 * de PII en el `context` antes de guardar (regla 10.8 del CLAUDE.md):
 * NUNCA loggear el token Sperant ni datos personales en plaintext.
 *
 * Las claves sensibles se enmascaran via Pii_Masker (email, phone) o
 * con `[masked]` (token, password). Lista extensible via filter
 * `wppe_bridge_log_pii_keys`.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Logger estatico que persiste a la tabla wp_wppebridge_logs.
 */
final class WPPE_Bridge_Logger {

	public const LEVEL_INFO  = 'info';
	public const LEVEL_WARN  = 'warn';
	public const LEVEL_ERROR = 'error';

	/**
	 * Nombre de la tabla (sin prefix).
	 */
	private const TABLE = 'wppebridge_logs';

	/**
	 * Maximo del campo `message` (text).
	 */
	private const MAX_MESSAGE_LENGTH = 1000;

	/**
	 * Maximo del campo `context` (longtext, JSON).
	 */
	private const MAX_CONTEXT_BYTES = 8192;

	/**
	 * Claves cuyo valor se trata como email (masked con Pii_Masker).
	 */
	private const KEYS_EMAIL = array( 'email' );

	/**
	 * Claves cuyo valor se trata como phone (masked con Pii_Masker).
	 */
	private const KEYS_PHONE = array( 'phone' );

	/**
	 * Claves cuyo valor se reemplaza por '[masked]' literal.
	 *
	 * `client_ip`/`ip` incluidas en v2.11.0 (hardening): la IP es dato
	 * personal (Ley 29733) y no debe quedar en claro en los logs —
	 * defensa en profundidad frente a cualquier caller que la pase sin
	 * pseudonimizar.
	 */
	private const KEYS_REDACT = array( 'token', 'api_token', 'authorization', 'password', 'document', 'client_ip', 'ip' );

	/**
	 * Loggea una entrada.
	 *
	 * @param string   $level    info|warn|error.
	 * @param string   $message  Mensaje breve (con PII enmascarada).
	 * @param array    $context  Contexto JSON-serializable.
	 * @param int|null $queue_id ID de queue relacionado, si aplica.
	 * @return void
	 */
	public static function log( string $level, string $message, array $context = array(), ?int $queue_id = null ): void {
		global $wpdb;

		// Validar nivel; defaultear a info si invalido.
		if ( ! in_array( $level, array( self::LEVEL_INFO, self::LEVEL_WARN, self::LEVEL_ERROR ), true ) ) {
			$level = self::LEVEL_INFO;
		}

		$masked  = self::mask_context( $context );
		$payload = self::truncate_message( $message );
		$json    = self::truncate_context( wp_json_encode( $masked ) );

		$wpdb->insert(
			$wpdb->prefix . self::TABLE,
			array(
				'queue_id'   => $queue_id,
				'level'      => $level,
				'message'    => $payload,
				'context'    => $json,
				'created_at' => current_time( 'mysql', true ),
			),
			array( '%d', '%s', '%s', '%s', '%s' )
		);
	}

	/**
	 * Atajo para nivel info.
	 *
	 * @param string   $message  Mensaje.
	 * @param array    $context  Contexto.
	 * @param int|null $queue_id ID queue.
	 * @return void
	 */
	public static function info( string $message, array $context = array(), ?int $queue_id = null ): void {
		self::log( self::LEVEL_INFO, $message, $context, $queue_id );
	}

	/**
	 * Atajo para nivel warn.
	 *
	 * @param string   $message  Mensaje.
	 * @param array    $context  Contexto.
	 * @param int|null $queue_id ID queue.
	 * @return void
	 */
	public static function warn( string $message, array $context = array(), ?int $queue_id = null ): void {
		self::log( self::LEVEL_WARN, $message, $context, $queue_id );
	}

	/**
	 * Atajo para nivel error.
	 *
	 * @param string   $message  Mensaje.
	 * @param array    $context  Contexto.
	 * @param int|null $queue_id ID queue.
	 * @return void
	 */
	public static function error( string $message, array $context = array(), ?int $queue_id = null ): void {
		self::log( self::LEVEL_ERROR, $message, $context, $queue_id );
	}

	/**
	 * Recupera los ultimos N logs, opcionalmente filtrados por nivel.
	 *
	 * @param int         $limit Cuantos a traer (default 50).
	 * @param string|null $level Filtro por nivel o null.
	 * @return array<int,object>
	 */
	public static function recent( int $limit = 50, ?string $level = null ): array {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;
		$limit = max( 1, $limit );

		if ( null === $level ) {
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
					"SELECT * FROM {$table} ORDER BY id DESC LIMIT %d",
					$limit
				)
			);
		} else {
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
					"SELECT * FROM {$table} WHERE level = %s ORDER BY id DESC LIMIT %d",
					$level,
					$limit
				)
			);
		}
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Recupera los logs vinculados a un queue_id especifico, en orden
	 * cronologico ascendente (primero el mas viejo). Util para
	 * "ver el flujo completo de un lead" desde la sub-pagina Logs.
	 *
	 * Tambien incluye logs sin queue_id si su context contiene el id
	 * (ej. logs de submission_received que aun no conocian el queue_id
	 * porque ocurrieron antes del insert).
	 *
	 * @param int $queue_id ID del queue item.
	 * @param int $limit    Cuantos logs como maximo (default 100).
	 * @return array<int,object>
	 */
	public static function recent_for_queue( int $queue_id, int $limit = 100 ): array {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;
		$limit = max( 1, $limit );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				"SELECT * FROM {$table} WHERE queue_id = %d ORDER BY id ASC LIMIT %d",
				$queue_id,
				$limit
			)
		);
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Busca un log por id.
	 *
	 * @param int $id ID.
	 * @return object|null
	 */
	public static function find( int $id ): ?object {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				"SELECT * FROM {$table} WHERE id = %d LIMIT 1",
				$id
			)
		);
		return is_object( $row ) ? $row : null;
	}

	/**
	 * Borra logs anteriores a `$days` dias atras. Llamado por el
	 * cron diario `wppe_bridge_logs_cleanup_tick`.
	 *
	 * @param int $days Dias de retencion.
	 * @return int Filas eliminadas.
	 */
	public static function purge_older_than( int $days ): int {
		global $wpdb;
		$table  = $wpdb->prefix . self::TABLE;
		$days   = max( 1, $days );
		$cutoff = gmdate( 'Y-m-d H:i:s', (int) strtotime( current_time( 'mysql', true ) ) - ( $days * DAY_IN_SECONDS ) );

		$rows = $wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				"DELETE FROM {$table} WHERE created_at < %s",
				$cutoff
			)
		);
		return max( 0, (int) $rows );
	}

	/**
	 * Hook del cron daily. Lee retention de wp_options con default 30.
	 *
	 * @return void
	 */
	public static function cleanup_tick(): void {
		$days = (int) get_option( 'wppe_bridge_logs_retention_days', 30 );
		self::purge_older_than( $days );
	}

	// ---------- masking ----------

	/**
	 * Aplica masking a las claves sensibles del context. Recorre
	 * recursivamente para capturar nested arrays (ej. payloads).
	 *
	 * @param array $context Contexto raw.
	 * @return array
	 */
	public static function mask_context( array $context ): array {
		$email_keys  = self::KEYS_EMAIL;
		$phone_keys  = self::KEYS_PHONE;
		$redact_keys = self::KEYS_REDACT;

		/**
		 * Permite extender la lista de claves PII a enmascarar.
		 *
		 * @param array $keys [email, phone, redact].
		 */
		$extended = apply_filters(
			'wppe_bridge_log_pii_keys',
			array(
				'email'  => $email_keys,
				'phone'  => $phone_keys,
				'redact' => $redact_keys,
			)
		);

		if ( is_array( $extended ) ) {
			$email_keys  = isset( $extended['email'] ) && is_array( $extended['email'] ) ? $extended['email'] : $email_keys;
			$phone_keys  = isset( $extended['phone'] ) && is_array( $extended['phone'] ) ? $extended['phone'] : $phone_keys;
			$redact_keys = isset( $extended['redact'] ) && is_array( $extended['redact'] ) ? $extended['redact'] : $redact_keys;
		}

		return self::mask_recursive( $context, $email_keys, $phone_keys, $redact_keys );
	}

	/**
	 * Recursion interna del masker.
	 *
	 * @param mixed    $value       Valor.
	 * @param string[] $email_keys  Claves email.
	 * @param string[] $phone_keys  Claves phone.
	 * @param string[] $redact_keys Claves redact.
	 * @param string   $current_key Clave actual (para decidir masking).
	 * @return mixed
	 */
	private static function mask_recursive( $value, array $email_keys, array $phone_keys, array $redact_keys, string $current_key = '' ) {
		$key_lower = strtolower( $current_key );

		if ( in_array( $key_lower, $email_keys, true ) && is_string( $value ) ) {
			return WPPE_Bridge_Pii_Masker::mask_email( $value );
		}
		if ( in_array( $key_lower, $phone_keys, true ) && is_string( $value ) ) {
			return WPPE_Bridge_Pii_Masker::mask_phone( $value );
		}
		if ( in_array( $key_lower, $redact_keys, true ) ) {
			return '[masked]';
		}

		if ( is_array( $value ) ) {
			$out = array();
			foreach ( $value as $k => $v ) {
				$out[ $k ] = self::mask_recursive( $v, $email_keys, $phone_keys, $redact_keys, (string) $k );
			}
			return $out;
		}

		return $value;
	}

	/**
	 * Trunca message a MAX_MESSAGE_LENGTH chars.
	 *
	 * @param string $message Mensaje.
	 * @return string
	 */
	private static function truncate_message( string $message ): string {
		if ( mb_strlen( $message, 'UTF-8' ) <= self::MAX_MESSAGE_LENGTH ) {
			return $message;
		}
		return mb_substr( $message, 0, self::MAX_MESSAGE_LENGTH - 3, 'UTF-8' ) . '...';
	}

	/**
	 * Trunca context JSON a MAX_CONTEXT_BYTES bytes.
	 *
	 * @param mixed $json String JSON o false.
	 * @return string|null
	 */
	private static function truncate_context( $json ): ?string {
		if ( ! is_string( $json ) ) {
			return null;
		}
		if ( strlen( $json ) <= self::MAX_CONTEXT_BYTES ) {
			return $json;
		}
		return substr( $json, 0, self::MAX_CONTEXT_BYTES - 18 ) . '..."[truncated]"}';
	}
}
