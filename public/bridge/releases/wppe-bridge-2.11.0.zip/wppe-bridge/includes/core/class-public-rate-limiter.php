<?php
/**
 * Rate limiter para endpoints PUBLICOS (frontend, visitantes anonimos).
 *
 * Distinto del throttle de Admin_Ajax (que es user_id-based, 1 llamada
 * por ventana y hace wp_die): este es IP-based, con contador real de
 * N llamadas por ventana, retorna bool (el caller decide la respuesta
 * HTTP) y se carga SIEMPRE (no solo en admin) porque su consumidor es
 * el endpoint REST del Widget de Contacto (D-W2).
 *
 * Storage: transient con contador + timestamp de reset. El increment
 * NO es atomico (get + set): dos requests simultaneos pueden contar
 * como uno. Aceptado — es proteccion anti-abuso best-effort, no un
 * contador de facturacion. Un atacante que explote la carrera gana a
 * lo sumo un par de requests extra por ventana.
 *
 * @package WPPE_Bridge
 * @since 2.11.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Rate limiter por key arbitraria (tipicamente IP) para trafico anonimo.
 */
final class WPPE_Bridge_Public_Rate_Limiter {

	/**
	 * Prefijo del transient. El key completo es
	 * `wppe_bridge_prl_{md5(scope|key)}` — md5 para acotar longitud
	 * (los transients viven en wp_options con option_name VARCHAR).
	 */
	public const TRANSIENT_PREFIX = 'wppe_bridge_prl_';

	/**
	 * Filter para override de la IP del cliente. Sitios detras de proxy
	 * (Cloudflare sin restore de IP a nivel server) pueden resolver la
	 * IP real aqui. Por default usamos REMOTE_ADDR y NUNCA confiamos en
	 * X-Forwarded-For (spoofeable por cualquier cliente).
	 */
	public const FILTER_CLIENT_IP = 'wppe_bridge_public_rate_limiter_client_ip';

	/**
	 * Consulta y consume un slot del limite. Un solo metodo porque
	 * separar check de consume abriria una segunda ventana de carrera.
	 *
	 * @param string $scope          Namespace del limite (ej. 'widget_lead').
	 * @param string $key            Identidad del cliente (ej. IP).
	 * @param int    $limit          Requests permitidos por ventana.
	 * @param int    $window_seconds Duracion de la ventana en segundos.
	 * @return bool true si el request esta permitido, false si excede.
	 */
	public static function allow( string $scope, string $key, int $limit, int $window_seconds ): bool {
		if ( $limit < 1 || $window_seconds < 1 ) {
			return false;
		}

		$transient_key = self::TRANSIENT_PREFIX . md5( $scope . '|' . $key );
		$now           = time();
		$state         = get_transient( $transient_key );

		if ( ! is_array( $state ) || ! isset( $state['count'], $state['reset_at'] ) || $now >= (int) $state['reset_at'] ) {
			// Ventana nueva.
			$state = array(
				'count'    => 0,
				'reset_at' => $now + $window_seconds,
			);
		}

		if ( (int) $state['count'] >= $limit ) {
			return false;
		}

		++$state['count'];
		// El TTL del transient acompaña el reset de la ventana para que
		// las keys de IPs que no vuelven se auto-limpien de wp_options.
		set_transient( $transient_key, $state, max( 1, (int) $state['reset_at'] - $now ) );

		return true;
	}

	/**
	 * IP del cliente para usar como key. Solo REMOTE_ADDR (ver
	 * FILTER_CLIENT_IP para el caso proxy). Si no hay IP disponible,
	 * retorna 'unknown' — todo ese trafico comparte un bucket, que es
	 * el comportamiento conservador correcto para requests anomalos.
	 *
	 * @return string
	 */
	public static function client_ip(): string {
		$ip = '';
		if ( isset( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		}

		/**
		 * Filtra la IP del cliente usada como key del rate limiter.
		 *
		 * @param string $ip IP detectada (REMOTE_ADDR o '').
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- constante con valor `wppe_bridge_public_rate_limiter_client_ip`, prefijo correcto.
		$ip = (string) apply_filters( self::FILTER_CLIENT_IP, $ip );

		return '' === $ip ? 'unknown' : $ip;
	}
}
