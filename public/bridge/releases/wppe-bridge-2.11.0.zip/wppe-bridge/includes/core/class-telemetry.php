<?php
/**
 * Telemetria operativa hacia api.wp.pe (guardrails anti uso no
 * autorizado).
 *
 * Envia eventos minimos — dominio del sitio, version del plugin,
 * estado de licencia — para que Mono Media sepa QUE dominios activan
 * el plugin y cuales intentan usarlo bloqueados. NO envia datos
 * personales de visitantes ni leads (el dominio de un sitio no es
 * dato personal; igual se declara en el readme por transparencia).
 *
 * Fire-and-forget: request no bloqueante con timeout corto; si el
 * endpoint receptor no existe todavia (pendiente en api.wp.pe), el
 * POST muere silencioso sin afectar nada.
 *
 * @package WPPE_Bridge
 * @since 2.11.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Beacon de eventos operativos hacia el servidor de Mono Media.
 */
final class WPPE_Bridge_Telemetry {

	/**
	 * Endpoint receptor (filtrable): app Coolify dedicada
	 * (repo monomediaperu/wppe-telemetry). Si el servicio no esta
	 * desplegado todavia, los POSTs se pierden sin efecto.
	 */
	public const DEFAULT_ENDPOINT = 'https://telemetry.wp.pe/';

	/**
	 * Eventos conocidos.
	 */
	public const EVENT_ACTIVATED       = 'activated';
	public const EVENT_BLOCKED_ATTEMPT = 'blocked_attempt';

	/**
	 * Throttle del evento blocked_attempt: 1 por dia. Un sitio
	 * bloqueado con trafico dispararia el beacon en cada tick del
	 * worker — con uno diario Mono ya sabe que sigue intentando.
	 */
	public const BLOCKED_THROTTLE_SECONDS = 86400;

	/**
	 * Transient key del throttle.
	 */
	public const THROTTLE_TRANSIENT = 'wppe_bridge_telemetry_blocked_sent';

	/**
	 * Envia un evento. Nunca lanza, nunca bloquea.
	 *
	 * @param string $event Nombre del evento.
	 * @param array  $extra Campos adicionales (escalares).
	 * @return void
	 */
	public static function send( string $event, array $extra = array() ): void {
		/**
		 * Permite desactivar la telemetria (ej. entornos dev).
		 *
		 * @param bool $enabled Default true.
		 */
		if ( ! apply_filters( 'wppe_bridge_telemetry_enabled', true ) ) {
			return;
		}
		if ( ! function_exists( 'wp_remote_post' ) ) {
			return;
		}

		/**
		 * Filtra el endpoint receptor de telemetria.
		 *
		 * @param string $endpoint Default DEFAULT_ENDPOINT.
		 */
		$endpoint = (string) apply_filters( 'wppe_bridge_telemetry_endpoint', self::DEFAULT_ENDPOINT );

		// Forzar HTTPS (hardening v2.11.0): un filtro mal configurado que
		// apunte a http:// mandaria el beacon en claro. Defensa en
		// profundidad — si no es https, no se envia.
		if ( 0 !== stripos( $endpoint, 'https://' ) ) {
			return;
		}

		$payload = array_merge(
			array(
				'event'         => $event,
				'domain'        => self::site_host(),
				'version'       => defined( 'WPPE_BRIDGE_VERSION' ) ? WPPE_BRIDGE_VERSION : '',
				'license_state' => class_exists( 'WPPE_Bridge_License_Manager' )
					? WPPE_Bridge_License_Manager::state()
					: 'unknown',
				'ts'            => time(),
			),
			$extra
		);

		wp_remote_post(
			$endpoint,
			array(
				'timeout'  => 2,
				'blocking' => false,
				'headers'  => array( 'Content-Type' => 'application/json' ),
				'body'     => wp_json_encode( $payload ),
			)
		);
	}

	/**
	 * Evento blocked_attempt con throttle diario.
	 *
	 * @return void
	 */
	public static function maybe_send_blocked(): void {
		if ( false !== get_transient( self::THROTTLE_TRANSIENT ) ) {
			return;
		}
		set_transient( self::THROTTLE_TRANSIENT, time(), self::BLOCKED_THROTTLE_SECONDS );
		self::send( self::EVENT_BLOCKED_ATTEMPT );
	}

	/**
	 * Host del sitio.
	 *
	 * @return string
	 */
	public static function site_host(): string {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		return is_string( $host ) ? $host : '';
	}
}
