<?php
/**
 * Singleton principal del plugin.
 *
 * Responsable de cargar todas las clases del plugin (autoload manual)
 * y registrar los hooks WordPress de runtime. Activator y Deactivator
 * se cargan aquí pero se ejecutan via register_activation_hook /
 * register_deactivation_hook desde el bootstrap.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

// Activator y Deactivator se cargan siempre (los hooks de WP los necesitan
// disponibles antes de plugins_loaded).
require_once WPPE_BRIDGE_PLUGIN_DIR . 'includes/class-activator.php';
require_once WPPE_BRIDGE_PLUGIN_DIR . 'includes/class-deactivator.php';

/**
 * Clase principal — singleton.
 */
final class WPPE_Bridge_Plugin {

	/**
	 * Instancia única.
	 *
	 * @var self|null
	 */
	private static ?self $instance = null;

	/**
	 * Acceso a la instancia. Idempotente.
	 *
	 * @return self
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->load_dependencies();
			self::$instance->register_hooks();
		}
		return self::$instance;
	}

	/**
	 * Constructor privado — usar instance().
	 */
	private function __construct() {}

	/**
	 * Carga manual de las clases del plugin.
	 *
	 * Sin Composer en runtime. Orden importa para herencias futuras.
	 */
	private function load_dependencies(): void {
		$base = WPPE_BRIDGE_PLUGIN_DIR . 'includes/';

		// Helpers (cargados antes de core porque Logger depende de Pii_Masker
		// y Webhook/Odoo destinations dependen de Url_Validator).
		require_once $base . 'helpers/class-pii-masker.php';
		require_once $base . 'helpers/class-url-validator.php';
		require_once $base . 'helpers/class-cache-detector.php';

		// Core.
		require_once $base . 'core/class-logger.php';
		require_once $base . 'core/class-normalizer.php';
		require_once $base . 'core/class-utm-channel-mapper.php';
		require_once $base . 'core/class-dedup.php';
		require_once $base . 'core/class-queue.php';
		require_once $base . 'core/class-sperant-client.php';
		require_once $base . 'core/class-ghl-client.php';
		require_once $base . 'core/class-odoo-client.php';
		require_once $base . 'core/class-hubspot-client.php';
		require_once $base . 'core/class-whitelist-client.php';
		require_once $base . 'core/class-license-manager.php';
		require_once $base . 'core/class-public-rate-limiter.php';
		require_once $base . 'core/class-telemetry.php';
		require_once $base . 'core/class-updater.php';
		require_once $base . 'core/class-notifier.php';
		require_once $base . 'core/class-worker.php';

		// Destinations (multi-CRM via factory).
		require_once $base . 'destinations/interface-destination.php';
		require_once $base . 'destinations/class-destination-result.php';
		require_once $base . 'destinations/class-sperant-destination.php';
		require_once $base . 'destinations/class-ghl-destination.php';
		require_once $base . 'destinations/class-odoo-destination.php';
		require_once $base . 'destinations/class-hubspot-destination.php';
		require_once $base . 'destinations/class-webhook-destination.php';
		require_once $base . 'destinations/class-destination-factory.php';

		// Adapters (interface y base abstracto antes de los concretos).
		require_once $base . 'adapters/interface-form-adapter.php';
		require_once $base . 'adapters/class-form-adapter-base.php';
		require_once $base . 'adapters/class-fluent-forms-adapter.php';
		require_once $base . 'adapters/class-gravity-forms-adapter.php';
		require_once $base . 'adapters/class-elementor-forms-adapter.php';
		require_once $base . 'adapters/class-cf7-forms-adapter.php';
		require_once $base . 'adapters/class-widget-adapter.php';

		// Modulos opcionales (D4.4).
		require_once $base . 'modules/class-module-utm-capture.php';
		require_once $base . 'modules/class-module-submit-lock.php';
		require_once $base . 'modules/class-module-meta-capi.php';
		require_once $base . 'modules/class-module-thank-you-pixel.php';
		require_once $base . 'modules/class-module-contact-widget.php';

		// REST publico del Widget de Contacto (D-W2). La CLASE se carga
		// siempre; la RUTA solo se registra si el modulo esta enabled
		// (ver Module_Contact_Widget::register).
		require_once $base . 'rest/class-widget-controller.php';

		// Admin (solo en wp-admin).
		if ( is_admin() ) {
			require_once $base . 'admin/class-admin-menu.php';
			require_once $base . 'admin/class-admin-ajax.php';
			require_once $base . 'admin/class-admin-assets.php';
			require_once $base . 'admin/class-form-discovery.php';
			require_once $base . 'admin/class-settings-page.php';
			require_once $base . 'admin/class-ghl-settings-page.php';
			require_once $base . 'admin/class-odoo-settings-page.php';
			require_once $base . 'admin/class-hubspot-settings-page.php';
			require_once $base . 'admin/class-webhook-settings-page.php';
			require_once $base . 'admin/class-mapping-page.php';
			require_once $base . 'admin/class-ghl-mapping-page.php';
			require_once $base . 'admin/class-odoo-mapping-page.php';
			require_once $base . 'admin/class-hubspot-mapping-page.php';
			require_once $base . 'admin/class-logs-list-table.php';
			require_once $base . 'admin/class-logs-page.php';
			require_once $base . 'admin/class-modules-page.php';
			require_once $base . 'admin/class-meta-capi-settings-page.php';
			require_once $base . 'admin/class-thank-you-pixel-settings-page.php';
			require_once $base . 'admin/class-widget-settings-page.php';
			require_once $base . 'admin/class-guardrails-notices.php';
			require_once $base . 'admin/class-help-page.php';
			require_once $base . 'admin/class-environment-diagnostics.php';
			require_once $base . 'admin/class-operational-status.php';
			require_once $base . 'admin/class-admin-notice.php';
			require_once $base . 'admin/class-plugin-row-actions.php';
			require_once $base . 'admin/class-setup-wizard.php';
		}

		// WP-CLI.
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			require_once $base . 'cli/class-cli-commands.php';
		}
	}

	/**
	 * Registra hooks WordPress de runtime.
	 *
	 * Los handlers concretos se implementan en cada clase. Aquí solo
	 * cableamos las suscripciones.
	 */
	private function register_hooks(): void {
		// v2.5.8: schema upgrade check. Corre 1ra vez post-update si
		// `WPPE_BRIDGE_DB_VERSION` subio. Idempotente (early return si
		// ya esta al dia). No corre en fresh install — `activate()` ya
		// crea la tabla con el schema actual.
		WPPE_Bridge_Activator::maybe_upgrade_database();

		// Worker (cron) y cleanup de logs (cron diario).
		add_action( 'wppe_bridge_worker_tick', array( 'WPPE_Bridge_Worker', 'process_queue' ) );
		add_action( 'wppe_bridge_logs_cleanup_tick', array( 'WPPE_Bridge_Logger', 'cleanup_tick' ) );

		// v2.5.9 — Cleanup diario de queue (retention LPDP).
		add_action( WPPE_Bridge_Activator::CRON_HOOK_QUEUE_CLEANUP, array( 'WPPE_Bridge_Queue', 'cleanup_tick' ) );

		// Whitelist refresh (cron diario, v1.1.0).
		add_action( WPPE_Bridge_Whitelist_Client::CRON_HOOK_REFRESH, array( 'WPPE_Bridge_Whitelist_Client', 'cron_refresh' ) );

		// Updater nativo de WordPress (v2.2.0). Hookea
		// pre_set_site_transient_update_plugins + plugins_api para que
		// el cliente vea badge "Update available" en wp-admin.
		WPPE_Bridge_Updater::register();

		// Notifier de errores por email batched (v2.4.0). Hookea
		// wppe_bridge_lead_failed para acumular, y registra el cron tick
		// que envia emails con throttle 15 min.
		WPPE_Bridge_Notifier::register();

		// Cron schedules custom registrados en runtime (v1.2.6). Antes
		// el filter solo se registraba dentro del activator. Si una
		// herramienta de mantenimiento limpia y reagenda los crons, el
		// schedule `wppebridge_minute` no esta disponible y WordPress
		// no puede reagendar nuestro evento. Registrarlo en runtime es
		// idempotente y barato.
		// phpcs:ignore WordPress.WP.CronInterval.ChangeDetected -- 1 minuto: ver Activator::register_cron_schedule.
		add_filter( 'cron_schedules', array( 'WPPE_Bridge_Activator', 'register_cron_schedule' ) );

		// Self-healing del cron (v1.2.6). En cada admin_init, verifica
		// que los 3 eventos del plugin esten agendados. Si falta
		// alguno, lo re-agenda. Cubre el caso "alguna herramienta limpio
		// los crons" sin necesidad de desactivar/reactivar el plugin.
		if ( is_admin() ) {
			add_action( 'admin_init', array( __CLASS__, 'ensure_cron_events' ) );
		}

		// Admin notice global de leads fallidos no atendidos (v2.4.0).
		if ( is_admin() ) {
			WPPE_Bridge_Admin_Notice::register();
		}

		// Plugin row actions: link "Buscar actualizacion" en
		// wp-admin/plugins.php (v2.5.2). Hookea
		// plugin_action_links_{basename} + admin_post handler + notice.
		if ( is_admin() ) {
			WPPE_Bridge_Plugin_Row_Actions::register();
		}

		// v2.5.13 — Setup wizard stepper global. Hookea admin_notices y
		// solo renderiza en pantallas del plugin. Auto-oculta como
		// mini-badge al 100%.
		if ( is_admin() ) {
			WPPE_Bridge_Setup_Wizard::register();
		}

		// v2.11.0 — Guardrails: CTA a ventas cuando la licencia esta
		// bloqueada + aviso/alerta de plugin de cache fuera del stack.
		if ( is_admin() ) {
			WPPE_Bridge_Guardrails_Notices::register();
		}

		// Admin menu, settings, AJAX, assets y mapping handler.
		if ( is_admin() ) {
			add_action( 'admin_menu', array( 'WPPE_Bridge_Admin_Menu', 'register' ) );
			add_action( 'admin_init', array( 'WPPE_Bridge_Settings_Page', 'register_settings' ) );
			add_action( 'admin_init', array( 'WPPE_Bridge_Ghl_Settings_Page', 'register_settings' ) );
			add_action( 'admin_init', array( 'WPPE_Bridge_Odoo_Settings_Page', 'register_settings' ) );
			add_action( 'admin_init', array( 'WPPE_Bridge_Hubspot_Settings_Page', 'register_settings' ) );
			add_action( 'admin_init', array( 'WPPE_Bridge_Webhook_Settings_Page', 'register_settings' ) );
			add_action( 'admin_enqueue_scripts', array( 'WPPE_Bridge_Admin_Assets', 'enqueue' ) );
			WPPE_Bridge_Admin_Ajax::register();
			WPPE_Bridge_Mapping_Page::register();
			WPPE_Bridge_Ghl_Mapping_Page::register();
			WPPE_Bridge_Odoo_Mapping_Page::register();
			WPPE_Bridge_Hubspot_Mapping_Page::register();
			WPPE_Bridge_Logs_Page::register();
			WPPE_Bridge_Modules_Page::register();
			add_action( 'admin_init', array( 'WPPE_Bridge_Meta_Capi_Settings_Page', 'register_settings' ) );
			add_action( 'admin_init', array( 'WPPE_Bridge_Thank_You_Pixel_Settings_Page', 'register_settings' ) );
			add_action( 'admin_init', array( 'WPPE_Bridge_Widget_Settings_Page', 'register_settings' ) );
		}

		// Modulos opcionales (D4.4).
		WPPE_Bridge_Module_Utm_Capture::register();
		WPPE_Bridge_Module_Submit_Lock::register();
		WPPE_Bridge_Module_Meta_Capi::register();
		WPPE_Bridge_Module_Thank_You_Pixel::register();
		WPPE_Bridge_Module_Contact_Widget::register();

		// Adapters de formularios — cada uno se autoregistra si su plugin esta activo.
		add_action( 'plugins_loaded', array( 'WPPE_Bridge_Fluent_Forms_Adapter', 'maybe_register' ), 20 );
		add_action( 'plugins_loaded', array( 'WPPE_Bridge_Gravity_Forms_Adapter', 'maybe_register' ), 20 );
		add_action( 'plugins_loaded', array( 'WPPE_Bridge_Elementor_Forms_Adapter', 'maybe_register' ), 20 );
		add_action( 'plugins_loaded', array( 'WPPE_Bridge_Cf7_Forms_Adapter', 'maybe_register' ), 20 );

		// WP-CLI.
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			WPPE_Bridge_CLI_Commands::register();
		}
	}

	/**
	 * Self-healing del cron (v1.2.6).
	 *
	 * Verifica que los 3 eventos del plugin esten agendados en WP-Cron.
	 * Si falta alguno, lo re-agenda con su schedule correspondiente.
	 *
	 * Razon: alguna herramienta externa (plugin de cache que limpia
	 * options, restore de backup, migracion entre servidores) puede
	 * vaciar el option `cron` de WordPress. Sin esto, los hooks del
	 * plugin se pierden y el operador tiene que desactivar/reactivar
	 * el plugin desde Plugins. Este self-healing automatiza esa
	 * recuperacion en cada page load del admin.
	 *
	 * Idempotente: solo agenda lo que falta. Si todos los eventos
	 * estan presentes, no hace nada.
	 *
	 * Hookeado en `admin_init` (no `init`) para evitar overhead en el
	 * frontend. Los crons del plugin son solo necesarios para
	 * operaciones admin (procesar queue, cleanup logs, refresh
	 * whitelist) — todas iniciadas desde el lado servidor.
	 *
	 * @return void
	 */
	public static function ensure_cron_events(): void {
		// Worker tick (cada minuto).
		if ( function_exists( 'wp_next_scheduled' )
			&& false === wp_next_scheduled( WPPE_Bridge_Activator::CRON_HOOK ) ) {
			wp_schedule_event(
				time() + MINUTE_IN_SECONDS,
				WPPE_Bridge_Activator::CRON_SCHEDULE,
				WPPE_Bridge_Activator::CRON_HOOK
			);
		}

		// Logs cleanup (diario).
		if ( function_exists( 'wp_next_scheduled' )
			&& false === wp_next_scheduled( WPPE_Bridge_Activator::CRON_HOOK_LOGS_CLEANUP ) ) {
			wp_schedule_event(
				time() + HOUR_IN_SECONDS,
				WPPE_Bridge_Activator::CRON_SCHEDULE_DAILY,
				WPPE_Bridge_Activator::CRON_HOOK_LOGS_CLEANUP
			);
		}

		// Whitelist refresh (diario).
		if ( class_exists( 'WPPE_Bridge_Whitelist_Client' )
			&& function_exists( 'wp_next_scheduled' )
			&& false === wp_next_scheduled( WPPE_Bridge_Whitelist_Client::CRON_HOOK_REFRESH ) ) {
			wp_schedule_event(
				time() + HOUR_IN_SECONDS,
				WPPE_Bridge_Activator::CRON_SCHEDULE_DAILY,
				WPPE_Bridge_Whitelist_Client::CRON_HOOK_REFRESH
			);
		}

		// Notifier tick (cada 5 min, v2.4.0). Self-heal igual que los
		// demas crons del plugin.
		if ( class_exists( 'WPPE_Bridge_Notifier' )
			&& function_exists( 'wp_next_scheduled' )
			&& false === wp_next_scheduled( WPPE_Bridge_Notifier::CRON_HOOK_TICK ) ) {
			wp_schedule_event(
				time() + ( 5 * MINUTE_IN_SECONDS ),
				WPPE_Bridge_Activator::CRON_SCHEDULE_5MIN,
				WPPE_Bridge_Notifier::CRON_HOOK_TICK
			);
		}
	}
}
