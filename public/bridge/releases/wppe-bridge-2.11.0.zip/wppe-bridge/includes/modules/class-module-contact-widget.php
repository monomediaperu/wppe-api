<?php
/**
 * Modulo opcional Widget de Contacto (D-W1).
 *
 * Boton flotante de contacto (WhatsApp + Llamada) con pre-captura de
 * datos: el visitante deja nombre/telefono ANTES de saltar al canal,
 * el lead entra al pipeline CRM con su atribucion (UTMs/gclid de la
 * cookie del modulo UTM Capture) y el visitante recibe un codigo de
 * referencia para cruzar la conversacion con el lead del CRM.
 *
 * Estado del ciclo (4 PRs):
 * - PR-1: endpoint REST publico + rate limiter + adapter. ✔
 * - PR-2 (este): render del boton flotante + apariencia + reglas por
 *   pagina. El panel abre un link directo a WhatsApp (estilo click-to-
 *   chat clasico); PR-3 lo reemplaza por el pre-chat de captura.
 * - PR-3: flujos por canal (pre-chat, llamada, enlaces).
 * - PR-4: horarios client-side + lead scoring.
 *
 * Rendimiento (D-W4): el HTML del widget se resuelve server-side SOLO
 * en funcion de options + path del request — byte a byte identico
 * entre cargas de la misma pagina, cacheable sin exclusiones. En
 * paginas donde el widget no aplica (reglas) no se enqueua NADA.
 *
 * @package WPPE_Bridge
 * @since 2.11.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Modulo Contact Widget: endpoint REST + render frontend del boton.
 */
final class WPPE_Bridge_Module_Contact_Widget {

	/**
	 * Slug del modulo (usado como key en wp_options).
	 */
	public const SLUG = 'contact_widget';

	/**
	 * Option key de enabled.
	 */
	public const OPTION_ENABLED = 'wppe_bridge_module_contact_widget_enabled';

	/**
	 * Option de apariencia (array: position, color_primary, color_text,
	 * icon, icon_custom_url, cta_label).
	 */
	public const OPTION_APPEARANCE = 'wppe_bridge_widget_appearance';

	/**
	 * Option del numero de WhatsApp global (overridable por regla).
	 */
	public const OPTION_WHATSAPP_NUMBER = 'wppe_bridge_widget_whatsapp_number';

	/**
	 * Option del saludo global (overridable por regla).
	 */
	public const OPTION_GREETING = 'wppe_bridge_widget_greeting';

	/**
	 * Option de reglas por pagina. Array de rules:
	 * `{pattern, action(show|hide), greeting, number}` — first match
	 * wins contra el path del request. Sin match => visible con
	 * defaults globales.
	 */
	public const OPTION_PAGE_RULES = 'wppe_bridge_widget_page_rules';

	/**
	 * Option de canales (array: whatsapp_enabled, llamada_enabled,
	 * central_number, allow_schedule).
	 */
	public const OPTION_CHANNELS = 'wppe_bridge_widget_channels';

	/**
	 * Option de enlaces personalizados (D-W8): array de
	 * `{label, url}` — links medidos SIN flujo de captura.
	 */
	public const OPTION_CUSTOM_LINKS = 'wppe_bridge_widget_custom_links';

	/**
	 * Option de consentimiento (array: privacy_url, text).
	 */
	public const OPTION_CONSENT = 'wppe_bridge_widget_consent';

	/**
	 * Option de lead scoring (D-W5): puntajes por accion. La suma
	 * viaja al CRM en `observation` para que el vendedor priorice.
	 */
	public const OPTION_SCORING = 'wppe_bridge_widget_scoring';

	/**
	 * Defaults de canales, incluyendo horarios (D-W7). Los horarios se
	 * evaluan CLIENT-SIDE contra la timezone del sitio para preservar
	 * el HTML byte-identico (D-W4): el server siempre emite la misma
	 * config; el JS decide que mostrar segun la hora del visitante.
	 *
	 * `*_off_behavior`: comportamiento fuera de horario —
	 * whatsapp: `note` (mostrar con aviso de respuesta diferida) o
	 * `hide`; llamada: `schedule_only` (solo "programar llamada",
	 * el caso "domingos sin call center") o `hide`.
	 */
	public const CHANNELS_DEFAULTS = array(
		'whatsapp_enabled'       => true,
		'llamada_enabled'        => false,
		'central_number'         => '',
		'allow_schedule'         => true,
		'whatsapp_hours_enabled' => false,
		'whatsapp_days'          => array( 1, 2, 3, 4, 5 ),
		'whatsapp_start'         => '09:00',
		'whatsapp_end'           => '18:00',
		'whatsapp_off_behavior'  => 'note',
		'llamada_hours_enabled'  => false,
		'llamada_days'           => array( 1, 2, 3, 4, 5 ),
		'llamada_start'          => '09:00',
		'llamada_end'            => '18:00',
		'llamada_off_behavior'   => 'schedule_only',
	);

	/**
	 * Defaults de scoring (D-W5): declarativo, configurable en admin,
	 * cero magia. `off_hours` suma porque un lead que deja datos fuera
	 * de horario muestra intencion alta.
	 */
	public const SCORING_DEFAULTS = array(
		'submit'             => 5,
		'whatsapp'           => 5,
		'llamada_inmediata'  => 10,
		'llamada_programada' => 8,
		'has_email'          => 2,
		'has_interest'       => 2,
		'paid_click'         => 3,
		'off_hours'          => 3,
	);

	/**
	 * Texto default del consentimiento (Ley 29733).
	 */
	public const CONSENT_DEFAULT_TEXT = 'Acepto el tratamiento de mis datos personales para ser contactado sobre mi consulta.';

	/**
	 * Handles de assets frontend.
	 */
	public const ASSET_HANDLE_CSS = 'wppe-bridge-contact-widget';
	public const ASSET_HANDLE_JS  = 'wppe-bridge-contact-widget';

	/**
	 * Defaults de apariencia.
	 */
	public const APPEARANCE_DEFAULTS = array(
		'position'        => 'br',
		'color_primary'   => '#25D366',
		'color_text'      => '#ffffff',
		'icon'            => 'whatsapp',
		'icon_custom_url' => '',
		'cta_label'       => 'Conversemos',
	);

	/**
	 * Valores validos de position e icon.
	 */
	public const VALID_POSITIONS = array( 'br', 'bl' );
	public const VALID_ICONS     = array( 'whatsapp', 'chat', 'phone' );

	/**
	 * Lee si el modulo esta enabled.
	 *
	 * @return bool
	 */
	public static function is_enabled(): bool {
		return (bool) get_option( self::OPTION_ENABLED, false );
	}

	/**
	 * Registra hooks runtime. Llamado desde Plugin::register_hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		add_action( 'rest_api_init', array( 'WPPE_Bridge_Widget_Controller', 'register_routes' ) );
		add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue_frontend' ) );
		add_action( 'wp_footer', array( self::class, 'render_widget' ), 20 );
	}

	/**
	 * Apariencia resuelta (defaults + option, whitelisted).
	 *
	 * @return array<string,string>
	 */
	public static function get_appearance(): array {
		$raw = get_option( self::OPTION_APPEARANCE, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}
		$out = array_merge( self::APPEARANCE_DEFAULTS, array_intersect_key( $raw, self::APPEARANCE_DEFAULTS ) );

		// Defensa en profundidad ante options corruptas (el sanitizer
		// del settings page ya valida al guardar).
		if ( ! in_array( $out['position'], self::VALID_POSITIONS, true ) ) {
			$out['position'] = self::APPEARANCE_DEFAULTS['position'];
		}
		if ( ! in_array( $out['icon'], self::VALID_ICONS, true ) ) {
			$out['icon'] = self::APPEARANCE_DEFAULTS['icon'];
		}
		foreach ( array( 'color_primary', 'color_text' ) as $key ) {
			if ( ! is_string( $out[ $key ] ) || ! preg_match( '/^#[0-9a-fA-F]{3,8}$/', $out[ $key ] ) ) {
				$out[ $key ] = self::APPEARANCE_DEFAULTS[ $key ];
			}
		}
		return $out;
	}

	/**
	 * Reglas por pagina saneadas.
	 *
	 * @return array<int,array{pattern:string,action:string,greeting:string,number:string}>
	 */
	public static function get_page_rules(): array {
		$raw = get_option( self::OPTION_PAGE_RULES, array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$rules = array();
		foreach ( $raw as $rule ) {
			if ( ! is_array( $rule ) || empty( $rule['pattern'] ) || ! is_string( $rule['pattern'] ) ) {
				continue;
			}
			$rules[] = array(
				'pattern'  => $rule['pattern'],
				'action'   => ( isset( $rule['action'] ) && 'hide' === $rule['action'] ) ? 'hide' : 'show',
				'greeting' => isset( $rule['greeting'] ) && is_string( $rule['greeting'] ) ? $rule['greeting'] : '',
				'number'   => isset( $rule['number'] ) && is_string( $rule['number'] ) ? $rule['number'] : '',
			);
		}
		return $rules;
	}

	/**
	 * Matchea un pattern de regla contra el path del request.
	 *
	 * Soporta: exacto (`/contacto`), prefijo con wildcard sufijo
	 * (`/depas*`) y catch-all (`*`). Trailing slash del path se
	 * normaliza (`/contacto/` == `/contacto`). Query string NO
	 * participa (la resolucion debe ser cacheable por URL de pagina).
	 *
	 * @param string $pattern Pattern de la regla.
	 * @param string $path    Path del request (con leading slash).
	 * @return bool
	 */
	public static function path_matches( string $pattern, string $path ): bool {
		$pattern = trim( $pattern );
		if ( '' === $pattern ) {
			return false;
		}
		if ( '*' === $pattern ) {
			return true;
		}

		// Normalizacion: leading slash + sin trailing slash.
		$normalize = static function ( string $value ): string {
			$value = '/' . ltrim( $value, '/' );
			return '/' === $value ? '/' : rtrim( $value, '/' );
		};

		$path = $normalize( strtok( $path, '?' ) );

		if ( str_ends_with( $pattern, '*' ) ) {
			$prefix = $normalize( substr( $pattern, 0, -1 ) );
			return 0 === strpos( $path . '/', rtrim( $prefix, '/' ) . '/' ) || $path === $prefix;
		}

		return $path === $normalize( $pattern );
	}

	/**
	 * Config de canales resuelta (defaults + option).
	 *
	 * @return array<string,mixed>
	 */
	public static function get_channels(): array {
		$raw = get_option( self::OPTION_CHANNELS, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}
		return array_merge( self::CHANNELS_DEFAULTS, array_intersect_key( $raw, self::CHANNELS_DEFAULTS ) );
	}

	/**
	 * Enlaces personalizados saneados.
	 *
	 * @return array<int,array{label:string,url:string}>
	 */
	public static function get_custom_links(): array {
		$raw = get_option( self::OPTION_CUSTOM_LINKS, array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$links = array();
		foreach ( $raw as $link ) {
			if ( ! is_array( $link ) || empty( $link['label'] ) || empty( $link['url'] )
				|| ! is_string( $link['label'] ) || ! is_string( $link['url'] ) ) {
				continue;
			}
			$links[] = array(
				'label' => $link['label'],
				'url'   => $link['url'],
			);
		}
		return $links;
	}

	/**
	 * Config de scoring resuelta (defaults + option).
	 *
	 * @return array<string,int>
	 */
	public static function get_scoring(): array {
		$raw = get_option( self::OPTION_SCORING, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}
		$out = self::SCORING_DEFAULTS;
		foreach ( $out as $key => $default_points ) {
			if ( isset( $raw[ $key ] ) && is_numeric( $raw[ $key ] ) ) {
				$out[ $key ] = (int) $raw[ $key ];
			}
		}
		return $out;
	}

	/**
	 * Timezone del sitio para la evaluacion client-side de horarios
	 * (D-W7): nombre IANA si esta configurado, sino offset `+HH:MM`
	 * desde gmt_offset. El JS soporta ambos formatos.
	 *
	 * @return string Ej. "America/Lima" o "-05:00".
	 */
	public static function site_timezone(): string {
		$tz = get_option( 'timezone_string', '' );
		if ( is_string( $tz ) && '' !== $tz ) {
			return $tz;
		}
		$offset  = (float) get_option( 'gmt_offset', 0 );
		$hours   = (int) $offset;
		$minutes = (int) round( abs( $offset - $hours ) * 60 );
		return sprintf( '%+03d:%02d', $hours, $minutes );
	}

	/**
	 * Config de horarios por canal para embeber en el HTML (JSON
	 * estatico — mismo para todos los visitantes de la pagina).
	 *
	 * @return array<string,array>
	 */
	public static function schedule_config(): array {
		$channels = self::get_channels();
		$build    = static function ( string $prefix ) use ( $channels ): array {
			return array(
				'enabled' => ! empty( $channels[ $prefix . '_hours_enabled' ] ),
				'days'    => array_values( array_map( 'intval', (array) $channels[ $prefix . '_days' ] ) ),
				'start'   => (string) $channels[ $prefix . '_start' ],
				'end'     => (string) $channels[ $prefix . '_end' ],
				'off'     => (string) $channels[ $prefix . '_off_behavior' ],
			);
		};
		return array(
			'whatsapp' => $build( 'whatsapp' ),
			'llamada'  => $build( 'llamada' ),
		);
	}

	/**
	 * Config de consentimiento (Ley 29733).
	 *
	 * @return array{privacy_url:string,text:string}
	 */
	public static function get_consent(): array {
		$raw = get_option( self::OPTION_CONSENT, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}
		$text = isset( $raw['text'] ) && is_string( $raw['text'] ) && '' !== trim( $raw['text'] )
			? $raw['text']
			: self::CONSENT_DEFAULT_TEXT;
		return array(
			'privacy_url' => isset( $raw['privacy_url'] ) && is_string( $raw['privacy_url'] ) ? $raw['privacy_url'] : '',
			'text'        => $text,
		);
	}

	/**
	 * Resuelve la config del widget para un path.
	 *
	 * First-match-wins sobre las reglas; `hide` => null; `show` =>
	 * greeting/number de la regla con fallback a los globales. Sin
	 * match => visible con globales. La disponibilidad de canales se
	 * evalua aparte en should_render().
	 *
	 * @param string $path Path del request.
	 * @return array{greeting:string,number:string}|null null = oculto por regla.
	 */
	public static function resolve_for_path( string $path ): ?array {
		$greeting = (string) get_option( self::OPTION_GREETING, '' );
		$number   = (string) get_option( self::OPTION_WHATSAPP_NUMBER, '' );

		foreach ( self::get_page_rules() as $rule ) {
			if ( ! self::path_matches( $rule['pattern'], $path ) ) {
				continue;
			}
			if ( 'hide' === $rule['action'] ) {
				return null;
			}
			if ( '' !== $rule['greeting'] ) {
				$greeting = $rule['greeting'];
			}
			if ( '' !== $rule['number'] ) {
				$number = $rule['number'];
			}
			break;
		}

		return array(
			'greeting' => $greeting,
			'number'   => $number,
		);
	}

	/**
	 * Decide si el widget tiene algo que ofrecer: al menos un canal
	 * activo con su dato minimo (WhatsApp con numero, Llamada con
	 * central) o un enlace personalizado.
	 *
	 * @param array|null $config Config resuelta por resolve_for_path.
	 * @return bool
	 */
	public static function should_render( ?array $config ): bool {
		if ( null === $config ) {
			return false;
		}

		$channels = self::get_channels();

		$whatsapp_ok = ! empty( $channels['whatsapp_enabled'] ) && '' !== $config['number'];
		$llamada_ok  = ! empty( $channels['llamada_enabled'] ) && '' !== (string) $channels['central_number'];

		return $whatsapp_ok || $llamada_ok || array() !== self::get_custom_links();
	}

	/**
	 * Path actual del request (sin query string).
	 *
	 * @return string
	 */
	public static function current_path(): string {
		if ( ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return '/';
		}
		$uri  = sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) );
		$path = wp_parse_url( $uri, PHP_URL_PATH );
		return is_string( $path ) && '' !== $path ? $path : '/';
	}

	/**
	 * Enqueua CSS + JS del widget SOLO si va a renderizar en esta
	 * pagina (cero bytes donde las reglas lo ocultan).
	 *
	 * @return void
	 */
	public static function enqueue_frontend(): void {
		if ( ! self::should_render( self::resolve_for_path( self::current_path() ) ) ) {
			return;
		}
		wp_enqueue_style(
			self::ASSET_HANDLE_CSS,
			WPPE_BRIDGE_PLUGIN_URL . 'assets/css/contact-widget.css',
			array(),
			WPPE_BRIDGE_VERSION
		);
		wp_enqueue_script(
			self::ASSET_HANDLE_JS,
			WPPE_BRIDGE_PLUGIN_URL . 'assets/js/contact-widget.js',
			array(),
			WPPE_BRIDGE_VERSION,
			true
		);
	}

	/**
	 * URL del endpoint REST del widget. Fallback al path estandar
	 * cuando rest_url no esta disponible (tests).
	 *
	 * @return string
	 */
	public static function endpoint_url(): string {
		if ( function_exists( 'rest_url' ) ) {
			return rest_url( 'wppe-bridge/v1/widget/lead' );
		}
		return home_url( '/wp-json/wppe-bridge/v1/widget/lead' );
	}

	/**
	 * Renderiza el widget en wp_footer. HTML estatico: depende solo de
	 * options + path (byte-identico entre cargas de la misma pagina).
	 *
	 * El panel ofrece los canales activos. WhatsApp y Llamada abren el
	 * pre-chat de captura (el lead entra al CRM ANTES de saltar al
	 * canal); los enlaces personalizados (D-W8) son links directos.
	 * El JS resuelve la interaccion leyendo los data-attributes — todo
	 * el estado esta embebido, cero requests de config.
	 *
	 * @return void
	 */
	public static function render_widget(): void {
		$config = self::resolve_for_path( self::current_path() );
		if ( ! self::should_render( $config ) ) {
			return;
		}

		$appearance = self::get_appearance();
		$channels   = self::get_channels();
		$consent    = self::get_consent();
		$links      = self::get_custom_links();

		$whatsapp_on = ! empty( $channels['whatsapp_enabled'] ) && '' !== $config['number'];
		$llamada_on  = ! empty( $channels['llamada_enabled'] ) && '' !== (string) $channels['central_number'];

		$style = sprintf(
			'--wppe-cw-primary:%s;--wppe-cw-text:%s;',
			$appearance['color_primary'],
			$appearance['color_text']
		);
		?>
<div class="wppe-cw wppe-cw--<?php echo esc_attr( $appearance['position'] ); ?>" data-wppe-cw
	data-endpoint="<?php echo esc_url( self::endpoint_url() ); ?>"
	data-widget-id="default"
	data-wa-number="<?php echo esc_attr( ltrim( $config['number'], '+' ) ); ?>"
	data-central-number="<?php echo esc_attr( (string) $channels['central_number'] ); ?>"
	data-tz="<?php echo esc_attr( self::site_timezone() ); ?>"
	data-schedule="<?php echo esc_attr( (string) wp_json_encode( self::schedule_config() ) ); ?>"
	style="<?php echo esc_attr( $style ); ?>">
	<div class="wppe-cw__panel" id="wppe-cw-panel" hidden>
		<p class="wppe-cw__greeting"><?php echo esc_html( $config['greeting'] ); ?></p>

		<div class="wppe-cw__channels">
			<?php if ( $whatsapp_on ) : ?>
			<button type="button" class="wppe-cw__channel" data-cw-channel="whatsapp">
				<?php esc_html_e( 'WhatsApp', 'wppe-bridge' ); ?>
			</button>
			<?php endif; ?>
			<?php if ( $llamada_on ) : ?>
			<button type="button" class="wppe-cw__channel" data-cw-channel="llamada">
				<?php esc_html_e( 'Llamada', 'wppe-bridge' ); ?>
			</button>
			<?php endif; ?>
			<?php foreach ( $links as $link ) : ?>
			<a class="wppe-cw__channel wppe-cw__channel--link" href="<?php echo esc_url( $link['url'] ); ?>" target="_blank" rel="noopener nofollow">
				<?php echo esc_html( $link['label'] ); ?>
			</a>
			<?php endforeach; ?>
		</div>

		<?php if ( $whatsapp_on || $llamada_on ) : ?>
		<form class="wppe-cw__form" hidden novalidate>
			<input type="text" name="website" class="wppe-cw__hp" tabindex="-1" autocomplete="off" aria-hidden="true" />
			<label class="wppe-cw__field">
				<span><?php esc_html_e( 'Nombre *', 'wppe-bridge' ); ?></span>
				<input type="text" name="name" required maxlength="100" autocomplete="name" />
			</label>
			<label class="wppe-cw__field">
				<span><?php esc_html_e( 'Telefono *', 'wppe-bridge' ); ?></span>
				<input type="tel" name="phone" required maxlength="20" autocomplete="tel" />
			</label>
			<label class="wppe-cw__field">
				<span><?php esc_html_e( 'Email (opcional)', 'wppe-bridge' ); ?></span>
				<input type="email" name="email" maxlength="100" autocomplete="email" />
			</label>
			<label class="wppe-cw__field">
				<span><?php esc_html_e( '¿Que te interesa? (opcional)', 'wppe-bridge' ); ?></span>
				<input type="text" name="interest" maxlength="200" />
			</label>

			<?php if ( $llamada_on ) : ?>
			<fieldset class="wppe-cw__call" data-cw-call hidden>
				<label class="wppe-cw__radio">
					<input type="radio" name="call_pref" value="llamada_inmediata" checked />
					<span><?php esc_html_e( 'Llamar ahora a la central', 'wppe-bridge' ); ?></span>
				</label>
				<?php if ( ! empty( $channels['allow_schedule'] ) ) : ?>
				<label class="wppe-cw__radio">
					<input type="radio" name="call_pref" value="llamada_programada" />
					<span><?php esc_html_e( 'Programar una llamada', 'wppe-bridge' ); ?></span>
				</label>
				<div class="wppe-cw__schedule" data-cw-schedule hidden>
					<label class="wppe-cw__field">
						<span><?php esc_html_e( 'Fecha', 'wppe-bridge' ); ?></span>
						<input type="date" name="call_date" />
					</label>
					<label class="wppe-cw__field">
						<span><?php esc_html_e( 'Franja', 'wppe-bridge' ); ?></span>
						<select name="call_slot">
							<option value="manana"><?php esc_html_e( 'Manana (9am-1pm)', 'wppe-bridge' ); ?></option>
							<option value="tarde"><?php esc_html_e( 'Tarde (2pm-6pm)', 'wppe-bridge' ); ?></option>
						</select>
					</label>
				</div>
				<?php endif; ?>
			</fieldset>
			<?php endif; ?>

			<label class="wppe-cw__consent">
				<input type="checkbox" name="consent" value="1" required />
				<span>
					<?php echo esc_html( $consent['text'] ); ?>
					<?php if ( '' !== $consent['privacy_url'] ) : ?>
						<a href="<?php echo esc_url( $consent['privacy_url'] ); ?>" target="_blank" rel="noopener">
							<?php esc_html_e( 'Politica de privacidad', 'wppe-bridge' ); ?>
						</a>
					<?php endif; ?>
				</span>
			</label>

			<button type="submit" class="wppe-cw__action"><?php esc_html_e( 'Continuar', 'wppe-bridge' ); ?></button>
			<p class="wppe-cw__status" role="status" aria-live="polite"></p>
		</form>
		<?php endif; ?>
	</div>
	<button type="button" class="wppe-cw__toggle" aria-expanded="false" aria-controls="wppe-cw-panel">
		<?php echo self::icon_markup( $appearance ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- SVG estatico interno o <img> con esc_url, ver icon_markup. ?>
		<span class="wppe-cw__label"><?php echo esc_html( $appearance['cta_label'] ); ?></span>
	</button>
</div>
		<?php
	}

	/**
	 * Markup del icono: SVG inline del set predefinido, o <img> si el
	 * admin configuro un icono propio.
	 *
	 * @param array<string,string> $appearance Apariencia resuelta.
	 * @return string HTML del icono (interno o escapado).
	 */
	public static function icon_markup( array $appearance ): string {
		if ( ! empty( $appearance['icon_custom_url'] ) ) {
			return '<img class="wppe-cw__icon" src="' . esc_url( $appearance['icon_custom_url'] ) . '" alt="" width="24" height="24" loading="lazy" />';
		}

		$svgs = array(
			'whatsapp' => '<svg class="wppe-cw__icon" viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.5.1-.2.2-.6.8-.8 1-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.2-.4.7-1.3 0-.2 0-.3-.1-.4l-.8-1.8c-.2-.5-.4-.4-.5-.4h-.5c-.2 0-.4.1-.7.3-.2.3-.9.9-.9 2.1s.9 2.4 1 2.6a10 10 0 0 0 3.8 3.4c.5.2 1 .4 1.3.5.5.2 1 .1 1.4.1.4-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.1-1.2 0-.1-.2-.1-.4-.2z"/></svg>',
			'chat'     => '<svg class="wppe-cw__icon" viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><path d="M4 3h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H8l-4 4a1 1 0 0 1-1.7-.7V5A2 2 0 0 1 4 3zm3 5a1 1 0 1 0 0 2h10a1 1 0 1 0 0-2H7zm0 4a1 1 0 1 0 0 2h6a1 1 0 1 0 0-2H7z"/></svg>',
			'phone'    => '<svg class="wppe-cw__icon" viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><path d="M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.4.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.4 0 .8-.2 1l-2.3 2.2z"/></svg>',
		);

		return $svgs[ $appearance['icon'] ] ?? $svgs['whatsapp'];
	}
}
