<?php
/**
 * Endpoint REST publico del Widget de Contacto (D-W2).
 *
 * PRIMERA superficie publica del plugin — hasta v2.10.x Bridge no
 * exponia ningun endpoint sin autenticacion. Decisiones de seguridad:
 *
 *  - **Sin nonce, por diseño**: las paginas que sirven el widget son
 *    cacheables (HTML byte-identico, D-W4). Un nonce embebido en HTML
 *    cacheado expira y rompe el envio para visitantes legitimos. Las
 *    defensas son: rate limit por IP, honeypot, validacion de Origin
 *    y caps de tamaño de input.
 *  - **Rate limit por IP** via Public_Rate_Limiter (contador real,
 *    default 5 requests / 60s, filtrable).
 *  - **Honeypot** (`website`): si viene lleno, respuesta 200 generica
 *    sin encolar — no le avisamos al bot que fue detectado.
 *  - **Origin check suave**: si el browser manda Origin/Referer y el
 *    host no coincide con el del sitio, 403. Si no manda header, se
 *    permite (curl lo saltea igual; el objetivo es abuso cross-site
 *    desde browsers, no reemplazar al rate limit).
 *  - **Respuestas genericas**: un `queued:false` con 200 cubre dedup
 *    (D4: exito hacia el usuario), mapping no configurado y descarte
 *    por validacion interna — el operador diagnostica via Logs, el
 *    cliente HTTP no aprende nada del estado interno.
 *
 * @package WPPE_Bridge
 * @since 2.11.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Controller del endpoint POST /wppe-bridge/v1/widget/lead.
 */
final class WPPE_Bridge_Widget_Controller {

	/**
	 * Namespace REST.
	 */
	public const REST_NAMESPACE = 'wppe-bridge/v1';

	/**
	 * Ruta del endpoint de leads.
	 */
	public const ROUTE_LEAD = '/widget/lead';

	/**
	 * Nombre del campo honeypot. Un humano nunca lo ve (CSS lo oculta,
	 * PR-2); un bot que rellena todo lo delata.
	 */
	public const HONEYPOT_FIELD = 'website';

	/**
	 * Rate limit default: requests por ventana por IP.
	 */
	public const RATE_LIMIT = 5;

	/**
	 * Ventana del rate limit en segundos.
	 */
	public const RATE_WINDOW_SECONDS = 60;

	/**
	 * Maximo de fields aceptados en el pre-form.
	 */
	public const MAX_FIELDS = 20;

	/**
	 * Longitud maxima de cada valor de field.
	 */
	public const MAX_FIELD_LENGTH = 500;

	/**
	 * Longitud maxima del widget_id (= form_id VARCHAR(50) en queue).
	 */
	public const MAX_WIDGET_ID_LENGTH = 50;

	/**
	 * Prefijo del codigo de referencia que el visitante lleva a
	 * WhatsApp (cruza la conversacion con el lead del CRM).
	 */
	public const REF_PREFIX = 'WPPE-';

	/**
	 * Registra las rutas REST. Hookeado en rest_api_init por el modulo.
	 *
	 * @return void
	 */
	public static function register_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			self::ROUTE_LEAD,
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'rest_callback' ),
				// Endpoint publico intencional (visitantes anonimos).
				// Las defensas viven en handle_lead — ver docblock.
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Callback REST: adapta WP_REST_Request al handler puro.
	 *
	 * @param object $request WP_REST_Request (duck-typed para tests).
	 * @return object WP_REST_Response.
	 */
	public static function rest_callback( $request ) {
		$params = method_exists( $request, 'get_params' ) ? (array) $request->get_params() : array();
		$origin = method_exists( $request, 'get_header' ) ? (string) $request->get_header( 'origin' ) : '';

		$result = self::handle_lead( $params, $origin );

		return new WP_REST_Response( $result['body'], $result['status'] );
	}

	/**
	 * Handler puro del lead. Sin dependencias de WP_REST_* para que
	 * sea testeable contra los stubs del bootstrap.
	 *
	 * @param array  $params Parametros del request (body JSON o form-encoded).
	 * @param string $origin Header Origin ('' si el browser no lo mando).
	 * @return array{status:int, body:array} Respuesta HTTP.
	 */
	public static function handle_lead( array $params, string $origin = '' ): array {
		// Defensa en profundidad: la ruta solo se registra con el modulo
		// enabled, pero la option puede cambiar con la ruta ya cacheada.
		if ( ! WPPE_Bridge_Module_Contact_Widget::is_enabled() ) {
			return self::error( 403, 'module_disabled' );
		}

		// Rate limit PRIMERO (hardening v2.11.0): antes iba tras el
		// check de Origin y el honeypot, que escriben un log por
		// request — un atacante inflaba wp_wppebridge_logs sin tocar el
		// limiter (mandando un Origin invalido o el honeypot lleno). Con
		// el limiter al frente, todo request cuenta contra el limite del
		// atacante y los paths de rechazo dejan de ser amplificadores de
		// escritura a DB. El log de rate-limit solo se emite en la
		// PRIMERA vez de la ventana (el limiter ya no re-escribe cuando
		// el bucket esta lleno) y con la IP HASHEADA (nunca en claro).
		$limit  = (int) apply_filters( 'wppe_bridge_widget_rate_limit', self::RATE_LIMIT );
		$window = (int) apply_filters( 'wppe_bridge_widget_rate_window', self::RATE_WINDOW_SECONDS );

		$ip = WPPE_Bridge_Public_Rate_Limiter::client_ip();
		if ( ! WPPE_Bridge_Public_Rate_Limiter::allow( 'widget_lead', $ip, $limit, $window ) ) {
			return self::error( 429, 'rate_limited' );
		}

		if ( ! self::origin_allowed( $origin ) ) {
			WPPE_Bridge_Logger::warn(
				'widget_origin_rejected',
				// Truncar el Origin del atacante (header arbitrario, sin
				// cap nativo) para que no infle el context del log.
				array( 'origin' => substr( $origin, 0, 255 ) )
			);
			return self::error( 403, 'origin_not_allowed' );
		}

		// Honeypot: exito generico sin encolar (no avisar al bot).
		if ( ! empty( $params[ self::HONEYPOT_FIELD ] ) ) {
			WPPE_Bridge_Logger::info( 'widget_honeypot_triggered', array() );
			return self::generic_ok();
		}

		// Gate de licencia (anti activacion no autorizada): un sitio
		// fuera de la whitelist (blocked) no debe acumular queue via el
		// endpoint publico — los leads jamas saldrian al CRM y la tabla
		// creceria sin limite. Respuesta generica: no le revelamos el
		// estado de licencia a un cliente HTTP anonimo; el operador lo
		// ve en Logs. Va DESPUES del rate limit para que el refresh
		// lazy de la whitelist no sea amplificable por trafico anonimo.
		if ( class_exists( 'WPPE_Bridge_License_Manager' )
			&& ! WPPE_Bridge_License_Manager::can_send_lead() ) {
			WPPE_Bridge_Logger::warn( 'widget_license_blocked', array() );
			if ( class_exists( 'WPPE_Bridge_Telemetry' ) ) {
				WPPE_Bridge_Telemetry::maybe_send_blocked();
			}
			return self::generic_ok();
		}

		// --- Validacion de shape ---

		$widget_id = isset( $params['widget_id'] ) && is_string( $params['widget_id'] )
			? sanitize_key( $params['widget_id'] )
			: '';
		if ( '' === $widget_id || strlen( $widget_id ) > self::MAX_WIDGET_ID_LENGTH ) {
			return self::error( 422, 'invalid_widget_id' );
		}

		$channel = isset( $params['channel'] ) && is_string( $params['channel'] )
			? sanitize_key( $params['channel'] )
			: '';
		if ( ! in_array( $channel, WPPE_Bridge_Widget_Adapter::VALID_CHANNELS, true ) ) {
			return self::error( 422, 'invalid_channel' );
		}

		$raw_fields = isset( $params['fields'] ) && is_array( $params['fields'] ) ? $params['fields'] : array();
		if ( count( $raw_fields ) > self::MAX_FIELDS ) {
			return self::error( 422, 'too_many_fields' );
		}

		$fields = array();
		foreach ( $raw_fields as $key => $value ) {
			if ( ! is_string( $key ) || ! ( is_string( $value ) || is_numeric( $value ) ) ) {
				continue; // Se ignoran keys/values no escalares.
			}
			$clean_key = sanitize_key( $key );
			if ( '' === $clean_key || strlen( $clean_key ) > 64 ) {
				continue;
			}
			$clean_value = sanitize_text_field( (string) $value );
			if ( strlen( $clean_value ) > self::MAX_FIELD_LENGTH ) {
				return self::error( 422, 'field_too_long' );
			}
			$fields[ $clean_key ] = $clean_value;
		}

		// Fast-fail: sin email ni telefono crudos no hay lead posible
		// (la validacion definitiva post-normalizacion vive en el
		// adapter base). Evita gastar pipeline en requests vacios.
		if ( empty( $fields['email'] ) && empty( $fields['phone'] ) ) {
			return self::error( 422, 'missing_contact' );
		}

		// Consentimiento obligatorio (Ley 29733): sin opt-in explicito
		// del visitante no se captura el dato personal. El front manda
		// consent=1 solo con el checkbox marcado; se re-valida server-
		// side porque la validacion frontend no cuenta como control.
		if ( empty( $params['consent'] ) ) {
			return self::error( 422, 'missing_consent' );
		}

		$queue_id = WPPE_Bridge_Widget_Adapter::on_lead( $fields, $channel, $widget_id );

		// null cubre: dedup (D4 = exito hacia el usuario), mapping no
		// configurado, descarte por validacion interna. Respuesta
		// generica — el operador diagnostica en Logs.
		if ( null === $queue_id ) {
			return self::generic_ok();
		}

		// Registro del consentimiento (Ley 29733): evidencia del opt-in
		// atada al lead. IP pseudonimizada con HMAC — NUNCA en claro; el
		// timestamp lo aporta created_at del log.
		WPPE_Bridge_Logger::info(
			'widget_consent_recorded',
			array(
				'ip_hash' => self::hash_ip( $ip ),
				'channel' => $channel,
			),
			$queue_id
		);

		return array(
			'status' => 200,
			'body'   => array(
				'queued' => true,
				'ref'    => self::reference_code( $queue_id ),
			),
		);
	}

	/**
	 * Pseudonimiza una IP con HMAC-SHA256 usando un secreto por sitio
	 * (hardening v2.11.0). Un `hash('sha256', $ip)` pelado es
	 * reversible: el espacio IPv4 completo (2^32) se precomputa en
	 * segundos, asi que NO cumple pseudonimizacion bajo la ANPDP. El
	 * HMAC con `wp_salt()` (secreto no derivable por el atacante) si.
	 *
	 * @param string $ip IP cruda.
	 * @return string Hex del HMAC.
	 */
	public static function hash_ip( string $ip ): string {
		$secret = function_exists( 'wp_salt' ) ? wp_salt( 'wppe_bridge_ip' ) : 'wppe-bridge-fallback-salt';
		return hash_hmac( 'sha256', $ip, $secret );
	}

	/**
	 * Codigo de referencia derivado del queue_id. Viaja en el mensaje
	 * pre-llenado de WhatsApp para que el vendedor cruce la conversacion
	 * con el lead del CRM.
	 *
	 * Hardening v2.11.0: antes era `base_convert(queue_id)` — reversible
	 * y enumerable, filtraba el AUTO_INCREMENT de la queue (un
	 * competidor calculaba el volumen de leads del cliente con dos
	 * envios). Ahora es un HMAC truncado del queue_id: sigue siendo
	 * deterministico (mismo lead -> mismo ref) pero no enumerable.
	 *
	 * @param int $queue_id ID del item en queue.
	 * @return string Ej. "WPPE-A3F9K2".
	 */
	public static function reference_code( int $queue_id ): string {
		$secret = function_exists( 'wp_salt' ) ? wp_salt( 'wppe_bridge_ref' ) : 'wppe-bridge-fallback-salt';
		$digest = hash_hmac( 'sha256', (string) $queue_id, $secret );
		return self::REF_PREFIX . strtoupper( substr( $digest, 0, 6 ) );
	}

	/**
	 * Valida el Origin (o su ausencia) contra el host del sitio.
	 *
	 * @param string $origin Header Origin del request ('' si ausente).
	 * @return bool
	 */
	public static function origin_allowed( string $origin ): bool {
		if ( '' === $origin ) {
			return true; // Ver docblock de la clase: check suave.
		}

		$origin_host = wp_parse_url( $origin, PHP_URL_HOST );
		if ( ! is_string( $origin_host ) || '' === $origin_host ) {
			return false;
		}

		$site_host = wp_parse_url( home_url(), PHP_URL_HOST );
		$allowed   = array( strtolower( (string) $site_host ) );

		/**
		 * Filtra la lista de hosts permitidos como Origin del widget.
		 * Util para sitios multi-dominio o staging apuntando a prod.
		 *
		 * @param string[] $allowed Hosts permitidos (lowercase).
		 */
		$allowed = (array) apply_filters( 'wppe_bridge_widget_allowed_origins', $allowed );

		return in_array( strtolower( $origin_host ), $allowed, true );
	}

	/**
	 * Respuesta de error uniforme.
	 *
	 * @param int    $status HTTP status.
	 * @param string $code   Codigo de error corto.
	 * @return array{status:int, body:array}
	 */
	private static function error( int $status, string $code ): array {
		return array(
			'status' => $status,
			'body'   => array(
				'queued' => false,
				'error'  => $code,
			),
		);
	}

	/**
	 * Exito generico sin detalles (honeypot, dedup, descarte interno).
	 *
	 * @return array{status:int, body:array}
	 */
	private static function generic_ok(): array {
		return array(
			'status' => 200,
			'body'   => array( 'queued' => false ),
		);
	}
}
