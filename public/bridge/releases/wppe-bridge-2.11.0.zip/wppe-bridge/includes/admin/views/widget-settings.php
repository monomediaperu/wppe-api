<?php
/**
 * Vista de configuracion del Widget de Contacto.
 *
 * @var array<string,string> $appearance Apariencia resuelta.
 * @var string               $number     Numero WhatsApp global.
 * @var string               $greeting   Saludo global.
 * @var array<int,array>     $rules      Reglas por pagina.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

$wppe_bridge_back = add_query_arg(
	array( 'page' => WPPE_Bridge_Admin_Menu::SLUG . '-modules' ),
	admin_url( 'admin.php' )
);

$wppe_bridge_opt_appearance = WPPE_Bridge_Module_Contact_Widget::OPTION_APPEARANCE;
$wppe_bridge_opt_number     = WPPE_Bridge_Module_Contact_Widget::OPTION_WHATSAPP_NUMBER;
$wppe_bridge_opt_greeting   = WPPE_Bridge_Module_Contact_Widget::OPTION_GREETING;
$wppe_bridge_opt_rules      = WPPE_Bridge_Module_Contact_Widget::OPTION_PAGE_RULES;
$wppe_bridge_opt_channels   = WPPE_Bridge_Module_Contact_Widget::OPTION_CHANNELS;
$wppe_bridge_opt_links      = WPPE_Bridge_Module_Contact_Widget::OPTION_CUSTOM_LINKS;
$wppe_bridge_opt_consent    = WPPE_Bridge_Module_Contact_Widget::OPTION_CONSENT;
$wppe_bridge_opt_defaults   = WPPE_Bridge_Widget_Adapter::OPTION_MAPPING_DEFAULTS;

// Filas del editor de enlaces: existentes + vacias hasta el maximo.
$wppe_bridge_link_rows = array_merge(
	$links,
	array_fill(
		0,
		max( 0, WPPE_Bridge_Widget_Settings_Page::MAX_LINKS - count( $links ) ),
		array(
			'label' => '',
			'url'   => '',
		)
	)
);

// Filas del editor de reglas: existentes + 3 vacias para agregar.
$wppe_bridge_rule_rows = array_merge(
	$rules,
	array_fill(
		0,
		3,
		array(
			'pattern'  => '',
			'action'   => 'show',
			'greeting' => '',
			'number'   => '',
		)
	)
);
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Widget de Contacto', 'wppe-bridge' ); ?></h1>

	<p>
		<a href="<?php echo esc_url( $wppe_bridge_back ); ?>" class="button">
			← <?php esc_html_e( 'Volver a Modulos', 'wppe-bridge' ); ?>
		</a>
	</p>

	<p class="description">
		<?php esc_html_e( 'Boton flotante de contacto. Configura la apariencia global, el numero de WhatsApp y el saludo; las reglas por pagina permiten ocultarlo o cambiar saludo/numero segun la URL.', 'wppe-bridge' ); ?>
	</p>

	<form method="post" action="options.php">
		<?php settings_fields( WPPE_Bridge_Widget_Settings_Page::OPTION_GROUP ); ?>

		<h2><?php esc_html_e( 'Canal WhatsApp', 'wppe-bridge' ); ?></h2>
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row">
						<label for="wppe-cw-number"><?php esc_html_e( 'Numero de WhatsApp', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input type="text" id="wppe-cw-number" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_number ); ?>"
							value="<?php echo esc_attr( $number ); ?>"
							placeholder="+51999888777" />
						<p class="description">
							<?php esc_html_e( 'Con codigo de pais (ej. +51999888777). Sin numero configurado el widget no se muestra.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe-cw-greeting"><?php esc_html_e( 'Saludo', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input type="text" id="wppe-cw-greeting" class="large-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_greeting ); ?>"
							value="<?php echo esc_attr( $greeting ); ?>"
							maxlength="<?php echo esc_attr( (string) WPPE_Bridge_Widget_Settings_Page::MAX_GREETING_LENGTH ); ?>"
							placeholder="<?php esc_attr_e( 'Hola 👋 ¿En que te ayudamos?', 'wppe-bridge' ); ?>" />
					</td>
				</tr>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Canales', 'wppe-bridge' ); ?></h2>
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Canales activos', 'wppe-bridge' ); ?></th>
					<td>
						<label style="display:block;margin-bottom:6px">
							<input type="checkbox" name="<?php echo esc_attr( $wppe_bridge_opt_channels ); ?>[whatsapp_enabled]" value="1" <?php checked( ! empty( $channels['whatsapp_enabled'] ) ); ?> />
							<?php esc_html_e( 'WhatsApp (usa el numero de arriba)', 'wppe-bridge' ); ?>
						</label>
						<label style="display:block">
							<input type="checkbox" name="<?php echo esc_attr( $wppe_bridge_opt_channels ); ?>[llamada_enabled]" value="1" <?php checked( ! empty( $channels['llamada_enabled'] ) ); ?> />
							<?php esc_html_e( 'Llamada (llamar ahora / programar)', 'wppe-bridge' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe-cw-central"><?php esc_html_e( 'Central telefonica', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input type="text" id="wppe-cw-central" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_channels ); ?>[central_number]"
							value="<?php echo esc_attr( (string) $channels['central_number'] ); ?>"
							placeholder="+5116543210" />
						<label style="margin-left:16px">
							<input type="checkbox" name="<?php echo esc_attr( $wppe_bridge_opt_channels ); ?>[allow_schedule]" value="1" <?php checked( ! empty( $channels['allow_schedule'] ) ); ?> />
							<?php esc_html_e( 'Permitir programar llamada', 'wppe-bridge' ); ?>
						</label>
					</td>
				</tr>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Horarios por canal', 'wppe-bridge' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Sin horario activado, el canal esta disponible siempre. La disponibilidad se evalua en el navegador con la zona horaria del sitio (el HTML cacheado nunca queda desfasado). Fuera de horario: WhatsApp muestra aviso de respuesta diferida u ocultarse; Llamada ofrece solo "programar" (ej. domingos sin call center) u ocultarse.', 'wppe-bridge' ); ?>
		</p>
		<table class="form-table" role="presentation">
			<tbody>
				<?php
				$wppe_bridge_day_labels    = array(
					1 => __( 'Lun', 'wppe-bridge' ),
					2 => __( 'Mar', 'wppe-bridge' ),
					3 => __( 'Mie', 'wppe-bridge' ),
					4 => __( 'Jue', 'wppe-bridge' ),
					5 => __( 'Vie', 'wppe-bridge' ),
					6 => __( 'Sab', 'wppe-bridge' ),
					0 => __( 'Dom', 'wppe-bridge' ),
				);
				$wppe_bridge_hour_channels = array(
					'whatsapp' => array(
						'label'    => __( 'WhatsApp', 'wppe-bridge' ),
						'off_opts' => array(
							'note' => __( 'Mostrar con aviso de respuesta diferida', 'wppe-bridge' ),
							'hide' => __( 'Ocultar el canal', 'wppe-bridge' ),
						),
					),
					'llamada'  => array(
						'label'    => __( 'Llamada', 'wppe-bridge' ),
						'off_opts' => array(
							'schedule_only' => __( 'Solo "programar llamada"', 'wppe-bridge' ),
							'hide'          => __( 'Ocultar el canal', 'wppe-bridge' ),
						),
					),
				);
				foreach ( $wppe_bridge_hour_channels as $wppe_bridge_ch => $wppe_bridge_ch_cfg ) :
					?>
				<tr>
					<th scope="row"><?php echo esc_html( $wppe_bridge_ch_cfg['label'] ); ?></th>
					<td>
						<label style="display:block;margin-bottom:8px">
							<input type="checkbox" name="<?php echo esc_attr( $wppe_bridge_opt_channels ); ?>[<?php echo esc_attr( $wppe_bridge_ch ); ?>_hours_enabled]" value="1" <?php checked( ! empty( $channels[ $wppe_bridge_ch . '_hours_enabled' ] ) ); ?> />
							<?php esc_html_e( 'Restringir por horario', 'wppe-bridge' ); ?>
						</label>
						<span style="display:inline-block;margin-right:12px">
							<?php foreach ( $wppe_bridge_day_labels as $wppe_bridge_d => $wppe_bridge_dlbl ) : ?>
							<label style="margin-right:8px">
								<input type="checkbox" name="<?php echo esc_attr( $wppe_bridge_opt_channels ); ?>[<?php echo esc_attr( $wppe_bridge_ch ); ?>_days][]" value="<?php echo esc_attr( (string) $wppe_bridge_d ); ?>" <?php checked( in_array( $wppe_bridge_d, (array) $channels[ $wppe_bridge_ch . '_days' ], true ) ); ?> />
								<?php echo esc_html( $wppe_bridge_dlbl ); ?>
							</label>
							<?php endforeach; ?>
						</span>
						<br />
						<label style="margin-right:12px">
							<?php esc_html_e( 'De', 'wppe-bridge' ); ?>
							<input type="time" name="<?php echo esc_attr( $wppe_bridge_opt_channels ); ?>[<?php echo esc_attr( $wppe_bridge_ch ); ?>_start]" value="<?php echo esc_attr( (string) $channels[ $wppe_bridge_ch . '_start' ] ); ?>" />
							<?php esc_html_e( 'a', 'wppe-bridge' ); ?>
							<input type="time" name="<?php echo esc_attr( $wppe_bridge_opt_channels ); ?>[<?php echo esc_attr( $wppe_bridge_ch ); ?>_end]" value="<?php echo esc_attr( (string) $channels[ $wppe_bridge_ch . '_end' ] ); ?>" />
						</label>
						<label>
							<?php esc_html_e( 'Fuera de horario:', 'wppe-bridge' ); ?>
							<select name="<?php echo esc_attr( $wppe_bridge_opt_channels ); ?>[<?php echo esc_attr( $wppe_bridge_ch ); ?>_off_behavior]">
								<?php foreach ( $wppe_bridge_ch_cfg['off_opts'] as $wppe_bridge_ov => $wppe_bridge_olbl ) : ?>
								<option value="<?php echo esc_attr( $wppe_bridge_ov ); ?>" <?php selected( $channels[ $wppe_bridge_ch . '_off_behavior' ], $wppe_bridge_ov ); ?>><?php echo esc_html( $wppe_bridge_olbl ); ?></option>
								<?php endforeach; ?>
							</select>
						</label>
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Lead scoring', 'wppe-bridge' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Puntaje por accion. La suma viaja al CRM en la observacion del lead (ej. "Canal preferido: whatsapp | Score: 15") para priorizar la atencion. 0 desactiva la senal.', 'wppe-bridge' ); ?>
		</p>
		<table class="form-table" role="presentation">
			<tbody>
				<?php
				$wppe_bridge_score_labels = array(
					'submit'             => __( 'Completo el pre-chat (base)', 'wppe-bridge' ),
					'whatsapp'           => __( 'Eligio WhatsApp', 'wppe-bridge' ),
					'llamada_inmediata'  => __( 'Pidio llamada inmediata', 'wppe-bridge' ),
					'llamada_programada' => __( 'Programo una llamada', 'wppe-bridge' ),
					'has_email'          => __( 'Dejo email', 'wppe-bridge' ),
					'has_interest'       => __( 'Describio su interes', 'wppe-bridge' ),
					'paid_click'         => __( 'Llego por click pagado (gclid/fbclid)', 'wppe-bridge' ),
					'off_hours'          => __( 'Dejo datos fuera de horario', 'wppe-bridge' ),
				);
				foreach ( $wppe_bridge_score_labels as $wppe_bridge_sk => $wppe_bridge_slbl ) :
					?>
				<tr>
					<th scope="row">
						<label for="wppe-cw-score-<?php echo esc_attr( $wppe_bridge_sk ); ?>"><?php echo esc_html( $wppe_bridge_slbl ); ?></label>
					</th>
					<td>
						<input type="number" min="0" max="100" id="wppe-cw-score-<?php echo esc_attr( $wppe_bridge_sk ); ?>"
							name="<?php echo esc_attr( WPPE_Bridge_Module_Contact_Widget::OPTION_SCORING ); ?>[<?php echo esc_attr( $wppe_bridge_sk ); ?>]"
							value="<?php echo esc_attr( (string) $scoring[ $wppe_bridge_sk ] ); ?>" />
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Enlaces personalizados', 'wppe-bridge' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Botones adicionales sin captura de datos (Messenger, Telegram, email...). Solo https, mailto: o tel:.', 'wppe-bridge' ); ?>
		</p>
		<table class="widefat striped" style="max-width:720px">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Etiqueta', 'wppe-bridge' ); ?></th>
					<th><?php esc_html_e( 'URL', 'wppe-bridge' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $wppe_bridge_link_rows as $wppe_bridge_li => $wppe_bridge_link ) : ?>
				<tr>
					<td>
						<input type="text" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_links ); ?>[<?php echo esc_attr( (string) $wppe_bridge_li ); ?>][label]"
							value="<?php echo esc_attr( $wppe_bridge_link['label'] ); ?>" />
					</td>
					<td>
						<input type="text" class="large-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_links ); ?>[<?php echo esc_attr( (string) $wppe_bridge_li ); ?>][url]"
							value="<?php echo esc_attr( $wppe_bridge_link['url'] ); ?>"
							placeholder="https://m.me/tuempresa" />
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Consentimiento (Ley 29733)', 'wppe-bridge' ); ?></h2>
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row">
						<label for="wppe-cw-privacy"><?php esc_html_e( 'URL de politica de privacidad', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input type="url" id="wppe-cw-privacy" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_consent ); ?>[privacy_url]"
							value="<?php echo esc_attr( $consent['privacy_url'] ); ?>"
							placeholder="https://" />
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe-cw-consent-text"><?php esc_html_e( 'Texto del checkbox', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input type="text" id="wppe-cw-consent-text" class="large-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_consent ); ?>[text]"
							value="<?php echo esc_attr( $consent['text'] ); ?>"
							maxlength="<?php echo esc_attr( (string) WPPE_Bridge_Widget_Settings_Page::MAX_CONSENT_LENGTH ); ?>" />
						<p class="description"><?php esc_html_e( 'El checkbox es obligatorio: sin opt-in el lead no se captura. Vacio usa el texto default.', 'wppe-bridge' ); ?></p>
					</td>
				</tr>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Defaults CRM del widget', 'wppe-bridge' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'IDs default que acompañan cada lead del widget (para Sperant; GHL/Odoo/HubSpot usan sus defaults globales). Los IDs salen de Sincronizar catalogos o del panel del CRM.', 'wppe-bridge' ); ?>
		</p>
		<table class="form-table" role="presentation">
			<tbody>
				<?php
				$wppe_bridge_default_fields = array(
					'input_channel_id' => __( 'Canal de entrada (input_channel_id)', 'wppe-bridge' ),
					'source_id'        => __( 'Fuente (source_id)', 'wppe-bridge' ),
					'interest_type_id' => __( 'Tipo de interes (interest_type_id)', 'wppe-bridge' ),
					'project_id'       => __( 'Proyecto (project_id)', 'wppe-bridge' ),
				);
				foreach ( $wppe_bridge_default_fields as $wppe_bridge_dk => $wppe_bridge_dlabel ) :
					?>
				<tr>
					<th scope="row">
						<label for="wppe-cw-def-<?php echo esc_attr( $wppe_bridge_dk ); ?>"><?php echo esc_html( $wppe_bridge_dlabel ); ?></label>
					</th>
					<td>
						<input type="text" id="wppe-cw-def-<?php echo esc_attr( $wppe_bridge_dk ); ?>" size="12"
							name="<?php echo esc_attr( $wppe_bridge_opt_defaults ); ?>[<?php echo esc_attr( $wppe_bridge_dk ); ?>]"
							value="<?php echo esc_attr( isset( $defaults[ $wppe_bridge_dk ] ) ? (string) $defaults[ $wppe_bridge_dk ] : '' ); ?>" />
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Apariencia', 'wppe-bridge' ); ?></h2>
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Posicion', 'wppe-bridge' ); ?></th>
					<td>
						<label style="margin-right:16px">
							<input type="radio" name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[position]" value="br" <?php checked( $appearance['position'], 'br' ); ?> />
							<?php esc_html_e( 'Abajo derecha', 'wppe-bridge' ); ?>
						</label>
						<label>
							<input type="radio" name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[position]" value="bl" <?php checked( $appearance['position'], 'bl' ); ?> />
							<?php esc_html_e( 'Abajo izquierda', 'wppe-bridge' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Icono', 'wppe-bridge' ); ?></th>
					<td>
						<select name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[icon]">
							<option value="whatsapp" <?php selected( $appearance['icon'], 'whatsapp' ); ?>><?php esc_html_e( 'WhatsApp', 'wppe-bridge' ); ?></option>
							<option value="chat" <?php selected( $appearance['icon'], 'chat' ); ?>><?php esc_html_e( 'Burbuja de chat', 'wppe-bridge' ); ?></option>
							<option value="phone" <?php selected( $appearance['icon'], 'phone' ); ?>><?php esc_html_e( 'Telefono', 'wppe-bridge' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Se ignora si configuras un icono propio abajo.', 'wppe-bridge' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe-cw-icon-url"><?php esc_html_e( 'Icono propio (URL)', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input type="url" id="wppe-cw-icon-url" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[icon_custom_url]"
							value="<?php echo esc_attr( $appearance['icon_custom_url'] ); ?>"
							placeholder="https://" />
						<p class="description"><?php esc_html_e( 'Solo https. Recomendado: PNG/SVG cuadrado de 48x48.', 'wppe-bridge' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe-cw-color-primary"><?php esc_html_e( 'Color del boton', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input type="text" id="wppe-cw-color-primary" size="9"
							name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[color_primary]"
							value="<?php echo esc_attr( $appearance['color_primary'] ); ?>"
							placeholder="#25d366" />
						<label style="margin-left:16px" for="wppe-cw-color-text"><?php esc_html_e( 'Color del texto', 'wppe-bridge' ); ?></label>
						<input type="text" id="wppe-cw-color-text" size="9"
							name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[color_text]"
							value="<?php echo esc_attr( $appearance['color_text'] ); ?>"
							placeholder="#ffffff" />
						<p class="description"><?php esc_html_e( 'Formato hex (#rrggbb).', 'wppe-bridge' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe-cw-cta"><?php esc_html_e( 'Texto del boton', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input type="text" id="wppe-cw-cta" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[cta_label]"
							value="<?php echo esc_attr( $appearance['cta_label'] ); ?>"
							maxlength="<?php echo esc_attr( (string) WPPE_Bridge_Widget_Settings_Page::MAX_CTA_LENGTH ); ?>" />
					</td>
				</tr>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Reglas por pagina', 'wppe-bridge' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Primera regla que coincida gana. Patterns: exacto (/contacto), prefijo (/proyectos*) o todo (*). Saludo y numero vacios heredan los globales. Filas sin pattern se descartan al guardar.', 'wppe-bridge' ); ?>
		</p>
		<table class="widefat striped" style="max-width:980px">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Pattern de URL', 'wppe-bridge' ); ?></th>
					<th><?php esc_html_e( 'Accion', 'wppe-bridge' ); ?></th>
					<th><?php esc_html_e( 'Saludo (override)', 'wppe-bridge' ); ?></th>
					<th><?php esc_html_e( 'Numero (override)', 'wppe-bridge' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $wppe_bridge_rule_rows as $wppe_bridge_i => $wppe_bridge_rule ) : ?>
				<tr>
					<td>
						<input type="text" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_rules ); ?>[<?php echo esc_attr( (string) $wppe_bridge_i ); ?>][pattern]"
							value="<?php echo esc_attr( $wppe_bridge_rule['pattern'] ); ?>"
							placeholder="/proyectos*" />
					</td>
					<td>
						<select name="<?php echo esc_attr( $wppe_bridge_opt_rules ); ?>[<?php echo esc_attr( (string) $wppe_bridge_i ); ?>][action]">
							<option value="show" <?php selected( $wppe_bridge_rule['action'], 'show' ); ?>><?php esc_html_e( 'Mostrar', 'wppe-bridge' ); ?></option>
							<option value="hide" <?php selected( $wppe_bridge_rule['action'], 'hide' ); ?>><?php esc_html_e( 'Ocultar', 'wppe-bridge' ); ?></option>
						</select>
					</td>
					<td>
						<input type="text" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_rules ); ?>[<?php echo esc_attr( (string) $wppe_bridge_i ); ?>][greeting]"
							value="<?php echo esc_attr( $wppe_bridge_rule['greeting'] ); ?>" />
					</td>
					<td>
						<input type="text" size="16"
							name="<?php echo esc_attr( $wppe_bridge_opt_rules ); ?>[<?php echo esc_attr( (string) $wppe_bridge_i ); ?>][number]"
							value="<?php echo esc_attr( $wppe_bridge_rule['number'] ); ?>" />
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<p class="description">
			<?php esc_html_e( '¿Necesitas mas filas? Guarda y se agregaran 3 vacias nuevas.', 'wppe-bridge' ); ?>
		</p>

		<?php submit_button( __( 'Guardar configuracion', 'wppe-bridge' ) ); ?>
	</form>
</div>
