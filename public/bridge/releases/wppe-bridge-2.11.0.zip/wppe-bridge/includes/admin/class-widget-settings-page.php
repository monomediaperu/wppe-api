<?php
/**
 * Sub-pagina admin oculta para configurar el Widget de Contacto.
 *
 * Accesible via link "Configurar" desde la lista de Modulos (patron
 * Meta CAPI / Thank You Pixel). Configura: apariencia (posicion,
 * colores, icono, CTA), numero de WhatsApp global, saludo global y
 * reglas por pagina (visibilidad + overrides de saludo/numero).
 *
 * @package WPPE_Bridge
 * @since 2.11.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sub-pagina de configuracion del Widget de Contacto.
 */
final class WPPE_Bridge_Widget_Settings_Page {

	/**
	 * Slug de la pagina (subpage oculta de WP.pe Bridge).
	 */
	public const PAGE_SLUG = 'wppe-bridge-contact-widget';

	/**
	 * Settings group de WP Settings API.
	 */
	public const OPTION_GROUP = 'wppe_bridge_contact_widget_settings';

	/**
	 * Maximo de reglas por pagina aceptadas.
	 */
	public const MAX_RULES = 50;

	/**
	 * Longitudes maximas de campos de texto.
	 */
	public const MAX_GREETING_LENGTH = 200;
	public const MAX_CTA_LENGTH      = 40;
	public const MAX_PATTERN_LENGTH  = 200;
	public const MAX_NUMBER_LENGTH   = 20;

	/**
	 * Maximo de enlaces personalizados.
	 */
	public const MAX_LINKS = 5;

	/**
	 * Longitud maxima del texto de consentimiento.
	 */
	public const MAX_CONSENT_LENGTH = 300;

	/**
	 * Option keys => sanitizer.
	 */
	public const OPTIONS = array(
		WPPE_Bridge_Module_Contact_Widget::OPTION_APPEARANCE => 'sanitize_appearance',
		WPPE_Bridge_Module_Contact_Widget::OPTION_WHATSAPP_NUMBER => 'sanitize_number',
		WPPE_Bridge_Module_Contact_Widget::OPTION_GREETING => 'sanitize_greeting',
		WPPE_Bridge_Module_Contact_Widget::OPTION_PAGE_RULES => 'sanitize_rules',
		WPPE_Bridge_Module_Contact_Widget::OPTION_CHANNELS => 'sanitize_channels',
		WPPE_Bridge_Module_Contact_Widget::OPTION_CUSTOM_LINKS => 'sanitize_links',
		WPPE_Bridge_Module_Contact_Widget::OPTION_CONSENT  => 'sanitize_consent',
		WPPE_Bridge_Widget_Adapter::OPTION_MAPPING_DEFAULTS => 'sanitize_mapping_defaults',
		WPPE_Bridge_Module_Contact_Widget::OPTION_SCORING  => 'sanitize_scoring',
	);

	/**
	 * Registra settings en WP Settings API.
	 *
	 * @return void
	 */
	public static function register_settings(): void {
		foreach ( self::OPTIONS as $key => $cb ) {
			register_setting(
				self::OPTION_GROUP,
				$key,
				array( 'sanitize_callback' => array( self::class, $cb ) )
			);
		}
	}

	/**
	 * Renderiza la pagina.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$appearance = WPPE_Bridge_Module_Contact_Widget::get_appearance();
		$number     = (string) get_option( WPPE_Bridge_Module_Contact_Widget::OPTION_WHATSAPP_NUMBER, '' );
		$greeting   = (string) get_option( WPPE_Bridge_Module_Contact_Widget::OPTION_GREETING, '' );
		$rules      = WPPE_Bridge_Module_Contact_Widget::get_page_rules();
		$channels   = WPPE_Bridge_Module_Contact_Widget::get_channels();
		$links      = WPPE_Bridge_Module_Contact_Widget::get_custom_links();
		$consent    = WPPE_Bridge_Module_Contact_Widget::get_consent();
		$defaults   = get_option( WPPE_Bridge_Widget_Adapter::OPTION_MAPPING_DEFAULTS, array() );
		$defaults   = is_array( $defaults ) ? $defaults : array();
		$scoring    = WPPE_Bridge_Module_Contact_Widget::get_scoring();

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/widget-settings.php';
	}

	// ---------- sanitizers ----------

	/**
	 * Sanitiza el array de apariencia: whitelist estricta de keys y
	 * valores; lo invalido cae al default (nunca persiste basura).
	 *
	 * @param mixed $value Valor crudo del POST.
	 * @return array<string,string>
	 */
	public static function sanitize_appearance( $value ): array {
		$defaults = WPPE_Bridge_Module_Contact_Widget::APPEARANCE_DEFAULTS;
		if ( ! is_array( $value ) ) {
			return $defaults;
		}

		$out = $defaults;

		if ( isset( $value['position'] ) && in_array( $value['position'], WPPE_Bridge_Module_Contact_Widget::VALID_POSITIONS, true ) ) {
			$out['position'] = $value['position'];
		}
		if ( isset( $value['icon'] ) && in_array( $value['icon'], WPPE_Bridge_Module_Contact_Widget::VALID_ICONS, true ) ) {
			$out['icon'] = $value['icon'];
		}

		foreach ( array( 'color_primary', 'color_text' ) as $key ) {
			if ( isset( $value[ $key ] ) && is_string( $value[ $key ] )
				&& preg_match( '/^#[0-9a-fA-F]{3,8}$/', trim( $value[ $key ] ) ) ) {
				$out[ $key ] = strtolower( trim( $value[ $key ] ) );
			}
		}

		if ( isset( $value['cta_label'] ) && is_string( $value['cta_label'] ) ) {
			$cta = sanitize_text_field( $value['cta_label'] );
			if ( '' !== $cta ) {
				$out['cta_label'] = mb_substr( $cta, 0, self::MAX_CTA_LENGTH );
			}
		}

		if ( isset( $value['icon_custom_url'] ) && is_string( $value['icon_custom_url'] ) ) {
			$out['icon_custom_url'] = self::sanitize_icon_url( $value['icon_custom_url'] );
		}

		return $out;
	}

	/**
	 * Sanitiza la URL del icono custom: https estricto (el widget se
	 * sirve en paginas https; un icono http romperia mixed content) y
	 * sin URLs internas/peligrosas.
	 *
	 * @param string $url URL cruda.
	 * @return string URL limpia o '' si invalida.
	 */
	public static function sanitize_icon_url( string $url ): string {
		$url = esc_url_raw( trim( $url ) );
		if ( '' === $url ) {
			return '';
		}
		if ( 0 !== strpos( $url, 'https://' ) ) {
			return '';
		}
		return $url;
	}

	/**
	 * Sanitiza el numero de WhatsApp: solo digitos y `+` inicial.
	 *
	 * @param mixed $value Valor crudo.
	 * @return string
	 */
	public static function sanitize_number( $value ): string {
		if ( ! is_string( $value ) && ! is_numeric( $value ) ) {
			return '';
		}
		$clean = preg_replace( '/[^0-9+]/', '', (string) $value );
		$clean = is_string( $clean ) ? $clean : '';
		// `+` solo como primer caracter.
		if ( '' !== $clean ) {
			$clean = ( '+' === $clean[0] ? '+' : '' ) . str_replace( '+', '', $clean );
		}
		return substr( $clean, 0, self::MAX_NUMBER_LENGTH );
	}

	/**
	 * Sanitiza el saludo.
	 *
	 * @param mixed $value Valor crudo.
	 * @return string
	 */
	public static function sanitize_greeting( $value ): string {
		if ( ! is_string( $value ) ) {
			return '';
		}
		return mb_substr( sanitize_text_field( $value ), 0, self::MAX_GREETING_LENGTH );
	}

	/**
	 * Sanitiza las reglas por pagina. Filas sin pattern se descartan
	 * (asi funcionan las filas vacias del formulario). Maximo
	 * MAX_RULES reglas.
	 *
	 * @param mixed $value Valor crudo del POST (array de filas).
	 * @return array<int,array{pattern:string,action:string,greeting:string,number:string}>
	 */
	public static function sanitize_rules( $value ): array {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$clean = array();
		foreach ( $value as $row ) {
			if ( count( $clean ) >= self::MAX_RULES ) {
				break;
			}
			if ( ! is_array( $row ) || ! isset( $row['pattern'] ) || ! is_string( $row['pattern'] ) ) {
				continue;
			}

			$pattern = sanitize_text_field( $row['pattern'] );
			$pattern = mb_substr( trim( $pattern ), 0, self::MAX_PATTERN_LENGTH );
			if ( '' === $pattern ) {
				continue;
			}
			// Normalizar: los patterns son paths — leading slash salvo
			// el catch-all `*`.
			if ( '*' !== $pattern && '/' !== $pattern[0] ) {
				$pattern = '/' . $pattern;
			}

			$clean[] = array(
				'pattern'  => $pattern,
				'action'   => ( isset( $row['action'] ) && 'hide' === $row['action'] ) ? 'hide' : 'show',
				'greeting' => isset( $row['greeting'] ) && is_string( $row['greeting'] )
					? mb_substr( sanitize_text_field( $row['greeting'] ), 0, self::MAX_GREETING_LENGTH )
					: '',
				'number'   => isset( $row['number'] ) ? self::sanitize_number( $row['number'] ) : '',
			);
		}

		return $clean;
	}

	/**
	 * Sanitiza la config de canales.
	 *
	 * @param mixed $value Valor crudo del POST.
	 * @return array<string,mixed>
	 */
	public static function sanitize_channels( $value ): array {
		$defaults = WPPE_Bridge_Module_Contact_Widget::CHANNELS_DEFAULTS;
		if ( ! is_array( $value ) ) {
			return $defaults;
		}

		$out = array(
			'whatsapp_enabled' => ! empty( $value['whatsapp_enabled'] ),
			'llamada_enabled'  => ! empty( $value['llamada_enabled'] ),
			'central_number'   => isset( $value['central_number'] ) ? self::sanitize_number( $value['central_number'] ) : '',
			'allow_schedule'   => ! empty( $value['allow_schedule'] ),
		);

		// Horarios por canal (D-W7).
		foreach ( array( 'whatsapp', 'llamada' ) as $ch ) {
			$out[ $ch . '_hours_enabled' ] = ! empty( $value[ $ch . '_hours_enabled' ] );
			$out[ $ch . '_days' ]          = self::sanitize_days( $value[ $ch . '_days' ] ?? null, $defaults[ $ch . '_days' ] );
			$out[ $ch . '_start' ]         = self::sanitize_time( $value[ $ch . '_start' ] ?? null, $defaults[ $ch . '_start' ] );
			$out[ $ch . '_end' ]           = self::sanitize_time( $value[ $ch . '_end' ] ?? null, $defaults[ $ch . '_end' ] );
		}
		$out['whatsapp_off_behavior'] = ( isset( $value['whatsapp_off_behavior'] ) && 'hide' === $value['whatsapp_off_behavior'] )
			? 'hide'
			: 'note';
		$out['llamada_off_behavior']  = ( isset( $value['llamada_off_behavior'] ) && 'hide' === $value['llamada_off_behavior'] )
			? 'hide'
			: 'schedule_only';

		return $out;
	}

	/**
	 * Sanitiza una lista de dias de semana (0=domingo .. 6=sabado).
	 *
	 * @param mixed $value    Valor crudo.
	 * @param array $fallback Default si no queda ningun dia valido.
	 * @return array<int,int>
	 */
	public static function sanitize_days( $value, array $fallback ): array {
		if ( ! is_array( $value ) ) {
			return $fallback;
		}
		$days = array();
		foreach ( $value as $day ) {
			$d = (int) $day;
			if ( $d >= 0 && $d <= 6 && ! in_array( $d, $days, true ) ) {
				$days[] = $d;
			}
		}
		return empty( $days ) ? $fallback : $days;
	}

	/**
	 * Sanitiza una hora HH:MM (24h).
	 *
	 * @param mixed  $value    Valor crudo.
	 * @param string $fallback Default si invalido.
	 * @return string
	 */
	public static function sanitize_time( $value, string $fallback ): string {
		if ( is_string( $value ) && preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', trim( $value ) ) ) {
			return trim( $value );
		}
		return $fallback;
	}

	/**
	 * Sanitiza los puntajes de lead scoring (D-W5): keys whitelist
	 * contra SCORING_DEFAULTS, valores enteros 0..100.
	 *
	 * @param mixed $value Valor crudo del POST.
	 * @return array<string,int>
	 */
	public static function sanitize_scoring( $value ): array {
		$defaults = WPPE_Bridge_Module_Contact_Widget::SCORING_DEFAULTS;
		if ( ! is_array( $value ) ) {
			return $defaults;
		}
		$out = $defaults;
		foreach ( $defaults as $key => $default_points ) {
			if ( isset( $value[ $key ] ) && is_numeric( $value[ $key ] ) ) {
				$out[ $key ] = max( 0, min( 100, (int) $value[ $key ] ) );
			}
		}
		return $out;
	}

	/**
	 * Sanitiza los enlaces personalizados (D-W8). Solo https, mailto:
	 * o tel: — un enlace javascript: en el footer de todo el sitio
	 * seria XSS almacenado.
	 *
	 * @param mixed $value Valor crudo del POST (array de filas).
	 * @return array<int,array{label:string,url:string}>
	 */
	public static function sanitize_links( $value ): array {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$clean = array();
		foreach ( $value as $row ) {
			if ( count( $clean ) >= self::MAX_LINKS ) {
				break;
			}
			if ( ! is_array( $row ) || empty( $row['label'] ) || empty( $row['url'] )
				|| ! is_string( $row['label'] ) || ! is_string( $row['url'] ) ) {
				continue;
			}

			$label = mb_substr( sanitize_text_field( $row['label'] ), 0, self::MAX_CTA_LENGTH );
			$url   = esc_url_raw( trim( $row['url'] ), array( 'https', 'mailto', 'tel' ) );
			// Whitelist explicita de schemes ademas de esc_url_raw:
			// defensa en profundidad — un javascript: aqui seria XSS
			// almacenado en el footer de todo el sitio.
			if ( '' === $label || '' === $url || ! preg_match( '#^(https://|mailto:|tel:)#i', $url ) ) {
				continue;
			}

			$clean[] = array(
				'label' => $label,
				'url'   => $url,
			);
		}

		return $clean;
	}

	/**
	 * Sanitiza la config de consentimiento (Ley 29733).
	 *
	 * @param mixed $value Valor crudo del POST.
	 * @return array{privacy_url:string,text:string}
	 */
	public static function sanitize_consent( $value ): array {
		if ( ! is_array( $value ) ) {
			return array(
				'privacy_url' => '',
				'text'        => '',
			);
		}

		$url = '';
		if ( isset( $value['privacy_url'] ) && is_string( $value['privacy_url'] ) ) {
			$url = esc_url_raw( trim( $value['privacy_url'] ), array( 'https' ) );
			// Whitelist explicita ademas de esc_url_raw (defensa en
			// profundidad, mismo criterio que sanitize_links).
			if ( 0 !== stripos( $url, 'https://' ) ) {
				$url = '';
			}
		}

		$text = '';
		if ( isset( $value['text'] ) && is_string( $value['text'] ) ) {
			$text = mb_substr( sanitize_text_field( $value['text'] ), 0, self::MAX_CONSENT_LENGTH );
		}

		return array(
			'privacy_url' => $url,
			'text'        => $text,
		);
	}

	/**
	 * Sanitiza los defaults CRM del widget (keys whitelist — son los
	 * mismos defaults per-form del mapping de Sperant).
	 *
	 * @param mixed $value Valor crudo del POST.
	 * @return array<string,string>
	 */
	public static function sanitize_mapping_defaults( $value ): array {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$allowed = array( 'input_channel_id', 'source_id', 'interest_type_id', 'project_id' );
		$clean   = array();
		foreach ( $allowed as $key ) {
			if ( empty( $value[ $key ] ) || ( ! is_string( $value[ $key ] ) && ! is_numeric( $value[ $key ] ) ) ) {
				continue;
			}
			$id = sanitize_text_field( (string) $value[ $key ] );
			if ( '' !== $id ) {
				$clean[ $key ] = mb_substr( $id, 0, 50 );
			}
		}

		return $clean;
	}
}
