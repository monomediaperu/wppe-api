<?php
/**
 * Avisos admin de guardrails: licencia bloqueada (CTA a ventas) y
 * cache fuera del stack (LiteSpeed es el soportado).
 *
 * Decisiones (2026-08-02, pedido de Carlos):
 * - Sitio `blocked` (demo agotado o fuera de whitelist): aviso
 *   NO-dismissible con CTA a ventas para cotizar — el servicio ya
 *   esta gateado (worker + endpoint); esto pone la puerta comercial
 *   encima del bloqueo tecnico.
 * - Cache no soportado detectado (WP Rocket, W3TC, etc.): aviso
 *   warning + email al operador UNA vez por combinacion detectada
 *   (option-flag; si el cliente cambia de plugin de cache, alerta de
 *   nuevo).
 *
 * @package WPPE_Bridge
 * @since 2.11.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Avisos admin de guardrails.
 */
final class WPPE_Bridge_Guardrails_Notices {

	/**
	 * Option con el contacto de ventas mostrado en el CTA.
	 */
	public const OPTION_SALES_CONTACT = 'wppe_bridge_sales_contact';

	/**
	 * Contacto de ventas default.
	 */
	public const DEFAULT_SALES_CONTACT = 'ventas@wp.pe';

	/**
	 * Option-flag de alertas de cache ya enviadas (csv de slugs).
	 */
	public const OPTION_CACHE_ALERTED = 'wppe_bridge_cache_alerted';

	/**
	 * Registra los hooks. Llamado desde Plugin::register_hooks (admin).
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_notices', array( self::class, 'render_license_notice' ) );
		add_action( 'admin_notices', array( self::class, 'render_cache_notice' ) );
		add_action( 'admin_init', array( self::class, 'maybe_alert_cache' ) );
	}

	/**
	 * Contacto de ventas configurado.
	 *
	 * @return string
	 */
	public static function sales_contact(): string {
		$contact = (string) get_option( self::OPTION_SALES_CONTACT, '' );
		return '' !== trim( $contact ) ? $contact : self::DEFAULT_SALES_CONTACT;
	}

	/**
	 * Aviso de licencia bloqueada con CTA a ventas. NO dismissible:
	 * desaparece solo cuando el dominio entra a la whitelist.
	 *
	 * @return void
	 */
	public static function render_license_notice(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( ! class_exists( 'WPPE_Bridge_License_Manager' )
			|| WPPE_Bridge_License_Manager::STATE_BLOCKED !== WPPE_Bridge_License_Manager::state() ) {
			return;
		}

		$contact = self::sales_contact();
		?>
<div class="notice notice-error">
	<p>
		<strong><?php esc_html_e( 'WP.pe Bridge — servicio pausado:', 'wppe-bridge' ); ?></strong>
		<?php esc_html_e( 'este dominio alcanzo el limite de leads de evaluacion o no cuenta con una licencia activa. Los leads capturados quedan en cola y NO se envian al CRM.', 'wppe-bridge' ); ?>
		<?php esc_html_e( 'Para activar el servicio, contacta a ventas y evaluamos una cotizacion:', 'wppe-bridge' ); ?>
		<a href="mailto:<?php echo esc_attr( $contact ); ?>?subject=<?php echo esc_attr( rawurlencode( 'Cotizacion WP.pe Bridge — ' . WPPE_Bridge_Telemetry::site_host() ) ); ?>">
			<?php echo esc_html( $contact ); ?>
		</a>
	</p>
</div>
		<?php
	}

	/**
	 * Aviso de cache fuera del stack.
	 *
	 * @return void
	 */
	public static function render_cache_notice(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$unsupported = WPPE_Bridge_Cache_Detector::unsupported();
		if ( empty( $unsupported ) ) {
			return;
		}

		$names = implode( ', ', array_column( $unsupported, 'name' ) );
		?>
<div class="notice notice-warning">
	<p>
		<strong><?php esc_html_e( 'WP.pe Bridge — plugin de cache no soportado:', 'wppe-bridge' ); ?></strong>
		<?php echo esc_html( $names ); ?>.
		<?php esc_html_e( 'El stack WP.pe usa LiteSpeed Cache; otro plugin de cache complica la gestion (purgas dobles, exclusiones duplicadas) y puede afectar el Widget de Contacto. Recomendamos migrar a LiteSpeed Cache.', 'wppe-bridge' ); ?>
	</p>
</div>
		<?php
	}

	/**
	 * Alerta por email al operador cuando aparece un cache no
	 * soportado — una vez por combinacion de plugins detectada.
	 *
	 * @return void
	 */
	public static function maybe_alert_cache(): void {
		// Capability check (hardening v2.11.0): corre en admin_init, que
		// dispara para cualquier usuario autenticado (incluido un
		// subscriber en su perfil). Sin esto, un usuario de bajo
		// privilegio podia gatillar el primer envio de email y setear el
		// option-flag. No es explotable como spam (throttle por flag) ni
		// permite inyeccion, pero es un side-effect que no debe alcanzar.
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$unsupported = WPPE_Bridge_Cache_Detector::unsupported();
		if ( empty( $unsupported ) ) {
			return;
		}

		$slugs = implode( ',', array_column( $unsupported, 'slug' ) );
		if ( (string) get_option( self::OPTION_CACHE_ALERTED, '' ) === $slugs ) {
			return;
		}
		update_option( self::OPTION_CACHE_ALERTED, $slugs );

		$to = (string) get_option( 'wppe_bridge_notification_email', '' );
		if ( '' === $to && function_exists( 'get_option' ) ) {
			$to = (string) get_option( 'admin_email', '' );
		}
		if ( '' === $to || ! function_exists( 'wp_mail' ) ) {
			return;
		}

		$names = implode( ', ', array_column( $unsupported, 'name' ) );
		wp_mail(
			$to,
			'[WP.pe Bridge] Plugin de cache no soportado detectado',
			sprintf(
				"Sitio: %s\n\nSe detecto un plugin de cache fuera del stack WP.pe: %s.\n\nEl stack soportado es LiteSpeed Cache. Otro plugin de cache complica la gestion (purgas dobles, exclusiones duplicadas) y puede afectar el Widget de Contacto.\n\nRecomendacion: migrar a LiteSpeed Cache.",
				WPPE_Bridge_Telemetry::site_host(),
				$names
			)
		);

		WPPE_Bridge_Logger::warn( 'unsupported_cache_detected', array( 'plugins' => $slugs ) );
	}
}
