<?php
/**
 * Adapter para el Widget de Contacto (modulo Contact Widget, D-W1).
 *
 * Quinta fuente de leads del Bridge. A diferencia de los adapters de
 * plugins de formularios, NO se suscribe a hooks de terceros: el
 * Widget_Controller (endpoint REST publico) lo invoca directamente via
 * `on_lead()` cuando un visitante completa el pre-form del widget.
 *
 * El `form_id` del pipeline es el `widget_id` (instancia/regla del
 * widget configurada en admin), asi el mapping per-form existente
 * funciona sin cambios: `wppe_bridge_field_mapping['widget'][$widget_id]`.
 *
 * El canal elegido (whatsapp | llamada_inmediata | llamada_programada)
 * se inyecta como field `preferred_channel` del form_data, mapeable
 * desde la UI de Mapeo a cualquier payload key (D-W3).
 *
 * @package WPPE_Bridge
 * @since 2.11.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Adapter del Widget de Contacto.
 */
final class WPPE_Bridge_Widget_Adapter extends WPPE_Bridge_Form_Adapter_Base {

	/**
	 * Field sintetico que lleva el canal elegido por el visitante.
	 */
	public const CHANNEL_FIELD = 'preferred_channel';

	/**
	 * Option con los defaults CRM del widget (input_channel_id,
	 * source_id, interest_type_id, project_id). Configurable en la
	 * sub-pagina del widget — el widget NO usa la UI de Mapeo porque
	 * sus campos son fijos (ver get_mapping).
	 */
	public const OPTION_MAPPING_DEFAULTS = 'wppe_bridge_widget_mapping_defaults';

	/**
	 * Mapping fijo field del pre-chat => payload key. A diferencia de
	 * los plugins de formularios (campos arbitrarios por form), el
	 * pre-chat del widget tiene campos conocidos — no hay nada que
	 * mapear visualmente.
	 */
	public const BUILTIN_FIELD_MAP = array(
		'name'              => 'fname',
		'email'             => 'email',
		'phone'             => 'phone',
		'interest'          => 'message',
		'preferred_channel' => 'observation',
	);

	/**
	 * Canales validos del widget (v1). Enlaces personalizados (D-W8)
	 * no pasan por aqui — son links medidos sin flujo de captura.
	 *
	 * @var string[]
	 */
	public const VALID_CHANNELS = array( 'whatsapp', 'llamada_inmediata', 'llamada_programada' );

	/**
	 * Slug de la fuente.
	 *
	 * @return string
	 */
	public static function plugin_slug(): string {
		return 'widget';
	}

	/**
	 * Disponible cuando el modulo Contact Widget esta activado.
	 *
	 * Filter `wppe_bridge_widget_is_available` permite a tests forzar
	 * el resultado (mismo patron que los demas adapters).
	 *
	 * @return bool
	 */
	public static function is_available(): bool {
		$detected = class_exists( 'WPPE_Bridge_Module_Contact_Widget' )
			&& WPPE_Bridge_Module_Contact_Widget::is_enabled();
		/**
		 * Filtra la deteccion del Widget de Contacto.
		 *
		 * @param bool $detected Resultado de la deteccion automatica.
		 */
		return (bool) apply_filters( 'wppe_bridge_widget_is_available', $detected );
	}

	/**
	 * No hay hook de tercero que suscribir: el entry point es
	 * `on_lead()`, invocado por el Widget_Controller. Metodo presente
	 * por contrato del interface.
	 *
	 * @return void
	 */
	public static function register(): void {}

	/**
	 * Auto-registro condicional (contrato comun de adapters). No-op
	 * porque register() no suscribe nada.
	 *
	 * @return void
	 */
	public static function maybe_register(): void {
		if ( self::is_available() ) {
			self::register();
		}
	}

	/**
	 * Mapping del widget: fields fijos (BUILTIN_FIELD_MAP) + defaults
	 * CRM desde option propia. Override del base — el widget no
	 * participa de `wppe_bridge_field_mapping` ni de la UI de Mapeo:
	 * sus campos son conocidos y su config vive completa en la
	 * sub-pagina del modulo (objetivo <30 min de onboarding, sec 1).
	 *
	 * Nunca retorna null: el widget siempre tiene mapping.
	 *
	 * @param string $form_id ID del widget (no participa del mapping fijo).
	 * @return array
	 */
	protected static function get_mapping( string $form_id ): ?array {
		unset( $form_id );
		$defaults = get_option( self::OPTION_MAPPING_DEFAULTS, array() );
		return array(
			'fields'   => self::BUILTIN_FIELD_MAP,
			'defaults' => is_array( $defaults ) ? array_filter( $defaults ) : array(),
		);
	}

	/**
	 * Entry point desde el endpoint REST del widget.
	 *
	 * Compone el field `preferred_channel` (canal + datos de llamada
	 * programada si aplica), sintetiza el entry_id (no existe
	 * submission externa — mismo patron que CF7) y delega al pipeline
	 * comun: mapping fijo, build_payload (UTMs de cookie incluidos),
	 * normalizacion D6, validacion email-o-phone y enqueue.
	 *
	 * @param array  $fields    Field name => value del pre-form (ya sanitizados por el controller).
	 * @param string $channel   Canal elegido (uno de VALID_CHANNELS).
	 * @param string $widget_id Instancia/regla del widget (hace de form_id).
	 * @return int|null queue_id si encolado, null si descartado.
	 */
	public static function on_lead( array $fields, string $channel, string $widget_id ): ?int {
		if ( ! in_array( $channel, self::VALID_CHANNELS, true ) ) {
			return null;
		}

		$fields[ self::CHANNEL_FIELD ] = self::compose_channel_note( $fields, $channel );
		// Canal crudo para compute_score (build_payload lo recibe como
		// form_data; el underscore lo mantiene fuera del payload — solo
		// los fields del BUILTIN_FIELD_MAP llegan al CRM).
		$fields['_channel_raw'] = $channel;

		$entry_id = sprintf( 'widget-%d-%s', time(), wp_generate_password( 6, false ) );

		return self::handle_submission( $fields, $entry_id, $widget_id );
	}

	/**
	 * Override de build_payload: al payload comun le suma el lead
	 * score (D-W5) en `observation` — universal a todos los destinos
	 * (un payload key custom rompe en CRMs con schema estricto).
	 *
	 * @param array  $form_data Fields del pre-form.
	 * @param array  $mapping   Mapping resuelto.
	 * @param string $entry_id  ID sintetico.
	 * @param string $form_id   ID del widget.
	 * @return array
	 */
	protected static function build_payload( array $form_data, array $mapping, string $entry_id, string $form_id ): array {
		$payload = parent::build_payload( $form_data, $mapping, $entry_id, $form_id );

		$score                  = self::compute_score( $form_data, $payload );
		$observation            = isset( $payload['observation'] ) ? (string) $payload['observation'] : '';
		$payload['observation'] = '' === $observation
			? 'Score: ' . $score
			: $observation . ' | Score: ' . $score;

		return $payload;
	}

	/**
	 * Suma declarativa del lead score (D-W5) segun la config de
	 * puntajes por accion. Cero magia: cada senal es observable.
	 *
	 * @param array $form_data Fields del pre-form (incluye _channel_raw, off_hours).
	 * @param array $payload   Payload ya construido (email/message/gclid resueltos).
	 * @return int
	 */
	public static function compute_score( array $form_data, array $payload ): int {
		$points = WPPE_Bridge_Module_Contact_Widget::get_scoring();
		$score  = $points['submit'];

		$channel = isset( $form_data['_channel_raw'] ) && is_string( $form_data['_channel_raw'] )
			? $form_data['_channel_raw']
			: '';
		if ( isset( $points[ $channel ] ) ) {
			$score += $points[ $channel ];
		}

		if ( ! empty( $payload['email'] ) ) {
			$score += $points['has_email'];
		}
		if ( ! empty( $payload['message'] ) ) {
			$score += $points['has_interest'];
		}
		if ( ! empty( $payload['gclid'] ) || ! empty( $payload['fbclid'] ) ) {
			$score += $points['paid_click'];
		}
		if ( isset( $form_data['off_hours'] ) && '1' === (string) $form_data['off_hours'] ) {
			$score += $points['off_hours'];
		}

		return max( 0, $score );
	}

	/**
	 * Compone la nota de canal que viaja a `observation` en el CRM.
	 * Para llamada programada incluye fecha y franja elegidas — es lo
	 * que el vendedor necesita ver primero.
	 *
	 * @param array  $fields  Fields del pre-form.
	 * @param string $channel Canal validado.
	 * @return string Ej. "Canal preferido: llamada_programada (2026-08-10, manana)".
	 */
	public static function compose_channel_note( array $fields, string $channel ): string {
		$note = 'Canal preferido: ' . $channel;

		if ( 'llamada_programada' === $channel ) {
			$parts = array();
			// Validacion de formato (hardening v2.11.0): antes se
			// concatenaban tal cual — ~1000 chars de texto arbitrario
			// del cliente en el campo observation que ve el vendedor.
			// call_date: solo YYYY-MM-DD; call_slot: whitelist.
			if ( ! empty( $fields['call_date'] ) && is_string( $fields['call_date'] )
				&& preg_match( '/^\d{4}-\d{2}-\d{2}$/', $fields['call_date'] ) ) {
				$parts[] = $fields['call_date'];
			}
			if ( ! empty( $fields['call_slot'] ) && is_string( $fields['call_slot'] )
				&& in_array( $fields['call_slot'], array( 'manana', 'tarde' ), true ) ) {
				$parts[] = $fields['call_slot'];
			}
			if ( ! empty( $parts ) ) {
				$note .= ' (' . implode( ', ', $parts ) . ')';
			}
		}

		if ( isset( $fields['off_hours'] ) && '1' === (string) $fields['off_hours'] ) {
			$note .= ' [fuera de horario]';
		}

		return $note;
	}
}
