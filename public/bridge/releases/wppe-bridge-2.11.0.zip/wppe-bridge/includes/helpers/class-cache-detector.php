<?php
/**
 * Detector de plugins de cache (guardrails de stack WP.pe).
 *
 * El stack soportado es LiteSpeed Cache (los sitios WP.pe corren
 * LiteSpeed). Otros plugins de cache (WP Rocket, W3TC, etc.) no son
 * parte del stack y complican la gestion: purgas que no purgan,
 * exclusiones duplicadas, page cache doble. Este detector alimenta el
 * aviso admin + alerta email de Guardrails_Notices.
 *
 * @package WPPE_Bridge
 * @since 2.11.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Deteccion de plugins de cache conocidos via constantes/clases.
 */
final class WPPE_Bridge_Cache_Detector {

	/**
	 * Slug del unico cache soportado por el stack WP.pe.
	 */
	public const SUPPORTED_SLUG = 'litespeed';

	/**
	 * Detecta plugins de cache activos.
	 *
	 * @param array<string,bool>|null $overrides Para tests: slug => presente.
	 *                                           null = deteccion real.
	 * @return array<int,array{slug:string,name:string,supported:bool}>
	 */
	public static function detect( ?array $overrides = null ): array {
		if ( null === $overrides ) {
			/**
			 * Seam de testing / entornos especiales: mapa slug => bool
			 * que reemplaza la deteccion por constantes/clases.
			 *
			 * @param array<string,bool>|null $overrides null = deteccion real.
			 */
			$filtered = apply_filters( 'wppe_bridge_cache_detect_overrides', null );
			if ( is_array( $filtered ) ) {
				$overrides = $filtered;
			}
		}

		$known = array(
			'litespeed'        => array(
				'name'    => 'LiteSpeed Cache',
				'present' => defined( 'LSCWP_V' ) || class_exists( 'LiteSpeed\Core' ),
			),
			'wp_rocket'        => array(
				'name'    => 'WP Rocket',
				'present' => defined( 'WP_ROCKET_VERSION' ),
			),
			'w3_total_cache'   => array(
				'name'    => 'W3 Total Cache',
				'present' => defined( 'W3TC' ),
			),
			'wp_super_cache'   => array(
				'name'    => 'WP Super Cache',
				'present' => defined( 'WPCACHEHOME' ),
			),
			'wp_fastest_cache' => array(
				'name'    => 'WP Fastest Cache',
				'present' => class_exists( 'WpFastestCache' ),
			),
		);

		$found = array();
		foreach ( $known as $slug => $info ) {
			$present = null !== $overrides
				? ! empty( $overrides[ $slug ] )
				: $info['present'];
			if ( ! $present ) {
				continue;
			}
			$found[] = array(
				'slug'      => $slug,
				'name'      => $info['name'],
				'supported' => self::SUPPORTED_SLUG === $slug,
			);
		}

		return $found;
	}

	/**
	 * Solo los caches NO soportados detectados.
	 *
	 * @param array<string,bool>|null $overrides Para tests.
	 * @return array<int,array{slug:string,name:string,supported:bool}>
	 */
	public static function unsupported( ?array $overrides = null ): array {
		return array_values(
			array_filter(
				self::detect( $overrides ),
				static fn( array $plugin ): bool => ! $plugin['supported']
			)
		);
	}
}
