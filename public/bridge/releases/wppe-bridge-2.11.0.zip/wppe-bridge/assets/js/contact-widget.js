/**
 * Widget de Contacto — comportamiento frontend (D-W4).
 *
 * Toggle del panel + flujo pre-chat: el visitante elige canal
 * (WhatsApp/Llamada), deja sus datos con consentimiento, el lead se
 * POSTea al endpoint del Bridge y RECIEN entonces salta al canal —
 * WhatsApp con mensaje pre-llenado que incluye el codigo de
 * referencia, o tel: a la central. Sin dependencias; toda la config
 * viene embebida en data-attributes del HTML estatico.
 */
( function () {
	'use strict';

	function init() {
		var root = document.querySelector( '[data-wppe-cw]' );
		if ( ! root ) {
			return;
		}

		var toggle = root.querySelector( '.wppe-cw__toggle' );
		var panel = root.querySelector( '.wppe-cw__panel' );
		if ( ! toggle || ! panel ) {
			return;
		}

		var form = root.querySelector( '.wppe-cw__form' );
		var callOpts = root.querySelector( '[data-cw-call]' );
		var schedule = root.querySelector( '[data-cw-schedule]' );
		var status = root.querySelector( '.wppe-cw__status' );
		var channel = '';

		// Horarios por canal (D-W7): la config viene embebida y
		// ESTATICA; la disponibilidad se evalua aqui, con la timezone
		// del sitio, para que el HTML cacheado nunca quede desfasado.
		var hoursCfg = {};
		try {
			hoursCfg = JSON.parse( root.getAttribute( 'data-schedule' ) || '{}' );
		} catch ( e ) {
			hoursCfg = {};
		}
		var tz = root.getAttribute( 'data-tz' ) || '';

		function nowInSiteTz() {
			var d = new Date();
			var m = tz.match( /^([+-])(\d{2}):(\d{2})$/ );
			if ( m ) {
				var off = ( '-' === m[ 1 ] ? -1 : 1 ) * ( parseInt( m[ 2 ], 10 ) * 60 + parseInt( m[ 3 ], 10 ) );
				d = new Date( d.getTime() + ( off + d.getTimezoneOffset() ) * 60000 );
			} else if ( tz ) {
				try {
					d = new Date( d.toLocaleString( 'en-US', { timeZone: tz } ) );
				} catch ( e ) {
					// Zona invalida: hora local del visitante como fallback.
				}
			}
			return { day: d.getDay(), minutes: d.getHours() * 60 + d.getMinutes() };
		}

		function toMinutes( hhmm ) {
			var parts = ( hhmm || '' ).split( ':' );
			return ( parseInt( parts[ 0 ], 10 ) || 0 ) * 60 + ( parseInt( parts[ 1 ], 10 ) || 0 );
		}

		function channelOpen( name ) {
			var cfg = hoursCfg[ name ];
			if ( ! cfg || ! cfg.enabled ) {
				return true;
			}
			var now = nowInSiteTz();
			if ( ( cfg.days || [] ).indexOf( now.day ) === -1 ) {
				return false;
			}
			return now.minutes >= toMinutes( cfg.start ) && now.minutes < toMinutes( cfg.end );
		}

		var waOpen = channelOpen( 'whatsapp' );
		var llOpen = channelOpen( 'llamada' );

		if ( ! waOpen && hoursCfg.whatsapp && 'hide' === hoursCfg.whatsapp.off ) {
			var waBtn = panel.querySelector( '[data-cw-channel="whatsapp"]' );
			if ( waBtn ) {
				waBtn.remove();
			}
		}
		if ( ! llOpen && hoursCfg.llamada && 'hide' === hoursCfg.llamada.off ) {
			var llBtn = panel.querySelector( '[data-cw-channel="llamada"]' );
			if ( llBtn ) {
				llBtn.remove();
			}
		}

		function setOpen( open ) {
			panel.hidden = ! open;
			toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		}

		function setStatus( text ) {
			if ( status ) {
				status.textContent = text;
			}
		}

		toggle.addEventListener( 'click', function () {
			setOpen( panel.hidden );
		} );

		document.addEventListener( 'keydown', function ( event ) {
			if ( 'Escape' === event.key && ! panel.hidden ) {
				setOpen( false );
				toggle.focus();
			}
		} );

		document.addEventListener( 'click', function ( event ) {
			if ( ! panel.hidden && ! root.contains( event.target ) ) {
				setOpen( false );
			}
		} );

		// Seleccion de canal: revela el pre-chat.
		panel.addEventListener( 'click', function ( event ) {
			var btn = event.target.closest( '[data-cw-channel]' );
			if ( ! btn || ! form ) {
				return;
			}
			channel = btn.getAttribute( 'data-cw-channel' );
			form.hidden = false;
			if ( callOpts ) {
				callOpts.hidden = 'llamada' !== channel;
			}
			setStatus( '' );

			// Fuera de horario: el caso "domingo sin call center" —
			// solo queda "programar llamada"; WhatsApp avisa respuesta
			// diferida (comportamientos configurables, D-W7).
			if ( 'llamada' === channel && ! llOpen && callOpts ) {
				var inmediata = callOpts.querySelector( 'input[value="llamada_inmediata"]' );
				var programada = callOpts.querySelector( 'input[value="llamada_programada"]' );
				if ( inmediata && inmediata.closest( 'label' ) ) {
					inmediata.closest( 'label' ).hidden = true;
					inmediata.checked = false;
				}
				if ( programada ) {
					programada.checked = true;
					if ( schedule ) {
						schedule.hidden = false;
					}
				}
			}
			if ( 'whatsapp' === channel && ! waOpen ) {
				setStatus( 'Estamos fuera de horario: deja tus datos y te respondemos apenas estemos en linea.' );
			}

			var first = form.querySelector( 'input[name="name"]' );
			if ( first ) {
				first.focus();
			}
		} );

		// Programar llamada: revela fecha/franja.
		if ( form && schedule ) {
			form.addEventListener( 'change', function ( event ) {
				if ( 'call_pref' === event.target.name ) {
					schedule.hidden = 'llamada_programada' !== event.target.value;
				}
			} );
		}

		if ( ! form ) {
			return;
		}

		form.addEventListener( 'submit', function ( event ) {
			event.preventDefault();

			var get = function ( name ) {
				var el = form.querySelector( '[name="' + name + '"]' );
				return el ? el.value.trim() : '';
			};

			var consent = form.querySelector( '[name="consent"]' );
			if ( ! get( 'name' ) || ! get( 'phone' ) || ! consent || ! consent.checked ) {
				setStatus( 'Completa nombre, telefono y acepta la politica para continuar.' );
				return;
			}

			var finalChannel = channel;
			var fields = {
				name: get( 'name' ),
				phone: get( 'phone' ),
				email: get( 'email' ),
				interest: get( 'interest' )
			};

			if ( 'llamada' === channel ) {
				var pref = form.querySelector( '[name="call_pref"]:checked' );
				finalChannel = pref ? pref.value : 'llamada_inmediata';
				if ( 'llamada_programada' === finalChannel ) {
					fields.call_date = get( 'call_date' );
					fields.call_slot = get( 'call_slot' );
				}
			}

			// Senal de scoring: lead capturado fuera de horario.
			if ( ( 'whatsapp' === channel && ! waOpen ) || ( 'llamada' === channel && ! llOpen ) ) {
				fields.off_hours = '1';
			}

			var submitBtn = form.querySelector( '[type="submit"]' );
			if ( submitBtn ) {
				submitBtn.disabled = true; // Submit lock: previene doble envio.
			}
			setStatus( 'Enviando…' );

			fetch( root.getAttribute( 'data-endpoint' ), {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify( {
					widget_id: root.getAttribute( 'data-widget-id' ),
					channel: finalChannel,
					consent: 1,
					website: get( 'website' ),
					fields: fields
				} )
			} )
				.then( function ( response ) {
					return response.json().then( function ( body ) {
						return { ok: response.ok, body: body };
					} );
				} )
				.then( function ( result ) {
					if ( ! result.ok ) {
						setStatus( 'No pudimos procesar tu solicitud. Intenta de nuevo en un momento.' );
						if ( submitBtn ) {
							submitBtn.disabled = false;
						}
						return;
					}

					if ( 'whatsapp' === finalChannel ) {
						var ref = result.body && result.body.ref ? ' (Ref: ' + result.body.ref + ')' : '';
						var text = 'Hola, soy ' + fields.name + ref + '. ' + ( fields.interest ? 'Me interesa: ' + fields.interest : 'Quiero mas informacion.' );
						window.open(
							'https://wa.me/' + root.getAttribute( 'data-wa-number' ) + '?text=' + encodeURIComponent( text ),
							'_blank',
							'noopener'
						);
						setStatus( 'Te abrimos WhatsApp. ¡Gracias!' );
					} else if ( 'llamada_inmediata' === finalChannel ) {
						setStatus( 'Marcando a la central…' );
						window.location.href = 'tel:' + root.getAttribute( 'data-central-number' );
					} else {
						setStatus( 'Listo: registramos tu solicitud y te llamaremos en la fecha elegida.' );
					}
					form.reset();
					if ( submitBtn ) {
						submitBtn.disabled = false;
					}
				} )
				.catch( function () {
					setStatus( 'Error de conexion. Intenta de nuevo.' );
					if ( submitBtn ) {
						submitBtn.disabled = false;
					}
				} );
		} );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
