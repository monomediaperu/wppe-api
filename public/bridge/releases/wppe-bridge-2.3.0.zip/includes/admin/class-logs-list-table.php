<?php
/**
 * WP_List_Table para queue items en la pagina admin Logs.
 *
 * Muestra registros de wp_wppebridge_queue con paginacion, filtro
 * por status y bulk action de retry.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * List table de queue items.
 */
final class WPPE_Bridge_Logs_List_Table extends WP_List_Table {

	/**
	 * Default items per page.
	 */
	public const PER_PAGE_DEFAULT = 25;

	/**
	 * Status filter activo.
	 *
	 * @var string|null
	 */
	private ?string $filter_status = null;

	/**
	 * Constructor — inicializa labels singular/plural y modo no-AJAX.
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'wppe_bridge_queue_item',
				'plural'   => 'wppe_bridge_queue_items',
				'ajax'     => false,
			)
		);
	}

	/**
	 * Columns headers.
	 *
	 * @return array<string,string>
	 */
	public function get_columns(): array {
		return array(
			'cb'       => '<input type="checkbox" />',
			'id'       => __( 'ID', 'wppe-bridge' ),
			'created'  => __( 'Fecha', 'wppe-bridge' ),
			'form'     => __( 'Form', 'wppe-bridge' ),
			'email'    => __( 'Email', 'wppe-bridge' ),
			'status'   => __( 'Status', 'wppe-bridge' ),
			'attempts' => __( 'Intentos', 'wppe-bridge' ),
		);
	}

	/**
	 * Bulk actions.
	 *
	 * @return array<string,string>
	 */
	public function get_bulk_actions(): array {
		return array(
			'retry' => __( 'Reintentar', 'wppe-bridge' ),
		);
	}

	/**
	 * Carga items para la pagina actual.
	 *
	 * @return void
	 */
	public function prepare_items(): void {
		$this->_column_headers = array( $this->get_columns(), array(), array() );

		$this->filter_status = isset( $_GET['status'] ) && is_string( $_GET['status'] ) && '' !== $_GET['status']  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			? sanitize_key( wp_unslash( $_GET['status'] ) )                                                          // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: null;

		$per_page     = self::PER_PAGE_DEFAULT;
		$current_page = $this->get_pagenum();

		$this->items = WPPE_Bridge_Queue::paginate(
			array(
				'status'   => $this->filter_status,
				'per_page' => $per_page,
				'page'     => $current_page,
			)
		);

		$total = WPPE_Bridge_Queue::count_by_status( $this->filter_status );

		$this->set_pagination_args(
			array(
				'total_items' => $total,
				'per_page'    => $per_page,
				'total_pages' => (int) ceil( $total / $per_page ),
			)
		);
	}

	/**
	 * Render del checkbox.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_cb( $item ): string {
		return sprintf( '<input type="checkbox" name="ids[]" value="%d" />', (int) $item->id );
	}

	/**
	 * Render columna ID con link a detalle.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_id( $item ): string {
		$detail = add_query_arg(
			array(
				'page'   => WPPE_Bridge_Admin_Menu::SLUG . '-logs',
				'action' => 'view',
				'id'     => (int) $item->id,
			),
			admin_url( 'admin.php' )
		);
		return sprintf(
			'<a href="%s">#%d</a>',
			esc_url( $detail ),
			(int) $item->id
		);
	}

	/**
	 * Render columna fecha.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_created( $item ): string {
		return esc_html( (string) $item->created_at );
	}

	/**
	 * Render columna form.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_form( $item ): string {
		return esc_html(
			sprintf( '%s #%s', $item->form_plugin, $item->form_id )
		);
	}

	/**
	 * Render columna email enmascarado.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_email( $item ): string {
		$payload = is_string( $item->payload ) ? json_decode( $item->payload, true ) : null;
		$email   = is_array( $payload ) && isset( $payload['email'] ) ? (string) $payload['email'] : '';
		return esc_html( WPPE_Bridge_Pii_Masker::mask_email( $email ) );
	}

	/**
	 * Render columna status como badge.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_status( $item ): string {
		$status    = (string) $item->status;
		$color_map = array(
			WPPE_Bridge_Queue::STATUS_PENDING          => '#dba617',
			WPPE_Bridge_Queue::STATUS_SENT             => '#46b450',
			WPPE_Bridge_Queue::STATUS_FAILED_TEMP      => '#dba617',
			WPPE_Bridge_Queue::STATUS_FAILED_PERMANENT => '#dc3232',
			WPPE_Bridge_Queue::STATUS_DEDUPED          => '#999',
		);
		$color     = $color_map[ $status ] ?? '#666';
		return sprintf(
			'<span style="color:%s;font-weight:600">%s</span>',
			esc_attr( $color ),
			esc_html( $status )
		);
	}

	/**
	 * Render columna intentos.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_attempts( $item ): string {
		return (string) (int) $item->attempts;
	}

	/**
	 * Default column render (fallback).
	 *
	 * @param object $item        Row.
	 * @param string $column_name Nombre de columna.
	 * @return string
	 */
	protected function column_default( $item, $column_name ): string {
		return isset( $item->{$column_name} ) ? esc_html( (string) $item->{$column_name} ) : '';
	}

	/**
	 * Mensaje cuando no hay items.
	 *
	 * @return void
	 */
	public function no_items(): void {
		esc_html_e( 'No hay leads en la cola.', 'wppe-bridge' );
	}
}
