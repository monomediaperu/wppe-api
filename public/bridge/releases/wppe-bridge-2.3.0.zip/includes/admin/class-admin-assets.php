<?php
/**
 * Enqueue de assets del panel admin.
 *
 * Solo carga JS/CSS en las pantallas del plugin para no contaminar el
 * resto del wp-admin. Inyecta `window.wppeSperantAdmin` con datos que
 * el JS necesita (ajaxUrl, nonce, action names, i18n).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Enqueue condicional de assets del panel admin.
 */
final class WPPE_Bridge_Admin_Assets {

	/**
	 * Handle del JS/CSS del plugin.
	 */
	public const HANDLE = 'wppe-bridge-admin';

	/**
	 * Hook al action `admin_enqueue_scripts`.
	 *
	 * @param string $hook_suffix Pantalla actual (provista por WP).
	 * @return void
	 */
	public static function enqueue( $hook_suffix ): void {
		if ( ! self::is_plugin_screen( (string) $hook_suffix ) ) {
			return;
		}

		wp_enqueue_style(
			self::HANDLE,
			WPPE_BRIDGE_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			WPPE_BRIDGE_VERSION
		);

		wp_enqueue_script(
			self::HANDLE,
			WPPE_BRIDGE_PLUGIN_URL . 'assets/js/admin.js',
			array(),
			WPPE_BRIDGE_VERSION,
			true
		);

		wp_localize_script(
			self::HANDLE,
			'wppeSperantAdmin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( WPPE_Bridge_Admin_Ajax::NONCE_ACTION ),
				'actions' => array(
					'syncCatalogs'    => WPPE_Bridge_Admin_Ajax::ACTION_SYNC_CATALOGS,
					'importCatalog'   => WPPE_Bridge_Admin_Ajax::ACTION_IMPORT_CATALOG,
					'syncGhlCatalogs' => WPPE_Bridge_Admin_Ajax::ACTION_SYNC_GHL_CATALOGS,
				),
				'i18n'    => array(
					'syncing'           => __( 'Sincronizando...', 'wppe-bridge' ),
					/* translators: %input_channels%, %sources%, %interest_types%, %projects% son contadores numericos por catalogo. El JS los reemplaza con los valores reales tras sincronizar. */
					'synced'            => __( 'Sincronizado: canales=%input_channels%, fuentes=%sources%, intereses=%interest_types%, proyectos=%projects%', 'wppe-bridge' ),
					/* translators: %pipelines%, %custom_fields%, %tags% son contadores numericos por catalogo GHL (v2.1.0 PR-2). */
					'syncedGhl'         => __( 'Sincronizado GHL: pipelines=%pipelines%, custom fields=%custom_fields%, tags=%tags%', 'wppe-bridge' ),
					'error'             => __( 'Error al sincronizar. Revisa el token y la URL.', 'wppe-bridge' ),
					'importEmpty'       => __( 'Pega el JSON antes.', 'wppe-bridge' ),
					'importInvalidJson' => __( 'JSON invalido', 'wppe-bridge' ),
					'importLoading'     => __( 'Importando...', 'wppe-bridge' ),
				),
			)
		);
	}

	/**
	 * Detecta si estamos en una pantalla del plugin. Las pantallas
	 * tienen hook_suffix con el patron `toplevel_page_{slug}` o
	 * `{toplevel}_page_{subpage_slug}`.
	 *
	 * @param string $hook_suffix Pantalla actual.
	 * @return bool
	 */
	private static function is_plugin_screen( string $hook_suffix ): bool {
		return false !== strpos( $hook_suffix, WPPE_Bridge_Admin_Menu::SLUG );
	}
}
