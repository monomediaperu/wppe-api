<?php
/**
 * Activator del plugin.
 *
 * Crea las tablas propias (queue, dedup, logs) via dbDelta, registra
 * opciones default y agenda el cron del worker.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Activator — métodos estáticos invocados por register_activation_hook.
 */
final class WPPE_Bridge_Activator {

	/**
	 * Hook cron del worker.
	 */
	public const CRON_HOOK = 'wppe_bridge_worker_tick';

	/**
	 * Schedule cron del worker (cada minuto).
	 */
	public const CRON_SCHEDULE = 'wppebridge_minute';

	/**
	 * Hook cron del cleanup de logs (diario).
	 */
	public const CRON_HOOK_LOGS_CLEANUP = 'wppe_bridge_logs_cleanup_tick';

	/**
	 * Schedule cron del cleanup de logs.
	 */
	public const CRON_SCHEDULE_DAILY = 'daily';

	/**
	 * TTL default de la tabla dedup (segundos).
	 */
	public const DEFAULT_DEDUP_TTL_SECONDS = 60;

	/**
	 * Retencion default de logs (dias).
	 */
	public const DEFAULT_LOGS_RETENTION_DAYS = 30;

	/**
	 * Punto de entrada.
	 */
	public static function activate(): void {
		self::create_tables();
		self::register_default_options();
		self::schedule_cron();
	}

	/**
	 * Crea las 3 tablas propias via dbDelta.
	 */
	private static function create_tables(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		$queue_table = $wpdb->prefix . 'wppebridge_queue';
		$dedup_table = $wpdb->prefix . 'wppebridge_dedup';
		$logs_table  = $wpdb->prefix . 'wppebridge_logs';

		// dbDelta es estricto con espaciado y backticks — seguir convencion.
		$queue_sql = "CREATE TABLE {$queue_table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			hash CHAR(64) NOT NULL,
			form_plugin VARCHAR(20) NOT NULL,
			form_id VARCHAR(50) NOT NULL,
			submission_id_external VARCHAR(50) DEFAULT NULL,
			payload LONGTEXT NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			last_attempt_at DATETIME DEFAULT NULL,
			next_retry_at DATETIME DEFAULT NULL,
			sperant_response LONGTEXT DEFAULT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY status_retry (status, next_retry_at),
			KEY hash_idx (hash),
			KEY created_idx (created_at)
		) {$charset_collate};";

		$dedup_sql = "CREATE TABLE {$dedup_table} (
			hash CHAR(64) NOT NULL,
			expires_at DATETIME NOT NULL,
			PRIMARY KEY  (hash),
			KEY expires_idx (expires_at)
		) {$charset_collate};";

		$logs_sql = "CREATE TABLE {$logs_table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			queue_id BIGINT UNSIGNED DEFAULT NULL,
			level VARCHAR(10) NOT NULL,
			message TEXT NOT NULL,
			context LONGTEXT DEFAULT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY level_created (level, created_at),
			KEY queue_idx (queue_id)
		) {$charset_collate};";

		dbDelta( $queue_sql );
		dbDelta( $dedup_sql );
		dbDelta( $logs_sql );
	}

	/**
	 * Registra opciones default. Usa add_option (no sobreescribe si existen).
	 */
	private static function register_default_options(): void {
		add_option( 'wppe_bridge_api_token', '' );
		add_option( 'wppe_bridge_api_base_url', 'https://api.sperant.com' );
		add_option( 'wppe_bridge_active_destination', 'sperant' );
		add_option( 'wppe_bridge_catalogs', array() );
		add_option( 'wppe_bridge_field_mapping', array() );
		add_option( 'wppe_bridge_db_version', WPPE_BRIDGE_DB_VERSION );
		add_option( 'wppe_bridge_dedup_ttl_seconds', self::DEFAULT_DEDUP_TTL_SECONDS );
		add_option( 'wppe_bridge_logs_retention_days', self::DEFAULT_LOGS_RETENTION_DAYS );
		add_option( 'wppe_bridge_panel_subdomain', '' );

		// Zona de peligro (v1.2.2). Default OFF — el uninstall preserva
		// data salvo que el operador opte explicitamente desde la UI.
		add_option( 'wppe_bridge_delete_data_on_uninstall', false );

		// License (v1.1.0). Whitelist remoto en wp_options.
		add_option( 'wppe_bridge_demo_leads_count', 0 );
		add_option( 'wppe_bridge_whitelist_cache', null );

		// Heartbeat del worker (v1.2.4). 0 marca "nunca corrio";
		// `Environment_Diagnostics::card_wp_cron()` lo usa para detectar
		// si WP-Cron quedo sin disparar el hook.
		add_option( 'wppe_bridge_worker_last_tick_at', 0 );

		// Modulos opcionales (D4.4) — todos off por default.
		add_option( 'wppe_bridge_module_utm_capture_enabled', false );
		add_option( 'wppe_bridge_module_submit_lock_enabled', false );
		add_option( 'wppe_bridge_module_meta_capi_enabled', false );
		add_option( 'wppe_bridge_meta_capi_pixel_id', '' );
		add_option( 'wppe_bridge_meta_capi_access_token', '' );
		add_option( 'wppe_bridge_meta_capi_test_event_code', '' );
		add_option( 'wppe_bridge_meta_event_name', 'Lead' );
		add_option( 'wppe_bridge_module_thank_you_pixel_enabled', false );
		add_option( 'wppe_bridge_thank_you_pixel_pages', array() );
	}

	/**
	 * Agenda el cron del worker. Filtro de schedules custom registrado
	 * tambien aqui de forma anticipada (el filtro se mantiene activo
	 * en runtime via Plugin::register_hooks en una iteracion siguiente).
	 */
	private static function schedule_cron(): void {
		// phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- Worker outbox: 1 minuto es necesario para latencia razonable hacia Sperant.
		add_filter( 'cron_schedules', array( __CLASS__, 'register_cron_schedule' ) );

		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, self::CRON_SCHEDULE, self::CRON_HOOK );
		}

		// Cleanup diario de logs.
		if ( ! wp_next_scheduled( self::CRON_HOOK_LOGS_CLEANUP ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, self::CRON_SCHEDULE_DAILY, self::CRON_HOOK_LOGS_CLEANUP );
		}

		// Whitelist refresh diario (v1.1.0).
		if ( class_exists( 'WPPE_Bridge_Whitelist_Client' )
			&& ! wp_next_scheduled( WPPE_Bridge_Whitelist_Client::CRON_HOOK_REFRESH ) ) {
			wp_schedule_event(
				time() + HOUR_IN_SECONDS,
				self::CRON_SCHEDULE_DAILY,
				WPPE_Bridge_Whitelist_Client::CRON_HOOK_REFRESH
			);
		}
	}

	/**
	 * Filter callback para registrar el schedule custom de 1 minuto.
	 *
	 * @param array $schedules Schedules existentes.
	 * @return array
	 */
	public static function register_cron_schedule( array $schedules ): array {
		$schedules[ self::CRON_SCHEDULE ] = array(
			'interval' => MINUTE_IN_SECONDS,
			'display'  => __( 'Cada minuto (WP.pe Bridge)', 'wppe-bridge' ),
		);
		return $schedules;
	}
}
