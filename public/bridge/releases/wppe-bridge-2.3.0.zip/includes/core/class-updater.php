<?php
/**
 * Updater nativo de WordPress para WP.pe Bridge.
 *
 * Hookea los filters del sistema de updates de WP para que el plugin
 * (instalado fuera de wordpress.org) reciba el badge "Update available"
 * en la pagina de Plugins, y el cliente pueda actualizar con un click
 * — mismo UX que cualquier plugin de wordpress.org.
 *
 * **Como funciona:**
 *
 * 1. WordPress chequea updates 2 veces al dia (cron `wp_version_check`).
 *    En cada chequeo dispara `pre_set_site_transient_update_plugins` con
 *    un objeto `$transient` que tiene `->checked[plugin_basename]` =
 *    version actual de cada plugin instalado. Nuestro filter detecta si
 *    nuestro plugin esta en `->checked`, consulta el manifest remoto,
 *    compara versiones, y si hay update inyecta una entrada en
 *    `$transient->response[plugin_basename]` con `new_version`,
 *    `package`, `url`, etc. WordPress despues renderiza el badge.
 *
 * 2. Cuando el usuario clickea "View details" del plugin en wp-admin,
 *    WP llama `plugins_api()` con `action='plugin_information'`. Si el
 *    slug coincide con el nuestro, servimos un objeto con `name`,
 *    `version`, `author`, `sections` (description/changelog/installation)
 *    para que la modal lo renderice.
 *
 * **Cache:** D-PR4-3. Transient `wppe_bridge_updater_manifest` con TTL
 * 12h. Coincide con el ciclo natural de chequeo de WP. Si el admin
 * quiere forzar un check, va a Plugins -> "Check again" (eso invalida
 * el transient `update_plugins` de WP, que dispara nuestro filter, que
 * respeta el transient propio — para forzar tambien el nuestro hay un
 * filter de bypass `wppe_bridge_updater_force_refresh`).
 *
 * **Fail-safe:** D-PR4-4. Si el endpoint esta caido o el JSON es
 * malformado, fallamos silencioso (return $transient sin tocar) y
 * loggeamos un warning. WordPress nunca debe romperse por un updater.
 *
 * **Auth:** D-PR4-2. Endpoint publico. La proteccion real esta en la
 * whitelist del plugin — el zip descargado ya pasa por install_package
 * de WP que verifica el header del plugin. La info del manifest es
 * publica (mismo nivel que un release page de GitHub).
 *
 * **Auto-update:** D-PR4-8. NO forzamos auto-updates. El cliente
 * decide via toggle "Enable auto-updates" en wp-admin -> Plugins.
 * Default WP es manual click — respetamos eso.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Updater nativo de WordPress integrado al plugin.
 */
final class WPPE_Bridge_Updater {

	/**
	 * URL del manifest publico generado por el workflow auto-mirror.
	 * Estructura esperada:
	 *   {
	 *     "version": "2.2.0",
	 *     "released_at": "2026-05-05T17:05:57Z",
	 *     "zip_url": "https://api.wp.pe/bridge/releases/wppe-bridge-2.2.0.zip",
	 *     "changelog_url": "https://github.com/.../releases/tag/v2.2.0",
	 *     "minimum_php": "8.1",
	 *     "minimum_wordpress": "6.4",
	 *     "tested": "6.7",        // PR-4: agregado al workflow
	 *     "last_updated": "..."   // PR-4: alias de released_at
	 *   }
	 */
	public const MANIFEST_URL = 'https://api.wp.pe/bridge/latest.json';

	/**
	 * Transient key que cachea la respuesta del manifest. TTL 12h.
	 * Si el admin quiere forzar refresh, puede borrarlo via WP-CLI:
	 *   wp transient delete wppe_bridge_updater_manifest
	 */
	public const TRANSIENT_KEY = 'wppe_bridge_updater_manifest';

	/**
	 * TTL del transient cache (12 horas). D-PR4-3.
	 */
	public const TRANSIENT_TTL_SECONDS = 12 * HOUR_IN_SECONDS;

	/**
	 * Timeout HTTP del fetch del manifest. Generoso porque api.wp.pe
	 * pasa por Coolify y tiene cold starts ocasionales.
	 */
	public const HTTP_TIMEOUT_SECONDS = 8;

	/**
	 * Slug del plugin (= nombre de la carpeta en wp-content/plugins/).
	 * D-PR4-7.
	 */
	public const PLUGIN_SLUG = 'wppe-bridge';

	/**
	 * Version maxima de WP testeada (fallback cuando el manifest no
	 * trae `tested`). Actualizar al subir esta cifra en el header del
	 * plugin tambien.
	 */
	public const FALLBACK_TESTED_WP = '6.7';

	/**
	 * Bootstrap: registra los 2 filters en WP. Llamado desde
	 * Plugin::register_hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_filter( 'pre_set_site_transient_update_plugins', array( self::class, 'check_for_update' ) );
		add_filter( 'plugins_api', array( self::class, 'plugin_information' ), 10, 3 );
	}

	/**
	 * Filter `pre_set_site_transient_update_plugins`.
	 *
	 * Inyecta una entrada en `$transient->response` si hay version nueva.
	 * WordPress despues compara `->response` vs `->checked` para mostrar
	 * el badge en la pagina de Plugins.
	 *
	 * Si nuestro plugin no esta en `->checked` (caso raro: WP corrio el
	 * filter antes de que el plugin estuviera activo), no hacemos nada.
	 *
	 * @param mixed $transient Site transient object.
	 * @return mixed
	 */
	public static function check_for_update( $transient ) {
		// Defensivo: en algunos contextos (tests, instalacion fresca) el
		// transient puede ser null en vez de objeto.
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$plugin_basename = self::plugin_basename();
		$current_version = self::current_version();

		$manifest = self::get_manifest();
		if ( null === $manifest ) {
			// Endpoint caido / network error / JSON invalido.
			// Fallamos silencioso (D-PR4-4) — no inyectamos nada.
			return $transient;
		}

		$remote_version = isset( $manifest['version'] ) ? (string) $manifest['version'] : '';
		if ( '' === $remote_version ) {
			return $transient;
		}

		// Comparacion semver. Solo notificamos si la remota es ESTRICTAMENTE
		// mayor — downgrades los ignoramos para no proponerle al admin
		// "instalar v2.0.5" cuando ya tiene v2.1.0.
		if ( version_compare( $remote_version, $current_version, '<=' ) ) {
			return $transient;
		}

		// Hay update. Construir el objeto que WP espera.
		$update_data = (object) array(
			'id'           => self::PLUGIN_SLUG,
			'slug'         => self::PLUGIN_SLUG,
			'plugin'       => $plugin_basename,
			'new_version'  => $remote_version,
			'url'          => isset( $manifest['changelog_url'] ) ? (string) $manifest['changelog_url'] : 'https://wp.pe/bridge',
			'package'      => isset( $manifest['zip_url'] ) ? (string) $manifest['zip_url'] : '',
			'tested'       => isset( $manifest['tested'] ) ? (string) $manifest['tested'] : self::FALLBACK_TESTED_WP,
			'requires_php' => isset( $manifest['minimum_php'] ) ? (string) $manifest['minimum_php'] : '8.1',
			'icons'        => array(),
			'banners'      => array(),
			'banners_rtl'  => array(),
		);

		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}
		$transient->response[ $plugin_basename ] = $update_data;

		// Tambien limpiar de `no_update` si estaba ahi (caso raro pero
		// posible si WP ya habia cacheado "sin updates").
		if ( isset( $transient->no_update[ $plugin_basename ] ) ) {
			unset( $transient->no_update[ $plugin_basename ] );
		}

		return $transient;
	}

	/**
	 * Filter `plugins_api`.
	 *
	 * Sirve metadatos del plugin cuando el usuario clickea "View details"
	 * en wp-admin. WP llama este filter con `$action='plugin_information'`
	 * y `$args->slug` = slug del plugin. Si coincide con el nuestro,
	 * retornamos un objeto con `sections` (description/changelog/install).
	 *
	 * Si NO es nuestro plugin, retornamos `$default` sin tocar (otro
	 * filter o el sistema default lo maneja).
	 *
	 * @param mixed  $default_value Default que viene del filter (puede ser false, WP_Error, o objeto).
	 * @param string $action        Accion solicitada ('plugin_information' principalmente).
	 * @param object $args          Args del request.
	 * @return mixed
	 */
	public static function plugin_information( $default_value, $action, $args ) {
		if ( 'plugin_information' !== $action ) {
			return $default_value;
		}
		if ( ! is_object( $args ) || ! isset( $args->slug ) || self::PLUGIN_SLUG !== $args->slug ) {
			return $default_value;
		}

		$manifest = self::get_manifest();
		if ( null === $manifest ) {
			return $default_value;
		}

		$remote_version = isset( $manifest['version'] ) ? (string) $manifest['version'] : '';
		$changelog_url  = isset( $manifest['changelog_url'] ) ? (string) $manifest['changelog_url'] : '';

		return (object) array(
			'name'          => 'WP.pe Bridge',
			'slug'          => self::PLUGIN_SLUG,
			'version'       => $remote_version,
			'author'        => '<a href="https://mono.media">Mono Media SAC</a>',
			'homepage'      => 'https://wp.pe/bridge',
			'requires'      => isset( $manifest['minimum_wordpress'] ) ? (string) $manifest['minimum_wordpress'] : '6.4',
			'tested'        => isset( $manifest['tested'] ) ? (string) $manifest['tested'] : self::FALLBACK_TESTED_WP,
			'requires_php'  => isset( $manifest['minimum_php'] ) ? (string) $manifest['minimum_php'] : '8.1',
			'last_updated'  => isset( $manifest['last_updated'] ) ? (string) $manifest['last_updated'] : ( $manifest['released_at'] ?? '' ),
			'download_link' => isset( $manifest['zip_url'] ) ? (string) $manifest['zip_url'] : '',
			'sections'      => self::sections( $changelog_url ),
		);
	}

	/**
	 * Construye las "sections" para la modal "View details" de wp-admin.
	 *
	 * D-PR4-1: hibrido. `description` e `installation` son texto fijo
	 * (raramente cambian). `changelog` es link al GitHub Release porque
	 * mantener changelog HTML local seria duplicacion innecesaria — el
	 * cliente clickea y ve el changelog completo en GitHub.
	 *
	 * @param string $changelog_url URL al GitHub Release de la version remota.
	 * @return array<string,string>
	 */
	private static function sections( string $changelog_url ): array {
		$changelog_link = '' !== $changelog_url
			? sprintf(
				'<p><a href="%s" target="_blank" rel="noopener">%s</a></p>',
				esc_url( $changelog_url ),
				esc_html__( 'Ver changelog completo en GitHub', 'wppe-bridge' )
			)
			: '<p>' . esc_html__( 'Changelog no disponible.', 'wppe-bridge' ) . '</p>';

		return array(
			'description'  => '<p>' . esc_html__( 'WP.pe Bridge integra formularios web (Fluent Forms, Gravity Forms, Elementor) con CRMs inmobiliarios. Soporta Sperant y GoHighLevel via arquitectura Destination interface, con queue async, dedup, manejo de errores diferenciado y modulos opcionales (UTM Capture, Meta CAPI, Submit Lock, Thank You Pixel). Producto interno de Mono Media para WP.pe.', 'wppe-bridge' ) . '</p>',
			'installation' => '<p>' . esc_html__( 'WP.pe Bridge se instala automaticamente en cuentas de WP.pe. Para clientes que actualizan desde versiones anteriores: el badge "Update available" en la pagina de Plugins permite actualizar con un click. La instalacion preserva configuracion existente — no hace falta reconfigurar token, mapeo o catalogos.', 'wppe-bridge' ) . '</p>',
			'changelog'    => $changelog_link,
		);
	}

	/**
	 * Lee el manifest remoto con cache transient.
	 *
	 * Si el transient esta poblado, retorna esos datos sin hacer HTTP.
	 * Si no, hace `wp_remote_get`, parsea el JSON, persiste en transient
	 * y retorna los datos. Si la request falla o el JSON es invalido,
	 * retorna `null` (D-PR4-4: fail-safe).
	 *
	 * Filter `wppe_bridge_updater_force_refresh` permite bypassear el
	 * cache para tests / debugging.
	 *
	 * @return array|null Manifest decodificado o null si error.
	 */
	public static function get_manifest(): ?array {
		$force_refresh = false;
		if ( function_exists( 'apply_filters' ) ) {
			$force_refresh = (bool) apply_filters( 'wppe_bridge_updater_force_refresh', false );
		}

		if ( ! $force_refresh ) {
			$cached = get_transient( self::TRANSIENT_KEY );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$url = self::MANIFEST_URL;
		if ( function_exists( 'apply_filters' ) ) {
			$url = (string) apply_filters( 'wppe_bridge_updater_manifest_url', $url );
		}

		$response = wp_remote_get(
			$url,
			array(
				'timeout' => self::HTTP_TIMEOUT_SECONDS,
				'headers' => array(
					'Accept'     => 'application/json',
					'User-Agent' => self::user_agent(),
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			self::log_warning(
				'manifest_fetch_failed',
				array( 'error' => $response->get_error_message() )
			);
			return null;
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		if ( $status < 200 || $status >= 300 ) {
			self::log_warning(
				'manifest_http_error',
				array( 'status' => $status )
			);
			return null;
		}

		$raw     = (string) wp_remote_retrieve_body( $response );
		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) ) {
			self::log_warning(
				'manifest_json_invalid',
				array( 'raw_excerpt' => substr( $raw, 0, 200 ) )
			);
			return null;
		}

		set_transient( self::TRANSIENT_KEY, $decoded, self::TRANSIENT_TTL_SECONDS );
		return $decoded;
	}

	/**
	 * Plugin basename (path relativo desde wp-content/plugins/), ej.
	 * `wppe-bridge/wppe-bridge.php`. Aislado en metodo para que tests
	 * lo puedan stubear.
	 *
	 * @return string
	 */
	public static function plugin_basename(): string {
		// Si la constante esta disponible, usar plugin_basename() de WP
		// que respeta installs raros. Si no (tests), construir manual.
		if ( defined( 'WPPE_BRIDGE_PLUGIN_FILE' ) && function_exists( 'plugin_basename' ) ) {
			return plugin_basename( WPPE_BRIDGE_PLUGIN_FILE );
		}
		return self::PLUGIN_SLUG . '/' . self::PLUGIN_SLUG . '.php';
	}

	/**
	 * Version actual del plugin instalado. Aislado para que tests lo
	 * puedan stubear.
	 *
	 * @return string
	 */
	public static function current_version(): string {
		if ( defined( 'WPPE_BRIDGE_VERSION' ) ) {
			return (string) WPPE_BRIDGE_VERSION;
		}
		return '0.0.0';
	}

	/**
	 * User-Agent del fetch (para que api.wp.pe identifique el origen).
	 *
	 * @return string
	 */
	private static function user_agent(): string {
		$version = self::current_version();
		return sprintf( 'WPPE-Bridge-Updater/%s', $version );
	}

	/**
	 * Loggea un warning sin romper si el Logger no esta cargado.
	 *
	 * @param string $code    Codigo de error (snake_case).
	 * @param array  $context Contexto adicional.
	 * @return void
	 */
	private static function log_warning( string $code, array $context ): void {
		if ( class_exists( 'WPPE_Bridge_Logger' ) ) {
			WPPE_Bridge_Logger::warn( 'updater_' . $code, $context );
		}
	}
}
