<?php
/**
 * Estado operativo del plugin (v1.2.6).
 *
 * Evalua si el plugin tiene TODO lo minimo necesario para que un lead
 * llegue al CRM. Resume la respuesta a "¿esto va a funcionar cuando
 * llegue una submission?" en una sola etiqueta:
 *
 *   - OPERATIVO         (verde)   — todos los requisitos criticos OK.
 *   - PARCIAL           (amarillo)— funciona, pero hay warnings.
 *   - NO OPERATIVO      (rojo)    — falla un critico, los leads no salen.
 *
 * El operador veía 7 cards distintas y tenia que mentalmente sumar.
 * Ahora hay 1 card destacada arriba que dice "vas/no vas".
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Evaluador del estado operativo agregado.
 */
final class WPPE_Bridge_Operational_Status {

	public const STATE_OPERATIONAL     = 'operational';
	public const STATE_PARTIAL         = 'partial';
	public const STATE_NOT_OPERATIONAL = 'not_operational';

	/**
	 * Evalua el estado global. Devuelve struct con state + checks.
	 *
	 * Logica:
	 *   - Si algun check `critical` falla → NOT_OPERATIONAL.
	 *   - Si todos los criticos OK pero algun no-critico falla → PARTIAL.
	 *   - Si todo OK → OPERATIONAL.
	 *
	 * @return array{
	 *   state:string,
	 *   checks:array<int,array<string,mixed>>,
	 *   summary:string
	 * }
	 */
	public static function evaluate(): array {
		$checks = self::checks();

		$critical_failed     = false;
		$non_critical_failed = false;
		foreach ( $checks as $c ) {
			if ( empty( $c['passed'] ) ) {
				if ( ! empty( $c['critical'] ) ) {
					$critical_failed = true;
				} else {
					$non_critical_failed = true;
				}
			}
		}

		if ( $critical_failed ) {
			$state   = self::STATE_NOT_OPERATIONAL;
			$summary = __( 'Falta algun requisito indispensable. Los leads NO se entregan al CRM hasta que lo configures.', 'wppe-bridge' );
		} elseif ( $non_critical_failed ) {
			$state   = self::STATE_PARTIAL;
			$summary = __( 'Plugin operativo, pero hay recomendaciones pendientes para optimizar entrega.', 'wppe-bridge' );
		} else {
			$state   = self::STATE_OPERATIONAL;
			$summary = __( 'Todos los requisitos OK. El plugin entrega leads al CRM correctamente.', 'wppe-bridge' );
		}

		return array(
			'state'   => $state,
			'checks'  => $checks,
			'summary' => $summary,
		);
	}

	/**
	 * Lista todos los checks evaluados, en orden de aparicion en la
	 * tabla expandible de la card. Los criticos van primero.
	 *
	 * Cada check:
	 *   - key (string): id estable.
	 *   - label (string): titulo legible.
	 *   - critical (bool): si su fallo bloquea operacion.
	 *   - passed (bool): si paso el check.
	 *   - message (string): texto de estado actual (con HTML inline OK).
	 *   - cta_url (string|null): URL para resolver si esta failed.
	 *   - cta_label (string|null): label del CTA.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function checks(): array {
		return array(
			self::check_token(),
			self::check_form_plugin(),
			self::check_forms_detected(),
			self::check_mapping(),
			self::check_wp_cron(),
			self::check_license(),
			self::check_php_version(),
			self::check_smtp(),
		);
	}

	// ---------- checks individuales ----------

	/**
	 * Token Sperant configurado (critico).
	 *
	 * @return array<string,mixed>
	 */
	public static function check_token(): array {
		$has = '' !== (string) get_option( 'wppe_bridge_api_token', '' );
		$url = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=' . WPPE_Bridge_Admin_Menu::SLUG . '-config' ) : '';
		return array(
			'key'       => 'token',
			'label'     => __( 'Token del CRM configurado', 'wppe-bridge' ),
			'critical'  => true,
			'passed'    => $has,
			'message'   => $has
				? __( 'Token guardado.', 'wppe-bridge' )
				: __( 'Sin token configurado. La integracion no puede autenticarse contra el CRM.', 'wppe-bridge' ),
			'cta_url'   => $has ? null : $url,
			'cta_label' => $has ? null : __( 'Configurar token', 'wppe-bridge' ),
		);
	}

	/**
	 * Plugin de forms detectado (critico).
	 *
	 * @return array<string,mixed>
	 */
	public static function check_form_plugin(): array {
		$fluent_active  = class_exists( 'WPPE_Bridge_Fluent_Forms_Adapter' )
			&& WPPE_Bridge_Fluent_Forms_Adapter::is_available();
		$gravity_active = class_exists( 'WPPE_Bridge_Gravity_Forms_Adapter' )
			&& WPPE_Bridge_Gravity_Forms_Adapter::is_available();
		$any            = $fluent_active || $gravity_active;

		$names = array();
		if ( $fluent_active ) {
			$names[] = 'Fluent Forms';
		}
		if ( $gravity_active ) {
			$names[] = 'Gravity Forms';
		}

		return array(
			'key'       => 'form_plugin',
			'label'     => __( 'Plugin de formularios activo', 'wppe-bridge' ),
			'critical'  => true,
			'passed'    => $any,
			'message'   => $any
				? sprintf(
					/* translators: %s = lista de plugins */
					__( 'Detectado: <strong>%s</strong>.', 'wppe-bridge' ),
					esc_html( implode( ', ', $names ) )
				)
				: __( 'Necesitas Fluent Forms Pro o Gravity Forms instalado y activo.', 'wppe-bridge' ),
			'cta_url'   => null,
			'cta_label' => null,
		);
	}

	/**
	 * Al menos 1 form detectado (critico — sin forms no hay leads).
	 *
	 * @return array<string,mixed>
	 */
	public static function check_forms_detected(): array {
		$count = 0;
		if ( class_exists( 'WPPE_Bridge_Form_Discovery' ) ) {
			$discovered = WPPE_Bridge_Form_Discovery::discover_all();
			$count      = count( $discovered['fluent'] ?? array() ) + count( $discovered['gravity'] ?? array() ) + count( $discovered['elementor'] ?? array() ) + count( $discovered['cf7'] ?? array() );
		}
		$url = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=' . WPPE_Bridge_Admin_Menu::SLUG . '-mapping' ) : '';

		return array(
			'key'       => 'forms_detected',
			'label'     => __( 'Formularios disponibles', 'wppe-bridge' ),
			'critical'  => true,
			'passed'    => $count > 0,
			'message'   => $count > 0
				? sprintf(
					/* translators: %d = numero de forms */
					_n( '%d formulario detectado.', '%d formularios detectados.', $count, 'wppe-bridge' ),
					$count
				)
				: __( 'Tu plugin de forms esta activo pero no encontramos formularios creados. Crea al menos uno.', 'wppe-bridge' ),
			'cta_url'   => $count > 0 ? null : $url,
			'cta_label' => $count > 0 ? null : __( 'Ver Mapeo', 'wppe-bridge' ),
		);
	}

	/**
	 * Al menos 1 form mapeado completo (critico).
	 *
	 * @return array<string,mixed>
	 */
	public static function check_mapping(): array {
		$mapping  = get_option( 'wppe_bridge_field_mapping', array() );
		$mapping  = is_array( $mapping ) ? $mapping : array();
		$complete = 0;
		foreach ( $mapping as $forms_by_plugin ) {
			if ( ! is_array( $forms_by_plugin ) ) {
				continue;
			}
			foreach ( $forms_by_plugin as $entry ) {
				if ( ! is_array( $entry ) ) {
					continue;
				}
				if ( class_exists( 'WPPE_Bridge_Mapping_Page' ) ) {
					$missing = WPPE_Bridge_Mapping_Page::validate_required_fields( $entry );
					if ( empty( $missing ) ) {
						++$complete;
					}
				} else {
					++$complete;
				}
			}
		}
		$url = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=' . WPPE_Bridge_Admin_Menu::SLUG . '-mapping' ) : '';

		return array(
			'key'       => 'mapping',
			'label'     => __( 'Mapeo de campos completo', 'wppe-bridge' ),
			'critical'  => true,
			'passed'    => $complete > 0,
			'message'   => $complete > 0
				? sprintf(
					/* translators: %d = forms con mapping completo */
					_n( '%d form con mapeo completo.', '%d forms con mapeo completo.', $complete, 'wppe-bridge' ),
					$complete
				)
				: __( 'Ningun form tiene los campos obligatorios mapeados (fname, input_channel_id, interest_type_id).', 'wppe-bridge' ),
			'cta_url'   => $complete > 0 ? null : $url,
			'cta_label' => $complete > 0 ? null : __( 'Configurar mapeo', 'wppe-bridge' ),
		);
	}

	/**
	 * WP-Cron operativo (critico para entrega).
	 *
	 * @return array<string,mixed>
	 */
	public static function check_wp_cron(): array {
		if ( ! class_exists( 'WPPE_Bridge_Environment_Diagnostics' ) ) {
			return array(
				'key'       => 'wp_cron',
				'label'     => __( 'WP-Cron del worker', 'wppe-bridge' ),
				'critical'  => true,
				'passed'    => false,
				'message'   => __( 'No se pudo evaluar.', 'wppe-bridge' ),
				'cta_url'   => null,
				'cta_label' => null,
			);
		}
		$state = WPPE_Bridge_Environment_Diagnostics::detect_wp_cron_state();

		// `ok` y `never_run` (instalacion fresca) no bloquean. El resto si.
		$passed  = in_array( $state['state'], array( 'ok', 'never_run' ), true );
		$message = '';
		switch ( $state['state'] ) {
			case 'ok':
				$message = __( 'Worker activo, ultimo tick reciente.', 'wppe-bridge' );
				break;
			case 'never_run':
				$message = __( 'Cron agendado pero el worker aun no tickeo (puede ser instalacion reciente).', 'wppe-bridge' );
				break;
			case 'stale':
				$message = __( 'El cron del servidor dejo de disparar — el worker no ha corrido en mas de 5 minutos.', 'wppe-bridge' );
				break;
			case 'disabled_no_external':
				$message = __( '<code>DISABLE_WP_CRON</code> esta activo y no hay un cron de servidor disparando <code>wp-cron.php</code>.', 'wppe-bridge' );
				break;
			case 'no_event':
			default:
				$message = __( 'El evento del worker no esta agendado en WP-Cron.', 'wppe-bridge' );
				break;
		}

		return array(
			'key'       => 'wp_cron',
			'label'     => __( 'WP-Cron del worker', 'wppe-bridge' ),
			'critical'  => true,
			'passed'    => $passed,
			'message'   => $message,
			'cta_url'   => null,
			'cta_label' => null,
		);
	}

	/**
	 * Licencia / Hosting (critico cuando esta blocked).
	 *
	 * @return array<string,mixed>
	 */
	public static function check_license(): array {
		if ( ! class_exists( 'WPPE_Bridge_License_Manager' ) ) {
			return array(
				'key'       => 'license',
				'label'     => __( 'Licencia / Hosting', 'wppe-bridge' ),
				'critical'  => false,
				'passed'    => true,
				'message'   => '',
				'cta_url'   => null,
				'cta_label' => null,
			);
		}
		$state = WPPE_Bridge_License_Manager::state();
		// blocked = critico (el worker no envia). demo = warning (envia pero con limite).
		$passed   = WPPE_Bridge_License_Manager::STATE_BLOCKED !== $state;
		$critical = WPPE_Bridge_License_Manager::STATE_BLOCKED === $state;

		$message = '';
		if ( WPPE_Bridge_License_Manager::STATE_MANAGED === $state ) {
			$message = __( 'Dominio gestionado por Mono Media — sin limite de leads.', 'wppe-bridge' );
		} elseif ( WPPE_Bridge_License_Manager::STATE_DEMO === $state ) {
			$message = sprintf(
				/* translators: 1: count, 2: limit */
				__( 'Modo demo: %1$d/%2$d leads enviados. Solicita whitelist a soporte@mono.media para uso ilimitado.', 'wppe-bridge' ),
				WPPE_Bridge_License_Manager::demo_leads_count(),
				WPPE_Bridge_License_Manager::demo_lead_limit()
			);
		} else {
			$message = __( 'Demo agotado. El worker NO envia leads al CRM hasta que el dominio aparezca en whitelist.', 'wppe-bridge' );
		}

		return array(
			'key'       => 'license',
			'label'     => __( 'Licencia / Hosting', 'wppe-bridge' ),
			'critical'  => $critical,
			'passed'    => $passed,
			'message'   => $message,
			'cta_url'   => null,
			'cta_label' => null,
		);
	}

	/**
	 * PHP version (no critico, solo warning si es 8.1).
	 *
	 * @return array<string,mixed>
	 */
	public static function check_php_version(): array {
		if ( ! class_exists( 'WPPE_Bridge_Environment_Diagnostics' ) ) {
			return array(
				'key'       => 'php_version',
				'label'     => __( 'Version de PHP', 'wppe-bridge' ),
				'critical'  => false,
				'passed'    => true,
				'message'   => '',
				'cta_url'   => null,
				'cta_label' => null,
			);
		}
		$version = WPPE_Bridge_Environment_Diagnostics::detect_php_version();
		$status  = WPPE_Bridge_Environment_Diagnostics::evaluate_php_version( $version );
		$passed  = WPPE_Bridge_Help_Page::STATUS_DONE === $status;

		return array(
			'key'       => 'php_version',
			'label'     => __( 'Version de PHP', 'wppe-bridge' ),
			'critical'  => false,
			'passed'    => $passed,
			'message'   => $passed
				? sprintf(
					/* translators: %s = PHP version instalada (ej. "8.4.19") */
					__( 'PHP %s — OK. Cumple con el minimo recomendado (8.2+).', 'wppe-bridge' ),
					esc_html( $version )
				)
				: sprintf(
					/* translators: %s = PHP version instalada */
					__( 'PHP %s — debajo del minimo recomendado. Pedir upgrade a 8.2+ al hosting.', 'wppe-bridge' ),
					esc_html( $version )
				),
			'cta_url'   => null,
			'cta_label' => null,
		);
	}

	/**
	 * SMTP plugin activo (no critico, solo recomendado).
	 *
	 * @return array<string,mixed>
	 */
	public static function check_smtp(): array {
		if ( ! class_exists( 'WPPE_Bridge_Environment_Diagnostics' ) ) {
			return array(
				'key'       => 'smtp',
				'label'     => __( 'SMTP saliente', 'wppe-bridge' ),
				'critical'  => false,
				'passed'    => true,
				'message'   => '',
				'cta_url'   => null,
				'cta_label' => null,
			);
		}
		$active = WPPE_Bridge_Environment_Diagnostics::detect_active_smtp_plugins();
		$passed = ! empty( $active );

		return array(
			'key'       => 'smtp',
			'label'     => __( 'SMTP saliente', 'wppe-bridge' ),
			'critical'  => false,
			'passed'    => $passed,
			'message'   => $passed
				? sprintf(
					/* translators: %s = plugin name */
					__( 'Plugin SMTP detectado: %s.', 'wppe-bridge' ),
					esc_html( implode( ', ', array_values( $active ) ) )
				)
				: __( 'Sin plugin SMTP activo. Los correos transaccionales pueden caer en spam.', 'wppe-bridge' ),
			'cta_url'   => null,
			'cta_label' => null,
		);
	}
}
