<?php
/**
 * Discovery de forms instalados en el WordPress.
 *
 * Consulta Fluent Forms y Gravity Forms via sus APIs publicas para
 * listar forms disponibles y sus campos. La pagina de Mapping usa
 * esto para poblar dropdowns y mostrar el editor sin que el admin
 * tenga que conocer IDs.
 *
 * Si ningun plugin de forms esta activo, devuelve estructura vacia
 * y la UI mostrara mensaje explicativo + opcion de mapping manual.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Discovery de forms instalados.
 */
final class WPPE_Bridge_Form_Discovery {

	/**
	 * Estructura uniforme de un form descubierto:
	 *   [
	 *     'id'     => string,   // ID stringificado (Fluent: numero, Gravity: numero).
	 *     'title'  => string,   // Titulo legible.
	 *     'fields' => [
	 *       ['name' => string, 'label' => string],
	 *     ],
	 *   ]
	 */

	/**
	 * Codigos de razon que retorna `discover_*_with_reason` cuando
	 * encontro 0 forms. Permiten que el banner de Mapeo muestre por
	 * que no detecto en lugar de un mensaje generico.
	 */
	public const REASON_OK              = 'ok';
	public const REASON_PLUGIN_INACTIVE = 'plugin_inactive';
	public const REASON_TABLE_MISSING   = 'table_missing';
	public const REASON_NO_FORMS        = 'no_forms';
	public const REASON_API_MISSING     = 'api_missing';

	/**
	 * Descubre todos los forms disponibles. Retorna estructura
	 * agrupada por plugin slug.
	 *
	 * @return array<string,array<int,array>> ['fluent' => [...], 'gravity' => [...], 'elementor' => [...], 'cf7' => [...]]
	 */
	public static function discover_all(): array {
		return array(
			'fluent'    => self::discover_fluent(),
			'gravity'   => self::discover_gravity(),
			'elementor' => self::discover_elementor(),
			'cf7'       => self::discover_cf7(),
		);
	}

	/**
	 * Variante de discover_all que ademas retorna el motivo cuando
	 * un plugin no aporta forms. Usado por la pagina de Mapeo para
	 * mostrar mensajes informativos.
	 *
	 * @return array{
	 *   forms:array<string,array<int,array>>,
	 *   reasons:array<string,string>
	 * }
	 */
	public static function discover_all_with_reasons(): array {
		[ $fluent_forms, $fluent_reason ]       = self::discover_fluent_with_reason();
		[ $gravity_forms, $gravity_reason ]     = self::discover_gravity_with_reason();
		[ $elementor_forms, $elementor_reason ] = self::discover_elementor_with_reason();
		[ $cf7_forms, $cf7_reason ]             = self::discover_cf7_with_reason();
		return array(
			'forms'   => array(
				'fluent'    => $fluent_forms,
				'gravity'   => $gravity_forms,
				'elementor' => $elementor_forms,
				'cf7'       => $cf7_forms,
			),
			'reasons' => array(
				'fluent'    => $fluent_reason,
				'gravity'   => $gravity_reason,
				'elementor' => $elementor_reason,
				'cf7'       => $cf7_reason,
			),
		);
	}

	/**
	 * Detecta forms de Fluent Forms si el plugin esta activo.
	 *
	 * Usa `$wpdb` directo en lugar de `wpFluent()->table()->get()`
	 * porque el query builder interno de Fluent puede cambiar entre
	 * versiones (lo hizo en >=5.x). La estructura de la tabla
	 * `fluentform_forms` (columnas `id`, `title`, `form_fields`)
	 * esta documentada oficialmente y es estable. No viola D2 — esto
	 * NO es polling de submissions, es lookup puntual de metadata
	 * de forms desde el admin.
	 *
	 * @return array<int,array>
	 */
	public static function discover_fluent(): array {
		[ $forms, ] = self::discover_fluent_with_reason();
		return $forms;
	}

	/**
	 * Variante con motivo. Retorna `[forms[], reason]`.
	 *
	 * @return array{0:array<int,array>,1:string}
	 */
	public static function discover_fluent_with_reason(): array {
		if ( ! WPPE_Bridge_Fluent_Forms_Adapter::is_available() ) {
			return array( array(), self::REASON_PLUGIN_INACTIVE );
		}

		global $wpdb;
		$table = $wpdb->prefix . 'fluentform_forms';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( $exists !== $table ) {
			return array( array(), self::REASON_TABLE_MISSING );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( "SELECT id, title, form_fields FROM `{$table}` ORDER BY id ASC" );
		if ( ! is_array( $rows ) || empty( $rows ) ) {
			return array( array(), self::REASON_NO_FORMS );
		}

		$out = array();
		foreach ( $rows as $row ) {
			$row_arr = is_object( $row ) ? (array) $row : (array) $row;
			$id      = isset( $row_arr['id'] ) ? (string) $row_arr['id'] : '';
			$title   = isset( $row_arr['title'] ) ? (string) $row_arr['title'] : '';
			if ( '' === $id ) {
				continue;
			}
			$out[] = array(
				'id'     => $id,
				'title'  => '' !== $title ? $title : sprintf( 'Form #%s', $id ),
				'fields' => self::parse_fluent_fields( $row_arr['form_fields'] ?? '' ),
			);
		}

		if ( empty( $out ) ) {
			return array( array(), self::REASON_NO_FORMS );
		}
		return array( $out, self::REASON_OK );
	}

	/**
	 * Detecta forms de Gravity Forms si el plugin esta activo.
	 *
	 * @return array<int,array>
	 */
	public static function discover_gravity(): array {
		[ $forms, ] = self::discover_gravity_with_reason();
		return $forms;
	}

	/**
	 * Variante con motivo. Retorna `[forms[], reason]`.
	 *
	 * @return array{0:array<int,array>,1:string}
	 */
	public static function discover_gravity_with_reason(): array {
		if ( ! WPPE_Bridge_Gravity_Forms_Adapter::is_available() ) {
			return array( array(), self::REASON_PLUGIN_INACTIVE );
		}
		if ( ! class_exists( 'GFAPI' ) || ! method_exists( 'GFAPI', 'get_forms' ) ) {
			return array( array(), self::REASON_API_MISSING );
		}

		$forms = \GFAPI::get_forms();
		if ( ! is_array( $forms ) || empty( $forms ) ) {
			return array( array(), self::REASON_NO_FORMS );
		}

		$out = array();
		foreach ( $forms as $form ) {
			$form_arr = is_array( $form ) ? $form : (array) $form;
			$id       = isset( $form_arr['id'] ) ? (string) $form_arr['id'] : '';
			$title    = isset( $form_arr['title'] ) ? (string) $form_arr['title'] : '';
			if ( '' === $id ) {
				continue;
			}
			$out[] = array(
				'id'     => $id,
				'title'  => '' !== $title ? $title : sprintf( 'Form #%s', $id ),
				'fields' => self::parse_gravity_fields( $form_arr['fields'] ?? array() ),
			);
		}

		if ( empty( $out ) ) {
			return array( array(), self::REASON_NO_FORMS );
		}
		return array( $out, self::REASON_OK );
	}

	/**
	 * Parsea el campo `form_fields` de Fluent (JSON). El JSON tiene
	 * `fields[]` con `attributes.name` y `settings.label`. Tolerante
	 * a estructuras viejas.
	 *
	 * Walk recursivo (v2.7.10) para descubrir fields anidados en
	 * containers (`container` con `columns[].fields[]`, `section_break`
	 * con `fields[]`, `form_step` con `fields[]`, etc.). Antes solo
	 * captaba top-level fields + `input_name` sub-fields. Reportado
	 * por cliente con form que tiene DNI dentro de columnas.
	 *
	 * @param mixed $raw String JSON, array o null.
	 * @return array<int,array{name:string,label:string}>
	 */
	public static function parse_fluent_fields( $raw ): array {
		$decoded = is_string( $raw ) ? json_decode( $raw, true ) : ( is_array( $raw ) ? $raw : array() );
		if ( ! is_array( $decoded ) ) {
			return array();
		}

		$fields = isset( $decoded['fields'] ) && is_array( $decoded['fields'] ) ? $decoded['fields'] : array();
		$out    = array();
		self::walk_fluent_fields( $fields, $out );
		return $out;
	}

	/**
	 * Recorre recursivamente la estructura de fields de Fluent Forms.
	 * Maneja:
	 *  - Fields con `attributes.name` → se agregan como leaf
	 *  - `input_name` con sub-fields → dot-notation (names.first_name)
	 *  - `container` con `columns[].fields[]` → recorre cada columna
	 *  - Cualquier struct con `fields[]` adentro → recorre recursivamente
	 *
	 * @param array $fields Lista de fields o sub-fields.
	 * @param array $out Acumulador de fields planos.
	 */
	private static function walk_fluent_fields( array $fields, array &$out ): void {
		foreach ( $fields as $f ) {
			if ( ! is_array( $f ) ) {
				continue;
			}
			$element = isset( $f['element'] ) && is_string( $f['element'] ) ? $f['element'] : '';

			// Containers con columnas (ej. `container` con `columns[]`).
			if ( isset( $f['columns'] ) && is_array( $f['columns'] ) ) {
				foreach ( $f['columns'] as $col ) {
					if ( is_array( $col ) && isset( $col['fields'] ) && is_array( $col['fields'] ) ) {
						self::walk_fluent_fields( $col['fields'], $out );
					}
				}
				continue;
			}

			$name  = '';
			$label = '';
			if ( isset( $f['attributes']['name'] ) && is_string( $f['attributes']['name'] ) ) {
				$name = $f['attributes']['name'];
			}
			if ( isset( $f['settings']['label'] ) && is_string( $f['settings']['label'] ) ) {
				$label = $f['settings']['label'];
			}

			// Field con nombre directo (input simple, numeric, select, etc.).
			if ( '' !== $name ) {
				$out[] = array(
					'name'  => $name,
					'label' => '' !== $label ? $label : $name,
				);

				// Campos compound (input_name): expandir sub-fields con dot-notation.
				if ( 'input_name' === $element && isset( $f['fields'] ) && is_array( $f['fields'] ) ) {
					foreach ( $f['fields'] as $sub_key => $sub_def ) {
						$sub_name  = isset( $sub_def['attributes']['name'] ) && is_string( $sub_def['attributes']['name'] )
							? $sub_def['attributes']['name']
							: (string) $sub_key;
						$sub_label = isset( $sub_def['settings']['label'] ) && is_string( $sub_def['settings']['label'] )
							? $sub_def['settings']['label']
							: $sub_name;
						if ( '' === $sub_name ) {
							continue;
						}
						$out[] = array(
							'name'  => $name . '.' . $sub_name,
							'label' => sprintf( '%s — %s', '' !== $label ? $label : $name, $sub_label ),
						);
					}
				}
				continue;
			}

			// Sin nombre directo pero con fields[] adentro (section_break, form_step, etc.).
			if ( isset( $f['fields'] ) && is_array( $f['fields'] ) ) {
				self::walk_fluent_fields( $f['fields'], $out );
			}
		}
	}

	/**
	 * Convierte la lista de fields de Gravity a la estructura uniforme.
	 * Prefiere `adminLabel` (mas estable), fallback a `label`. El
	 * `name` que devolvemos es exactamente lo que el adapter Gravity
	 * usa para mapear (ver class-gravity-forms-adapter.php).
	 *
	 * @param mixed $fields Lista de fields (array o objetos GF_Field).
	 * @return array<int,array{name:string,label:string}>
	 */
	public static function parse_gravity_fields( $fields ): array {
		if ( ! is_array( $fields ) ) {
			return array();
		}
		$out = array();
		foreach ( $fields as $field ) {
			$f         = is_array( $field ) ? $field : (array) $field;
			$id        = isset( $f['id'] ) ? (string) $f['id'] : '';
			$admin_lbl = isset( $f['adminLabel'] ) && is_string( $f['adminLabel'] ) ? $f['adminLabel'] : '';
			$label     = isset( $f['label'] ) && is_string( $f['label'] ) ? $f['label'] : '';
			$name      = '' !== $admin_lbl ? $admin_lbl : ( '' !== $label ? $label : 'field_' . $id );
			$out[]     = array(
				'name'  => $name,
				'label' => '' !== $label ? $label : $name,
			);
		}
		return $out;
	}

	/**
	 * Detecta forms de Elementor Pro Forms si el plugin esta activo.
	 *
	 * Elementor Forms NO son un post type propio — son widgets embedidos
	 * dentro de cualquier post/page/template via `_elementor_data` (JSON
	 * en meta). Por eso recorremos `wp_postmeta` filtrando por la firma
	 * `"widgetType":"form"` en el meta_value, decodificamos el JSON, y
	 * extraemos los widgets de form recursivamente.
	 *
	 * @since 2.8.0
	 * @return array<int,array>
	 */
	public static function discover_elementor(): array {
		[ $forms, ] = self::discover_elementor_with_reason();
		return $forms;
	}

	/**
	 * Variante con motivo. Retorna `[forms[], reason]`.
	 *
	 * @since 2.8.0
	 * @return array{0:array<int,array>,1:string}
	 */
	public static function discover_elementor_with_reason(): array {
		if ( ! class_exists( 'WPPE_Bridge_Elementor_Forms_Adapter' ) || ! WPPE_Bridge_Elementor_Forms_Adapter::is_available() ) {
			return array( array(), self::REASON_PLUGIN_INACTIVE );
		}

		global $wpdb;

		// Buscar postmeta con widgets de form. El meta_value puede ser
		// grande (JSON de toda la pagina) pero el LIKE es barato porque
		// indexado por meta_key. Limite de 200 posts para evitar cargar
		// todo en sitios grandes — suficiente para 99% de casos.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value LIKE %s LIMIT %d",
				'_elementor_data',
				'%"widgetType":"form"%',
				200
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared

		if ( ! is_array( $rows ) || empty( $rows ) ) {
			return array( array(), self::REASON_NO_FORMS );
		}

		$out = array();
		foreach ( $rows as $row ) {
			$post_id    = isset( $row->post_id ) ? (int) $row->post_id : 0;
			$meta_value = isset( $row->meta_value ) ? (string) $row->meta_value : '';
			if ( 0 === $post_id || '' === $meta_value ) {
				continue;
			}

			$decoded = json_decode( $meta_value, true );
			if ( ! is_array( $decoded ) ) {
				continue;
			}

			$post_title = get_the_title( $post_id );
			if ( '' === $post_title ) {
				$post_title = sprintf( '(post #%d)', $post_id );
			}

			$widgets = array();
			self::collect_elementor_form_widgets( $decoded, $widgets );

			foreach ( $widgets as $widget ) {
				$settings = isset( $widget['settings'] ) && is_array( $widget['settings'] ) ? $widget['settings'] : array();

				// ID estable: form_name (custom) > widget id (auto).
				$form_name = isset( $settings['form_name'] ) ? (string) $settings['form_name'] : '';
				$widget_id = isset( $widget['id'] ) ? (string) $widget['id'] : '';
				$form_id   = '' !== $form_name ? $form_name : $widget_id;
				if ( '' === $form_id ) {
					continue;
				}

				$out[] = array(
					'id'     => $form_id,
					'title'  => sprintf( '%s — %s', $post_title, '' !== $form_name ? $form_name : sprintf( 'widget %s', $widget_id ) ),
					'fields' => self::parse_elementor_fields( isset( $settings['form_fields'] ) ? $settings['form_fields'] : array() ),
				);
			}
		}

		if ( empty( $out ) ) {
			return array( array(), self::REASON_NO_FORMS );
		}
		return array( $out, self::REASON_OK );
	}

	/**
	 * Recorre recursivamente la estructura JSON de Elementor y acumula
	 * widgets cuyo `widgetType` sea `form`.
	 *
	 * Elementor anida widgets dentro de `elements[]` (sections →
	 * columns → widgets, o containers → containers/widgets). Walk
	 * recursivo sobre `elements[]`.
	 *
	 * @since 2.8.0
	 * @param array $elements Nodo de Elementor (section, column, container, widget).
	 * @param array $out      Acumulador de widgets de form.
	 */
	private static function collect_elementor_form_widgets( array $elements, array &$out ): void {
		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}

			$type        = isset( $element['elType'] ) ? (string) $element['elType'] : '';
			$widget_type = isset( $element['widgetType'] ) ? (string) $element['widgetType'] : '';

			if ( 'widget' === $type && 'form' === $widget_type ) {
				$out[] = $element;
				// Los forms no contienen otros forms adentro, podemos
				// detener el descenso aqui (pero seguir con siblings).
				continue;
			}

			// Container / section / column → descender a elements[].
			if ( isset( $element['elements'] ) && is_array( $element['elements'] ) ) {
				self::collect_elementor_form_widgets( $element['elements'], $out );
			}
		}
	}

	/**
	 * Convierte la lista `form_fields` de Elementor a la estructura
	 * uniforme. Cada field tiene `custom_id` (configurable) y
	 * `field_label`.
	 *
	 * `custom_id` es lo que Elementor manda al record en el hook
	 * `elementor_pro/forms/new_record` como key. Si el operador no lo
	 * configura, Elementor auto-genera "field_xxxxx".
	 *
	 * @since 2.8.0
	 * @param mixed $form_fields Lista de fields de Elementor.
	 * @return array<int,array{name:string,label:string}>
	 */
	public static function parse_elementor_fields( $form_fields ): array {
		if ( ! is_array( $form_fields ) ) {
			return array();
		}
		$out = array();
		foreach ( $form_fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			// Skip step markers (multi-step forms).
			$field_type = isset( $field['field_type'] ) ? (string) $field['field_type'] : '';
			if ( 'step' === $field_type ) {
				continue;
			}
			$custom_id = isset( $field['custom_id'] ) ? (string) $field['custom_id'] : '';
			$label     = isset( $field['field_label'] ) ? (string) $field['field_label'] : '';
			if ( '' === $custom_id ) {
				continue;
			}
			$out[] = array(
				'name'  => $custom_id,
				'label' => '' !== $label ? $label : $custom_id,
			);
		}
		return $out;
	}

	/**
	 * Detecta forms de Contact Form 7 si el plugin esta activo.
	 *
	 * CF7 guarda cada form como post del tipo `wpcf7_contact_form`.
	 * El template del form (shortcodes [text* your-name], [email*
	 * your-email], etc.) vive en el postmeta `_form`. Parseamos los
	 * tags para extraer los names.
	 *
	 * @since 2.9.0
	 * @return array<int,array>
	 */
	public static function discover_cf7(): array {
		[ $forms, ] = self::discover_cf7_with_reason();
		return $forms;
	}

	/**
	 * Variante con motivo. Retorna `[forms[], reason]`.
	 *
	 * @since 2.9.0
	 * @return array{0:array<int,array>,1:string}
	 */
	public static function discover_cf7_with_reason(): array {
		if ( ! class_exists( 'WPPE_Bridge_Cf7_Forms_Adapter' ) || ! WPPE_Bridge_Cf7_Forms_Adapter::is_available() ) {
			return array( array(), self::REASON_PLUGIN_INACTIVE );
		}

		// Usamos get_posts (publico) + get_post_meta para evitar leer
		// tablas directas. Esto cumple D2 — todo via WP API publica.
		// Cap intencional de 200 forms (mismo que Elementor / Fluent).
		// Es admin-side query puntual (no en el front), suficiente para
		// 99% de sites — los pocos clientes con >200 forms son raros y
		// pueden filtrar via el dropdown del admin.
		$posts = get_posts(
			array(
				'post_type'      => 'wpcf7_contact_form',
				'post_status'    => 'any',
				// phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page
				'posts_per_page' => 200,
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);

		if ( ! is_array( $posts ) || empty( $posts ) ) {
			return array( array(), self::REASON_NO_FORMS );
		}

		$out = array();
		foreach ( $posts as $post ) {
			$post_arr = is_object( $post ) ? (array) $post : (array) $post;
			$id       = isset( $post_arr['ID'] ) ? (string) $post_arr['ID'] : '';
			$title    = isset( $post_arr['post_title'] ) ? (string) $post_arr['post_title'] : '';
			if ( '' === $id ) {
				continue;
			}
			$template = get_post_meta( (int) $id, '_form', true );
			$out[]    = array(
				'id'     => $id,
				'title'  => '' !== $title ? $title : sprintf( 'Form #%s', $id ),
				'fields' => self::parse_cf7_fields( $template ),
			);
		}

		if ( empty( $out ) ) {
			return array( array(), self::REASON_NO_FORMS );
		}
		return array( $out, self::REASON_OK );
	}

	/**
	 * Parsea el template (shortcode-style) de un form CF7 y extrae los
	 * names de cada tag.
	 *
	 * Sintaxis CF7:
	 *   [tipo* name attr]    → required field
	 *   [tipo name attr]     → optional field
	 *
	 * Ejemplos:
	 *   [text* your-name]      → name=your-name, tipo=text
	 *   [email* your-email]    → name=your-email, tipo=email
	 *   [tel your-phone]       → name=your-phone, tipo=tel
	 *   [select project include_blank "Vanguardia|7" "Marques|12"]
	 *   [submit "Enviar"]      → ignorado (submit/captcha-r/recaptcha)
	 *
	 * Tags ignorados: submit, response, captcha*, recaptcha (no son
	 * fields de datos del lead).
	 *
	 * @since 2.9.0
	 * @param mixed $template String del template `_form` de CF7.
	 * @return array<int,array{name:string,label:string}>
	 */
	public static function parse_cf7_fields( $template ): array {
		if ( ! is_string( $template ) || '' === $template ) {
			return array();
		}

		// Regex: `[tipo* name ...]` o `[tipo name ...]`. Tipo es
		// alfanumerico + dashes. El `*` indica required. Capturamos
		// tipo y name.
		$ignore_types = array( 'submit', 'response', 'captcha', 'captchac', 'captchar', 'recaptcha', 'acceptance' );

		$out  = array();
		$seen = array();
		if ( preg_match_all( '/\[([a-z][a-z0-9_-]*)\*?\s+([a-zA-Z0-9_-]+)/i', $template, $matches, PREG_SET_ORDER ) ) {
			foreach ( $matches as $match ) {
				$tag  = strtolower( $match[1] );
				$name = $match[2];
				if ( in_array( $tag, $ignore_types, true ) ) {
					continue;
				}
				// Dedup por name (un mismo name no aparece dos veces).
				if ( isset( $seen[ $name ] ) ) {
					continue;
				}
				$seen[ $name ] = true;
				$out[]         = array(
					'name'  => $name,
					'label' => $name,
				);
			}
		}

		return $out;
	}
}
