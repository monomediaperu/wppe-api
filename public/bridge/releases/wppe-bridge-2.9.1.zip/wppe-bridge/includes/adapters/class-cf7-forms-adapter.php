<?php
/**
 * Adapter para Contact Form 7 (CF7).
 *
 * Hook nativo: `wpcf7_mail_sent`.
 * Args del callback: ($contact_form) — instancia WPCF7_ContactForm.
 *
 * Por que `wpcf7_mail_sent` y no `wpcf7_before_send_mail`:
 *   - `wpcf7_before_send_mail` se dispara incluso si CF7 luego rechaza
 *     el envio (spam, validacion fallida tardia). Capturar leads que CF7
 *     descarta seria falso-positivo.
 *   - `wpcf7_mail_sent` solo se dispara despues de que CF7 considero la
 *     submission valida y mando el email. Es el momento equivalente a
 *     `fluentform/submission_inserted` y `gform_after_submission`.
 *
 * Como obtenemos form_data:
 *   CF7 no pasa los datos al callback. Hay que pedirlos a
 *   `WPCF7_Submission::get_instance()->get_posted_data()` durante el
 *   ciclo del request. La instancia existe SOLO mientras CF7 procesa
 *   la submission — por eso es seguro llamarla aqui.
 *
 * Decision D2 del CLAUDE.md: solo hooks publicos, nunca leemos tablas
 * internas de CF7.
 *
 * Disponibilidad: CF7 es plugin gratuito muy popular. Detectamos via
 * `WPCF7_VERSION` (constante definida por el plugin) o la clase
 * `WPCF7_ContactForm`.
 *
 * @package WPPE_Bridge
 * @since 2.9.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Adapter para Contact Form 7.
 */
final class WPPE_Bridge_Cf7_Forms_Adapter extends WPPE_Bridge_Form_Adapter_Base {

	/**
	 * Slug del plugin de forms.
	 *
	 * @return string
	 */
	public static function plugin_slug(): string {
		return 'cf7';
	}

	/**
	 * Detecta si CF7 esta activo.
	 *
	 * Filter `wppe_bridge_cf7_is_available` permite a tests forzar
	 * el resultado.
	 *
	 * @return bool
	 */
	public static function is_available(): bool {
		$detected = defined( 'WPCF7_VERSION' ) || class_exists( 'WPCF7_ContactForm' );
		/**
		 * Filtra la deteccion de Contact Form 7.
		 *
		 * @param bool $detected Resultado de la deteccion automatica.
		 */
		return (bool) apply_filters( 'wppe_bridge_cf7_is_available', $detected );
	}

	/**
	 * Suscribe el hook nativo de CF7.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'wpcf7_mail_sent', array( self::class, 'on_submission' ), 10, 1 );
	}

	/**
	 * Auto-registro condicional.
	 *
	 * @return void
	 */
	public static function maybe_register(): void {
		if ( self::is_available() ) {
			self::register();
		}
	}

	/**
	 * Callback del hook `wpcf7_mail_sent`.
	 *
	 * El `$contact_form` es una instancia de WPCF7_ContactForm con metodos:
	 *  - `id()`: ID del post type wpcf7_contact_form.
	 *  - `title()`: titulo legible.
	 *
	 * `WPCF7_Submission::get_instance()` retorna la instancia activa
	 * del submission en proceso. Su `get_posted_data()` da el array
	 * `[field_name => value]`.
	 *
	 * @param object|null $contact_form WPCF7_ContactForm o null en tests.
	 * @return void
	 */
	public static function on_submission( $contact_form ): void {
		if ( ! is_object( $contact_form ) ) {
			return;
		}

		$form_id   = self::extract_form_id( $contact_form );
		$form_data = self::extract_form_data();

		// Entry ID sintetico: CF7 no asigna ID a la submission (a menos
		// que el cliente tenga Flamingo / DB plugin instalado). Generamos
		// uno para trazabilidad en logs.
		$entry_id = sprintf( 'cf7-%d-%s', time(), wp_generate_password( 6, false ) );

		self::handle_submission( $form_data, $entry_id, $form_id );
	}

	/**
	 * Extrae el form_id del contact_form.
	 *
	 * @param object $contact_form WPCF7_ContactForm.
	 * @return string
	 */
	public static function extract_form_id( $contact_form ): string {
		if ( ! is_object( $contact_form ) ) {
			return '';
		}
		if ( method_exists( $contact_form, 'id' ) ) {
			return (string) $contact_form->id();
		}
		return '';
	}

	/**
	 * Extrae el form_data desde WPCF7_Submission. En tests, se puede
	 * inyectar via filtro `wppe_bridge_cf7_test_posted_data`.
	 *
	 * @return array
	 */
	public static function extract_form_data(): array {
		// Hook de testing: permite inyectar form_data sin requerir
		// WPCF7_Submission real.
		$injected = apply_filters( 'wppe_bridge_cf7_test_posted_data', null );
		if ( is_array( $injected ) ) {
			return $injected;
		}

		if ( ! class_exists( 'WPCF7_Submission' ) ) {
			return array();
		}

		// phpcs:ignore Generic.Files.LineLength.TooLong
		$submission = call_user_func( array( 'WPCF7_Submission', 'get_instance' ) );
		if ( ! is_object( $submission ) || ! method_exists( $submission, 'get_posted_data' ) ) {
			return array();
		}

		$posted = $submission->get_posted_data();
		return is_array( $posted ) ? $posted : array();
	}
}
