<?php
/**
 * Pagina admin de mapeo de campos.
 *
 * UI para configurar, por cada form Fluent o Gravity:
 * - Mapeo de campos del form -> claves del payload Sperant (fname,
 *   lname, email, phone, document, etc.).
 * - Defaults: input_channel_id, source_id, interest_type_id,
 *   project_id (poblados desde catalogos sincronizados).
 *
 * Persiste en wp_options['wppe_bridge_field_mapping'] usando la
 * misma estructura que los adapters consumen (ver D7).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pagina admin de mapeo de campos del form a campos Sperant.
 */
final class WPPE_Bridge_Mapping_Page {

	/**
	 * Action del POST handler.
	 */
	public const ACTION_SAVE = 'wppe_bridge_save_mapping';

	/**
	 * Nonce action / field.
	 */
	public const NONCE_ACTION = 'wppe_bridge_save_mapping';

	/**
	 * Action POST handler para guardar el mapeo global de
	 * `utm_source -> input_channel_id` (v2.5.1). Separado de
	 * `ACTION_SAVE` (que es per-form) porque esta config es global
	 * y vive en una option propia.
	 */
	public const ACTION_SAVE_UTM_CHANNEL = 'wppe_bridge_save_utm_channel_map';

	/**
	 * Nonce action para el form de utm_source -> input_channel.
	 */
	public const NONCE_UTM_CHANNEL = 'wppe_bridge_save_utm_channel_map';

	/**
	 * Lista de payload keys que el admin puede mapear.
	 */
	public const PAYLOAD_KEYS = array(
		'fname',
		'lname',
		'email',
		'phone',
		'document',
		'address',
		'message',
		'observation',
	);

	/**
	 * Defaults posibles por catalogo.
	 *
	 * @var array<string,string>
	 */
	public const DEFAULT_KEYS = array(
		'input_channel_id' => 'input_channels',
		'source_id'        => 'sources',
		'interest_type_id' => 'interest_types',
		'project_id'       => 'projects',
	);

	/**
	 * Registra el handler del submit (admin_post_*).
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_post_' . self::ACTION_SAVE, array( self::class, 'handle_save' ) );
		add_action( 'admin_post_' . self::ACTION_SAVE_UTM_CHANNEL, array( self::class, 'handle_save_utm_channel_map' ) );
	}

	/**
	 * Renderiza la pagina.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Datos para la vista.
		$discovery_result  = WPPE_Bridge_Form_Discovery::discover_all_with_reasons();
		$discovered        = $discovery_result['forms'];
		$discovery_reasons = $discovery_result['reasons'];
		$catalogs          = get_option( 'wppe_bridge_catalogs', array() );
		$mapping           = get_option( 'wppe_bridge_field_mapping', array() );
		$catalogs          = is_array( $catalogs ) ? $catalogs : array();
		$mapping           = is_array( $mapping ) ? $mapping : array();
		// Errores del ultimo sync de catalogos (para mostrar al lado de
		// cada dropdown que tenga catalogo no disponible).
		$catalogs_errors = isset( $catalogs['_errors'] ) && is_array( $catalogs['_errors'] ) ? $catalogs['_errors'] : array();

		$selected_plugin = isset( $_GET['plugin'] ) ? sanitize_key( wp_unslash( $_GET['plugin'] ) ) : 'fluent';  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$selected_form   = isset( $_GET['form'] ) ? sanitize_text_field( wp_unslash( $_GET['form'] ) ) : '';      // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		// Encontrar form seleccionado en discovery.
		$selected_form_data = null;
		if ( '' !== $selected_form && isset( $discovered[ $selected_plugin ] ) ) {
			foreach ( $discovered[ $selected_plugin ] as $form ) {
				if ( (string) $form['id'] === $selected_form ) {
					$selected_form_data = $form;
					break;
				}
			}
		}

		$existing_mapping = isset( $mapping[ $selected_plugin ][ $selected_form ] )
			? $mapping[ $selected_plugin ][ $selected_form ]
			: array(
				'fields'   => array(),
				'defaults' => array(),
			);

		$catalogs_present = ! empty(
			array_filter(
				array( 'input_channels', 'sources', 'interest_types', 'projects' ),
				static fn ( $k ) => isset( $catalogs[ $k ] ) && is_array( $catalogs[ $k ] ) && ! empty( $catalogs[ $k ] )
			)
		);

		// v2.5.1: mapeo global utm_source -> input_channel_id. Variables
		// para el bloque nuevo en la vista. `input_channels_for_dropdown`
		// se arma con el catalogo sincronizado para que el admin elija de
		// un select en lugar de pegar un id a mano.
		$utm_channel_map             = WPPE_Bridge_Utm_Channel_Mapper::get_all();
		$input_channels_for_dropdown = isset( $catalogs['input_channels'] ) && is_array( $catalogs['input_channels'] )
			? $catalogs['input_channels']
			: array();

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/mapping.php';
	}

	/**
	 * Handler del admin_post_* que guarda el mapping enviado.
	 *
	 * @return void
	 */
	public static function handle_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_ACTION );

		$post   = wp_unslash( $_POST );
		$plugin = isset( $post['plugin'] ) ? sanitize_key( $post['plugin'] ) : '';
		$form   = isset( $post['form'] ) ? sanitize_text_field( $post['form'] ) : '';

		if ( '' === $plugin || '' === $form ) {
			wp_safe_redirect( self::redirect_url( $plugin, $form, 'error_missing_form' ) );
			exit;
		}

		$entry = self::build_entry_from_post( is_array( $post ) ? $post : array() );

		// Validacion de campos obligatorios (v1.2.0; v2.7.0 expande required).
		// `fname`, `input_channel_id`, `interest_type_id`: Sperant rechaza
		// con 422 si faltan. `source_id`, `project_id`: politica WP.pe Bridge
		// (CLAUDE.md sec 1 — reporting de fuente y proyecto es parte del
		// onboarding minimo, Sperant los acepta vacios pero Mono Media no).
		$missing = self::validate_required_fields( $entry );
		if ( ! empty( $missing ) ) {
			wp_safe_redirect(
				self::redirect_url(
					$plugin,
					$form,
					'error_required',
					$missing
				)
			);
			exit;
		}

		// Persiste sin perder los demas forms.
		$current = get_option( 'wppe_bridge_field_mapping', array() );
		if ( ! is_array( $current ) ) {
			$current = array();
		}
		if ( ! isset( $current[ $plugin ] ) || ! is_array( $current[ $plugin ] ) ) {
			$current[ $plugin ] = array();
		}
		$current[ $plugin ][ $form ] = $entry;

		update_option( 'wppe_bridge_field_mapping', $current );

		wp_safe_redirect( self::redirect_url( $plugin, $form, 'saved' ) );
		exit;
	}

	/**
	 * Handler del POST que guarda el mapeo global
	 * `utm_source -> input_channel_id` (v2.5.1). Sustituye el contenido
	 * completo de la option `wppe_bridge_utm_to_input_channel_map` con
	 * lo enviado en el form — la edicion siempre es "lista completa",
	 * no incremental.
	 *
	 * Persistencia delegada a `WPPE_Bridge_Utm_Channel_Mapper::save()`,
	 * que sanitiza, deduplica y persiste.
	 *
	 * @return void
	 */
	public static function handle_save_utm_channel_map(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_UTM_CHANNEL );

		$post     = wp_unslash( $_POST );
		$entries  = array();
		$raw_rows = isset( $post['utm_channel_map'] ) && is_array( $post['utm_channel_map'] ) ? $post['utm_channel_map'] : array();

		foreach ( $raw_rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$entries[] = array(
				'utm_source'       => isset( $row['utm_source'] ) ? (string) $row['utm_source'] : '',
				'input_channel_id' => isset( $row['input_channel_id'] ) ? $row['input_channel_id'] : 0,
			);
		}

		WPPE_Bridge_Utm_Channel_Mapper::save( $entries );

		$redirect = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=wppe-bridge-mapping&flash=utm_channel_saved' ) : 'admin.php';
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Defaults obligatorios al guardar el mapping. Desde v2.7.0
	 * `source_id` y `project_id` se exigen por politica de producto
	 * (WP.pe Bridge para clientes inmobiliarios: reporting de fuente
	 * y proyecto es parte del onboarding minimo, ver CLAUDE.md sec 1).
	 * Sperant no rechaza con 422 si faltan, pero Mono Media si.
	 *
	 * @var array<int,string>
	 */
	public const REQUIRED_DEFAULTS = array(
		'input_channel_id',
		'source_id',
		'interest_type_id',
		'project_id',
	);

	/**
	 * Valida que el entry tenga los campos obligatorios:
	 *
	 *   - `fname` mapeado: al menos un campo del form mapea a 'fname'.
	 *   - Cada key de REQUIRED_DEFAULTS con valor > 0.
	 *
	 * @param array{fields:array<string,string>,defaults:array<string,int>} $entry Entry construido.
	 * @return array<int,string> Lista de keys faltantes (vacia = OK).
	 */
	public static function validate_required_fields( array $entry ): array {
		$missing = array();

		// 1. fname mapeado (al menos uno).
		$fields    = isset( $entry['fields'] ) && is_array( $entry['fields'] ) ? $entry['fields'] : array();
		$has_fname = false;
		foreach ( $fields as $payload_key ) {
			if ( 'fname' === $payload_key ) {
				$has_fname = true;
				break;
			}
		}
		if ( ! $has_fname ) {
			$missing[] = 'fname';
		}

		// 2. Defaults obligatorios.
		$defaults = isset( $entry['defaults'] ) && is_array( $entry['defaults'] ) ? $entry['defaults'] : array();
		foreach ( self::REQUIRED_DEFAULTS as $required_default ) {
			$value = isset( $defaults[ $required_default ] ) ? (int) $defaults[ $required_default ] : 0;
			if ( $value <= 0 ) {
				$missing[] = $required_default;
			}
		}

		return $missing;
	}

	/**
	 * Construye la entrada `{fields, defaults}` a partir del POST.
	 *
	 * Espera:
	 *   $post['field_map'][<form_field_name>] = '<payload_key>' | 'custom:<key>' | ''
	 *   $post['custom_payload_key'][<form_field_name>] = string  (cuando custom)
	 *   $post['defaults'][<input_channel_id>] = '123' | ''
	 *
	 * @param array $post POST sanitizado.
	 * @return array{fields:array<string,string>,defaults:array<string,int>}
	 */
	public static function build_entry_from_post( array $post ): array {
		$fields   = array();
		$defaults = array();

		$field_map  = isset( $post['field_map'] ) && is_array( $post['field_map'] ) ? $post['field_map'] : array();
		$custom_map = isset( $post['custom_payload_key'] ) && is_array( $post['custom_payload_key'] ) ? $post['custom_payload_key'] : array();

		foreach ( $field_map as $form_field => $payload_key ) {
			$form_field  = sanitize_text_field( (string) $form_field );
			$payload_key = is_string( $payload_key ) ? trim( $payload_key ) : '';
			if ( '' === $form_field || '' === $payload_key ) {
				continue;
			}
			if ( 'custom' === $payload_key ) {
				$custom_value = isset( $custom_map[ $form_field ] ) ? sanitize_key( $custom_map[ $form_field ] ) : '';
				if ( '' === $custom_value ) {
					continue;
				}
				$fields[ $form_field ] = $custom_value;
				continue;
			}
			// Validar contra lista permitida.
			if ( ! in_array( $payload_key, self::PAYLOAD_KEYS, true ) ) {
				continue;
			}
			$fields[ $form_field ] = $payload_key;
		}

		$defaults_post = isset( $post['defaults'] ) && is_array( $post['defaults'] ) ? $post['defaults'] : array();
		$manual_post   = isset( $post['defaults_manual'] ) && is_array( $post['defaults_manual'] ) ? $post['defaults_manual'] : array();
		foreach ( self::DEFAULT_KEYS as $default_key => $catalog_key ) {
			unset( $catalog_key );
			// Prioridad: input manual > dropdown. Util cuando un catalogo
			// no esta disponible en la API publica (caso conocido:
			// /v3/sources retorna 404 en algunas instancias) y el admin
			// quiere ingresar el ID conocido del panel web Sperant.
			$manual_value = isset( $manual_post[ $default_key ] ) ? (int) $manual_post[ $default_key ] : 0;
			if ( $manual_value > 0 ) {
				$defaults[ $default_key ] = $manual_value;
				continue;
			}
			$value = isset( $defaults_post[ $default_key ] ) ? (int) $defaults_post[ $default_key ] : 0;
			if ( $value > 0 ) {
				$defaults[ $default_key ] = $value;
			}
		}

		return array(
			'fields'   => $fields,
			'defaults' => $defaults,
		);
	}

	/**
	 * Construye URL de redirect para mostrar flash messages.
	 *
	 * @param string            $plugin  Plugin slug.
	 * @param string            $form    Form ID.
	 * @param string            $flash   Codigo de mensaje ('saved' | 'error_*').
	 * @param array<int,string> $missing Lista de campos faltantes (solo para flash error_required).
	 * @return string
	 */
	private static function redirect_url( string $plugin, string $form, string $flash, array $missing = array() ): string {
		$args = array(
			'page'   => WPPE_Bridge_Admin_Menu::SLUG . '-mapping',
			'plugin' => $plugin,
			'form'   => $form,
			'flash'  => $flash,
		);
		if ( ! empty( $missing ) ) {
			// CSV de keys faltantes para que la vista renderice el detalle.
			$args['missing'] = implode( ',', array_map( 'sanitize_key', $missing ) );
		}
		return add_query_arg(
			$args,
			admin_url( 'admin.php' )
		);
	}
}
