<?php
/**
 * Pagina admin de configuracion general.
 *
 * Usa WP Settings API para token, URL base, TTL dedup y country code.
 * El token se persiste en wp_options['wppe_bridge_api_token'] (D9 del
 * CLAUDE.md). El campo password en UI nunca muestra el valor existente
 * (solo "configurado / no configurado") para evitar shoulder-surfing.
 *
 * El boton "Sincronizar catalogos" dispara via AJAX a
 * WPPE_Bridge_Admin_Ajax::sync_catalogs.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pagina admin de configuracion (token, URL base, TTL dedup, sync catalogos).
 */
final class WPPE_Bridge_Settings_Page {

	/**
	 * Slug del settings group de WP Settings API (config general).
	 */
	public const OPTION_GROUP = 'wppe_bridge_settings';

	/**
	 * Slug del settings group para la "zona de peligro" (uninstall
	 * data toggle). Aislado en su propio group para que tenga su
	 * propio form con submit separado, asi un guardado del form
	 * principal no toca este toggle (que de otro modo se desactivaria
	 * cada vez por como funcionan los HTML checkboxes en POST).
	 */
	public const OPTION_GROUP_DANGER = 'wppe_bridge_danger_zone';

	/**
	 * Slug de la seccion principal.
	 */
	public const SECTION_GENERAL = 'wppe_bridge_section_general';

	/**
	 * Lista de option keys que registramos para WP Settings API.
	 *
	 * Cada entrada:
	 *   key            string  Option name en wp_options.
	 *   sanitize_cb    string  Funcion sanitizadora.
	 */
	public const OPTIONS = array(
		'wppe_bridge_api_token'                        => 'sanitize_token',
		'wppe_bridge_api_base_url'                     => 'sanitize_url',
		'wppe_bridge_dedup_ttl_seconds'                => 'sanitize_ttl',
		'wppe_bridge_default_country_code'             => 'sanitize_country_code',
		'wppe_bridge_panel_subdomain'                  => 'sanitize_panel_subdomain',
		'wppe_bridge_notification_email'               => 'sanitize_notification_email',
		WPPE_Bridge_Destination_Factory::OPTION_ACTIVE => 'sanitize_destination',
	);

	/**
	 * Options de la zona de peligro. Form separado, group separado.
	 */
	public const OPTIONS_DANGER = array(
		'wppe_bridge_delete_data_on_uninstall' => 'sanitize_delete_data',
	);

	/**
	 * Dominio del panel de Sperant (host completo donde corre el panel
	 * web del cliente, por convencion `<subdomain>.sperant.com`).
	 *
	 * Aislado como constante para que tests y otros consumers no
	 * dependan del literal hardcodeado.
	 */
	public const PANEL_DOMAIN = 'sperant.com';

	/**
	 * Entornos de la API Sperant. Map URL → label legible.
	 *
	 * Usado en la vista de Configuracion para renderizar el dropdown
	 * de "URL base API" (v1.2.2). Antes era un input libre, lo
	 * convertimos en select para que operadores no tecnicos no se
	 * confundan ni rompan la integracion con typos.
	 *
	 * Para devs / tests / mock servers: el cliente HTTP
	 * `WPPE_Sperant_Client` aplica el filter `wppe_bridge_api_base_url`
	 * sobre el valor leido del option, asi se puede override en
	 * runtime sin tocar la UI ni la whitelist.
	 *
	 * @return array<string,string>
	 */
	public static function api_environments(): array {
		return array(
			'https://api.sperant.com'     => __( 'Produccion (api.sperant.com)', 'wppe-bridge' ),
			'https://api.eterniasoft.com' => __( 'Pruebas / Eternia (api.eterniasoft.com)', 'wppe-bridge' ),
		);
	}

	/**
	 * Bootstrap: registra hooks de Settings API. Llamado desde
	 * Plugin::register_hooks via admin_init.
	 *
	 * @return void
	 */
	public static function register_settings(): void {
		foreach ( self::OPTIONS as $option_key => $sanitize_cb ) {
			register_setting(
				self::OPTION_GROUP,
				$option_key,
				array(
					'sanitize_callback' => array( self::class, $sanitize_cb ),
				)
			);
		}
		// Group separado para la zona de peligro (form propio).
		foreach ( self::OPTIONS_DANGER as $option_key => $sanitize_cb ) {
			register_setting(
				self::OPTION_GROUP_DANGER,
				$option_key,
				array(
					'sanitize_callback' => array( self::class, $sanitize_cb ),
				)
			);
		}
	}

	/**
	 * Renderiza la pagina de Settings.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Datos para la vista.
		$has_token              = '' !== (string) get_option( 'wppe_bridge_api_token', '' );
		$base_url               = (string) get_option( 'wppe_bridge_api_base_url', 'https://api.sperant.com' );
		$dedup_ttl              = (int) get_option( 'wppe_bridge_dedup_ttl_seconds', 60 );
		$country_code           = (string) get_option( 'wppe_bridge_default_country_code', '+51' );
		$catalogs               = get_option( 'wppe_bridge_catalogs', array() );
		$catalogs_present       = is_array( $catalogs ) && ! empty( $catalogs ) && ! empty( array_filter( $catalogs, 'is_array' ) );
		$active_destination     = WPPE_Bridge_Destination_Factory::active_slug();
		$available_destinations = WPPE_Bridge_Destination_Factory::available();
		$panel_subdomain        = (string) get_option( 'wppe_bridge_panel_subdomain', '' );
		$delete_data_uninstall  = (bool) get_option( 'wppe_bridge_delete_data_on_uninstall', false );
		$api_environments       = self::api_environments();

		// v2.5.3: cuando el destino activo NO es Sperant, la vista oculta
		// los campos Sperant-specific y muestra un aviso amigable con
		// link a la sub-pagina de configuracion del CRM elegido. Sin
		// esto, el admin ve "Token Sperant *" obligatorio aunque haya
		// elegido Odoo/GHL/HubSpot/Webhook — bug visual reportado.
		$active_destination_label      = self::resolve_destination_label( $active_destination, $available_destinations );
		$active_destination_config_url = self::resolve_destination_config_url( $active_destination );

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/settings.php';
	}

	/**
	 * Resuelve el label legible del CRM activo. Lee del Factory cuando
	 * existe el slug en el registry; fallback al slug crudo para slugs
	 * desconocidos (defensa, no deberia pasar).
	 *
	 * @param string $slug                   Slug del destino activo.
	 * @param array  $available_destinations Map slug => label legible.
	 * @return string
	 */
	public static function resolve_destination_label( string $slug, array $available_destinations ): string {
		if ( isset( $available_destinations[ $slug ] ) ) {
			return (string) $available_destinations[ $slug ];
		}
		return ucfirst( $slug );
	}

	/**
	 * Resuelve la URL de la sub-pagina de configuracion del CRM activo.
	 * Para Sperant retorna vacio (no tiene sub-pagina separada — su
	 * config vive en esta misma pantalla principal).
	 *
	 * @param string $slug Slug del destino activo (sperant/ghl/odoo/hubspot/webhook).
	 * @return string Empty string si Sperant o slug desconocido.
	 */
	public static function resolve_destination_config_url( string $slug ): string {
		// Map slug -> sub-page slug. Mismo patron que cada destino se
		// auto-registra en Admin_Menu condicional al active.
		$map = array(
			'ghl'     => 'wppe-bridge-ghl-config',
			'odoo'    => 'wppe-bridge-odoo-config',
			'hubspot' => 'wppe-bridge-hubspot-config',
			'webhook' => 'wppe-bridge-webhook-config',
		);
		if ( ! isset( $map[ $slug ] ) ) {
			return '';
		}
		return function_exists( 'admin_url' )
			? admin_url( 'admin.php?page=' . $map[ $slug ] )
			: '';
	}

	// ---------- sanitizers ----------

	/**
	 * Sanitiza token: trim. Si llega vacio, conserva el valor previo
	 * (no permitimos borrarlo accidentalmente desde la UI; para borrar
	 * hay que usar WP-CLI: `wp option delete wppe_bridge_api_token`).
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_token( $value ): string {
		$new = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $new ) {
			$previous = (string) get_option( 'wppe_bridge_api_token', '' );
			// Si es la PRIMER configuracion (sin token previo) y llega
			// vacio, registramos un settings_error para que WordPress
			// muestre un notice de "obligatorio". Sin esto el guardado
			// silenciosamente persistia string vacio.
			if ( '' === $previous && function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_api_token',
					'wppe_bridge_token_required',
					__( 'El token de Sperant es obligatorio. Sin token la integracion no funciona — los leads no se enviaran al CRM.', 'wppe-bridge' )
				);
			}
			return $previous;
		}
		return $new;
	}

	/**
	 * Sanitiza URL base API: solo acepta valores de la whitelist
	 * {@see api_environments()}. Cualquier otro valor cae al default
	 * (Produccion).
	 *
	 * Esta whitelist NO restringe a devs ni tests — para usar mock
	 * servers locales (`http://127.0.0.1:8787` etc.), aplicar el
	 * filter `wppe_bridge_api_base_url` desde un mu-plugin o desde
	 * tests. El cliente HTTP `WPPE_Sperant_Client` lo respeta.
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_url( $value ): string {
		$value = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $value ) {
			return 'https://api.sperant.com';
		}
		// Strip trailing slash para canonicalizar.
		$normalized = rtrim( $value, '/' );
		$whitelist  = array_keys( self::api_environments() );
		if ( in_array( $normalized, $whitelist, true ) ) {
			return $normalized;
		}
		// Fuera de whitelist → default produccion (defensivo).
		return 'https://api.sperant.com';
	}

	/**
	 * Sanitiza el toggle "Borrar todos los datos al desinstalar"
	 * (zona de peligro, v1.2.2). Boolean estricto.
	 *
	 * @param mixed $value Valor del input (checkbox).
	 * @return bool
	 */
	public static function sanitize_delete_data( $value ): bool {
		// Checkboxes vienen como '1' o ausentes (null).
		if ( '1' === $value || 1 === $value || true === $value || 'true' === $value || 'on' === $value ) {
			return true;
		}
		return false;
	}

	/**
	 * Sanitiza TTL dedup: entero >= 1, default 60.
	 *
	 * @param mixed $value Valor del input.
	 * @return int
	 */
	public static function sanitize_ttl( $value ): int {
		$n = (int) $value;
		if ( $n < 1 ) {
			return 60;
		}
		return $n;
	}

	/**
	 * Sanitiza el slug del destino activo: solo permite valores del
	 * whitelist del factory. Cualquier otro cae al default (sperant).
	 *
	 * @param mixed $value Valor crudo del POST.
	 * @return string
	 */
	public static function sanitize_destination( $value ): string {
		$slug     = is_string( $value ) ? trim( $value ) : '';
		$registry = WPPE_Bridge_Destination_Factory::registry();
		if ( '' !== $slug && isset( $registry[ $slug ] ) ) {
			return $slug;
		}
		return WPPE_Bridge_Destination_Factory::DEFAULT_SLUG;
	}

	/**
	 * Sanitiza el subdomain del panel Sperant.
	 *
	 * Acepta:
	 *  - Subdomain solo (ej. `andeninversiones`).
	 *  - Host completo `<sub>.sperant.com` (extrae el subdomain).
	 *  - URL completa `https://<sub>.sperant.com/...` (extrae el subdomain).
	 *
	 * El subdomain final solo puede contener `[a-z0-9-]`. Si invalido o
	 * vacio, devuelve string vacio (= no configurado).
	 *
	 * @param mixed $value Valor crudo del input.
	 * @return string
	 */
	public static function sanitize_panel_subdomain( $value ): string {
		$raw = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $raw ) {
			return '';
		}

		// Lower-case temprano para que regex y matching sean uniformes.
		$lower = strtolower( $raw );

		// Si pegan URL completa, extraer host.
		if ( false !== strpos( $lower, '://' ) ) {
			$parts = wp_parse_url( $lower );
			$lower = isset( $parts['host'] ) ? (string) $parts['host'] : '';
		}

		// Si quedo `<sub>.sperant.com`, extraer el subdomain.
		$suffix = '.' . self::PANEL_DOMAIN;
		if ( '' !== $lower && substr( $lower, -strlen( $suffix ) ) === $suffix ) {
			$lower = substr( $lower, 0, -strlen( $suffix ) );
		}

		// Solo `[a-z0-9-]`, no puede empezar/terminar con guion.
		if ( '' === $lower ) {
			return '';
		}
		if ( ! preg_match( '/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/', $lower ) ) {
			return '';
		}
		return $lower;
	}

	/**
	 * Construye la URL absoluta de un endpoint del panel Sperant.
	 *
	 * Usado por la vista de Configuracion para hacer los `<a href>` de
	 * "Importar catalogos manualmente". Si no hay subdomain configurado,
	 * devuelve string vacio (la vista renderiza placeholder en su lugar).
	 *
	 * @param string $endpoint Path absoluto en el panel (ej. `/sources.json`).
	 * @return string URL absoluta o string vacio si no hay subdomain.
	 */
	public static function panel_url( string $endpoint ): string {
		$sub = (string) get_option( 'wppe_bridge_panel_subdomain', '' );
		if ( '' === $sub ) {
			return '';
		}
		$path = '/' . ltrim( $endpoint, '/' );
		return 'https://' . $sub . '.' . self::PANEL_DOMAIN . $path;
	}

	/**
	 * Sanitiza el email de notificacion (v2.4.0). Si llega vacio o
	 * invalido, persiste string vacio (que el Notifier interpreta como
	 * "usar admin_email default"). No bloquea con error_settings — es
	 * un override opcional, no un campo obligatorio.
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_notification_email( $value ): string {
		$raw = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $raw ) {
			return '';
		}
		// is_email() de WP retorna el email si es valido, false si no.
		$valid = is_email( $raw );
		if ( false === $valid ) {
			if ( function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_notification_email',
					'wppe_bridge_notification_email_invalid',
					__( 'Email de notificacion invalido. Se vuelve a usar admin_email.', 'wppe-bridge' ),
					'warning'
				);
			}
			return '';
		}
		return (string) $valid;
	}

	/**
	 * Sanitiza country code: debe empezar con `+` y tener al menos 2
	 * caracteres. Si invalido, retorna +51.
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_country_code( $value ): string {
		$s = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $s || '+' !== $s[0] || strlen( $s ) < 2 ) {
			return '+51';
		}
		// Solo `+` seguido de digitos (1-3 digitos en ISO E.164).
		if ( ! preg_match( '/^\+\d{1,3}$/', $s ) ) {
			return '+51';
		}
		return $s;
	}
}
