<?php
/**
 * Handlers AJAX del panel admin.
 *
 * Cada handler:
 * - Verifica capability (manage_options).
 * - Verifica nonce (check_ajax_referer).
 * - Devuelve JSON via wp_send_json_success / wp_send_json_error.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Handlers AJAX del panel admin.
 */
final class WPPE_Bridge_Admin_Ajax {

	/**
	 * Action AJAX para sincronizar catalogos.
	 */
	public const ACTION_SYNC_CATALOGS = 'wppe_bridge_sync_catalogs';

	/**
	 * Action AJAX para importar un catalogo manualmente (paste de JSON).
	 */
	public const ACTION_IMPORT_CATALOG = 'wppe_bridge_import_catalog';

	/**
	 * Nonce action.
	 */
	public const NONCE_ACTION = 'wppe_bridge_admin_nonce';

	/**
	 * Catalogos validos para import manual.
	 */
	public const VALID_CATALOG_KEYS = array(
		'input_channels',
		'sources',
		'interest_types',
		'projects',
	);

	/**
	 * Registra los handlers en el hook wp_ajax_*.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'wp_ajax_' . self::ACTION_SYNC_CATALOGS, array( self::class, 'sync_catalogs' ) );
		add_action( 'wp_ajax_' . self::ACTION_IMPORT_CATALOG, array( self::class, 'import_catalog' ) );
	}

	/**
	 * Handler: sincronizar catalogos contra Sperant. Persiste en
	 * wp_options['wppe_bridge_catalogs'].
	 *
	 * @return void
	 */
	public static function sync_catalogs(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'No tienes permisos.', 'wppe-bridge' ) ),
				403
			);
		}

		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		$token = (string) get_option( 'wppe_bridge_api_token', '' );
		if ( '' === $token ) {
			wp_send_json_error(
				array( 'message' => __( 'No hay token configurado. Guardalo en Settings primero.', 'wppe-bridge' ) ),
				400
			);
		}

		$existing = get_option( 'wppe_bridge_catalogs', array() );
		$existing = is_array( $existing ) ? $existing : array();
		$result   = WPPE_Sperant_Client::sync_catalogs();

		// Si un catalogo viene vacio del API (ej. sources HTTP 404)
		// PERO ya hay data manual para ese catalogo, preservar la
		// data manual. Solo sobrescribimos con datos reales del API.
		$existing_sources = isset( $existing['_sources'] ) && is_array( $existing['_sources'] ) ? $existing['_sources'] : array();
		foreach ( self::VALID_CATALOG_KEYS as $catalog_key ) {
			$api_failed = isset( $result['_errors'][ $catalog_key ] );
			$has_manual = 'manual' === ( $existing_sources[ $catalog_key ] ?? '' );
			if ( $api_failed && $has_manual && isset( $existing[ $catalog_key ] ) ) {
				$result[ $catalog_key ] = $existing[ $catalog_key ];
				// Mantener la marca manual.
				if ( ! isset( $result['_sources'] ) ) {
					$result['_sources'] = array();
				}
				$result['_sources'][ $catalog_key ] = 'manual';
				// Mantener el error registrado pero adicionar nota.
				$result['_errors'][ $catalog_key ] .= ' (preservando import manual)';
			}
		}

		update_option( 'wppe_bridge_catalogs', $result );

		// Conteo por catalogo.
		$counts = array();
		foreach ( array( 'input_channels', 'sources', 'interest_types', 'projects' ) as $k ) {
			$counts[ $k ] = isset( $result[ $k ] ) && is_array( $result[ $k ] ) ? count( $result[ $k ] ) : 0;
		}

		$has_errors = isset( $result['_errors'] ) && ! empty( $result['_errors'] );

		wp_send_json_success(
			array(
				'counts'     => $counts,
				'errors'     => $has_errors ? $result['_errors'] : new \stdClass(),
				'has_errors' => $has_errors,
			)
		);
	}

	/**
	 * Handler: importar un catalogo manualmente desde el JSON pegado
	 * por el admin (workaround para endpoints no expuestos en API
	 * publica v3, caso conocido: /v3/sources retorna 404).
	 *
	 * El admin abre el panel web del cliente Sperant en otro tab,
	 * visita la URL `<sub>.sperant.com/<catalog>.json`, copia el JSON
	 * y lo pega en el textarea correspondiente. Este handler valida
	 * el JSON, lo aplana usando flatten_jsonapi_collection (acepta
	 * shape plano y JSON:API) y persiste en wp_options.
	 *
	 * Espera POST:
	 * - nonce
	 * - catalog: 'input_channels' | 'sources' | 'interest_types' | 'projects'
	 * - json: string con el JSON pegado
	 *
	 * @return void
	 */
	public static function import_catalog(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'No tienes permisos.', 'wppe-bridge' ) ),
				403
			);
		}

		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		$post    = wp_unslash( $_POST );
		$catalog = isset( $post['catalog'] ) ? sanitize_key( $post['catalog'] ) : '';
		$json    = isset( $post['json'] ) && is_string( $post['json'] ) ? trim( $post['json'] ) : '';

		if ( ! in_array( $catalog, self::VALID_CATALOG_KEYS, true ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Catalogo invalido.', 'wppe-bridge' ) ),
				400
			);
		}

		if ( '' === $json ) {
			wp_send_json_error(
				array( 'message' => __( 'JSON vacio. Pega el contenido completo del endpoint del panel Sperant.', 'wppe-bridge' ) ),
				400
			);
		}

		$decoded = json_decode( $json, true );
		if ( null === $decoded && JSON_ERROR_NONE !== json_last_error() ) {
			wp_send_json_error(
				array(
					'message' => sprintf(
						/* translators: %s = error de parseo JSON */
						__( 'JSON invalido: %s', 'wppe-bridge' ),
						json_last_error_msg()
					),
				),
				400
			);
		}

		// Aplanar al shape uniforme [{id, name, ...}] usando el helper
		// del SperantClient (acepta shape plano y JSON:API).
		$flattened = WPPE_Sperant_Client::flatten_jsonapi_collection( $decoded );

		if ( empty( $flattened ) ) {
			wp_send_json_error(
				array( 'message' => __( 'El JSON no contiene items con `id`. Verifica que estes pegando el contenido correcto.', 'wppe-bridge' ) ),
				400
			);
		}

		// Persistir manteniendo el resto de los catalogos intactos.
		$current_catalogs = get_option( 'wppe_bridge_catalogs', array() );
		if ( ! is_array( $current_catalogs ) ) {
			$current_catalogs = array();
		}
		$current_catalogs[ $catalog ] = $flattened;

		// Si habia un error en _errors para este catalogo, limpiarlo
		// porque ahora tenemos data manual valida.
		if ( isset( $current_catalogs['_errors'] ) && is_array( $current_catalogs['_errors'] ) ) {
			unset( $current_catalogs['_errors'][ $catalog ] );
			if ( empty( $current_catalogs['_errors'] ) ) {
				unset( $current_catalogs['_errors'] );
			}
		}

		// Marcar este catalogo como "manual" para diferenciar del sync API.
		if ( ! isset( $current_catalogs['_sources'] ) || ! is_array( $current_catalogs['_sources'] ) ) {
			$current_catalogs['_sources'] = array();
		}
		$current_catalogs['_sources'][ $catalog ] = 'manual';

		update_option( 'wppe_bridge_catalogs', $current_catalogs );

		wp_send_json_success(
			array(
				'catalog' => $catalog,
				'count'   => count( $flattened ),
				'message' => sprintf(
					/* translators: 1: count, 2: catalog key */
					_n( '%1$d item importado en "%2$s".', '%1$d items importados en "%2$s".', count( $flattened ), 'wppe-bridge' ),
					count( $flattened ),
					$catalog
				),
			)
		);
	}
}
