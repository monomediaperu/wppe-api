/**
 * Scripts del panel admin del plugin.
 *
 * @package WPPE_Bridge
 */
( function () {
	'use strict';

	function ready( fn ) {
		if ( document.readyState !== 'loading' ) {
			fn();
		} else {
			document.addEventListener( 'DOMContentLoaded', fn );
		}
	}

	ready( function () {
		var btn    = document.getElementById( 'wppe-bridge-sync-catalogs' );
		var status = document.getElementById( 'wppe-bridge-sync-status' );

		if ( ! btn || ! status || typeof window.wppeSperantAdmin === 'undefined' ) {
			return;
		}

		btn.addEventListener( 'click', function () {
			btn.disabled = true;
			status.textContent = window.wppeSperantAdmin.i18n.syncing;
			status.style.color = '#666';

			var data = new FormData();
			data.append( 'action', window.wppeSperantAdmin.actions.syncCatalogs );
			data.append( 'nonce', window.wppeSperantAdmin.nonce );

			fetch( window.wppeSperantAdmin.ajaxUrl, {
				method:      'POST',
				credentials: 'same-origin',
				body:        data,
			} )
			.then( function ( res ) {
				return res.json();
			} )
			.then( function ( payload ) {
				btn.disabled = false;
				if ( ! payload || ! payload.success ) {
					status.textContent = ( payload && payload.data && payload.data.message ) || window.wppeSperantAdmin.i18n.error;
					status.style.color = '#dc3232';
					return;
				}

				var counts = payload.data.counts || {};
				var summary = window.wppeSperantAdmin.i18n.synced
					.replace( '%input_channels%', counts.input_channels || 0 )
					.replace( '%sources%', counts.sources || 0 )
					.replace( '%interest_types%', counts.interest_types || 0 )
					.replace( '%projects%', counts.projects || 0 );

				// Si hubo errores, agregarlos al texto del status para
				// que el admin sepa exactamente cual catalogo fallo.
				if ( payload.data.has_errors && payload.data.errors ) {
					var errParts = [];
					for ( var k in payload.data.errors ) {
						if ( Object.prototype.hasOwnProperty.call( payload.data.errors, k ) ) {
							errParts.push( k + ': ' + payload.data.errors[k] );
						}
					}
					if ( errParts.length ) {
						summary += ' — ' + errParts.join( ', ' );
					}
				}

				status.textContent = summary;
				status.style.color = payload.data.has_errors ? '#dba617' : '#46b450';

				// Recargar despues de 1.5s para reflejar la tabla con counts.
				setTimeout( function () {
					window.location.reload();
				}, 1500 );
			} )
			.catch( function () {
				btn.disabled = false;
				status.textContent = window.wppeSperantAdmin.i18n.error;
				status.style.color = '#dc3232';
			} );
		} );

		// ---------- Import manual de catalogos (v1.0.4) ----------
		// Cada boton .wppe-bridge-import-btn dispara un POST AJAX
		// con el JSON pegado en el textarea adyacente.
		var importBtns = document.querySelectorAll( '.wppe-bridge-import-btn' );
		for ( var i = 0; i < importBtns.length; i++ ) {
			importBtns[i].addEventListener( 'click', handleImportClick );
		}

		function handleImportClick( evt ) {
			var btn       = evt.currentTarget;
			var catalog   = btn.getAttribute( 'data-catalog' );
			var card      = btn.closest( '.wppe-bridge-import-card' );
			var textarea  = card ? card.querySelector( 'textarea' ) : null;
			var statusEl  = card ? card.querySelector( '.wppe-bridge-import-status' ) : null;

			if ( ! textarea || ! statusEl ) {
				return;
			}

			var json = textarea.value.trim();
			if ( '' === json ) {
				statusEl.textContent = window.wppeSperantAdmin.i18n.importEmpty || 'Pega el JSON antes.';
				statusEl.style.color = '#dba617';
				return;
			}

			// Validacion local rapida del JSON antes de mandar.
			try {
				JSON.parse( json );
			} catch ( e ) {
				statusEl.textContent = ( window.wppeSperantAdmin.i18n.importInvalidJson || 'JSON invalido' ) + ': ' + e.message;
				statusEl.style.color = '#dc3232';
				return;
			}

			btn.disabled        = true;
			statusEl.textContent = window.wppeSperantAdmin.i18n.importLoading || 'Importando...';
			statusEl.style.color = '#666';

			var data = new FormData();
			data.append( 'action', window.wppeSperantAdmin.actions.importCatalog );
			data.append( 'nonce', window.wppeSperantAdmin.nonce );
			data.append( 'catalog', catalog );
			data.append( 'json', json );

			fetch( window.wppeSperantAdmin.ajaxUrl, {
				method:      'POST',
				credentials: 'same-origin',
				body:        data,
			} )
			.then( function ( res ) { return res.json(); } )
			.then( function ( payload ) {
				btn.disabled = false;
				if ( ! payload || ! payload.success ) {
					var msg = ( payload && payload.data && payload.data.message ) || window.wppeSperantAdmin.i18n.error;
					statusEl.textContent = msg;
					statusEl.style.color = '#dc3232';
					return;
				}
				statusEl.textContent = payload.data.message || ( '✓ ' + payload.data.count );
				statusEl.style.color = '#46b450';
				// Limpieza visual instantanea (v1.2.2). Antes el textarea
				// quedaba con la data pegada hasta que la pagina recargaba
				// 1.2s despues — daba sensacion de "no se importo".
				textarea.value = '';
				// Recarga para reflejar la tabla con el nuevo origen "Manual".
				setTimeout( function () {
					window.location.reload();
				}, 1200 );
			} )
			.catch( function () {
				btn.disabled = false;
				statusEl.textContent = window.wppeSperantAdmin.i18n.error;
				statusEl.style.color = '#dc3232';
			} );
		}

		// ---------- Panel subdomain: live preview de las URLs de import (v1.1.2) ----------
		// Refleja en vivo el subdomain configurado en cada card de
		// "Importar catalogos manualmente". Aplica el mismo sanitizer
		// que `Settings_Page::sanitize_panel_subdomain` para que el
		// preview sea consistente con lo que se guardara.
		var subdomainInput = document.getElementById( 'wppe_bridge_panel_subdomain' );
		if ( subdomainInput ) {
			var panelDomain  = subdomainInput.getAttribute( 'data-panel-domain' ) || 'sperant.com';
			var feedback     = document.getElementById( 'wppe-bridge-subdomain-feedback' );
			var urlWraps     = document.querySelectorAll( '.wppe-bridge-panel-url-wrap' );

			function sanitizeSubdomain( raw ) {
				if ( typeof raw !== 'string' ) {
					return '';
				}
				var s = raw.trim().toLowerCase();
				if ( ! s ) {
					return '';
				}
				// URL completa: extraer host.
				if ( s.indexOf( '://' ) !== -1 ) {
					try {
						s = new URL( s ).hostname;
					} catch ( e ) {
						return '';
					}
				}
				// <sub>.sperant.com -> extraer sub.
				var suffix = '.' + panelDomain;
				if ( s.length > suffix.length && s.slice( -suffix.length ) === suffix ) {
					s = s.slice( 0, -suffix.length );
				}
				if ( ! s ) {
					return '';
				}
				// Solo a-z0-9-, no leading/trailing hyphen.
				if ( ! /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test( s ) ) {
					return '';
				}
				return s;
			}

			function updatePreview() {
				var raw      = subdomainInput.value;
				var sub      = sanitizeSubdomain( raw );
				var hasInput = !! raw.trim();

				// Feedback visual junto al input.
				if ( feedback ) {
					if ( sub ) {
						feedback.style.color = '#46b450';
						feedback.textContent = '✓ ' + sub + '.' + panelDomain;
					} else if ( hasInput ) {
						feedback.style.color = '#dc3232';
						feedback.textContent = '✗ Invalido (usa solo letras minusculas, numeros y guiones)';
					} else {
						feedback.textContent = '';
					}
				}

				// Actualizar cada card de import.
				urlWraps.forEach( function ( wrap ) {
					var endpoint    = wrap.getAttribute( 'data-endpoint' ) || '';
					var link        = wrap.querySelector( '.wppe-bridge-panel-link' );
					var code        = wrap.querySelector( '.wppe-bridge-panel-link-code' );
					var placeholder = wrap.querySelector( '.wppe-bridge-panel-placeholder' );

					if ( sub && link && code && placeholder ) {
						var fullUrl = 'https://' + sub + '.' + panelDomain + '/' + endpoint;
						link.setAttribute( 'href', fullUrl );
						code.textContent = fullUrl;
						link.style.display = '';
						placeholder.style.display = 'none';
					} else if ( link && placeholder ) {
						link.style.display = 'none';
						placeholder.style.display = '';
					}
				} );
			}

			subdomainInput.addEventListener( 'input', updatePreview );
			// Run once en DOMContentLoaded para reflejar el estado salvado
			// y manejar el caso de subdomain ya configurado (server-rendered).
			updatePreview();

			// ---------- Click en tip "subdomain" → scroll + focus + highlight (v1.2.2) ----------
			// Cuando el operador clickea el link "subdomain del panel
			// Sperant" en el tip amarillo arriba de las cards de import,
			// scrolleamos suavemente al campo, lo enfocamos, y le damos
			// un highlight de 2s para que sea obvio donde tipear.
			var tipLinks = document.querySelectorAll( 'a[href="#wppe_bridge_panel_subdomain"]' );
			for ( var li = 0; li < tipLinks.length; li++ ) {
				tipLinks[li].addEventListener( 'click', function ( evt ) {
					evt.preventDefault();
					subdomainInput.scrollIntoView( { behavior: 'smooth', block: 'center' } );
					setTimeout( function () {
						subdomainInput.focus();
						var origBoxShadow = subdomainInput.style.boxShadow;
						subdomainInput.style.transition = 'box-shadow 0.3s ease-in-out';
						subdomainInput.style.boxShadow  = '0 0 0 3px #ffd966';
						setTimeout( function () {
							subdomainInput.style.boxShadow = origBoxShadow;
						}, 2000 );
					}, 400 );
				} );
			}
		}
	} );
}() );
