<?php
/**
 * Cola interna del bridge.
 *
 * Decision D3 del CLAUDE.md (patron outbox). El hook recibe la submission,
 * el adapter la traduce a payload normalizado, y aqui se inserta en la
 * tabla wp_wppebridge_queue con status `pending`. El usuario ya tiene
 * su thank you page; el envio a Sperant lo hace el worker async.
 *
 * Politica de reintentos (D5): 1m, 5m, 15m, 1h. Despues del 4to fallo
 * temporal -> failed_permanent.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Cola interna outbox: persiste submissions y las entrega al worker async.
 */
final class WPPE_Bridge_Queue {

	public const STATUS_PENDING          = 'pending';
	public const STATUS_SENT             = 'sent';
	public const STATUS_FAILED_TEMP      = 'failed_temp';
	public const STATUS_FAILED_PERMANENT = 'failed_permanent';
	public const STATUS_DEDUPED          = 'deduped';

	/**
	 * Backoff exponencial para reintentos. Indice 0 = primer reintento.
	 * Despues del ultimo elemento, se marca failed_permanent.
	 *
	 * @var int[]
	 */
	public const RETRY_BACKOFF_SECONDS = array( 60, 300, 900, 3600 );

	/**
	 * Nombre de la tabla (sin prefix de WP).
	 */
	private const TABLE = 'wppebridge_queue';

	/**
	 * Tamano default de batch al recuperar items.
	 */
	private const DEFAULT_BATCH_LIMIT = 25;

	/**
	 * Inserta un payload normalizado en la cola.
	 *
	 * Aplica dedup antes de insertar. Si dedup atrapa, retorna null.
	 *
	 * El payload puede traer claves "meta" prefijadas con `_` que se
	 * extraen al campo correspondiente de la tabla en lugar de quedar
	 * en el JSON: `_form_plugin`, `_form_id`, `_submission_id`.
	 *
	 * @param array $normalized_payload Payload ya normalizado (D6).
	 * @return int|null queue_id si insertado, null si fue descartado.
	 */
	public static function enqueue( array $normalized_payload ): ?int {
		global $wpdb;

		$hash = WPPE_Bridge_Dedup::hash( $normalized_payload );
		$ttl  = (int) get_option( 'wppe_bridge_dedup_ttl_seconds', 60 );

		if ( ! WPPE_Bridge_Dedup::try_reserve( $hash, $ttl ) ) {
			// Log persistente del dedup (v1.2.1). Antes solo se disparaba
			// el hook — si el operador buscaba un lead "perdido" en logs,
			// no veia que dedup lo habia atrapado.
			WPPE_Bridge_Logger::info(
				'lead_deduped',
				array(
					'hash'        => $hash,
					'ttl_seconds' => $ttl,
					'form_plugin' => (string) ( $normalized_payload['_form_plugin'] ?? 'unknown' ),
					'form_id'     => (string) ( $normalized_payload['_form_id'] ?? '' ),
				)
			);
			/**
			 * Fires when a submission is silently discarded because dedup
			 * caught it inside the TTL window. Useful para metricas y
			 * para integrar con el snippet Meta CAPI sin contar duplicados.
			 *
			 * @param array  $normalized_payload Payload ya normalizado.
			 * @param string $hash               Hash que disparo dedup.
			 */
			do_action( 'wppe_bridge_lead_deduped', $normalized_payload, $hash );
			return null;
		}

		$now           = current_time( 'mysql', true );
		$form_plugin   = (string) ( $normalized_payload['_form_plugin'] ?? 'unknown' );
		$form_id       = (string) ( $normalized_payload['_form_id'] ?? $normalized_payload['form_id'] ?? '' );
		$submission_id = $normalized_payload['_submission_id'] ?? null;

		// Filtrar las meta keys del payload que va al JSON.
		$payload_for_json = $normalized_payload;
		unset( $payload_for_json['_form_plugin'], $payload_for_json['_form_id'], $payload_for_json['_submission_id'] );

		$inserted = $wpdb->insert(
			$wpdb->prefix . self::TABLE,
			array(
				'hash'                   => $hash,
				'form_plugin'            => $form_plugin,
				'form_id'                => $form_id,
				'submission_id_external' => null === $submission_id ? null : (string) $submission_id,
				'payload'                => wp_json_encode( $payload_for_json ),
				'status'                 => self::STATUS_PENDING,
				'attempts'               => 0,
				'created_at'             => $now,
				'updated_at'             => $now,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
		);

		if ( false === $inserted || 0 === (int) $inserted ) {
			// Log explicito (v1.2.1). Antes silente; si la DB tenia
			// problemas (tabla missing, charset incompatible, write
			// lock), el lead se perdia sin rastro alguno.
			$db_error = property_exists( $wpdb, 'last_error' ) ? (string) $wpdb->last_error : '';
			WPPE_Bridge_Logger::error(
				'queue_insert_failed',
				array(
					'hash'        => $hash,
					'form_plugin' => $form_plugin,
					'form_id'     => $form_id,
					'db_error'    => '' === $db_error ? 'unknown' : $db_error,
				)
			);
			return null;
		}

		$queue_id = (int) $wpdb->insert_id;

		// Log persistente del enqueue (v1.2.1). Antes el primer log que
		// el operador veia era cuando el worker procesaba el item (puede
		// tardar hasta 1 minuto). Ahora hay rastro inmediato de
		// "lead llego a queue".
		WPPE_Bridge_Logger::info(
			'lead_queued',
			array(
				'hash'        => $hash,
				'form_plugin' => $form_plugin,
				'form_id'     => $form_id,
			),
			$queue_id
		);

		/**
		 * Fires right after a submission is enqueued (insert exitoso).
		 *
		 * Util para modulos opcionales que necesitan reaccionar al
		 * submit en tiempo real, sin esperar al worker async. Caso
		 * de uso principal: Thank You Pixel setea cookie con queue_id
		 * para sincronizar event_id con Meta CAPI server-side.
		 *
		 * @param int    $queue_id           ID asignado al item.
		 * @param array  $normalized_payload Payload normalizado.
		 * @param string $hash               Hash de dedup.
		 */
		do_action( 'wppe_bridge_lead_queued', $queue_id, $normalized_payload, $hash );

		return $queue_id;
	}

	/**
	 * Busca un item por id. Devuelve null si no existe.
	 *
	 * @param int $queue_id ID.
	 * @return object|null
	 */
	public static function find( int $queue_id ): ?object {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				"SELECT * FROM {$table} WHERE id = %d LIMIT 1",
				$queue_id
			)
		);
		return is_object( $row ) ? $row : null;
	}

	/**
	 * Cuenta items por status. Si status=null, cuenta total.
	 *
	 * @param string|null $status Uno de los STATUS_* o null.
	 * @return int
	 */
	public static function count_by_status( ?string $status = null ): int {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;

		if ( null === $status ) {
			$rows = $wpdb->get_var(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				"SELECT COUNT(*) FROM {$table}"
			);
		} else {
			$rows = $wpdb->get_var(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
					"SELECT COUNT(*) FROM {$table} WHERE status = %s",
					$status
				)
			);
		}
		return max( 0, (int) $rows );
	}

	/**
	 * Lista paginada de queue items con filtro opcional por status.
	 * Para el panel admin de Logs.
	 *
	 * Args soportados: `status` (string|null, filtro), `per_page` (int,
	 * default 25), `page` (int 1-based, default 1).
	 *
	 * @param array $args Argumentos descritos arriba.
	 * @return array<int,object>
	 */
	public static function paginate( array $args = array() ): array {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;

		$per_page = isset( $args['per_page'] ) ? max( 1, (int) $args['per_page'] ) : 25;
		$page     = isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1;
		$offset   = ( $page - 1 ) * $per_page;
		$status   = isset( $args['status'] ) && is_string( $args['status'] ) && '' !== $args['status'] ? $args['status'] : null;

		if ( null === $status ) {
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
					"SELECT * FROM {$table} ORDER BY id DESC LIMIT %d OFFSET %d",
					$per_page,
					$offset
				)
			);
		} else {
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
					"SELECT * FROM {$table} WHERE status = %s ORDER BY id DESC LIMIT %d OFFSET %d",
					$status,
					$per_page,
					$offset
				)
			);
		}
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Reconstruye el payload de un item legacy aplicando el flatten
	 * de campos nested (v1.2.6) y lo re-encola.
	 *
	 * Caso de uso: leads que se encolaron con el plugin pre-v1.2.5
	 * tienen `fname` como objeto `{first_name, last_name}` en su
	 * payload guardado, y van a fallar siempre con 422/500 al
	 * enviarlos a Sperant. Esta funcion aplana esos campos
	 * directamente en el row de queue y resetea el lead a `pending`
	 * para que el worker lo reintente.
	 *
	 * Lo unico que reescribe son los campos `fname`, `lname` (si
	 * son arrays nested). Los demas datos del payload se conservan
	 * sin tocar — lo importante es no perder UTMs, IDs externos, etc.
	 *
	 * Si el payload ya esta correcto (no nested), igual hace el
	 * reset a pending para forzar reintento.
	 *
	 * @param int $queue_id ID del item.
	 * @return array{ok:bool,modified:bool,reason:string}
	 */
	public static function rebuild_payload_and_retry( int $queue_id ): array {
		global $wpdb;

		$row = self::find( $queue_id );
		if ( null === $row ) {
			return array(
				'ok'       => false,
				'modified' => false,
				'reason'   => 'not_found',
			);
		}

		$payload = json_decode( (string) $row->payload, true );
		if ( ! is_array( $payload ) ) {
			return array(
				'ok'       => false,
				'modified' => false,
				'reason'   => 'invalid_payload',
			);
		}

		$modified = false;
		$keys     = array( 'fname', 'lname' );
		foreach ( $keys as $k ) {
			if ( isset( $payload[ $k ] ) && is_array( $payload[ $k ] ) ) {
				$flattened = class_exists( 'WPPE_Bridge_Form_Adapter_Base' )
					? WPPE_Bridge_Form_Adapter_Base::flatten_nested_value( $payload[ $k ], $k )
					: null;
				if ( null !== $flattened ) {
					$payload[ $k ] = $flattened;
					$modified      = true;
				}
			}
		}

		// Re-guardar payload + reset a pending.
		$now = current_time( 'mysql', true );
		$wpdb->update(
			$wpdb->prefix . self::TABLE,
			array(
				'payload'       => wp_json_encode( $payload ),
				'status'        => self::STATUS_PENDING,
				'next_retry_at' => $now,
				'updated_at'    => $now,
			),
			array( 'id' => $queue_id ),
			array( '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);

		return array(
			'ok'       => true,
			'modified' => $modified,
			'reason'   => $modified ? 'rebuilt_and_requeued' : 'requeued_unchanged',
		);
	}

	/**
	 * Resetea un item para reintento manual: status -> pending,
	 * next_retry_at -> NOW(), conserva attempts (para que el backoff
	 * siga progresando si vuelve a fallar).
	 *
	 * @param int $queue_id ID.
	 * @return bool True si actualizo, false si no existia.
	 */
	public static function queue_for_retry( int $queue_id ): bool {
		global $wpdb;
		$now    = current_time( 'mysql', true );
		$result = $wpdb->update(
			$wpdb->prefix . self::TABLE,
			array(
				'status'        => self::STATUS_PENDING,
				'next_retry_at' => $now,
				'updated_at'    => $now,
			),
			array( 'id' => $queue_id ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);
		return false !== $result && (int) $result > 0;
	}

	/**
	 * Recupera siguientes items pendientes/listos para reintento.
	 *
	 * Filtros:
	 * - status IN (pending, failed_temp).
	 * - next_retry_at IS NULL OR next_retry_at <= NOW().
	 *
	 * @param int $limit Cuantos a traer.
	 * @return array<int,object>
	 */
	public static function next_batch( int $limit = self::DEFAULT_BATCH_LIMIT ): array {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;
		$now   = current_time( 'mysql', true );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				"SELECT * FROM {$table}
				 WHERE status IN (%s, %s)
				   AND ( next_retry_at IS NULL OR next_retry_at <= %s )
				 ORDER BY id ASC
				 LIMIT %d",
				self::STATUS_PENDING,
				self::STATUS_FAILED_TEMP,
				$now,
				max( 1, $limit )
			)
		);
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Marca un item con un status final (sent | failed_permanent | deduped).
	 *
	 * @param int    $queue_id           ID en la tabla.
	 * @param string $status             Uno de los STATUS_* constantes.
	 * @param array  $sperant_response   Response cruda de la API.
	 * @return void
	 */
	public static function mark( int $queue_id, string $status, array $sperant_response = array() ): void {
		global $wpdb;
		$wpdb->update(
			$wpdb->prefix . self::TABLE,
			array(
				'status'           => $status,
				'sperant_response' => empty( $sperant_response ) ? null : wp_json_encode( $sperant_response ),
				'updated_at'       => current_time( 'mysql', true ),
			),
			array( 'id' => $queue_id ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Programa un reintento futuro con backoff exponencial.
	 * Si attempt_n excede el numero de pasos del backoff, marca
	 * failed_permanent.
	 *
	 * V1.2.6: ahora acepta `$sperant_response` opcional. Antes solo
	 * `Queue::mark()` (sent/failed_permanent) lo guardaba; los
	 * `failed_temp` perdian el body de respuesta y los operadores
	 * no podian ver por que Sperant rechazaba (5xx con HTML, 422
	 * con detail JSON, etc.) Ahora se guarda en cada intento.
	 *
	 * @param int        $queue_id         ID en la tabla.
	 * @param int        $attempt_n        Numero de intento que va (1, 2, 3, 4...).
	 * @param array|null $sperant_response Body decoded (legacy shape) o null.
	 * @return string Status final aplicado: failed_temp o failed_permanent.
	 */
	public static function schedule_retry( int $queue_id, int $attempt_n, ?array $sperant_response = null ): string {
		global $wpdb;
		$now_ts = (int) strtotime( current_time( 'mysql', true ) );

		$response_json = ( null !== $sperant_response && ! empty( $sperant_response ) )
			? wp_json_encode( $sperant_response )
			: null;

		// attempt_n 1 -> indice 0 del backoff.
		$index = $attempt_n - 1;

		if ( $index < 0 || $index >= count( self::RETRY_BACKOFF_SECONDS ) ) {
			$update = array(
				'status'          => self::STATUS_FAILED_PERMANENT,
				'attempts'        => $attempt_n,
				'last_attempt_at' => gmdate( 'Y-m-d H:i:s', $now_ts ),
				'updated_at'      => gmdate( 'Y-m-d H:i:s', $now_ts ),
			);
			$format = array( '%s', '%d', '%s', '%s' );
			if ( null !== $response_json ) {
				$update['sperant_response'] = $response_json;
				$format[]                   = '%s';
			}
			$wpdb->update(
				$wpdb->prefix . self::TABLE,
				$update,
				array( 'id' => $queue_id ),
				$format,
				array( '%d' )
			);
			return self::STATUS_FAILED_PERMANENT;
		}

		$backoff      = self::RETRY_BACKOFF_SECONDS[ $index ];
		$next_retry   = gmdate( 'Y-m-d H:i:s', $now_ts + $backoff );
		$last_attempt = gmdate( 'Y-m-d H:i:s', $now_ts );

		$update = array(
			'status'          => self::STATUS_FAILED_TEMP,
			'attempts'        => $attempt_n,
			'last_attempt_at' => $last_attempt,
			'next_retry_at'   => $next_retry,
			'updated_at'      => $last_attempt,
		);
		$format = array( '%s', '%d', '%s', '%s', '%s' );
		if ( null !== $response_json ) {
			$update['sperant_response'] = $response_json;
			$format[]                   = '%s';
		}

		$wpdb->update(
			$wpdb->prefix . self::TABLE,
			$update,
			array( 'id' => $queue_id ),
			$format,
			array( '%d' )
		);
		return self::STATUS_FAILED_TEMP;
	}
}
