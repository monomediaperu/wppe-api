/**
 * Widget de Contacto — comportamiento frontend (D-W4, D-W9).
 *
 * Modelo de contactos (v2.12): el visitante elige un contacto (o hay
 * uno solo y se salta ese paso), deja sus datos con consentimiento, el
 * lead se POSTea al Bridge y RECIEN entonces salta al canal — WhatsApp
 * con mensaje pre-llenado que incluye el codigo de referencia, o tel:
 * al numero del contacto. Sin dependencias; toda la config viene
 * embebida en data-attributes del HTML estatico.
 */
( function () {
	'use strict';

	function init() {
		var root = document.querySelector( '[data-wppe-cw]' );
		if ( ! root ) {
			return;
		}

		var toggle = root.querySelector( '.wppe-cw__toggle' );
		var panel = root.querySelector( '.wppe-cw__panel' );
		if ( ! toggle || ! panel ) {
			return;
		}

		var form = root.querySelector( '.wppe-cw__form' );
		var callOpts = root.querySelector( '[data-cw-call]' );
		var scheduleOpt = root.querySelector( '[data-cw-schedule-opt]' );
		var schedule = root.querySelector( '[data-cw-schedule]' );
		var status = root.querySelector( '.wppe-cw__status' );
		var greetingEl = root.querySelector( '[data-cw-greeting]' );

		var contacts = {};
		try {
			contacts = JSON.parse( root.getAttribute( 'data-contacts' ) || '{}' );
		} catch ( e ) {
			contacts = {};
		}
		var tz = root.getAttribute( 'data-tz' ) || '';
		var isSingle = '1' === root.getAttribute( 'data-single' );
		var currentId = '';

		// --- Horarios (D-W7): evaluados aqui con la timezone del sitio
		// sobre config estatica, para que el HTML cacheado nunca quede
		// desfasado.

		function nowInSiteTz() {
			var d = new Date();
			var m = tz.match( /^([+-])(\d{2}):(\d{2})$/ );
			if ( m ) {
				var off = ( '-' === m[ 1 ] ? -1 : 1 ) * ( parseInt( m[ 2 ], 10 ) * 60 + parseInt( m[ 3 ], 10 ) );
				d = new Date( d.getTime() + ( off + d.getTimezoneOffset() ) * 60000 );
			} else if ( tz ) {
				try {
					d = new Date( d.toLocaleString( 'en-US', { timeZone: tz } ) );
				} catch ( e ) {
					// Zona invalida: hora local del visitante como fallback.
				}
			}
			return { day: d.getDay(), minutes: d.getHours() * 60 + d.getMinutes() };
		}

		function toMinutes( hhmm ) {
			var parts = ( hhmm || '' ).split( ':' );
			return ( parseInt( parts[ 0 ], 10 ) || 0 ) * 60 + ( parseInt( parts[ 1 ], 10 ) || 0 );
		}

		function contactOpen( id ) {
			var cfg = contacts[ id ] && contacts[ id ].schedule;
			if ( ! cfg || ! cfg.enabled ) {
				return true;
			}
			var now = nowInSiteTz();
			if ( ( cfg.days || [] ).indexOf( now.day ) === -1 ) {
				return false;
			}
			return now.minutes >= toMinutes( cfg.start ) && now.minutes < toMinutes( cfg.end );
		}

		// Ocultar de entrada los contactos cerrados cuyo comportamiento
		// fuera de horario sea "hide".
		Object.keys( contacts ).forEach( function ( id ) {
			var cfg = contacts[ id ];
			if ( ! contactOpen( id ) && cfg.schedule && 'hide' === cfg.schedule.off ) {
				var btn = panel.querySelector( '[data-cw-contact="' + id + '"]' );
				if ( btn ) {
					btn.remove();
				}
				delete contacts[ id ];
			}
		} );

		function setOpen( open ) {
			panel.hidden = ! open;
			toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		}

		function setStatus( text ) {
			if ( status ) {
				status.textContent = text;
			}
		}

		function selectContact( id ) {
			if ( ! contacts[ id ] || ! form ) {
				return;
			}
			currentId = id;
			var cfg = contacts[ id ];
			var open = contactOpen( id );

			form.hidden = false;
			setStatus( '' );

			if ( greetingEl && cfg.greeting ) {
				greetingEl.textContent = cfg.greeting;
			}

			// Opciones de llamada solo para contactos de ese canal.
			if ( callOpts ) {
				callOpts.hidden = 'llamada' !== cfg.channel;
			}

			if ( 'llamada' === cfg.channel && callOpts ) {
				var inmediata = callOpts.querySelector( 'input[value="llamada_inmediata"]' );
				var programada = callOpts.querySelector( 'input[value="llamada_programada"]' );

				// "Programar" solo si el contacto lo permite.
				if ( scheduleOpt ) {
					scheduleOpt.hidden = ! cfg.schedulable;
				}

				// Fuera de horario: el caso "domingo sin call center" —
				// se cae "llamar ahora" y queda solo programar.
				if ( ! open && cfg.schedulable && programada ) {
					if ( inmediata && inmediata.closest( 'label' ) ) {
						inmediata.closest( 'label' ).hidden = true;
						inmediata.checked = false;
					}
					programada.checked = true;
					if ( schedule ) {
						schedule.hidden = false;
					}
				} else if ( inmediata && inmediata.closest( 'label' ) ) {
					inmediata.closest( 'label' ).hidden = false;
				}
			}

			if ( 'whatsapp' === cfg.channel && ! open ) {
				setStatus( 'Estamos fuera de horario: deja tus datos y te respondemos apenas estemos en línea.' );
			}

			var first = form.querySelector( 'input[name="name"]' );
			if ( first ) {
				first.focus();
			}
		}

		toggle.addEventListener( 'click', function () {
			var opening = panel.hidden;
			setOpen( opening );
			// Con un solo contacto no hay nada que elegir: al pre-chat.
			if ( opening && isSingle ) {
				var ids = Object.keys( contacts );
				if ( 1 === ids.length ) {
					selectContact( ids[ 0 ] );
				}
			}
		} );

		document.addEventListener( 'keydown', function ( event ) {
			if ( 'Escape' === event.key && ! panel.hidden ) {
				setOpen( false );
				toggle.focus();
			}
		} );

		document.addEventListener( 'click', function ( event ) {
			if ( ! panel.hidden && ! root.contains( event.target ) ) {
				setOpen( false );
			}
		} );

		panel.addEventListener( 'click', function ( event ) {
			var btn = event.target.closest( '[data-cw-contact]' );
			if ( btn ) {
				selectContact( btn.getAttribute( 'data-cw-contact' ) );
			}
		} );

		if ( form && schedule ) {
			form.addEventListener( 'change', function ( event ) {
				if ( 'call_pref' === event.target.name ) {
					schedule.hidden = 'llamada_programada' !== event.target.value;
				}
			} );
		}

		if ( ! form ) {
			return;
		}

		form.addEventListener( 'submit', function ( event ) {
			event.preventDefault();

			var cfg = contacts[ currentId ];
			if ( ! cfg ) {
				return;
			}

			var get = function ( name ) {
				var el = form.querySelector( '[name="' + name + '"]' );
				return el ? el.value.trim() : '';
			};

			var consent = form.querySelector( '[name="consent"]' );
			if ( ! get( 'name' ) || ! get( 'phone' ) || ! consent || ! consent.checked ) {
				setStatus( 'Completa tu nombre, tu teléfono y acepta la política para continuar.' );
				return;
			}

			var finalChannel = 'whatsapp';
			var fields = {
				name: get( 'name' ),
				phone: get( 'phone' ),
				email: get( 'email' ),
				interest: get( 'interest' )
			};

			// Pregunta calificadora (D-W10): solo viaja si el visitante
			// eligió una opción.
			var qualifier = get( 'qualifier' );
			if ( qualifier ) {
				fields.qualifier = qualifier;
			}

			if ( 'llamada' === cfg.channel ) {
				var pref = form.querySelector( '[name="call_pref"]:checked' );
				finalChannel = pref ? pref.value : 'llamada_inmediata';
				if ( 'llamada_programada' === finalChannel ) {
					fields.call_date = get( 'call_date' );
					fields.call_slot = get( 'call_slot' );
				}
			}

			// Señal de scoring: lead capturado fuera de horario.
			if ( ! contactOpen( currentId ) ) {
				fields.off_hours = '1';
			}

			var submitBtn = form.querySelector( '[type="submit"]' );
			if ( submitBtn ) {
				submitBtn.disabled = true; // Submit lock: previene doble envío.
			}
			setStatus( 'Enviando…' );

			fetch( root.getAttribute( 'data-endpoint' ), {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify( {
					widget_id: root.getAttribute( 'data-widget-id' ),
					contact_id: currentId,
					channel: finalChannel,
					consent: 1,
					website: get( 'website' ),
					fields: fields
				} )
			} )
				.then( function ( response ) {
					return response.json().then( function ( body ) {
						return { ok: response.ok, body: body };
					} );
				} )
				.then( function ( result ) {
					if ( ! result.ok ) {
						setStatus( 'No pudimos procesar tu solicitud. Inténtalo de nuevo en un momento.' );
						if ( submitBtn ) {
							submitBtn.disabled = false;
						}
						return;
					}

					if ( 'whatsapp' === finalChannel ) {
						var ref = result.body && result.body.ref ? ' (Ref: ' + result.body.ref + ')' : '';
						var text = 'Hola, soy ' + fields.name + ref + '. ' + ( fields.interest ? 'Me interesa: ' + fields.interest : 'Quiero más información.' );
						window.open(
							'https://wa.me/' + cfg.number + '?text=' + encodeURIComponent( text ),
							'_blank',
							'noopener'
						);
						setStatus( 'Te abrimos WhatsApp. ¡Gracias!' );
					} else if ( 'llamada_inmediata' === finalChannel ) {
						setStatus( 'Marcando…' );
						window.location.href = 'tel:+' + cfg.number;
					} else {
						setStatus( 'Listo: registramos tu solicitud y te llamaremos en la fecha elegida.' );
					}
					form.reset();
					if ( submitBtn ) {
						submitBtn.disabled = false;
					}
				} )
				.catch( function () {
					setStatus( 'Error de conexión. Inténtalo de nuevo.' );
					if ( submitBtn ) {
						submitBtn.disabled = false;
					}
				} );
		} );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
