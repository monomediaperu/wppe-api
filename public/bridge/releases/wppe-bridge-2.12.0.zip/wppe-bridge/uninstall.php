<?php
/**
 * Limpieza al desinstalar el plugin.
 *
 * **IMPORTANTE (v1.2.2): por default NO borra options ni tablas.**
 *
 * El comportamiento previo (v1.0.0 - v1.2.1) era hard-delete de todo,
 * pero eso causaba perdida de mapeos cuando el operador hacia
 * "Desactivar → Eliminar → Subir nuevo ZIP" para actualizar el plugin.
 *
 * Patron nuevo (estandar en plugins serios como WooCommerce, Yoast):
 *   - Default: preservar data (token, mapeos, catalogos, logs, queue).
 *   - Opt-in via option `wppe_bridge_delete_data_on_uninstall = true`,
 *     configurable desde la sub-pagina "Configuracion → Zona de peligro".
 *
 * Si el operador realmente quiere limpieza total (ej. para descontinuar
 * el plugin de forma permanente), activa el toggle en la UI antes de
 * eliminar.
 *
 * Crons agendados se limpian SIEMPRE (no son data — son artifacts del
 * plugin que sin el codigo no tienen consumer).
 *
 * @package WPPE_Bridge
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

/**
 * Ejecuta la limpieza condicional. Aislado en funcion para no
 * contaminar el scope global con variables sin prefijo.
 *
 * @return void
 */
function wppe_bridge_uninstall(): void {
	global $wpdb;

	// Cron hooks: SIEMPRE se limpian. Sin el codigo del plugin no
	// tienen handler, asi que dejarlos agendados solo genera errores
	// en logs de WP-Cron.
	wp_clear_scheduled_hook( 'wppe_bridge_worker_tick' );
	wp_clear_scheduled_hook( 'wppe_bridge_logs_cleanup_tick' );
	wp_clear_scheduled_hook( 'wppe_bridge_whitelist_refresh_tick' );

	// Hard delete: solo si el operador opto explicitamente desde la UI.
	// Default false → preserva todo entre desactivar/reinstalar.
	$delete_data = (bool) get_option( 'wppe_bridge_delete_data_on_uninstall', false );
	if ( ! $delete_data ) {
		return;
	}

	$wppe_bridge_tables = array(
		$wpdb->prefix . 'wppebridge_queue',
		$wpdb->prefix . 'wppebridge_dedup',
		$wpdb->prefix . 'wppebridge_logs',
	);

	foreach ( $wppe_bridge_tables as $wppe_bridge_table ) {
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange
		$wpdb->query( "DROP TABLE IF EXISTS `{$wppe_bridge_table}`" );
	}

	$wppe_bridge_options = array(
		'wppe_bridge_api_token',
		'wppe_bridge_api_base_url',
		'wppe_bridge_active_destination',
		'wppe_bridge_catalogs',
		'wppe_bridge_field_mapping',
		'wppe_bridge_db_version',
		'wppe_bridge_dedup_ttl_seconds',
		'wppe_bridge_logs_retention_days',
		'wppe_bridge_default_country_code',
		'wppe_bridge_panel_subdomain',
		'wppe_bridge_demo_leads_count',
		'wppe_bridge_whitelist_cache',
		'wppe_bridge_module_utm_capture_enabled',
		'wppe_bridge_module_submit_lock_enabled',
		'wppe_bridge_module_meta_capi_enabled',
		'wppe_bridge_meta_capi_pixel_id',
		'wppe_bridge_meta_capi_access_token',
		'wppe_bridge_meta_capi_test_event_code',
		'wppe_bridge_meta_event_name',
		'wppe_bridge_module_thank_you_pixel_enabled',
		'wppe_bridge_thank_you_pixel_pages',
		'wppe_bridge_module_contact_widget_enabled',
		'wppe_bridge_widget_appearance',
		'wppe_bridge_widget_whatsapp_number',
		'wppe_bridge_widget_greeting',
		'wppe_bridge_widget_page_rules',
		'wppe_bridge_widget_channels',
		'wppe_bridge_widget_custom_links',
		'wppe_bridge_widget_consent',
		'wppe_bridge_widget_mapping_defaults',
		'wppe_bridge_widget_scoring',
		'wppe_bridge_widget_contacts',
		'wppe_bridge_widget_contacts_migrated',
		'wppe_bridge_scoring_enabled',
		'wppe_bridge_scoring_weights',
		'wppe_bridge_scoring_bands',
		'wppe_bridge_scoring_question',
		'wppe_bridge_sales_contact',
		'wppe_bridge_cache_alerted',
		'wppe_bridge_delete_data_on_uninstall',
	);

	foreach ( $wppe_bridge_options as $wppe_bridge_option ) {
		delete_option( $wppe_bridge_option );
	}
}

wppe_bridge_uninstall();
