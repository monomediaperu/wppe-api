<?php
/**
 * Base abstracto para adapters de formularios.
 *
 * Centraliza la logica comun (mapping, build payload, captura UTMs,
 * normalizacion + enqueue, validacion minima). Las subclases concretas
 * solo proveen `plugin_slug()`, `is_available()`, `register()` (con su
 * hook nativo) y traducen los args del callback al shape comun antes de
 * delegar en `handle_submission()`.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Clase abstracta base para adapters de plugins de forms.
 */
abstract class WPPE_Bridge_Form_Adapter_Base implements WPPE_Bridge_Form_Adapter_Interface {

	/**
	 * Cookie que el modulo D4.4 UTM Capture deja en el visitante.
	 * Si existe, contiene un JSON con las claves `utm_source`,
	 * `utm_medium`, `utm_campaign`, `utm_term`, `utm_content`,
	 * `gclid`, `fbclid`, `landing_url`.
	 */
	public const UTMS_COOKIE_KEY = 'wppe_bridge_utms';

	/**
	 * Sub-keys conocidas de campos compound type "Name" de Fluent Forms.
	 * Orden importa para concatenacion sensata cuando el destino
	 * espera un solo string.
	 *
	 * @var string[]
	 */
	public const NAME_SUB_KEYS = array( 'first_name', 'middle_name', 'last_name' );

	/**
	 * Lee el mapping del form de wp_options.
	 *
	 * @param string $form_id ID del form (string para tolerar formatos
	 *                        distintos entre Fluent y Gravity).
	 * @return array|null `['fields' => [...], 'defaults' => [...]]` o
	 *                    null si no hay mapping configurado.
	 */
	protected static function get_mapping( string $form_id ): ?array {
		$all = get_option( 'wppe_bridge_field_mapping', array() );
		if ( ! is_array( $all ) ) {
			return null;
		}
		$slug = static::plugin_slug();
		if ( ! isset( $all[ $slug ][ $form_id ] ) || ! is_array( $all[ $slug ][ $form_id ] ) ) {
			return null;
		}
		$entry = $all[ $slug ][ $form_id ];
		return array(
			'fields'   => isset( $entry['fields'] ) && is_array( $entry['fields'] ) ? $entry['fields'] : array(),
			'defaults' => isset( $entry['defaults'] ) && is_array( $entry['defaults'] ) ? $entry['defaults'] : array(),
		);
	}

	/**
	 * Construye el payload en forma comun. Aplica mapping de field
	 * names a payload keys, agrega defaults, agrega UTMs y meta keys.
	 *
	 * @param array  $form_data     Field name => value (raw del plugin de forms).
	 * @param array  $mapping       Mapping resuelto por get_mapping().
	 * @param string $entry_id      ID externo de la submission.
	 * @param string $form_id       ID del form.
	 * @return array
	 */
	protected static function build_payload( array $form_data, array $mapping, string $entry_id, string $form_id ): array {
		$payload = array();

		// Traduccion field name -> payload key. Soporta dot-notation
		// (ej. `names.first_name`) y aplana valores nested cuando el
		// plugin de forms los entrega como array (caso input_name de
		// Fluent Forms — sin esto Sperant recibe `fname` como objeto y
		// rechaza con 422).
		foreach ( $mapping['fields'] as $form_field => $payload_key ) {
			$value = self::resolve_form_value( $form_data, $form_field, $payload_key );
			if ( null !== $value ) {
				$payload[ $payload_key ] = $value;
			}
		}

		// Defaults (input_channel_id, source_id, etc). NO sobreescriben
		// si el mapping ya los traduce de un campo del form.
		foreach ( $mapping['defaults'] as $key => $value ) {
			if ( ! array_key_exists( $key, $payload ) ) {
				$payload[ $key ] = $value;
			}
		}

		// UTMs.
		$payload = array_merge( $payload, self::capture_utms() );

		// UTM source -> input_channel_id routing (v2.5.1).
		//
		// Si el admin configuro un mapeo "utm_source -> Canal Sperant"
		// en la pagina de Mapeo, override el `input_channel_id` del
		// payload con el match correspondiente. Sin match -> conserva
		// el default que el mapping puso arriba (comportamiento legacy
		// preservado).
		//
		// Reportado por cliente: hasta v2.5.0 todos los leads caian al
		// mismo canal Sperant (tipicamente "Pagina Web") aunque
		// vinieran de Google Ads, Facebook Ads, etc. Esto rompia el
		// reporting de atribucion en el panel Sperant. Issue resuelta
		// con mapeo global utm_source -> input_channel_id.
		if ( class_exists( 'WPPE_Bridge_Utm_Channel_Mapper' ) ) {
			$utm_source       = isset( $payload['utm_source'] ) ? (string) $payload['utm_source'] : '';
			$resolved_channel = WPPE_Bridge_Utm_Channel_Mapper::resolve( $utm_source, $payload );
			if ( null !== $resolved_channel ) {
				$payload['input_channel_id'] = $resolved_channel;
			}
		}

		// Meta keys (consumidas por Queue::enqueue).
		$payload['_form_plugin']   = static::plugin_slug();
		$payload['_form_id']       = $form_id;
		$payload['_submission_id'] = $entry_id;

		// landing_url tambien va al hash de dedup. Si no vino de UTMs,
		// fallback al referer del request. Cap de longitud (hardening
		// v2.11.0): el Referer es un header controlado por el cliente
		// sin limite nativo — sin cap, decenas de KB de basura entran al
		// payload LONGTEXT de la queue.
		if ( empty( $payload['landing_url'] ) && isset( $_SERVER['HTTP_REFERER'] ) ) {
			$payload['landing_url'] = self::cap( sanitize_text_field( wp_unslash( $_SERVER['HTTP_REFERER'] ) ), 500 );
		}

		// Datos del request para integraciones server-side (Meta CAPI):
		// IP y user-agent del visitante. Se guardan al recibir la
		// submission, no en el Worker (donde la IP seria del cron).
		if ( isset( $_SERVER['REMOTE_ADDR'] ) ) {
			$payload['client_ip'] = self::cap( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ), 45 );
		}
		if ( isset( $_SERVER['HTTP_USER_AGENT'] ) ) {
			$payload['client_user_agent'] = self::cap( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 400 );
		}

		// Lead scoring global (v2.12.0, D-W10): aplica a TODAS las
		// fuentes, no solo al widget. El score viaja como payload key
		// mapeable (`lead_score`) y la banda legible se agrega a la
		// observacion para que el vendedor priorice de un vistazo.
		if ( class_exists( 'WPPE_Bridge_Lead_Scoring' ) && WPPE_Bridge_Lead_Scoring::is_enabled() ) {
			$score = WPPE_Bridge_Lead_Scoring::score( $payload, static::scoring_context( $form_data ) );
			$payload[ WPPE_Bridge_Lead_Scoring::PAYLOAD_KEY ] = $score;

			$annotation             = WPPE_Bridge_Lead_Scoring::annotation( $score );
			$observation            = isset( $payload['observation'] ) ? (string) $payload['observation'] : '';
			$payload['observation'] = '' === $observation
				? $annotation
				: $observation . ' | ' . $annotation;
		}

		return $payload;
	}

	/**
	 * Señales de scoring propias de la fuente. El base asume
	 * formulario web; las subclases con mas contexto (el Widget sabe
	 * el canal elegido y si fue fuera de horario) lo sobreescriben.
	 *
	 * @param array $form_data Datos crudos de la submission.
	 * @return array<string,mixed>
	 */
	protected static function scoring_context( array $form_data ): array {
		$context = array( 'channel' => 'formulario' );

		// La pregunta calificadora puede venir de cualquier form si el
		// cliente la agrego con el name esperado.
		if ( isset( $form_data['qualifier'] ) && is_string( $form_data['qualifier'] )
			&& in_array( $form_data['qualifier'], array( 'high', 'medium', 'low' ), true ) ) {
			$context['question'] = $form_data['qualifier'];
		}

		return $context;
	}

	/**
	 * Resuelve el valor de un field del form para un payload_key
	 * destino, aplanando estructuras nested cuando hace falta.
	 *
	 * Casos cubiertos:
	 *
	 *   1. **Scalar simple**: `form_data['email'] = 'x@y.com'`,
	 *      mapping `'email' => 'email'` → retorna `'x@y.com'`.
	 *   2. **Dot-notation**: `mapping = 'names.first_name' => 'fname'`
	 *      con `form_data['names'] = ['first_name' => 'Carlos', ...]`
	 *      → retorna `'Carlos'`.
	 *   3. **Top-level con value nested + destino fname/lname**:
	 *      `mapping = 'names' => 'fname'` con value array nested →
	 *      extrae el sub-field correspondiente (`first_name` para
	 *      `fname`, `last_name` para `lname`).
	 *   4. **Top-level con value nested + otro destino**: concatena
	 *      todos los valores no-vacios con espacio (estilo
	 *      `FormDataParser::formatName` de Fluent Forms).
	 *   5. **Field ausente**: retorna `null` (caller debe omitir el key
	 *      en lugar de pasar string vacio).
	 *
	 * @param array  $form_data   Field name => value (raw del plugin).
	 * @param string $form_field  Nombre del field (puede contener `.`).
	 * @param string $payload_key Key destino en el payload Sperant.
	 * @return mixed|null Valor resuelto o null si el field no existe.
	 */
	public static function resolve_form_value( array $form_data, string $form_field, string $payload_key ) {
		// Caso 2: dot-notation explicita.
		if ( false !== strpos( $form_field, '.' ) ) {
			return self::lookup_dot_notation( $form_data, $form_field );
		}

		// Caso 5: field ausente.
		if ( ! array_key_exists( $form_field, $form_data ) ) {
			return null;
		}

		$value = $form_data[ $form_field ];

		// Casos 3 y 4: value nested.
		if ( is_array( $value ) ) {
			return self::flatten_nested_value( $value, $payload_key );
		}

		// Caso 1: scalar simple.
		return $value;
	}

	/**
	 * Resuelve `'a.b.c'` contra un array nested. Devuelve `null` si
	 * algun nivel falta o no es array.
	 *
	 * @param array  $data Array nested.
	 * @param string $path Path con `.` separador.
	 * @return mixed|null
	 */
	public static function lookup_dot_notation( array $data, string $path ) {
		$parts   = explode( '.', $path );
		$current = $data;
		foreach ( $parts as $part ) {
			if ( ! is_array( $current ) || ! array_key_exists( $part, $current ) ) {
				return null;
			}
			$current = $current[ $part ];
		}
		return $current;
	}

	/**
	 * Aplana un array nested al string apropiado segun el destino.
	 *
	 * Heuristica:
	 *
	 *   - Destino `fname`: extrae `first_name` si esta presente, sino
	 *     el primer valor no-vacio del array.
	 *   - Destino `lname`: extrae `last_name` si esta presente, sino
	 *     el ultimo valor no-vacio.
	 *   - Cualquier otro destino: concatena todos los valores no-vacios
	 *     con espacio, en orden `first_name`, `middle_name`, `last_name`
	 *     (resto de keys despues, en orden de aparicion).
	 *
	 * Si el array no es asociativo (lista), concatena con espacio
	 * todos los strings.
	 *
	 * Si despues de aplanar resulta string vacio, retorna `null`
	 * (consistente con "field ausente" del caller).
	 *
	 * @param array  $value       Array nested.
	 * @param string $payload_key Key destino.
	 * @return string|null
	 */
	public static function flatten_nested_value( array $value, string $payload_key ) {
		if ( empty( $value ) ) {
			return null;
		}

		// Aplanar a strings, ignorando sub-arrays mas profundos por
		// ahora (no hemos visto un caso real que lo necesite).
		$strings = array();
		foreach ( $value as $k => $v ) {
			if ( is_string( $v ) || is_numeric( $v ) ) {
				$strings[ $k ] = trim( (string) $v );
			}
		}

		// Filtrar vacios sin perder keys.
		$non_empty = array_filter(
			$strings,
			static fn( $v ) => '' !== $v
		);

		if ( empty( $non_empty ) ) {
			return null;
		}

		// Destino fname/lname: extraer sub-key especifica.
		if ( 'fname' === $payload_key && isset( $non_empty['first_name'] ) ) {
			return $non_empty['first_name'];
		}
		if ( 'lname' === $payload_key && isset( $non_empty['last_name'] ) ) {
			return $non_empty['last_name'];
		}

		// Caso fallback fname sin first_name: primer valor no-vacio
		// (preserva orden first_name, middle_name, last_name si vienen
		// en ese orden).
		if ( 'fname' === $payload_key ) {
			$first = reset( $non_empty );
			return false === $first ? null : (string) $first;
		}
		if ( 'lname' === $payload_key ) {
			$last = end( $non_empty );
			return false === $last ? null : (string) $last;
		}

		// Otro destino: concat con orden conocido + resto.
		$ordered = array();
		foreach ( self::NAME_SUB_KEYS as $sub ) {
			if ( isset( $non_empty[ $sub ] ) ) {
				$ordered[] = $non_empty[ $sub ];
				unset( $non_empty[ $sub ] );
			}
		}
		// Cualquier sub-key adicional, en orden de aparicion.
		foreach ( $non_empty as $extra ) {
			$ordered[] = $extra;
		}
		$joined = implode( ' ', $ordered );
		return '' === $joined ? null : $joined;
	}

	/**
	 * Trunca un string a un maximo de caracteres (multibyte-safe).
	 * Helper de hardening v2.11.0 para acotar datos de headers/cookies
	 * controlados por el cliente antes de que entren al payload.
	 *
	 * @param string $value Valor a truncar.
	 * @param int    $max   Maximo de caracteres.
	 * @return string
	 */
	protected static function cap( string $value, int $max ): string {
		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, $max ) : substr( $value, 0, $max );
	}

	/**
	 * Captura UTMs del visitante. Estrategia (en orden):
	 * 1. Cookie `wppe_bridge_utms` (JSON). Esto es lo que dejara el
	 *    modulo D4.4 UTM Capture cuando se implemente.
	 * 2. $_GET['utm_*'] / gclid / fbclid del request actual.
	 * 3. Default: `utm_source = 'direct'`.
	 *
	 * @return array
	 */
	protected static function capture_utms(): array {
		$keys = array( 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'gclid', 'fbclid', 'fbp', 'landing_url' );

		// 1. Cookie. La cookie contiene JSON; sanitizamos cada campo
		// individualmente despues de json_decode (sanitize_text_field
		// pre-decode rompe el JSON con newlines validos).
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitizamos cada campo decodificado abajo.
		if ( isset( $_COOKIE[ self::UTMS_COOKIE_KEY ] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitizamos cada campo decodificado abajo.
			$raw     = wp_unslash( $_COOKIE[ self::UTMS_COOKIE_KEY ] );
			$decoded = is_string( $raw ) ? json_decode( $raw, true ) : null;
			if ( is_array( $decoded ) ) {
				$out = array();
				foreach ( $keys as $k ) {
					if ( isset( $decoded[ $k ] ) && is_string( $decoded[ $k ] ) ) {
						// Cap de longitud (hardening v2.11.0): la cookie
						// wppe_bridge_utms es 100% controlada por el
						// cliente; sin cap, un valor gigante entra al
						// payload/queue sorteando los limites del endpoint.
						$out[ $k ] = self::cap( sanitize_text_field( $decoded[ $k ] ), 300 );
					}
				}
				if ( ! empty( $out ) ) {
					return $out;
				}
			}
		}

		// 2. $_GET. Los UTMs vienen en la URL del visitante al landing
		// (no es procesamiento de form con nonce).
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- UTMs en URL del visitante, no procesamiento de form.
		$out = array();
		foreach ( $keys as $k ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- UTMs en URL del visitante, no procesamiento de form.
			if ( isset( $_GET[ $k ] ) && is_string( $_GET[ $k ] ) ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- UTMs en URL del visitante, no procesamiento de form.
				$out[ $k ] = sanitize_text_field( wp_unslash( $_GET[ $k ] ) );
			}
		}
		if ( ! empty( $out ) ) {
			return $out;
		}

		// 3. Default.
		return array( 'utm_source' => 'direct' );
	}

	/**
	 * Punto de entrada cuando llega una submission del plugin nativo.
	 *
	 * Las subclases concretas extraen `$form_data`, `$entry_id`,
	 * `$form_id` del shape especifico de su hook y llaman aqui.
	 *
	 * @param array  $form_data Field name => value.
	 * @param string $entry_id  ID externo de la submission.
	 * @param string $form_id   ID del form.
	 * @return int|null queue_id si encolado, null si fue descartado.
	 */
	protected static function handle_submission( array $form_data, string $entry_id, string $form_id ): ?int {
		// Log de entrada (v1.2.1). Antes el primer log era condicional —
		// solo aparecia si la submission era rechazada o si el worker la
		// procesaba. Si por algun motivo el lead se "perdia" entre estos
		// dos puntos (queue insert fallido, etc.), no quedaba rastro.
		// Ahora SIEMPRE registramos que el adapter recibio la submission.
		WPPE_Bridge_Logger::info(
			'submission_received',
			array(
				'form_plugin' => static::plugin_slug(),
				'form_id'     => $form_id,
				'entry_id'    => $entry_id,
				'field_count' => count( $form_data ),
			)
		);

		$mapping = static::get_mapping( $form_id );
		if ( null === $mapping ) {
			WPPE_Bridge_Logger::warn(
				'no_mapping_configured',
				array(
					'form_plugin' => static::plugin_slug(),
					'form_id'     => $form_id,
				)
			);
			return null;
		}

		$payload    = static::build_payload( $form_data, $mapping, $entry_id, $form_id );
		$normalized = WPPE_Bridge_Normalizer::normalize( $payload );

		// Validacion minima: necesitamos al menos email O phone para
		// que Sperant pueda dedup / ubicar al lead.
		$has_email = ! empty( $normalized['email'] );
		$has_phone = ! empty( $normalized['phone'] );
		if ( ! $has_email && ! $has_phone ) {
			WPPE_Bridge_Logger::warn(
				'submission_missing_contact_info',
				array(
					'form_plugin' => static::plugin_slug(),
					'form_id'     => $form_id,
				)
			);
			return null;
		}

		return WPPE_Bridge_Queue::enqueue( $normalized );
	}
}
