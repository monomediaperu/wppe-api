<?php
/**
 * Vista de configuracion del Widget de Contacto.
 *
 * @var array<string,string> $appearance Apariencia resuelta.
 * @var array<int,array>     $contacts   Contactos configurados (v2.12).
 * @var array<int,array>     $rules      Reglas por pagina.
 * @var array<int,array>     $links      Enlaces personalizados.
 * @var array<string,string> $consent    Config de consentimiento.
 * @var array<string,mixed>  $defaults   Defaults CRM del widget.
 * @var array<string,int>    $scoring    Puntajes de lead scoring.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

$wppe_bridge_back = add_query_arg(
	array( 'page' => WPPE_Bridge_Admin_Menu::SLUG . '-modules' ),
	admin_url( 'admin.php' )
);

$wppe_bridge_opt_appearance = WPPE_Bridge_Module_Contact_Widget::OPTION_APPEARANCE;
$wppe_bridge_opt_rules      = WPPE_Bridge_Module_Contact_Widget::OPTION_PAGE_RULES;
$wppe_bridge_opt_links      = WPPE_Bridge_Module_Contact_Widget::OPTION_CUSTOM_LINKS;
$wppe_bridge_opt_consent    = WPPE_Bridge_Module_Contact_Widget::OPTION_CONSENT;
$wppe_bridge_opt_defaults   = WPPE_Bridge_Widget_Adapter::OPTION_MAPPING_DEFAULTS;
$wppe_bridge_opt_contacts   = WPPE_Bridge_Widget_Contacts::OPTION_CONTACTS;

// Etiquetas de dias (0 = domingo, como JS getDay()).
$wppe_bridge_day_labels = array(
	1 => __( 'Lun', 'wppe-bridge' ),
	2 => __( 'Mar', 'wppe-bridge' ),
	3 => __( 'Mié', 'wppe-bridge' ),
	4 => __( 'Jue', 'wppe-bridge' ),
	5 => __( 'Vie', 'wppe-bridge' ),
	6 => __( 'Sáb', 'wppe-bridge' ),
	0 => __( 'Dom', 'wppe-bridge' ),
);

// Fichas de contacto: las existentes + una vacia para crear la
// siguiente (sin JS: el repeater se extiende al guardar).
$wppe_bridge_contact_rows = array_merge(
	$contacts,
	array( WPPE_Bridge_Widget_Contacts::defaults() )
);

// Paginas del sitio para los selectores de reglas y enlaces.
$wppe_bridge_pages = get_pages( array( 'sort_column' => 'post_title' ) );
if ( ! is_array( $wppe_bridge_pages ) ) {
	$wppe_bridge_pages = array();
}

// Filas del editor de enlaces: existentes + vacias hasta el maximo.
$wppe_bridge_link_rows = array_merge(
	$links,
	array_fill(
		0,
		max( 0, WPPE_Bridge_Widget_Settings_Page::MAX_LINKS - count( $links ) ),
		array(
			'label'   => '',
			'url'     => '',
			'type'    => 'internal',
			'page_id' => 0,
		)
	)
);

// Fichas de regla: las existentes + una vacia para crear la siguiente.
$wppe_bridge_rule_rows = array_merge(
	$rules,
	array(
		array(
			'match_type' => 'page',
			'page_ids'   => array(),
			'pattern'    => '',
			'action'     => 'show',
			'contacts'   => array(),
		),
	)
);
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Widget de Contacto', 'wppe-bridge' ); ?></h1>

	<p>
		<a href="<?php echo esc_url( $wppe_bridge_back ); ?>" class="button">
			← <?php esc_html_e( 'Volver a Módulos', 'wppe-bridge' ); ?>
		</a>
	</p>

	<p class="description">
		<?php esc_html_e( 'Botón flotante de contacto. Crea un contacto por cada número que atiende, define dónde aparece y qué datos pides antes de que el visitante salte a WhatsApp o al teléfono.', 'wppe-bridge' ); ?>
	</p>

	<form method="post" action="options.php">
		<?php settings_fields( WPPE_Bridge_Widget_Settings_Page::OPTION_GROUP ); ?>

		<h2><?php esc_html_e( 'Contactos', 'wppe-bridge' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Cada contacto es un número con su propia configuración: nombre visible, foto, canal, saludo y horario de atención. Si hay un solo contacto activo, el botón lleva directo a su formulario; si hay varios, el visitante elige con quién hablar.', 'wppe-bridge' ); ?>
		</p>

		<?php foreach ( $wppe_bridge_contact_rows as $wppe_bridge_i => $wppe_bridge_c ) : ?>
			<?php
			$wppe_bridge_f      = $wppe_bridge_opt_contacts . '[' . $wppe_bridge_i . ']';
			$wppe_bridge_is_new = '' === (string) $wppe_bridge_c['number'];
			?>
		<div class="wppe-bridge-card" style="border:1px solid #dcdcde;border-radius:8px;padding:16px;margin-bottom:16px;background:#fff;max-width:900px">
			<h3 style="margin-top:0">
				<?php
				echo $wppe_bridge_is_new
					? esc_html__( 'Nuevo contacto', 'wppe-bridge' )
					: esc_html( (string) $wppe_bridge_c['label'] );
				?>
			</h3>

			<input type="hidden" name="<?php echo esc_attr( $wppe_bridge_f ); ?>[id]" value="<?php echo esc_attr( (string) $wppe_bridge_c['id'] ); ?>" />

			<table class="form-table" role="presentation">
				<tbody>
					<tr>
						<th scope="row"><?php esc_html_e( 'Nombre visible', 'wppe-bridge' ); ?></th>
						<td>
							<input type="text" class="regular-text"
								name="<?php echo esc_attr( $wppe_bridge_f ); ?>[label]"
								value="<?php echo esc_attr( (string) $wppe_bridge_c['label'] ); ?>"
								placeholder="<?php esc_attr_e( 'Ventas', 'wppe-bridge' ); ?>" />
							<input type="text" class="regular-text" style="margin-left:8px"
								name="<?php echo esc_attr( $wppe_bridge_f ); ?>[role]"
								value="<?php echo esc_attr( (string) $wppe_bridge_c['role'] ); ?>"
								placeholder="<?php esc_attr_e( 'Cargo o área (opcional)', 'wppe-bridge' ); ?>" />
							<p class="description"><?php esc_html_e( 'Es lo que ve el visitante en el panel del widget.', 'wppe-bridge' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Canal', 'wppe-bridge' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( $wppe_bridge_f ); ?>[channel]">
								<option value="whatsapp" <?php selected( $wppe_bridge_c['channel'], 'whatsapp' ); ?>><?php esc_html_e( 'WhatsApp', 'wppe-bridge' ); ?></option>
								<option value="llamada" <?php selected( $wppe_bridge_c['channel'], 'llamada' ); ?>><?php esc_html_e( 'Llamada telefónica', 'wppe-bridge' ); ?></option>
							</select>
							<label style="margin-left:16px">
								<input type="checkbox" name="<?php echo esc_attr( $wppe_bridge_f ); ?>[allow_schedule]" value="1" <?php checked( ! empty( $wppe_bridge_c['allow_schedule'] ) ); ?> />
								<?php esc_html_e( 'Permitir que el visitante programe la llamada', 'wppe-bridge' ); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Número', 'wppe-bridge' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( $wppe_bridge_f ); ?>[country]">
								<?php foreach ( WPPE_Bridge_Widget_Contacts::COUNTRIES as $wppe_bridge_iso => $wppe_bridge_pref ) : ?>
								<option value="<?php echo esc_attr( $wppe_bridge_iso ); ?>" <?php selected( $wppe_bridge_c['country'], $wppe_bridge_iso ); ?>>
									<?php echo esc_html( $wppe_bridge_iso . ' ' . $wppe_bridge_pref ); ?>
								</option>
								<?php endforeach; ?>
							</select>
							<input type="text" class="regular-text" style="margin-left:8px"
								name="<?php echo esc_attr( $wppe_bridge_f ); ?>[number]"
								value="<?php echo esc_attr( (string) $wppe_bridge_c['number'] ); ?>"
								placeholder="<?php esc_attr_e( '999 888 777', 'wppe-bridge' ); ?>" />
							<p class="description"><?php esc_html_e( 'Solo el número local, sin el código de país: ese lo aporta el selector de la izquierda.', 'wppe-bridge' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Foto', 'wppe-bridge' ); ?></th>
						<td data-wppe-avatar-row>
							<?php $wppe_bridge_avatar = WPPE_Bridge_Widget_Contacts::avatar_url( $wppe_bridge_c ); ?>
							<img data-wppe-avatar-preview
								<?php if ( '' !== $wppe_bridge_avatar ) : ?>
									src="<?php echo esc_url( $wppe_bridge_avatar ); ?>"
								<?php else : ?>
									hidden
								<?php endif; ?>
								alt="" width="48" height="48"
								style="border-radius:50%;vertical-align:middle;margin-right:10px;object-fit:cover" />
							<button type="button" class="button" data-wppe-avatar-pick
								data-title="<?php esc_attr_e( 'Seleccionar foto del contacto', 'wppe-bridge' ); ?>"
								data-button="<?php esc_attr_e( 'Usar esta foto', 'wppe-bridge' ); ?>">
								<?php esc_html_e( 'Seleccionar foto', 'wppe-bridge' ); ?>
							</button>
							<button type="button" class="button-link" style="margin-left:8px" data-wppe-avatar-clear>
								<?php esc_html_e( 'Quitar', 'wppe-bridge' ); ?>
							</button>
							<input type="hidden" data-wppe-avatar-id
								name="<?php echo esc_attr( $wppe_bridge_f ); ?>[avatar_id]"
								value="<?php echo esc_attr( (string) $wppe_bridge_c['avatar_id'] ); ?>" />
							<p class="description"><?php esc_html_e( 'Opcional. Se muestra junto al nombre cuando hay varios contactos. Recomendado: imagen cuadrada de 96x96 px.', 'wppe-bridge' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Saludo', 'wppe-bridge' ); ?></th>
						<td>
							<input type="text" class="large-text"
								name="<?php echo esc_attr( $wppe_bridge_f ); ?>[greeting]"
								value="<?php echo esc_attr( (string) $wppe_bridge_c['greeting'] ); ?>"
								maxlength="<?php echo esc_attr( (string) WPPE_Bridge_Widget_Settings_Page::MAX_GREETING_LENGTH ); ?>"
								placeholder="<?php esc_attr_e( 'Hola 👋 ¿En qué te ayudamos?', 'wppe-bridge' ); ?>" />
							<p class="description"><?php esc_html_e( 'Se muestra sobre el formulario cuando el visitante elige este contacto.', 'wppe-bridge' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Horario de atención', 'wppe-bridge' ); ?></th>
						<td>
							<label style="display:block;margin-bottom:8px">
								<input type="checkbox" name="<?php echo esc_attr( $wppe_bridge_f ); ?>[hours_enabled]" value="1" <?php checked( ! empty( $wppe_bridge_c['hours_enabled'] ) ); ?> />
								<?php esc_html_e( 'Este contacto solo atiende en ciertos días y horas', 'wppe-bridge' ); ?>
							</label>
							<span style="display:inline-block;margin-bottom:8px">
								<?php foreach ( $wppe_bridge_day_labels as $wppe_bridge_d => $wppe_bridge_dlbl ) : ?>
								<label style="margin-right:8px">
									<input type="checkbox" name="<?php echo esc_attr( $wppe_bridge_f ); ?>[days][]" value="<?php echo esc_attr( (string) $wppe_bridge_d ); ?>" <?php checked( in_array( $wppe_bridge_d, (array) $wppe_bridge_c['days'], true ) ); ?> />
									<?php echo esc_html( $wppe_bridge_dlbl ); ?>
								</label>
								<?php endforeach; ?>
							</span>
							<br />
							<label style="margin-right:12px">
								<?php esc_html_e( 'De', 'wppe-bridge' ); ?>
								<input type="time" name="<?php echo esc_attr( $wppe_bridge_f ); ?>[start]" value="<?php echo esc_attr( (string) $wppe_bridge_c['start'] ); ?>" />
								<?php esc_html_e( 'a', 'wppe-bridge' ); ?>
								<input type="time" name="<?php echo esc_attr( $wppe_bridge_f ); ?>[end]" value="<?php echo esc_attr( (string) $wppe_bridge_c['end'] ); ?>" />
							</label>
							<label>
								<?php esc_html_e( 'Fuera de horario:', 'wppe-bridge' ); ?>
								<select name="<?php echo esc_attr( $wppe_bridge_f ); ?>[off_behavior]">
									<option value="note" <?php selected( $wppe_bridge_c['off_behavior'], 'note' ); ?>><?php esc_html_e( 'Avisar que se responderá más tarde (WhatsApp)', 'wppe-bridge' ); ?></option>
									<option value="schedule_only" <?php selected( $wppe_bridge_c['off_behavior'], 'schedule_only' ); ?>><?php esc_html_e( 'Ofrecer solo programar llamada', 'wppe-bridge' ); ?></option>
									<option value="hide" <?php selected( $wppe_bridge_c['off_behavior'], 'hide' ); ?>><?php esc_html_e( 'Ocultar este contacto', 'wppe-bridge' ); ?></option>
								</select>
							</label>
							<p class="description"><?php esc_html_e( 'La disponibilidad se calcula en el navegador con la zona horaria del sitio, así que una página guardada en caché siempre muestra el estado correcto.', 'wppe-bridge' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Activo', 'wppe-bridge' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( $wppe_bridge_f ); ?>[enabled]" value="1" <?php checked( ! empty( $wppe_bridge_c['enabled'] ) ); ?> />
								<?php esc_html_e( 'Mostrar este contacto en el sitio', 'wppe-bridge' ); ?>
							</label>
							<p class="description"><?php esc_html_e( 'Para eliminar un contacto, borra su nombre y su número, y guarda.', 'wppe-bridge' ); ?></p>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<?php endforeach; ?>
		<p class="description" style="margin-bottom:24px">
			<?php esc_html_e( 'Al guardar se añade una ficha vacía para que puedas crear el siguiente contacto.', 'wppe-bridge' ); ?>
		</p>

		<h2><?php esc_html_e( 'Lead Scoring', 'wppe-bridge' ); ?></h2>
		<p class="description">
			<?php
			printf(
				/* translators: %s: enlace a la pagina de Lead Scoring */
				esc_html__( 'El puntaje de leads ahora se configura en %s, porque aplica a todas las fuentes (este widget y los formularios del sitio), no solo al widget.', 'wppe-bridge' ),
				'<a href="' . esc_url( add_query_arg( array( 'page' => WPPE_Bridge_Scoring_Page::PAGE_SLUG ), admin_url( 'admin.php' ) ) ) . '">' . esc_html__( 'Lead Scoring', 'wppe-bridge' ) . '</a>'
			);
			?>
		</p>

		<h2><?php esc_html_e( 'Enlaces adicionales', 'wppe-bridge' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Botones extra en el panel que llevan directo a otro lugar, sin pedir datos al visitante. Sirven para enviar a una página del sitio (por ejemplo "Ver proyectos") o a un canal externo como Messenger, Telegram o un correo.', 'wppe-bridge' ); ?>
		</p>
		<table class="widefat striped" style="max-width:900px">
			<thead>
				<tr>
					<th style="width:200px"><?php esc_html_e( 'Texto del botón', 'wppe-bridge' ); ?></th>
					<th><?php esc_html_e( 'A dónde lleva', 'wppe-bridge' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $wppe_bridge_link_rows as $wppe_bridge_li => $wppe_bridge_link ) : ?>
					<?php
					$wppe_bridge_lf   = $wppe_bridge_opt_links . '[' . $wppe_bridge_li . ']';
					$wppe_bridge_ltyp = isset( $wppe_bridge_link['type'] ) && 'internal' === $wppe_bridge_link['type'] ? 'internal' : 'external';
					?>
				<tr data-wppe-link-row>
					<td>
						<input type="text" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_lf ); ?>[label]"
							value="<?php echo esc_attr( $wppe_bridge_link['label'] ); ?>"
							placeholder="<?php esc_attr_e( 'Ver proyectos', 'wppe-bridge' ); ?>" />
					</td>
					<td>
						<label style="margin-right:16px">
							<input type="radio" data-wppe-link-type value="internal"
								name="<?php echo esc_attr( $wppe_bridge_lf ); ?>[type]"
								<?php checked( $wppe_bridge_ltyp, 'internal' ); ?> />
							<?php esc_html_e( 'Una página de este sitio', 'wppe-bridge' ); ?>
						</label>
						<label>
							<input type="radio" data-wppe-link-type value="external"
								name="<?php echo esc_attr( $wppe_bridge_lf ); ?>[type]"
								<?php checked( $wppe_bridge_ltyp, 'external' ); ?> />
							<?php esc_html_e( 'Una dirección externa', 'wppe-bridge' ); ?>
						</label>

						<div data-wppe-link-internal style="margin-top:8px" <?php echo 'internal' === $wppe_bridge_ltyp ? '' : 'hidden'; ?>>
							<select name="<?php echo esc_attr( $wppe_bridge_lf ); ?>[page_id]">
								<option value="0"><?php esc_html_e( '— Elige una página —', 'wppe-bridge' ); ?></option>
								<?php foreach ( $wppe_bridge_pages as $wppe_bridge_page ) : ?>
								<option value="<?php echo esc_attr( (string) $wppe_bridge_page->ID ); ?>" <?php selected( (int) ( $wppe_bridge_link['page_id'] ?? 0 ), (int) $wppe_bridge_page->ID ); ?>>
									<?php echo esc_html( get_the_title( $wppe_bridge_page->ID ) ); ?>
								</option>
								<?php endforeach; ?>
							</select>
						</div>

						<div data-wppe-link-external style="margin-top:8px" <?php echo 'external' === $wppe_bridge_ltyp ? '' : 'hidden'; ?>>
							<input type="text" class="large-text"
								name="<?php echo esc_attr( $wppe_bridge_lf ); ?>[url]"
								value="<?php echo esc_attr( 'external' === $wppe_bridge_ltyp ? $wppe_bridge_link['url'] : '' ); ?>"
								placeholder="https://m.me/tuempresa" />
							<p class="description"><?php esc_html_e( 'Acepta direcciones https, correos (mailto:) y teléfonos (tel:). Se abre en una pestaña nueva.', 'wppe-bridge' ); ?></p>
						</div>
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Consentimiento (Ley 29733)', 'wppe-bridge' ); ?></h2>
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row">
						<label for="wppe-cw-privacy"><?php esc_html_e( 'Dirección de tu política de privacidad', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input type="url" id="wppe-cw-privacy" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_consent ); ?>[privacy_url]"
							value="<?php echo esc_attr( $consent['privacy_url'] ); ?>"
							placeholder="https://" />
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe-cw-consent-text"><?php esc_html_e( 'Texto de la casilla', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input type="text" id="wppe-cw-consent-text" class="large-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_consent ); ?>[text]"
							value="<?php echo esc_attr( $consent['text'] ); ?>"
							maxlength="<?php echo esc_attr( (string) WPPE_Bridge_Widget_Settings_Page::MAX_CONSENT_LENGTH ); ?>" />
						<p class="description"><?php esc_html_e( 'La casilla es obligatoria: sin su aceptación el lead no se captura. Si lo dejas vacío se usa el texto por defecto.', 'wppe-bridge' ); ?></p>
					</td>
				</tr>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Datos que se envían al CRM', 'wppe-bridge' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Valores que acompañan a cada lead del widget en Sperant. GHL, Odoo y HubSpot usan los suyos propios. Los IDs los obtienes con «Sincronizar catálogos» o desde el panel de tu CRM.', 'wppe-bridge' ); ?>
		</p>
		<table class="form-table" role="presentation">
			<tbody>
				<?php
				$wppe_bridge_default_fields = array(
					'input_channel_id' => __( 'Canal de entrada (input_channel_id)', 'wppe-bridge' ),
					'source_id'        => __( 'Fuente (source_id)', 'wppe-bridge' ),
					'interest_type_id' => __( 'Tipo de interés (interest_type_id)', 'wppe-bridge' ),
					'project_id'       => __( 'Proyecto (project_id)', 'wppe-bridge' ),
				);
				foreach ( $wppe_bridge_default_fields as $wppe_bridge_dk => $wppe_bridge_dlabel ) :
					?>
				<tr>
					<th scope="row">
						<label for="wppe-cw-def-<?php echo esc_attr( $wppe_bridge_dk ); ?>"><?php echo esc_html( $wppe_bridge_dlabel ); ?></label>
					</th>
					<td>
						<input type="text" id="wppe-cw-def-<?php echo esc_attr( $wppe_bridge_dk ); ?>" size="12"
							name="<?php echo esc_attr( $wppe_bridge_opt_defaults ); ?>[<?php echo esc_attr( $wppe_bridge_dk ); ?>]"
							value="<?php echo esc_attr( isset( $defaults[ $wppe_bridge_dk ] ) ? (string) $defaults[ $wppe_bridge_dk ] : '' ); ?>" />
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Apariencia', 'wppe-bridge' ); ?></h2>
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Posicion', 'wppe-bridge' ); ?></th>
					<td>
						<label style="margin-right:16px">
							<input type="radio" name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[position]" value="br" <?php checked( $appearance['position'], 'br' ); ?> />
							<?php esc_html_e( 'Abajo a la derecha', 'wppe-bridge' ); ?>
						</label>
						<label>
							<input type="radio" name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[position]" value="bl" <?php checked( $appearance['position'], 'bl' ); ?> />
							<?php esc_html_e( 'Abajo a la izquierda', 'wppe-bridge' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Icono', 'wppe-bridge' ); ?></th>
					<td>
						<select name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[icon]">
							<option value="whatsapp" <?php selected( $appearance['icon'], 'whatsapp' ); ?>><?php esc_html_e( 'WhatsApp', 'wppe-bridge' ); ?></option>
							<option value="chat" <?php selected( $appearance['icon'], 'chat' ); ?>><?php esc_html_e( 'Burbuja de chat', 'wppe-bridge' ); ?></option>
							<option value="phone" <?php selected( $appearance['icon'], 'phone' ); ?>><?php esc_html_e( 'Teléfono', 'wppe-bridge' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Se ignora si más abajo configuras un icono propio.', 'wppe-bridge' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe-cw-icon-url"><?php esc_html_e( 'Icono propio (dirección de la imagen)', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input type="url" id="wppe-cw-icon-url" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[icon_custom_url]"
							value="<?php echo esc_attr( $appearance['icon_custom_url'] ); ?>"
							placeholder="https://" />
						<p class="description"><?php esc_html_e( 'Solo direcciones https. Recomendado: PNG o SVG cuadrado de 48x48 px.', 'wppe-bridge' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe-cw-color-primary"><?php esc_html_e( 'Color del botón', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input type="text" id="wppe-cw-color-primary" size="9"
							name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[color_primary]"
							value="<?php echo esc_attr( $appearance['color_primary'] ); ?>"
							placeholder="#25d366" />
						<label style="margin-left:16px" for="wppe-cw-color-text"><?php esc_html_e( 'Color del texto', 'wppe-bridge' ); ?></label>
						<input type="text" id="wppe-cw-color-text" size="9"
							name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[color_text]"
							value="<?php echo esc_attr( $appearance['color_text'] ); ?>"
							placeholder="#ffffff" />
						<p class="description"><?php esc_html_e( 'Formato hexadecimal (#rrggbb).', 'wppe-bridge' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wppe-cw-cta"><?php esc_html_e( 'Texto del botón', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input type="text" id="wppe-cw-cta" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_appearance ); ?>[cta_label]"
							value="<?php echo esc_attr( $appearance['cta_label'] ); ?>"
							maxlength="<?php echo esc_attr( (string) WPPE_Bridge_Widget_Settings_Page::MAX_CTA_LENGTH ); ?>" />
					</td>
				</tr>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Dónde aparece el widget', 'wppe-bridge' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Sin reglas, el widget aparece en todo el sitio con todos los contactos activos. Cada regla te permite ocultarlo en ciertas páginas o mostrar solo algunos contactos. Se aplica la primera regla que coincida, así que pon arriba las más específicas.', 'wppe-bridge' ); ?>
		</p>

		<?php foreach ( $wppe_bridge_rule_rows as $wppe_bridge_i => $wppe_bridge_rule ) : ?>
			<?php
			$wppe_bridge_rf    = $wppe_bridge_opt_rules . '[' . $wppe_bridge_i . ']';
			$wppe_bridge_rtype = isset( $wppe_bridge_rule['match_type'] ) && 'pattern' === $wppe_bridge_rule['match_type'] ? 'pattern' : 'page';
			?>
		<div data-wppe-rule-row style="border:1px solid #dcdcde;border-radius:8px;padding:16px;margin-bottom:12px;background:#fff;max-width:900px">
			<table class="form-table" role="presentation">
				<tbody>
					<tr>
						<th scope="row"><?php esc_html_e( 'Aplicar en', 'wppe-bridge' ); ?></th>
						<td>
							<label style="margin-right:16px">
								<input type="radio" data-wppe-rule-match value="page"
									name="<?php echo esc_attr( $wppe_bridge_rf ); ?>[match_type]"
									<?php checked( $wppe_bridge_rtype, 'page' ); ?> />
								<?php esc_html_e( 'Páginas que yo elija', 'wppe-bridge' ); ?>
							</label>
							<label>
								<input type="radio" data-wppe-rule-match value="pattern"
									name="<?php echo esc_attr( $wppe_bridge_rf ); ?>[match_type]"
									<?php checked( $wppe_bridge_rtype, 'pattern' ); ?> />
								<?php esc_html_e( 'Una dirección con comodín (avanzado)', 'wppe-bridge' ); ?>
							</label>

							<div data-wppe-rule-pages style="margin-top:10px" <?php echo 'page' === $wppe_bridge_rtype ? '' : 'hidden'; ?>>
								<select multiple size="6" style="min-width:320px"
									name="<?php echo esc_attr( $wppe_bridge_rf ); ?>[page_ids][]">
									<?php foreach ( $wppe_bridge_pages as $wppe_bridge_page ) : ?>
									<option value="<?php echo esc_attr( (string) $wppe_bridge_page->ID ); ?>" <?php echo in_array( (int) $wppe_bridge_page->ID, (array) ( $wppe_bridge_rule['page_ids'] ?? array() ), true ) ? 'selected' : ''; ?>>
										<?php echo esc_html( get_the_title( $wppe_bridge_page->ID ) ); ?>
									</option>
									<?php endforeach; ?>
								</select>
								<p class="description"><?php esc_html_e( 'Mantén pulsado Ctrl (o Cmd en Mac) para elegir varias.', 'wppe-bridge' ); ?></p>
							</div>

							<div data-wppe-rule-pattern style="margin-top:10px" <?php echo 'pattern' === $wppe_bridge_rtype ? '' : 'hidden'; ?>>
								<input type="text" class="regular-text"
									name="<?php echo esc_attr( $wppe_bridge_rf ); ?>[pattern]"
									value="<?php echo esc_attr( (string) ( $wppe_bridge_rule['pattern'] ?? '' ) ); ?>"
									placeholder="/proyectos*" />
								<p class="description"><?php esc_html_e( 'Útil para direcciones dinámicas: /contacto (una exacta), /proyectos* (todas las que empiecen así) o * (todo el sitio).', 'wppe-bridge' ); ?></p>
							</div>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Qué hacer ahí', 'wppe-bridge' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( $wppe_bridge_rf ); ?>[action]">
								<option value="show" <?php selected( $wppe_bridge_rule['action'] ?? 'show', 'show' ); ?>><?php esc_html_e( 'Mostrar el widget', 'wppe-bridge' ); ?></option>
								<option value="hide" <?php selected( $wppe_bridge_rule['action'] ?? 'show', 'hide' ); ?>><?php esc_html_e( 'Ocultar el widget', 'wppe-bridge' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Contactos a mostrar', 'wppe-bridge' ); ?></th>
						<td>
							<?php if ( empty( $contacts ) ) : ?>
								<em><?php esc_html_e( 'Todavía no has creado contactos.', 'wppe-bridge' ); ?></em>
							<?php else : ?>
								<?php foreach ( $contacts as $wppe_bridge_rc ) : ?>
								<label style="display:block;margin-bottom:4px">
									<input type="checkbox" value="<?php echo esc_attr( (string) $wppe_bridge_rc['id'] ); ?>"
										name="<?php echo esc_attr( $wppe_bridge_rf ); ?>[contacts][]"
										<?php checked( in_array( (string) $wppe_bridge_rc['id'], (array) ( $wppe_bridge_rule['contacts'] ?? array() ), true ) ); ?> />
									<?php echo esc_html( (string) $wppe_bridge_rc['label'] ); ?>
								</label>
								<?php endforeach; ?>
								<p class="description"><?php esc_html_e( 'Si no marcas ninguno, se muestran todos los contactos activos.', 'wppe-bridge' ); ?></p>
							<?php endif; ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<?php endforeach; ?>
		<p class="description" style="margin-bottom:24px">
			<?php esc_html_e( 'Al guardar se añade una regla vacía para que puedas crear la siguiente. Las reglas sin páginas ni dirección se descartan.', 'wppe-bridge' ); ?>
		</p>

		<?php submit_button( __( 'Guardar configuración', 'wppe-bridge' ) ); ?>
	</form>
</div>
