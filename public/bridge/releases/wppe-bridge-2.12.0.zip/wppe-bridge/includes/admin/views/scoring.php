<?php
/**
 * Vista de configuracion del Lead Scoring global.
 *
 * @var bool                 $enabled  Scoring activo.
 * @var array<string,int>    $weights  Pesos por señal.
 * @var array<string,int>    $bands    Umbrales de banda.
 * @var array<string,string> $question Pregunta calificadora.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

$wppe_bridge_opt_enabled  = WPPE_Bridge_Lead_Scoring::OPTION_ENABLED;
$wppe_bridge_opt_weights  = WPPE_Bridge_Lead_Scoring::OPTION_WEIGHTS;
$wppe_bridge_opt_bands    = WPPE_Bridge_Lead_Scoring::OPTION_BANDS;
$wppe_bridge_opt_question = WPPE_Bridge_Lead_Scoring::OPTION_QUESTION;
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Lead Scoring', 'wppe-bridge' ); ?></h1>

	<p class="description" style="max-width:820px">
		<?php esc_html_e( 'Puntúa cada lead del 0 al 100 según lo que hizo, qué tan calificado está y de dónde vino. El puntaje viaja al CRM en la observación del lead (por ejemplo «🔥 Caliente (67)») y también como campo propio, para que puedas ordenar y filtrar dentro del CRM. Aplica a todas las fuentes: el widget de contacto y los formularios de Fluent Forms, Gravity Forms, Elementor y Contact Form 7.', 'wppe-bridge' ); ?>
	</p>

	<div class="notice notice-info inline" style="max-width:820px;margin:16px 0">
		<p>
			<strong><?php esc_html_e( 'Importante:', 'wppe-bridge' ); ?></strong>
			<?php esc_html_e( 'los puntajes que vienen por defecto son un punto de partida razonable, no una verdad. Un modelo de scoring recién sirve cuando se ajusta con datos reales de cierres. Por eso el puntaje solo ordena la atención del equipo: nunca bloquea ni descarta leads.', 'wppe-bridge' ); ?>
		</p>
	</div>

	<form method="post" action="options.php">
		<?php settings_fields( WPPE_Bridge_Scoring_Page::OPTION_GROUP ); ?>

		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Activar', 'wppe-bridge' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="<?php echo esc_attr( $wppe_bridge_opt_enabled ); ?>" value="1" <?php checked( $enabled ); ?> />
							<?php esc_html_e( 'Calcular el puntaje y enviarlo al CRM con cada lead', 'wppe-bridge' ); ?>
						</label>
					</td>
				</tr>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Pregunta calificadora', 'wppe-bridge' ); ?></h2>
		<p class="description" style="max-width:820px">
			<?php esc_html_e( 'Una sola pregunta en el formulario del widget que suele predecir mejor un cierre que todo el resto del puntaje junto. Adáptala a tu negocio: una inmobiliaria pregunta por el plazo de compra, una clínica por la urgencia, un colegio por el año de ingreso.', 'wppe-bridge' ); ?>
		</p>
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Mostrarla', 'wppe-bridge' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="<?php echo esc_attr( $wppe_bridge_opt_question ); ?>[enabled]" value="1" <?php checked( ! empty( $question['enabled'] ) ); ?> />
							<?php esc_html_e( 'Incluir esta pregunta en el formulario del widget', 'wppe-bridge' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Pregunta', 'wppe-bridge' ); ?></th>
					<td>
						<input type="text" class="large-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_question ); ?>[label]"
							value="<?php echo esc_attr( $question['label'] ); ?>"
							maxlength="<?php echo esc_attr( (string) WPPE_Bridge_Scoring_Page::MAX_QUESTION_LENGTH ); ?>" />
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Opción de mayor intención', 'wppe-bridge' ); ?></th>
					<td>
						<input type="text" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_question ); ?>[high]"
							value="<?php echo esc_attr( $question['high'] ); ?>" />
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Opción intermedia', 'wppe-bridge' ); ?></th>
					<td>
						<input type="text" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_question ); ?>[medium]"
							value="<?php echo esc_attr( $question['medium'] ); ?>" />
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Opción de menor intención', 'wppe-bridge' ); ?></th>
					<td>
						<input type="text" class="regular-text"
							name="<?php echo esc_attr( $wppe_bridge_opt_question ); ?>[low]"
							value="<?php echo esc_attr( $question['low'] ); ?>" />
					</td>
				</tr>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Puntajes', 'wppe-bridge' ); ?></h2>
		<p class="description" style="max-width:820px">
			<?php esc_html_e( 'Cada señal suma (o resta, en las penalizaciones) los puntos que indiques. Un 0 desactiva esa señal. El total siempre queda entre 0 y 100.', 'wppe-bridge' ); ?>
		</p>

		<?php foreach ( WPPE_Bridge_Scoring_Page::groups() as $wppe_bridge_group ) : ?>
		<h3 style="margin-bottom:4px"><?php echo esc_html( $wppe_bridge_group['title'] ); ?></h3>
		<p class="description" style="margin-top:0;max-width:820px"><?php echo esc_html( $wppe_bridge_group['description'] ); ?></p>
		<table class="form-table" role="presentation">
			<tbody>
				<?php foreach ( $wppe_bridge_group['keys'] as $wppe_bridge_k => $wppe_bridge_label ) : ?>
				<tr>
					<th scope="row" style="font-weight:400">
						<label for="wppe-score-<?php echo esc_attr( $wppe_bridge_k ); ?>"><?php echo esc_html( $wppe_bridge_label ); ?></label>
					</th>
					<td>
						<input type="number" min="0" max="100" style="width:90px"
							id="wppe-score-<?php echo esc_attr( $wppe_bridge_k ); ?>"
							name="<?php echo esc_attr( $wppe_bridge_opt_weights ); ?>[<?php echo esc_attr( $wppe_bridge_k ); ?>]"
							value="<?php echo esc_attr( (string) ( $weights[ $wppe_bridge_k ] ?? 0 ) ); ?>" />
						<?php if ( 0 === strpos( $wppe_bridge_k, 'penalty_' ) ) : ?>
							<span class="description" style="margin-left:8px"><?php esc_html_e( 'se resta', 'wppe-bridge' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php endforeach; ?>

		<h2><?php esc_html_e( 'Bandas', 'wppe-bridge' ); ?></h2>
		<p class="description" style="max-width:820px">
			<?php esc_html_e( 'La banda es lo que el vendedor lee primero en el CRM. Indica desde qué puntaje empieza cada una: por debajo de la primera, el lead se marca como Frío.', 'wppe-bridge' ); ?>
		</p>
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><?php esc_html_e( '🟡 Tibio desde', 'wppe-bridge' ); ?></th>
					<td><input type="number" min="0" max="100" style="width:90px" name="<?php echo esc_attr( $wppe_bridge_opt_bands ); ?>[tibio]" value="<?php echo esc_attr( (string) $bands['tibio'] ); ?>" /></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( '🔥 Caliente desde', 'wppe-bridge' ); ?></th>
					<td><input type="number" min="0" max="100" style="width:90px" name="<?php echo esc_attr( $wppe_bridge_opt_bands ); ?>[caliente]" value="<?php echo esc_attr( (string) $bands['caliente'] ); ?>" /></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( '🔥 Prioritario desde', 'wppe-bridge' ); ?></th>
					<td><input type="number" min="0" max="100" style="width:90px" name="<?php echo esc_attr( $wppe_bridge_opt_bands ); ?>[prioritario]" value="<?php echo esc_attr( (string) $bands['prioritario'] ); ?>" /></td>
				</tr>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Enviar el puntaje a un campo del CRM', 'wppe-bridge' ); ?></h2>
		<p class="description" style="max-width:820px">
			<?php
			printf(
				/* translators: %s: nombre del campo del payload */
				esc_html__( 'La banda siempre se agrega a la observación del lead. Si además quieres poder ordenar y filtrar por puntaje dentro del CRM, mapea el campo %s a una propiedad numérica de tu CRM desde la página de Mapeo.', 'wppe-bridge' ),
				'<code>' . esc_html( WPPE_Bridge_Lead_Scoring::PAYLOAD_KEY ) . '</code>'
			);
			?>
		</p>

		<?php submit_button( __( 'Guardar configuración', 'wppe-bridge' ) ); ?>
	</form>
</div>
