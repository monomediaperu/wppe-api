<?php
/**
 * Pagina admin de Lead Scoring global (v2.12.0, D-W10).
 *
 * Vive fuera del Widget porque el scoring aplica a TODAS las fuentes
 * de leads (widget + los 4 plugins de formularios).
 *
 * @package WPPE_Bridge
 * @since 2.12.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Configuracion del lead scoring global.
 */
final class WPPE_Bridge_Scoring_Page {

	/**
	 * Slug de la pagina (submenu de WP.pe Bridge).
	 */
	public const PAGE_SLUG = 'wppe-bridge-scoring';

	/**
	 * Settings group de WP Settings API.
	 */
	public const OPTION_GROUP = 'wppe_bridge_scoring_settings';

	/**
	 * Longitud maxima de los textos de la pregunta calificadora.
	 */
	public const MAX_QUESTION_LENGTH = 120;

	/**
	 * Option keys => sanitizer.
	 */
	public const OPTIONS = array(
		WPPE_Bridge_Lead_Scoring::OPTION_ENABLED  => 'sanitize_enabled',
		WPPE_Bridge_Lead_Scoring::OPTION_WEIGHTS  => 'sanitize_weights',
		WPPE_Bridge_Lead_Scoring::OPTION_BANDS    => 'sanitize_bands',
		WPPE_Bridge_Lead_Scoring::OPTION_QUESTION => 'sanitize_question',
	);

	/**
	 * Registra los settings.
	 *
	 * @return void
	 */
	public static function register_settings(): void {
		foreach ( self::OPTIONS as $key => $cb ) {
			register_setting(
				self::OPTION_GROUP,
				$key,
				array( 'sanitize_callback' => array( self::class, $cb ) )
			);
		}
	}

	/**
	 * Renderiza la pagina.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$enabled  = WPPE_Bridge_Lead_Scoring::is_enabled();
		$weights  = WPPE_Bridge_Lead_Scoring::weights();
		$bands    = WPPE_Bridge_Lead_Scoring::bands();
		$question = WPPE_Bridge_Lead_Scoring::question();

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/scoring.php';
	}

	/**
	 * Grupos de señales para pintar la pagina, con su explicacion.
	 *
	 * @return array<int,array{title:string,description:string,keys:array<string,string>}>
	 */
	public static function groups(): array {
		return array(
			array(
				'title'       => __( 'Qué pidió el visitante', 'wppe-bridge' ),
				'description' => __( 'Mide la urgencia. Solo suma una de estas: la acción que realmente hizo.', 'wppe-bridge' ),
				'keys'        => array(
					'channel_llamada_inmediata'  => __( 'Pidió que lo llamen ahora', 'wppe-bridge' ),
					'channel_llamada_programada' => __( 'Programó una llamada', 'wppe-bridge' ),
					'channel_whatsapp'           => __( 'Escribió por WhatsApp', 'wppe-bridge' ),
					'channel_formulario'         => __( 'Envió un formulario del sitio', 'wppe-bridge' ),
				),
			),
			array(
				'title'       => __( 'Qué tan calificado está', 'wppe-bridge' ),
				'description' => __( 'La señal que más predice un cierre. La pregunta calificadora se configura más abajo.', 'wppe-bridge' ),
				'keys'        => array(
					'question_high'     => __( 'Respondió la opción de mayor intención', 'wppe-bridge' ),
					'question_medium'   => __( 'Respondió la opción intermedia', 'wppe-bridge' ),
					'question_low'      => __( 'Respondió la opción de menor intención', 'wppe-bridge' ),
					'specific_interest' => __( 'Indicó un interés o proyecto concreto', 'wppe-bridge' ),
					'has_document'      => __( 'Dejó su documento (DNI o RUC)', 'wppe-bridge' ),
				),
			),
			array(
				'title'       => __( 'Calidad de los datos', 'wppe-bridge' ),
				'description' => __( 'Qué tan utilizable es el contacto que dejó.', 'wppe-bridge' ),
				'keys'        => array(
					'valid_phone'    => __( 'Teléfono con formato válido', 'wppe-bridge' ),
					'has_email'      => __( 'Dejó email además del teléfono', 'wppe-bridge' ),
					'plausible_name' => __( 'Nombre que parece real', 'wppe-bridge' ),
				),
			),
			array(
				'title'       => __( 'De dónde vino', 'wppe-bridge' ),
				'description' => __( 'Búsqueda pagada puntúa más que social pagado: en la búsqueda te estaban buscando, en redes te apareciste.', 'wppe-bridge' ),
				'keys'        => array(
					'source_paid_search' => __( 'Búsqueda pagada (Google Ads)', 'wppe-bridge' ),
					'source_organic'     => __( 'Búsqueda orgánica', 'wppe-bridge' ),
					'source_direct'      => __( 'Directo o referido', 'wppe-bridge' ),
					'source_paid_social' => __( 'Redes sociales pagadas (Meta, TikTok)', 'wppe-bridge' ),
					'returning_visitor'  => __( 'Ya había visitado el sitio antes', 'wppe-bridge' ),
					'off_hours'          => __( 'Dejó sus datos fuera de horario', 'wppe-bridge' ),
				),
			),
			array(
				'title'       => __( 'Penalizaciones', 'wppe-bridge' ),
				'description' => __( 'Se restan del total. Sin estas, todos los leads se acumulan arriba y el puntaje deja de servir para ordenar.', 'wppe-bridge' ),
				'keys'        => array(
					'penalty_fake_data'        => __( 'Datos evidentemente falsos (teléfono 999999999, nombre sin sentido)', 'wppe-bridge' ),
					'penalty_disposable_email' => __( 'Email de un servicio de correo temporal', 'wppe-bridge' ),
					'penalty_minimal_effort'   => __( 'Sin email y sin describir su interés', 'wppe-bridge' ),
				),
			),
		);
	}

	// ---------- sanitizers ----------

	/**
	 * Sanitiza el flag de activado.
	 *
	 * @param mixed $value Valor crudo.
	 * @return bool
	 */
	public static function sanitize_enabled( $value ): bool {
		return ! empty( $value );
	}

	/**
	 * Sanitiza los pesos: keys whitelist, enteros 0..100.
	 *
	 * @param mixed $value Valor crudo.
	 * @return array<string,int>
	 */
	public static function sanitize_weights( $value ): array {
		$defaults = WPPE_Bridge_Lead_Scoring::WEIGHT_DEFAULTS;
		if ( ! is_array( $value ) ) {
			return $defaults;
		}
		$out = $defaults;
		foreach ( $defaults as $key => $default ) {
			if ( isset( $value[ $key ] ) && is_numeric( $value[ $key ] ) ) {
				$out[ $key ] = max( 0, min( 100, (int) $value[ $key ] ) );
			}
		}
		return $out;
	}

	/**
	 * Sanitiza los umbrales de banda.
	 *
	 * @param mixed $value Valor crudo.
	 * @return array<string,int>
	 */
	public static function sanitize_bands( $value ): array {
		$defaults = WPPE_Bridge_Lead_Scoring::BAND_DEFAULTS;
		if ( ! is_array( $value ) ) {
			return $defaults;
		}
		$out = $defaults;
		foreach ( $defaults as $key => $default ) {
			if ( isset( $value[ $key ] ) && is_numeric( $value[ $key ] ) ) {
				$out[ $key ] = max( 0, min( 100, (int) $value[ $key ] ) );
			}
		}
		return $out;
	}

	/**
	 * Sanitiza la pregunta calificadora.
	 *
	 * @param mixed $value Valor crudo.
	 * @return array<string,string>
	 */
	public static function sanitize_question( $value ): array {
		$defaults = WPPE_Bridge_Lead_Scoring::question_defaults();
		if ( ! is_array( $value ) ) {
			return $defaults;
		}

		$out = array( 'enabled' => ! empty( $value['enabled'] ) ? '1' : '' );
		foreach ( array( 'label', 'high', 'medium', 'low' ) as $key ) {
			$raw         = isset( $value[ $key ] ) && is_string( $value[ $key ] ) ? $value[ $key ] : '';
			$clean       = mb_substr( sanitize_text_field( $raw ), 0, self::MAX_QUESTION_LENGTH );
			$out[ $key ] = '' !== $clean ? $clean : $defaults[ $key ];
		}

		return $out;
	}
}
