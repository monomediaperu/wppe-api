<?php
/**
 * Activator del plugin.
 *
 * Crea las tablas propias (queue, dedup, logs) via dbDelta, registra
 * opciones default y agenda el cron del worker.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Activator — métodos estáticos invocados por register_activation_hook.
 */
final class WPPE_Bridge_Activator {

	/**
	 * Hook cron del worker.
	 */
	public const CRON_HOOK = 'wppe_bridge_worker_tick';

	/**
	 * Schedule cron del worker (cada minuto).
	 */
	public const CRON_SCHEDULE = 'wppebridge_minute';

	/**
	 * Schedule custom de 5 minutos (v2.4.0). Usado por el Notifier
	 * para enviar emails batched de leads fallidos. WP no provee
	 * intervalos de minutos < diario por default.
	 */
	public const CRON_SCHEDULE_5MIN = 'wppebridge_5min';

	/**
	 * Hook cron del cleanup de logs (diario).
	 */
	public const CRON_HOOK_LOGS_CLEANUP = 'wppe_bridge_logs_cleanup_tick';

	/**
	 * V2.5.9 — Hook cron del cleanup de queue (retention LPDP). Diario.
	 * Purga items con status sent/deduped despues de N dias y items con
	 * status failed_permanent despues de M dias (N y M configurables via
	 * `wppe_bridge_queue_retention_sent_days` / `..._failed_days`, defaults
	 * 90 y 180). Items en pending/failed_temp/paused NUNCA se purgan (son
	 * leads en proceso).
	 */
	public const CRON_HOOK_QUEUE_CLEANUP = 'wppe_bridge_queue_cleanup_tick';

	/**
	 * Schedule cron del cleanup de logs.
	 */
	public const CRON_SCHEDULE_DAILY = 'daily';

	/**
	 * TTL default de la tabla dedup (segundos).
	 */
	public const DEFAULT_DEDUP_TTL_SECONDS = 60;

	/**
	 * Retencion default de logs (dias).
	 */
	public const DEFAULT_LOGS_RETENTION_DAYS = 30;

	/**
	 * V2.5.9 — Retencion default de queue para items entregados
	 * (sent + deduped). 90 dias por convencion comercial peruana —
	 * permite auditar entregas del trimestre anterior + 30d de buffer.
	 */
	public const DEFAULT_QUEUE_RETENTION_SENT_DAYS = 90;

	/**
	 * V2.5.9 — Retencion default de queue para failed_permanent. 180 dias
	 * mas largo que sent porque los fallos suelen requerir diagnostico
	 * post-mortem. Aun asi acotado para cumplir con principio de
	 * conservacion limitada (LPDP 29733).
	 */
	public const DEFAULT_QUEUE_RETENTION_FAILED_DAYS = 180;

	/**
	 * Punto de entrada.
	 */
	public static function activate(): void {
		self::create_tables();
		self::register_default_options();
		self::schedule_cron();

		// Beacon de activacion (v2.11.0): Mono Media registra QUE
		// dominios activan el plugin — la via para detectar
		// activaciones no autorizadas. Fire-and-forget, jamas afecta
		// la activacion.
		if ( class_exists( 'WPPE_Bridge_Telemetry' ) ) {
			WPPE_Bridge_Telemetry::send( WPPE_Bridge_Telemetry::EVENT_ACTIVATED );
		}
	}

	/**
	 * Migra el schema de DB al `WPPE_BRIDGE_DB_VERSION` actual. Idempotente:
	 * compara la option `wppe_bridge_db_version` con la constante actual y
	 * corre las migrations faltantes en orden. Se ejecuta cada page-load
	 * via `plugins_loaded` (cheap: solo lee la option si no hay nada que
	 * hacer).
	 *
	 * V2.5.8 — Migration #2: renombra la columna `sperant_response` →
	 * `destination_response` en `wp_wppebridge_queue`. Era naming legacy
	 * de cuando el plugin solo soportaba Sperant. Renombrar (no DROP +
	 * ADD) preserva la data existente — clientes con leads ya enviados
	 * mantienen el response body para inspeccion en Logs.
	 *
	 * Defensa: usa SHOW COLUMNS para chequear el nombre actual antes del
	 * ALTER, por si el DB ya esta migrado pero la option quedo desfasada.
	 *
	 * @return void
	 */
	public static function maybe_upgrade_database(): void {
		$installed_version = (string) get_option( 'wppe_bridge_db_version', '1' );
		$current_version   = (string) WPPE_BRIDGE_DB_VERSION;

		if ( version_compare( $installed_version, $current_version, '>=' ) ) {
			return;
		}

		global $wpdb;
		$queue_table = $wpdb->prefix . 'wppebridge_queue';

		// Migration v1 → v2: rename column sperant_response → destination_response.
		if ( version_compare( $installed_version, '2', '<' ) ) {
			// Chequeo defensivo: la columna nueva ya puede existir si la
			// migration corrio parcialmente en un page-load anterior y
			// fallo al update_option. ALTER TABLE en MySQL no es transaccional
			// con UPDATE wp_options, asi que esta defensa es necesaria.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- schema migration, no hay alternativa via WP API.
			$has_old = $wpdb->get_var(
				$wpdb->prepare(
					"SHOW COLUMNS FROM `{$queue_table}` LIKE %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name comes from $wpdb->prefix.
					'sperant_response'
				)
			);
			if ( $has_old ) {
				// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- schema migration: ALTER TABLE no soportado via WP API; nombre de tabla viene de $wpdb->prefix (no de input usuario).
				$wpdb->query( "ALTER TABLE `{$queue_table}` CHANGE COLUMN `sperant_response` `destination_response` LONGTEXT DEFAULT NULL" );
				// phpcs:enable
			}
		}

		update_option( 'wppe_bridge_db_version', $current_version, false );
	}

	/**
	 * Crea las 3 tablas propias via dbDelta.
	 */
	private static function create_tables(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		$queue_table = $wpdb->prefix . 'wppebridge_queue';
		$dedup_table = $wpdb->prefix . 'wppebridge_dedup';
		$logs_table  = $wpdb->prefix . 'wppebridge_logs';

		// dbDelta es estricto con espaciado y backticks — seguir convencion.
		$queue_sql = "CREATE TABLE {$queue_table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			hash CHAR(64) NOT NULL,
			form_plugin VARCHAR(20) NOT NULL,
			form_id VARCHAR(50) NOT NULL,
			submission_id_external VARCHAR(50) DEFAULT NULL,
			payload LONGTEXT NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			last_attempt_at DATETIME DEFAULT NULL,
			next_retry_at DATETIME DEFAULT NULL,
			destination_response LONGTEXT DEFAULT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY status_retry (status, next_retry_at),
			KEY hash_idx (hash),
			KEY created_idx (created_at)
		) {$charset_collate};";

		$dedup_sql = "CREATE TABLE {$dedup_table} (
			hash CHAR(64) NOT NULL,
			expires_at DATETIME NOT NULL,
			PRIMARY KEY  (hash),
			KEY expires_idx (expires_at)
		) {$charset_collate};";

		$logs_sql = "CREATE TABLE {$logs_table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			queue_id BIGINT UNSIGNED DEFAULT NULL,
			level VARCHAR(10) NOT NULL,
			message TEXT NOT NULL,
			context LONGTEXT DEFAULT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY level_created (level, created_at),
			KEY queue_idx (queue_id)
		) {$charset_collate};";

		dbDelta( $queue_sql );
		dbDelta( $dedup_sql );
		dbDelta( $logs_sql );
	}

	/**
	 * Registra opciones default. Usa add_option (no sobreescribe si existen).
	 */
	private static function register_default_options(): void {
		add_option( 'wppe_bridge_api_token', '' );
		add_option( 'wppe_bridge_api_base_url', 'https://api.sperant.com' );
		// v2.5.6: fresh installs ya NO pre-asignan un destino por default.
		// El user elige explicitamente desde el selector visual de
		// Configuracion. Hasta que elija, el Worker no procesa el queue
		// (ver Worker::process_queue + Factory::is_configured). Esto evita
		// que un fresh install reciba leads y los mande sin querer a
		// Sperant por accidente. Instalaciones existentes (que ya tienen
		// la option setteada como 'sperant') no se ven afectadas — el
		// add_option no sobreescribe valores existentes.
		add_option( 'wppe_bridge_catalogs', array() );
		add_option( 'wppe_bridge_field_mapping', array() );
		add_option( 'wppe_bridge_db_version', WPPE_BRIDGE_DB_VERSION );
		add_option( 'wppe_bridge_dedup_ttl_seconds', self::DEFAULT_DEDUP_TTL_SECONDS );
		add_option( 'wppe_bridge_logs_retention_days', self::DEFAULT_LOGS_RETENTION_DAYS );
		// v2.5.9 — Retention LPDP de la queue. Defaults conservadores:
		// sent/deduped (datos ya entregados al CRM) viven 90 dias para
		// permitir auditoria de delivery; failed_permanent vive 180 para
		// que el operador pueda diagnosticar fallos historicos. Items
		// pending/failed_temp/paused nunca se purgan — son leads activos.
		add_option( 'wppe_bridge_queue_retention_sent_days', self::DEFAULT_QUEUE_RETENTION_SENT_DAYS );
		add_option( 'wppe_bridge_queue_retention_failed_days', self::DEFAULT_QUEUE_RETENTION_FAILED_DAYS );
		add_option( 'wppe_bridge_panel_subdomain', '' );

		// Zona de peligro (v1.2.2). Default OFF — el uninstall preserva
		// data salvo que el operador opte explicitamente desde la UI.
		add_option( 'wppe_bridge_delete_data_on_uninstall', false );

		// License (v1.1.0). Whitelist remoto en wp_options.
		add_option( 'wppe_bridge_demo_leads_count', 0 );
		add_option( 'wppe_bridge_whitelist_cache', null );

		// Heartbeat del worker (v1.2.4). 0 marca "nunca corrio";
		// `Environment_Diagnostics::card_wp_cron()` lo usa para detectar
		// si WP-Cron quedo sin disparar el hook.
		add_option( 'wppe_bridge_worker_last_tick_at', 0 );

		// Modulos opcionales (D4.4) — todos off por default.
		add_option( 'wppe_bridge_module_utm_capture_enabled', false );
		add_option( 'wppe_bridge_module_submit_lock_enabled', false );
		add_option( 'wppe_bridge_module_meta_capi_enabled', false );
		add_option( 'wppe_bridge_meta_capi_pixel_id', '' );
		add_option( 'wppe_bridge_meta_capi_access_token', '' );
		add_option( 'wppe_bridge_meta_capi_test_event_code', '' );
		add_option( 'wppe_bridge_meta_event_name', 'Lead' );
		add_option( 'wppe_bridge_module_thank_you_pixel_enabled', false );
		add_option( 'wppe_bridge_thank_you_pixel_pages', array() );

		// Widget de Contacto (D-W1, v2.11.0) — off por default.
		add_option( 'wppe_bridge_module_contact_widget_enabled', false );
		add_option( 'wppe_bridge_widget_appearance', array() );
		add_option( 'wppe_bridge_widget_whatsapp_number', '' );
		add_option( 'wppe_bridge_widget_greeting', 'Hola 👋 ¿En que te ayudamos?' );
		add_option( 'wppe_bridge_widget_page_rules', array() );
		add_option( 'wppe_bridge_widget_channels', array() );
		add_option( 'wppe_bridge_widget_custom_links', array() );
		add_option( 'wppe_bridge_widget_consent', array() );
		add_option( 'wppe_bridge_widget_mapping_defaults', array() );

		// Lead Scoring global (D-W10, v2.12.0) — off por default.
		add_option( 'wppe_bridge_scoring_enabled', false );
		add_option( 'wppe_bridge_scoring_weights', array() );
		add_option( 'wppe_bridge_scoring_bands', array() );
		add_option( 'wppe_bridge_scoring_question', array() );

		// Guardrails (v2.11.0).
		add_option( 'wppe_bridge_sales_contact', '' );
		add_option( 'wppe_bridge_cache_alerted', '' );
	}

	/**
	 * Agenda el cron del worker. Filtro de schedules custom registrado
	 * tambien aqui de forma anticipada (el filtro se mantiene activo
	 * en runtime via Plugin::register_hooks en una iteracion siguiente).
	 */
	private static function schedule_cron(): void {
		// phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- Worker outbox: 1 minuto es necesario para latencia razonable hacia Sperant.
		add_filter( 'cron_schedules', array( __CLASS__, 'register_cron_schedule' ) );

		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, self::CRON_SCHEDULE, self::CRON_HOOK );
		}

		// Cleanup diario de logs.
		if ( ! wp_next_scheduled( self::CRON_HOOK_LOGS_CLEANUP ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, self::CRON_SCHEDULE_DAILY, self::CRON_HOOK_LOGS_CLEANUP );
		}

		// V2.5.9 — Cleanup diario de queue (retention LPDP). Offset 2h
		// para no chocar con logs cleanup (offset 1h).
		if ( ! wp_next_scheduled( self::CRON_HOOK_QUEUE_CLEANUP ) ) {
			wp_schedule_event( time() + ( 2 * HOUR_IN_SECONDS ), self::CRON_SCHEDULE_DAILY, self::CRON_HOOK_QUEUE_CLEANUP );
		}

		// Whitelist refresh diario (v1.1.0).
		if ( class_exists( 'WPPE_Bridge_Whitelist_Client' )
			&& ! wp_next_scheduled( WPPE_Bridge_Whitelist_Client::CRON_HOOK_REFRESH ) ) {
			wp_schedule_event(
				time() + HOUR_IN_SECONDS,
				self::CRON_SCHEDULE_DAILY,
				WPPE_Bridge_Whitelist_Client::CRON_HOOK_REFRESH
			);
		}

		// Notifier tick cada 5 min (v2.4.0). El tick chequea buffer +
		// throttle y envia email batched si corresponde.
		if ( class_exists( 'WPPE_Bridge_Notifier' )
			&& ! wp_next_scheduled( WPPE_Bridge_Notifier::CRON_HOOK_TICK ) ) {
			wp_schedule_event(
				time() + ( 5 * MINUTE_IN_SECONDS ),
				self::CRON_SCHEDULE_5MIN,
				WPPE_Bridge_Notifier::CRON_HOOK_TICK
			);
		}
	}

	/**
	 * Filter callback para registrar el schedule custom de 1 minuto.
	 *
	 * @param array $schedules Schedules existentes.
	 * @return array
	 */
	public static function register_cron_schedule( array $schedules ): array {
		$schedules[ self::CRON_SCHEDULE ] = array(
			'interval' => MINUTE_IN_SECONDS,
			'display'  => __( 'Cada minuto (WP.pe Bridge)', 'wppe-bridge' ),
		);
		// v2.4.0: schedule de 5 min para el Notifier tick.
		$schedules[ self::CRON_SCHEDULE_5MIN ] = array(
			'interval' => 5 * MINUTE_IN_SECONDS,
			'display'  => __( 'Cada 5 minutos (WP.pe Bridge)', 'wppe-bridge' ),
		);
		return $schedules;
	}
}
