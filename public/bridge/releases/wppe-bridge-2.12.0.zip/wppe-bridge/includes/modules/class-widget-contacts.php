<?php
/**
 * Modelo de Contactos del Widget (v2.12.0, D-W9).
 *
 * Reemplaza el modelo v2.11 de "un numero global + reglas que lo
 * sobreescriben" por una lista de CONTACTOS, cada uno con su
 * configuracion completa: nombre visible, avatar, canal, pais, numero,
 * saludo y horario propio.
 *
 * Beneficio inmediato: multi-agente (varios contactos con horarios
 * distintos) sale gratis, y las reglas por pagina pasan a decidir QUE
 * contactos se muestran donde, en vez de sobreescribir campos sueltos.
 *
 * @package WPPE_Bridge
 * @since 2.12.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * CRUD y resolucion de los contactos del widget.
 */
final class WPPE_Bridge_Widget_Contacts {

	/**
	 * Option que guarda la lista de contactos.
	 */
	public const OPTION_CONTACTS = 'wppe_bridge_widget_contacts';

	/**
	 * Flag de migracion del modelo v2.11 -> v2.12 (idempotencia).
	 */
	public const OPTION_MIGRATED = 'wppe_bridge_widget_contacts_migrated';

	/**
	 * Maximo de contactos configurables.
	 */
	public const MAX_CONTACTS = 20;

	/**
	 * Canales validos de un contacto.
	 */
	public const VALID_CHANNELS = array( 'whatsapp', 'llamada' );

	/**
	 * Comportamientos fuera de horario por canal.
	 */
	public const OFF_BEHAVIORS_WHATSAPP = array( 'note', 'hide' );
	public const OFF_BEHAVIORS_LLAMADA  = array( 'schedule_only', 'hide' );

	/**
	 * Codigos de pais soportados: ISO => prefijo telefonico. Peru
	 * primero porque es el default del producto (D6 ya asume +51).
	 *
	 * @var array<string,string>
	 */
	public const COUNTRIES = array(
		'PE' => '+51',
		'CL' => '+56',
		'CO' => '+57',
		'MX' => '+52',
		'AR' => '+54',
		'EC' => '+593',
		'BO' => '+591',
		'US' => '+1',
		'ES' => '+34',
	);

	/**
	 * Pais por defecto.
	 */
	public const DEFAULT_COUNTRY = 'PE';

	/**
	 * Shape de un contacto nuevo (defaults).
	 *
	 * @return array<string,mixed>
	 */
	public static function defaults(): array {
		return array(
			'id'             => '',
			'label'          => '',
			'role'           => '',
			'avatar_id'      => 0,
			'channel'        => 'whatsapp',
			'country'        => self::DEFAULT_COUNTRY,
			'number'         => '',
			'greeting'       => '',
			'enabled'        => true,
			'hours_enabled'  => false,
			'days'           => array( 1, 2, 3, 4, 5 ),
			'start'          => '09:00',
			'end'            => '18:00',
			'off_behavior'   => 'note',
			'allow_schedule' => true,
		);
	}

	/**
	 * Lee la lista de contactos saneada.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function all(): array {
		$raw = get_option( self::OPTION_CONTACTS, array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$out = array();
		foreach ( $raw as $contact ) {
			if ( ! is_array( $contact ) ) {
				continue;
			}
			$clean = array_merge( self::defaults(), array_intersect_key( $contact, self::defaults() ) );

			// Defensa en profundidad ante options corruptas (el
			// sanitizer del settings page ya valida al guardar).
			if ( '' === (string) $clean['id'] || '' === (string) $clean['number'] ) {
				continue;
			}
			if ( ! in_array( $clean['channel'], self::VALID_CHANNELS, true ) ) {
				$clean['channel'] = 'whatsapp';
			}
			if ( ! isset( self::COUNTRIES[ $clean['country'] ] ) ) {
				$clean['country'] = self::DEFAULT_COUNTRY;
			}
			$clean['enabled'] = (bool) $clean['enabled'];
			$clean['days']    = array_values( array_map( 'intval', (array) $clean['days'] ) );

			$out[] = $clean;
		}

		return $out;
	}

	/**
	 * Solo los contactos activos.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function active(): array {
		return array_values(
			array_filter(
				self::all(),
				static fn( array $c ): bool => ! empty( $c['enabled'] )
			)
		);
	}

	/**
	 * Busca un contacto por id.
	 *
	 * @param string $id Id del contacto.
	 * @return array<string,mixed>|null
	 */
	public static function find( string $id ): ?array {
		foreach ( self::all() as $contact ) {
			if ( (string) $contact['id'] === $id ) {
				return $contact;
			}
		}
		return null;
	}

	/**
	 * Numero completo en E.164 (prefijo de pais + numero local).
	 *
	 * @param array<string,mixed> $contact Contacto.
	 * @return string Ej. "+51999888777".
	 */
	public static function full_number( array $contact ): string {
		$prefix = self::COUNTRIES[ $contact['country'] ] ?? self::COUNTRIES[ self::DEFAULT_COUNTRY ];
		$local  = preg_replace( '/\D/', '', (string) $contact['number'] );
		return $prefix . ( is_string( $local ) ? $local : '' );
	}

	/**
	 * URL del avatar del contacto ('' si no tiene o no existe).
	 *
	 * @param array<string,mixed> $contact Contacto.
	 * @return string
	 */
	public static function avatar_url( array $contact ): string {
		$id = (int) ( $contact['avatar_id'] ?? 0 );
		if ( $id <= 0 || ! function_exists( 'wp_get_attachment_image_url' ) ) {
			return '';
		}
		$url = wp_get_attachment_image_url( $id, 'thumbnail' );
		return is_string( $url ) ? $url : '';
	}

	/**
	 * Config de horario del contacto para embeber en el HTML (D-W7:
	 * la disponibilidad se evalua client-side sobre config estatica).
	 *
	 * @param array<string,mixed> $contact Contacto.
	 * @return array<string,mixed>
	 */
	public static function schedule_of( array $contact ): array {
		return array(
			'enabled' => ! empty( $contact['hours_enabled'] ),
			'days'    => array_values( array_map( 'intval', (array) $contact['days'] ) ),
			'start'   => (string) $contact['start'],
			'end'     => (string) $contact['end'],
			'off'     => (string) $contact['off_behavior'],
		);
	}

	/**
	 * Migracion del modelo v2.11 (numero global + canales + saludo) al
	 * modelo de contactos. Idempotente via OPTION_MIGRATED.
	 *
	 * En v2.11.0 el modulo se publico OFF por default, asi que en la
	 * practica casi ningun sitio tendra config previa — pero si alguien
	 * alcanzo a configurarlo, no se pierde: el numero de WhatsApp se
	 * convierte en el primer contacto y la central telefonica (si
	 * estaba activa) en el segundo.
	 *
	 * @return int Cantidad de contactos creados.
	 */
	public static function maybe_migrate_from_v211(): int {
		if ( get_option( self::OPTION_MIGRATED, false ) ) {
			return 0;
		}
		update_option( self::OPTION_MIGRATED, true );

		// Si ya hay contactos (instalacion nueva que arranco en v2.12),
		// no hay nada que migrar.
		$existing = get_option( self::OPTION_CONTACTS, array() );
		if ( is_array( $existing ) && ! empty( $existing ) ) {
			return 0;
		}

		$legacy_number = (string) get_option( 'wppe_bridge_widget_whatsapp_number', '' );
		$legacy_greet  = (string) get_option( 'wppe_bridge_widget_greeting', '' );
		$legacy_chan   = get_option( 'wppe_bridge_widget_channels', array() );
		$legacy_chan   = is_array( $legacy_chan ) ? $legacy_chan : array();

		$contacts = array();

		if ( '' !== $legacy_number ) {
			$contacts[] = array_merge(
				self::defaults(),
				array(
					'id'            => 'whatsapp-1',
					'label'         => __( 'WhatsApp', 'wppe-bridge' ),
					'channel'       => 'whatsapp',
					'country'       => self::DEFAULT_COUNTRY,
					'number'        => self::strip_country_prefix( $legacy_number ),
					'greeting'      => $legacy_greet,
					'enabled'       => ! empty( $legacy_chan['whatsapp_enabled'] ) || ! isset( $legacy_chan['whatsapp_enabled'] ),
					'hours_enabled' => ! empty( $legacy_chan['whatsapp_hours_enabled'] ),
					'days'          => isset( $legacy_chan['whatsapp_days'] ) ? (array) $legacy_chan['whatsapp_days'] : self::defaults()['days'],
					'start'         => (string) ( $legacy_chan['whatsapp_start'] ?? '09:00' ),
					'end'           => (string) ( $legacy_chan['whatsapp_end'] ?? '18:00' ),
					'off_behavior'  => (string) ( $legacy_chan['whatsapp_off_behavior'] ?? 'note' ),
				)
			);
		}

		$central = (string) ( $legacy_chan['central_number'] ?? '' );
		if ( '' !== $central ) {
			$contacts[] = array_merge(
				self::defaults(),
				array(
					'id'             => 'llamada-1',
					'label'          => __( 'Llamada', 'wppe-bridge' ),
					'channel'        => 'llamada',
					'country'        => self::DEFAULT_COUNTRY,
					'number'         => self::strip_country_prefix( $central ),
					'greeting'       => $legacy_greet,
					'enabled'        => ! empty( $legacy_chan['llamada_enabled'] ),
					'hours_enabled'  => ! empty( $legacy_chan['llamada_hours_enabled'] ),
					'days'           => isset( $legacy_chan['llamada_days'] ) ? (array) $legacy_chan['llamada_days'] : self::defaults()['days'],
					'start'          => (string) ( $legacy_chan['llamada_start'] ?? '09:00' ),
					'end'            => (string) ( $legacy_chan['llamada_end'] ?? '18:00' ),
					'off_behavior'   => (string) ( $legacy_chan['llamada_off_behavior'] ?? 'schedule_only' ),
					'allow_schedule' => ! empty( $legacy_chan['allow_schedule'] ),
				)
			);
		}

		if ( empty( $contacts ) ) {
			return 0;
		}

		update_option( self::OPTION_CONTACTS, $contacts );

		if ( class_exists( 'WPPE_Bridge_Logger' ) ) {
			WPPE_Bridge_Logger::info(
				'widget_contacts_migrated',
				array( 'count' => count( $contacts ) )
			);
		}

		return count( $contacts );
	}

	/**
	 * Separa el prefijo de pais de un numero E.164 legacy para quedarse
	 * con la parte local (el pais viaja aparte en el modelo nuevo).
	 *
	 * @param string $number Numero legacy (puede traer +51...).
	 * @return string Numero local, solo digitos.
	 */
	public static function strip_country_prefix( string $number ): string {
		$digits = preg_replace( '/\D/', '', $number );
		$digits = is_string( $digits ) ? $digits : '';

		foreach ( self::COUNTRIES as $prefix ) {
			$bare = ltrim( $prefix, '+' );
			if ( 0 === strpos( $digits, $bare ) && strlen( $digits ) > strlen( $bare ) ) {
				return substr( $digits, strlen( $bare ) );
			}
		}

		return $digits;
	}
}
