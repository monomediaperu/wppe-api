<?php
/**
 * Modulo opcional Widget de Contacto (D-W1).
 *
 * Boton flotante de contacto (WhatsApp + Llamada) con pre-captura de
 * datos: el visitante deja nombre/telefono ANTES de saltar al canal,
 * el lead entra al pipeline CRM con su atribucion (UTMs/gclid de la
 * cookie del modulo UTM Capture) y el visitante recibe un codigo de
 * referencia para cruzar la conversacion con el lead del CRM.
 *
 * Estado del ciclo (4 PRs):
 * - PR-1: endpoint REST publico + rate limiter + adapter. ✔
 * - PR-2 (este): render del boton flotante + apariencia + reglas por
 *   pagina. El panel abre un link directo a WhatsApp (estilo click-to-
 *   chat clasico); PR-3 lo reemplaza por el pre-chat de captura.
 * - PR-3: flujos por canal (pre-chat, llamada, enlaces).
 * - PR-4: horarios client-side + lead scoring.
 *
 * Rendimiento (D-W4): el HTML del widget se resuelve server-side SOLO
 * en funcion de options + path del request — byte a byte identico
 * entre cargas de la misma pagina, cacheable sin exclusiones. En
 * paginas donde el widget no aplica (reglas) no se enqueua NADA.
 *
 * @package WPPE_Bridge
 * @since 2.11.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Modulo Contact Widget: endpoint REST + render frontend del boton.
 */
final class WPPE_Bridge_Module_Contact_Widget {

	/**
	 * Slug del modulo (usado como key en wp_options).
	 */
	public const SLUG = 'contact_widget';

	/**
	 * Option key de enabled.
	 */
	public const OPTION_ENABLED = 'wppe_bridge_module_contact_widget_enabled';

	/**
	 * Option de apariencia (array: position, color_primary, color_text,
	 * icon, icon_custom_url, cta_label).
	 */
	public const OPTION_APPEARANCE = 'wppe_bridge_widget_appearance';

	/**
	 * Option del numero de WhatsApp global (overridable por regla).
	 */
	public const OPTION_WHATSAPP_NUMBER = 'wppe_bridge_widget_whatsapp_number';

	/**
	 * Option del saludo global (overridable por regla).
	 */
	public const OPTION_GREETING = 'wppe_bridge_widget_greeting';

	/**
	 * Option de reglas por pagina. Array de rules:
	 * `{pattern, action(show|hide), greeting, number}` — first match
	 * wins contra el path del request. Sin match => visible con
	 * defaults globales.
	 */
	public const OPTION_PAGE_RULES = 'wppe_bridge_widget_page_rules';

	/**
	 * Option de canales (array: whatsapp_enabled, llamada_enabled,
	 * central_number, allow_schedule).
	 */
	public const OPTION_CHANNELS = 'wppe_bridge_widget_channels';

	/**
	 * Option de enlaces personalizados (D-W8): array de
	 * `{label, url}` — links medidos SIN flujo de captura.
	 */
	public const OPTION_CUSTOM_LINKS = 'wppe_bridge_widget_custom_links';

	/**
	 * Option de consentimiento (array: privacy_url, text).
	 */
	public const OPTION_CONSENT = 'wppe_bridge_widget_consent';


	/**
	 * Defaults de canales, incluyendo horarios (D-W7). Los horarios se
	 * evaluan CLIENT-SIDE contra la timezone del sitio para preservar
	 * el HTML byte-identico (D-W4): el server siempre emite la misma
	 * config; el JS decide que mostrar segun la hora del visitante.
	 *
	 * `*_off_behavior`: comportamiento fuera de horario —
	 * whatsapp: `note` (mostrar con aviso de respuesta diferida) o
	 * `hide`; llamada: `schedule_only` (solo "programar llamada",
	 * el caso "domingos sin call center") o `hide`.
	 */
	public const CHANNELS_DEFAULTS = array(
		'whatsapp_enabled'       => true,
		'llamada_enabled'        => false,
		'central_number'         => '',
		'allow_schedule'         => true,
		'whatsapp_hours_enabled' => false,
		'whatsapp_days'          => array( 1, 2, 3, 4, 5 ),
		'whatsapp_start'         => '09:00',
		'whatsapp_end'           => '18:00',
		'whatsapp_off_behavior'  => 'note',
		'llamada_hours_enabled'  => false,
		'llamada_days'           => array( 1, 2, 3, 4, 5 ),
		'llamada_start'          => '09:00',
		'llamada_end'            => '18:00',
		'llamada_off_behavior'   => 'schedule_only',
	);


	/**
	 * Texto default del consentimiento (Ley 29733).
	 */
	public const CONSENT_DEFAULT_TEXT = 'Acepto el tratamiento de mis datos personales para ser contactado sobre mi consulta.';

	/**
	 * Handles de assets frontend.
	 */
	public const ASSET_HANDLE_CSS = 'wppe-bridge-contact-widget';
	public const ASSET_HANDLE_JS  = 'wppe-bridge-contact-widget';

	/**
	 * Defaults de apariencia.
	 */
	public const APPEARANCE_DEFAULTS = array(
		'position'        => 'br',
		'color_primary'   => '#25D366',
		'color_text'      => '#ffffff',
		'icon'            => 'whatsapp',
		'icon_custom_url' => '',
		'cta_label'       => 'Conversemos',
		// Titulo del panel cuando hay VARIOS contactos (con uno solo se
		// muestra su saludo propio).
		'panel_title'     => '¿Con quién quieres hablar?',
	);

	/**
	 * Valores validos de position e icon.
	 */
	public const VALID_POSITIONS = array( 'br', 'bl' );
	public const VALID_ICONS     = array( 'whatsapp', 'chat', 'phone' );

	/**
	 * Lee si el modulo esta enabled.
	 *
	 * @return bool
	 */
	public static function is_enabled(): bool {
		return (bool) get_option( self::OPTION_ENABLED, false );
	}

	/**
	 * Registra hooks runtime. Llamado desde Plugin::register_hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		// Migracion v2.11 -> v2.12 del modelo de contactos. Idempotente
		// (option-flag): tras la primera corrida es un solo get_option.
		if ( class_exists( 'WPPE_Bridge_Widget_Contacts' ) ) {
			WPPE_Bridge_Widget_Contacts::maybe_migrate_from_v211();
		}
		add_action( 'rest_api_init', array( 'WPPE_Bridge_Widget_Controller', 'register_routes' ) );
		add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue_frontend' ) );
		add_action( 'wp_footer', array( self::class, 'render_widget' ), 20 );
	}

	/**
	 * Apariencia resuelta (defaults + option, whitelisted).
	 *
	 * @return array<string,string>
	 */
	public static function get_appearance(): array {
		$raw = get_option( self::OPTION_APPEARANCE, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}
		$out = array_merge( self::APPEARANCE_DEFAULTS, array_intersect_key( $raw, self::APPEARANCE_DEFAULTS ) );

		// Defensa en profundidad ante options corruptas (el sanitizer
		// del settings page ya valida al guardar).
		if ( ! in_array( $out['position'], self::VALID_POSITIONS, true ) ) {
			$out['position'] = self::APPEARANCE_DEFAULTS['position'];
		}
		if ( ! in_array( $out['icon'], self::VALID_ICONS, true ) ) {
			$out['icon'] = self::APPEARANCE_DEFAULTS['icon'];
		}
		foreach ( array( 'color_primary', 'color_text' ) as $key ) {
			if ( ! is_string( $out[ $key ] ) || ! preg_match( '/^#[0-9a-fA-F]{3,8}$/', $out[ $key ] ) ) {
				$out[ $key ] = self::APPEARANCE_DEFAULTS[ $key ];
			}
		}
		if ( ! is_string( $out['panel_title'] ) || '' === trim( $out['panel_title'] ) ) {
			$out['panel_title'] = self::APPEARANCE_DEFAULTS['panel_title'];
		}
		return $out;
	}

	/**
	 * Reglas por pagina saneadas (modelo v2.12).
	 *
	 * Una regla ahora decide QUE CONTACTOS se muestran, en vez de
	 * sobreescribir campos sueltos. El target puede ser un conjunto de
	 * paginas WP (`page_ids`, seleccionadas de un listado) o un patron
	 * de URL (`pattern`, modo avanzado para rutas dinamicas).
	 *
	 * @return array<int,array{match_type:string,page_ids:int[],pattern:string,action:string,contacts:string[]}>
	 */
	public static function get_page_rules(): array {
		$raw = get_option( self::OPTION_PAGE_RULES, array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$rules = array();
		foreach ( $raw as $rule ) {
			if ( ! is_array( $rule ) ) {
				continue;
			}

			$match_type = ( isset( $rule['match_type'] ) && 'pattern' === $rule['match_type'] ) ? 'pattern' : 'page';
			$page_ids   = array_values( array_filter( array_map( 'intval', (array) ( $rule['page_ids'] ?? array() ) ) ) );
			$pattern    = isset( $rule['pattern'] ) && is_string( $rule['pattern'] ) ? $rule['pattern'] : '';

			// Una regla sin target no aplica a nada.
			if ( 'page' === $match_type && empty( $page_ids ) ) {
				continue;
			}
			if ( 'pattern' === $match_type && '' === trim( $pattern ) ) {
				continue;
			}

			$rules[] = array(
				'match_type' => $match_type,
				'page_ids'   => $page_ids,
				'pattern'    => $pattern,
				'action'     => ( isset( $rule['action'] ) && 'hide' === $rule['action'] ) ? 'hide' : 'show',
				'contacts'   => array_values(
					array_filter(
						array_map( 'strval', (array) ( $rule['contacts'] ?? array() ) ),
						static fn( string $id ): bool => '' !== $id
					)
				),
			);
		}
		return $rules;
	}

	/**
	 * True si la regla aplica al request actual.
	 *
	 * @param array  $rule            Regla saneada.
	 * @param string $path            Path del request.
	 * @param int    $current_page_id ID de la pagina actual (0 si no aplica).
	 * @return bool
	 */
	public static function rule_matches( array $rule, string $path, int $current_page_id ): bool {
		if ( 'page' === $rule['match_type'] ) {
			return $current_page_id > 0 && in_array( $current_page_id, $rule['page_ids'], true );
		}
		return self::path_matches( $rule['pattern'], $path );
	}

	/**
	 * Matchea un pattern de regla contra el path del request.
	 *
	 * Soporta: exacto (`/contacto`), prefijo con wildcard sufijo
	 * (`/depas*`) y catch-all (`*`). Trailing slash del path se
	 * normaliza (`/contacto/` == `/contacto`). Query string NO
	 * participa (la resolucion debe ser cacheable por URL de pagina).
	 *
	 * @param string $pattern Pattern de la regla.
	 * @param string $path    Path del request (con leading slash).
	 * @return bool
	 */
	public static function path_matches( string $pattern, string $path ): bool {
		$pattern = trim( $pattern );
		if ( '' === $pattern ) {
			return false;
		}
		if ( '*' === $pattern ) {
			return true;
		}

		// Normalizacion: leading slash + sin trailing slash.
		$normalize = static function ( string $value ): string {
			$value = '/' . ltrim( $value, '/' );
			return '/' === $value ? '/' : rtrim( $value, '/' );
		};

		$path = $normalize( strtok( $path, '?' ) );

		if ( str_ends_with( $pattern, '*' ) ) {
			$prefix = $normalize( substr( $pattern, 0, -1 ) );
			return 0 === strpos( $path . '/', rtrim( $prefix, '/' ) . '/' ) || $path === $prefix;
		}

		return $path === $normalize( $pattern );
	}

	/**
	 * Config de canales resuelta (defaults + option).
	 *
	 * @return array<string,mixed>
	 */
	public static function get_channels(): array {
		$raw = get_option( self::OPTION_CHANNELS, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}
		return array_merge( self::CHANNELS_DEFAULTS, array_intersect_key( $raw, self::CHANNELS_DEFAULTS ) );
	}

	/**
	 * Enlaces personalizados saneados.
	 *
	 * @return array<int,array{label:string,url:string}>
	 */
	public static function get_custom_links(): array {
		$raw = get_option( self::OPTION_CUSTOM_LINKS, array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$links = array();
		foreach ( $raw as $link ) {
			if ( ! is_array( $link ) || empty( $link['label'] ) || empty( $link['url'] )
				|| ! is_string( $link['label'] ) || ! is_string( $link['url'] ) ) {
				continue;
			}
			$links[] = array(
				'label'    => $link['label'],
				'url'      => $link['url'],
				// Los internos abren en la misma pestaña; los externos
				// en una nueva (v2.12.0 PR-2).
				'internal' => ! empty( $link['internal'] ),
				'type'     => isset( $link['type'] ) && 'internal' === $link['type'] ? 'internal' : 'external',
				'page_id'  => isset( $link['page_id'] ) ? (int) $link['page_id'] : 0,
			);
		}
		return $links;
	}


	/**
	 * Timezone del sitio para la evaluacion client-side de horarios
	 * (D-W7): nombre IANA si esta configurado, sino offset `+HH:MM`
	 * desde gmt_offset. El JS soporta ambos formatos.
	 *
	 * @return string Ej. "America/Lima" o "-05:00".
	 */
	public static function site_timezone(): string {
		$tz = get_option( 'timezone_string', '' );
		if ( is_string( $tz ) && '' !== $tz ) {
			return $tz;
		}
		$offset  = (float) get_option( 'gmt_offset', 0 );
		$hours   = (int) $offset;
		$minutes = (int) round( abs( $offset - $hours ) * 60 );
		return sprintf( '%+03d:%02d', $hours, $minutes );
	}

	/**
	 * Config de horarios por canal para embeber en el HTML (JSON
	 * estatico — mismo para todos los visitantes de la pagina).
	 *
	 * @return array<string,array>
	 */
	public static function schedule_config(): array {
		$channels = self::get_channels();
		$build    = static function ( string $prefix ) use ( $channels ): array {
			return array(
				'enabled' => ! empty( $channels[ $prefix . '_hours_enabled' ] ),
				'days'    => array_values( array_map( 'intval', (array) $channels[ $prefix . '_days' ] ) ),
				'start'   => (string) $channels[ $prefix . '_start' ],
				'end'     => (string) $channels[ $prefix . '_end' ],
				'off'     => (string) $channels[ $prefix . '_off_behavior' ],
			);
		};
		return array(
			'whatsapp' => $build( 'whatsapp' ),
			'llamada'  => $build( 'llamada' ),
		);
	}

	/**
	 * Config de consentimiento (Ley 29733).
	 *
	 * @return array{privacy_url:string,text:string}
	 */
	public static function get_consent(): array {
		$raw = get_option( self::OPTION_CONSENT, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}
		$text = isset( $raw['text'] ) && is_string( $raw['text'] ) && '' !== trim( $raw['text'] )
			? $raw['text']
			: self::CONSENT_DEFAULT_TEXT;
		return array(
			'privacy_url' => isset( $raw['privacy_url'] ) && is_string( $raw['privacy_url'] ) ? $raw['privacy_url'] : '',
			'text'        => $text,
		);
	}

	/**
	 * Resuelve QUE CONTACTOS se muestran en esta pagina (modelo v2.12).
	 *
	 * First-match-wins sobre las reglas:
	 *   - `hide`  => null (widget oculto aqui).
	 *   - `show`  => los contactos listados en la regla (si la regla no
	 *                lista ninguno, todos los activos).
	 *   - Sin match => todos los contactos activos.
	 *
	 * @param string $path            Path del request.
	 * @param int    $current_page_id ID de la pagina actual (0 si no aplica).
	 * @return array<int,array<string,mixed>>|null null = oculto por regla.
	 */
	public static function resolve_contacts_for_path( string $path, int $current_page_id = 0 ): ?array {
		$active = WPPE_Bridge_Widget_Contacts::active();

		foreach ( self::get_page_rules() as $rule ) {
			if ( ! self::rule_matches( $rule, $path, $current_page_id ) ) {
				continue;
			}
			if ( 'hide' === $rule['action'] ) {
				return null;
			}
			if ( ! empty( $rule['contacts'] ) ) {
				$active = array_values(
					array_filter(
						$active,
						static fn( array $c ): bool => in_array( (string) $c['id'], $rule['contacts'], true )
					)
				);
			}
			break;
		}

		return $active;
	}

	/**
	 * Decide si el widget tiene algo que ofrecer en esta pagina: al
	 * menos un contacto activo o un enlace personalizado.
	 *
	 * @param array|null $contacts Contactos resueltos (null = oculto).
	 * @return bool
	 */
	public static function should_render( ?array $contacts ): bool {
		if ( null === $contacts ) {
			return false;
		}
		return ! empty( $contacts ) || array() !== self::get_custom_links();
	}

	/**
	 * ID de la pagina/entrada actual, si el request es una singular.
	 *
	 * @return int
	 */
	public static function current_page_id(): int {
		return function_exists( 'get_queried_object_id' ) ? (int) get_queried_object_id() : 0;
	}

	/**
	 * Path actual del request (sin query string).
	 *
	 * @return string
	 */
	public static function current_path(): string {
		if ( ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return '/';
		}
		$uri  = sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) );
		$path = wp_parse_url( $uri, PHP_URL_PATH );
		return is_string( $path ) && '' !== $path ? $path : '/';
	}

	/**
	 * Enqueua CSS + JS del widget SOLO si va a renderizar en esta
	 * pagina (cero bytes donde las reglas lo ocultan).
	 *
	 * @return void
	 */
	public static function enqueue_frontend(): void {
		$contacts = self::resolve_contacts_for_path( self::current_path(), self::current_page_id() );
		if ( ! self::should_render( $contacts ) ) {
			return;
		}
		wp_enqueue_style(
			self::ASSET_HANDLE_CSS,
			WPPE_BRIDGE_PLUGIN_URL . 'assets/css/contact-widget.css',
			array(),
			WPPE_BRIDGE_VERSION
		);
		wp_enqueue_script(
			self::ASSET_HANDLE_JS,
			WPPE_BRIDGE_PLUGIN_URL . 'assets/js/contact-widget.js',
			array(),
			WPPE_BRIDGE_VERSION,
			true
		);
	}

	/**
	 * Config de la pregunta calificadora si corresponde mostrarla:
	 * el scoring global debe estar activo Y la pregunta habilitada.
	 *
	 * @return array<string,string>|null null = no se muestra.
	 */
	public static function qualifier_config(): ?array {
		if ( ! class_exists( 'WPPE_Bridge_Lead_Scoring' ) || ! WPPE_Bridge_Lead_Scoring::is_enabled() ) {
			return null;
		}
		$question = WPPE_Bridge_Lead_Scoring::question();
		if ( empty( $question['enabled'] ) ) {
			return null;
		}
		return $question;
	}

	/**
	 * URL del endpoint REST del widget. Fallback al path estandar
	 * cuando rest_url no esta disponible (tests).
	 *
	 * @return string
	 */
	public static function endpoint_url(): string {
		if ( function_exists( 'rest_url' ) ) {
			return rest_url( 'wppe-bridge/v1/widget/lead' );
		}
		return home_url( '/wp-json/wppe-bridge/v1/widget/lead' );
	}

	/**
	 * Renderiza el widget en wp_footer. HTML estatico: depende solo de
	 * options + path (byte-identico entre cargas de la misma pagina).
	 *
	 * El panel ofrece los canales activos. WhatsApp y Llamada abren el
	 * pre-chat de captura (el lead entra al CRM ANTES de saltar al
	 * canal); los enlaces personalizados (D-W8) son links directos.
	 * El JS resuelve la interaccion leyendo los data-attributes — todo
	 * el estado esta embebido, cero requests de config.
	 *
	 * @return void
	 */
	public static function render_widget(): void {
		$contacts = self::resolve_contacts_for_path( self::current_path(), self::current_page_id() );
		if ( ! self::should_render( $contacts ) ) {
			return;
		}

		$appearance = self::get_appearance();
		$consent    = self::get_consent();
		$links      = self::get_custom_links();

		// Un solo contacto: el panel va directo al pre-chat (misma UX
		// que v2.11). Varios: se listan para elegir con quien hablar.
		$single       = 1 === count( $contacts );
		$has_llamada  = false;
		$contacts_cfg = array();
		foreach ( $contacts as $contact ) {
			if ( 'llamada' === $contact['channel'] ) {
				$has_llamada = true;
			}
			$contacts_cfg[ (string) $contact['id'] ] = array(
				'channel'     => (string) $contact['channel'],
				'number'      => ltrim( WPPE_Bridge_Widget_Contacts::full_number( $contact ), '+' ),
				'greeting'    => (string) $contact['greeting'],
				'schedule'    => WPPE_Bridge_Widget_Contacts::schedule_of( $contact ),
				'schedulable' => ! empty( $contact['allow_schedule'] ),
			);
		}

		$style = sprintf(
			'--wppe-cw-primary:%s;--wppe-cw-text:%s;',
			$appearance['color_primary'],
			$appearance['color_text']
		);
		?>
<div class="wppe-cw wppe-cw--<?php echo esc_attr( $appearance['position'] ); ?>" data-wppe-cw
	data-endpoint="<?php echo esc_url( self::endpoint_url() ); ?>"
	data-widget-id="default"
	data-single="<?php echo $single ? '1' : '0'; ?>"
	data-tz="<?php echo esc_attr( self::site_timezone() ); ?>"
	data-contacts="<?php echo esc_attr( (string) wp_json_encode( $contacts_cfg ) ); ?>"
	style="<?php echo esc_attr( $style ); ?>">
	<div class="wppe-cw__panel" id="wppe-cw-panel" hidden>
		<p class="wppe-cw__greeting" data-cw-greeting><?php echo esc_html( $single && isset( $contacts[0] ) ? (string) $contacts[0]['greeting'] : $appearance['panel_title'] ); ?></p>

		<div class="wppe-cw__channels">
			<?php foreach ( $contacts as $contact ) : ?>
				<?php $avatar = WPPE_Bridge_Widget_Contacts::avatar_url( $contact ); ?>
			<button type="button" class="wppe-cw__contact" data-cw-contact="<?php echo esc_attr( (string) $contact['id'] ); ?>">
				<?php if ( '' !== $avatar ) : ?>
				<img class="wppe-cw__avatar" src="<?php echo esc_url( $avatar ); ?>" alt="" width="36" height="36" loading="lazy" />
				<?php endif; ?>
				<span class="wppe-cw__contact-text">
					<span class="wppe-cw__contact-name"><?php echo esc_html( (string) $contact['label'] ); ?></span>
					<?php if ( '' !== (string) $contact['role'] ) : ?>
					<span class="wppe-cw__contact-role"><?php echo esc_html( (string) $contact['role'] ); ?></span>
					<?php endif; ?>
				</span>
			</button>
			<?php endforeach; ?>

			<?php foreach ( $links as $link ) : ?>
			<a class="wppe-cw__channel wppe-cw__channel--link" href="<?php echo esc_url( $link['url'] ); ?>"<?php echo empty( $link['internal'] ) ? ' target="_blank" rel="noopener nofollow"' : ''; ?>>
				<?php echo esc_html( $link['label'] ); ?>
			</a>
			<?php endforeach; ?>
		</div>

		<?php if ( ! empty( $contacts ) ) : ?>
		<form class="wppe-cw__form" hidden novalidate>
			<input type="text" name="website" class="wppe-cw__hp" tabindex="-1" autocomplete="off" aria-hidden="true" />
			<label class="wppe-cw__field">
				<span><?php esc_html_e( 'Nombre *', 'wppe-bridge' ); ?></span>
				<input type="text" name="name" required maxlength="100" autocomplete="name" />
			</label>
			<label class="wppe-cw__field">
				<span><?php esc_html_e( 'Teléfono *', 'wppe-bridge' ); ?></span>
				<input type="tel" name="phone" required maxlength="20" autocomplete="tel" />
			</label>
			<label class="wppe-cw__field">
				<span><?php esc_html_e( 'Email (opcional)', 'wppe-bridge' ); ?></span>
				<input type="email" name="email" maxlength="100" autocomplete="email" />
			</label>
			<label class="wppe-cw__field">
				<span><?php esc_html_e( '¿Qué te interesa? (opcional)', 'wppe-bridge' ); ?></span>
				<input type="text" name="interest" maxlength="200" />
			</label>

			<?php
			// Pregunta calificadora (D-W10): la señal que mas predice un
			// cierre. Se configura en WP.pe Bridge -> Lead Scoring y solo
			// se renderiza si esta activa.
			$qualifier = self::qualifier_config();
			if ( null !== $qualifier ) :
				?>
			<label class="wppe-cw__field">
				<span><?php echo esc_html( $qualifier['label'] ); ?></span>
				<select name="qualifier">
					<option value=""><?php esc_html_e( 'Selecciona una opción', 'wppe-bridge' ); ?></option>
					<option value="high"><?php echo esc_html( $qualifier['high'] ); ?></option>
					<option value="medium"><?php echo esc_html( $qualifier['medium'] ); ?></option>
					<option value="low"><?php echo esc_html( $qualifier['low'] ); ?></option>
				</select>
			</label>
			<?php endif; ?>

			<?php if ( $has_llamada ) : ?>
			<fieldset class="wppe-cw__call" data-cw-call hidden>
				<label class="wppe-cw__radio">
					<input type="radio" name="call_pref" value="llamada_inmediata" checked />
					<span><?php esc_html_e( 'Llamar ahora', 'wppe-bridge' ); ?></span>
				</label>
				<label class="wppe-cw__radio" data-cw-schedule-opt>
					<input type="radio" name="call_pref" value="llamada_programada" />
					<span><?php esc_html_e( 'Programar una llamada', 'wppe-bridge' ); ?></span>
				</label>
				<div class="wppe-cw__schedule" data-cw-schedule hidden>
					<label class="wppe-cw__field">
						<span><?php esc_html_e( 'Fecha', 'wppe-bridge' ); ?></span>
						<input type="date" name="call_date" />
					</label>
					<label class="wppe-cw__field">
						<span><?php esc_html_e( 'Franja horaria', 'wppe-bridge' ); ?></span>
						<select name="call_slot">
							<option value="manana"><?php esc_html_e( 'Mañana (9am a 1pm)', 'wppe-bridge' ); ?></option>
							<option value="tarde"><?php esc_html_e( 'Tarde (2pm a 6pm)', 'wppe-bridge' ); ?></option>
						</select>
					</label>
				</div>
			</fieldset>
			<?php endif; ?>

			<label class="wppe-cw__consent">
				<input type="checkbox" name="consent" value="1" required />
				<span>
					<?php echo esc_html( $consent['text'] ); ?>
					<?php if ( '' !== $consent['privacy_url'] ) : ?>
						<a href="<?php echo esc_url( $consent['privacy_url'] ); ?>" target="_blank" rel="noopener">
							<?php esc_html_e( 'Política de privacidad', 'wppe-bridge' ); ?>
						</a>
					<?php endif; ?>
				</span>
			</label>

			<button type="submit" class="wppe-cw__action"><?php esc_html_e( 'Continuar', 'wppe-bridge' ); ?></button>
			<p class="wppe-cw__status" role="status" aria-live="polite"></p>
		</form>
		<?php endif; ?>
	</div>
	<button type="button" class="wppe-cw__toggle" aria-expanded="false" aria-controls="wppe-cw-panel">
		<?php echo self::icon_markup( $appearance ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- SVG estatico interno o <img> con esc_url, ver icon_markup. ?>
		<span class="wppe-cw__label"><?php echo esc_html( $appearance['cta_label'] ); ?></span>
	</button>
</div>
		<?php
	}

	/**
	 * Markup del icono: SVG inline del set predefinido, o <img> si el
	 * admin configuro un icono propio.
	 *
	 * @param array<string,string> $appearance Apariencia resuelta.
	 * @return string HTML del icono (interno o escapado).
	 */
	public static function icon_markup( array $appearance ): string {
		if ( ! empty( $appearance['icon_custom_url'] ) ) {
			return '<img class="wppe-cw__icon" src="' . esc_url( $appearance['icon_custom_url'] ) . '" alt="" width="24" height="24" loading="lazy" />';
		}

		$svgs = array(
			'whatsapp' => '<svg class="wppe-cw__icon" viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.5.1-.2.2-.6.8-.8 1-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.2-.4.7-1.3 0-.2 0-.3-.1-.4l-.8-1.8c-.2-.5-.4-.4-.5-.4h-.5c-.2 0-.4.1-.7.3-.2.3-.9.9-.9 2.1s.9 2.4 1 2.6a10 10 0 0 0 3.8 3.4c.5.2 1 .4 1.3.5.5.2 1 .1 1.4.1.4-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.1-1.2 0-.1-.2-.1-.4-.2z"/></svg>',
			'chat'     => '<svg class="wppe-cw__icon" viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><path d="M4 3h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H8l-4 4a1 1 0 0 1-1.7-.7V5A2 2 0 0 1 4 3zm3 5a1 1 0 1 0 0 2h10a1 1 0 1 0 0-2H7zm0 4a1 1 0 1 0 0 2h6a1 1 0 1 0 0-2H7z"/></svg>',
			'phone'    => '<svg class="wppe-cw__icon" viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><path d="M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.4.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.4 0 .8-.2 1l-2.3 2.2z"/></svg>',
		);

		return $svgs[ $appearance['icon'] ] ?? $svgs['whatsapp'];
	}
}
