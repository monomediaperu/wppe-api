<?php
/**
 * Lead Scoring global (v2.12.0, D-W10).
 *
 * Sale del Widget y pasa a ser una capa GLOBAL que puntua leads de
 * TODAS las fuentes (widget + Fluent + Gravity + Elementor + CF7).
 *
 * Modelo de 4 grupos con techo natural en 100, mas penalizaciones:
 *
 *   1. Intencion declarada (excluyentes, max 30) — que pidio.
 *   2. Calificacion (max 30) — quien es. Incluye la pregunta
 *      calificadora configurable, la señal mas predictiva.
 *   3. Calidad del contacto (max 15) — datos utilizables.
 *   4. Origen y comportamiento (max 25) — de donde vino.
 *   - Penalizaciones (hasta -35) — datos basura.
 *
 * Advertencia de diseño: los pesos por defecto son criterio
 * profesional, NO evidencia. Un modelo de scoring solo vale cuando se
 * calibra contra cierres reales — por eso el score INFORMA (ordena la
 * atencion del vendedor) y nunca filtra ni bloquea leads.
 *
 * @package WPPE_Bridge
 * @since 2.12.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Calculo y configuracion del lead scoring global.
 */
final class WPPE_Bridge_Lead_Scoring {

	/**
	 * Option de pesos.
	 */
	public const OPTION_WEIGHTS = 'wppe_bridge_scoring_weights';

	/**
	 * Option de umbrales de banda.
	 */
	public const OPTION_BANDS = 'wppe_bridge_scoring_bands';

	/**
	 * Option del enabled global.
	 */
	public const OPTION_ENABLED = 'wppe_bridge_scoring_enabled';

	/**
	 * Option de la pregunta calificadora (enunciado + 3 opciones).
	 */
	public const OPTION_QUESTION = 'wppe_bridge_scoring_question';

	/**
	 * Field del payload donde viaja el score numerico (mapeable a un
	 * campo del CRM desde la pagina de Mapeo).
	 */
	public const PAYLOAD_KEY = 'lead_score';

	/**
	 * Pesos por defecto. Diseñados para que el maximo practico caiga
	 * cerca de 100 (30 + 30 + 15 + 25).
	 *
	 * @var array<string,int>
	 */
	public const WEIGHT_DEFAULTS = array(
		// Grupo 1 — Intencion declarada (excluyentes).
		'channel_llamada_inmediata'  => 30,
		'channel_llamada_programada' => 24,
		'channel_whatsapp'           => 20,
		'channel_formulario'         => 10,

		// Grupo 2 — Calificacion.
		'question_high'              => 18,
		'question_medium'            => 8,
		'question_low'               => 0,
		'specific_interest'          => 6,
		'has_document'               => 6,

		// Grupo 3 — Calidad del contacto.
		'valid_phone'                => 5,
		'has_email'                  => 5,
		'plausible_name'             => 5,

		// Grupo 4 — Origen y comportamiento.
		'source_paid_search'         => 12,
		'source_organic'             => 10,
		'source_direct'              => 8,
		'source_paid_social'         => 6,
		'returning_visitor'          => 8,
		'off_hours'                  => 5,

		// Penalizaciones (valores positivos; se restan).
		'penalty_fake_data'          => 20,
		'penalty_disposable_email'   => 15,
		'penalty_minimal_effort'     => 5,
	);

	/**
	 * Umbrales de banda por defecto (limite inferior de cada una).
	 *
	 * @var array<string,int>
	 */
	public const BAND_DEFAULTS = array(
		'tibio'       => 30,
		'caliente'    => 60,
		'prioritario' => 80,
	);

	/**
	 * Dominios de correo temporal mas comunes (penalizacion).
	 *
	 * @var string[]
	 */
	public const DISPOSABLE_DOMAINS = array(
		'mailinator.com',
		'tempmail.com',
		'guerrillamail.com',
		'10minutemail.com',
		'yopmail.com',
		'trashmail.com',
		'sharklasers.com',
		'temp-mail.org',
	);

	/**
	 * Pregunta calificadora por defecto (inmobiliaria; el cliente la
	 * adapta a su vertical desde el admin).
	 *
	 * @return array<string,string>
	 */
	public static function question_defaults(): array {
		return array(
			'enabled' => '',
			'label'   => '¿Cuándo planeas comprar?',
			'high'    => 'Lo antes posible',
			'medium'  => 'En los próximos 3 a 6 meses',
			'low'     => 'Solo estoy explorando',
		);
	}

	/**
	 * True si el scoring global esta activo.
	 *
	 * @return bool
	 */
	public static function is_enabled(): bool {
		return (bool) get_option( self::OPTION_ENABLED, false );
	}

	/**
	 * Pesos resueltos (defaults + option, keys whitelisted).
	 *
	 * @return array<string,int>
	 */
	public static function weights(): array {
		$raw = get_option( self::OPTION_WEIGHTS, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}
		$out = self::WEIGHT_DEFAULTS;
		foreach ( $out as $key => $default ) {
			if ( isset( $raw[ $key ] ) && is_numeric( $raw[ $key ] ) ) {
				$out[ $key ] = max( 0, min( 100, (int) $raw[ $key ] ) );
			}
		}
		return $out;
	}

	/**
	 * Umbrales de banda resueltos y ordenados coherentemente.
	 *
	 * @return array<string,int>
	 */
	public static function bands(): array {
		$raw = get_option( self::OPTION_BANDS, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}
		$out = self::BAND_DEFAULTS;
		foreach ( $out as $key => $default ) {
			if ( isset( $raw[ $key ] ) && is_numeric( $raw[ $key ] ) ) {
				$out[ $key ] = max( 0, min( 100, (int) $raw[ $key ] ) );
			}
		}
		// Umbrales cruzados (ej. caliente < tibio) romperian la
		// clasificacion: los ordenamos de menor a mayor.
		$sorted = array_values( $out );
		sort( $sorted );
		return array_combine( array_keys( $out ), $sorted );
	}

	/**
	 * Config de la pregunta calificadora.
	 *
	 * @return array<string,string>
	 */
	public static function question(): array {
		$raw = get_option( self::OPTION_QUESTION, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}
		return array_merge( self::question_defaults(), array_intersect_key( $raw, self::question_defaults() ) );
	}

	/**
	 * Calcula el score de un lead.
	 *
	 * @param array $payload Payload normalizado (email, phone, fname, message, gclid...).
	 * @param array $context Señales extra de la fuente:
	 *                       `channel` (llamada_inmediata|llamada_programada|whatsapp|formulario),
	 *                       `question` (high|medium|low), `off_hours` (bool),
	 *                       `returning` (bool).
	 * @return int Score 0..100.
	 */
	public static function score( array $payload, array $context = array() ): int {
		$w     = self::weights();
		$score = 0;

		// --- Grupo 1: intencion declarada (excluyentes) ---
		$channel = isset( $context['channel'] ) ? (string) $context['channel'] : 'formulario';
		$key     = 'channel_' . $channel;
		$score  += isset( $w[ $key ] ) ? $w[ $key ] : $w['channel_formulario'];

		// --- Grupo 2: calificacion ---
		$answer = isset( $context['question'] ) ? (string) $context['question'] : '';
		if ( isset( $w[ 'question_' . $answer ] ) ) {
			$score += $w[ 'question_' . $answer ];
		}
		if ( ! empty( $payload['message'] ) || ! empty( $payload['project_id'] ) ) {
			$score += $w['specific_interest'];
		}
		if ( ! empty( $payload['document'] ) ) {
			$score += $w['has_document'];
		}

		// --- Grupo 3: calidad del contacto ---
		if ( self::is_valid_phone( (string) ( $payload['phone'] ?? '' ) ) ) {
			$score += $w['valid_phone'];
		}
		if ( ! empty( $payload['email'] ) ) {
			$score += $w['has_email'];
		}
		if ( self::is_plausible_name( (string) ( $payload['fname'] ?? '' ) ) ) {
			$score += $w['plausible_name'];
		}

		// --- Grupo 4: origen y comportamiento ---
		$score += $w[ 'source_' . self::classify_source( $payload ) ];
		if ( ! empty( $context['returning'] ) ) {
			$score += $w['returning_visitor'];
		}
		if ( ! empty( $context['off_hours'] ) ) {
			$score += $w['off_hours'];
		}

		// --- Penalizaciones ---
		if ( self::looks_fake( $payload ) ) {
			$score -= $w['penalty_fake_data'];
		}
		if ( self::is_disposable_email( (string) ( $payload['email'] ?? '' ) ) ) {
			$score -= $w['penalty_disposable_email'];
		}
		if ( empty( $payload['email'] ) && empty( $payload['message'] ) ) {
			$score -= $w['penalty_minimal_effort'];
		}

		return max( 0, min( 100, $score ) );
	}

	/**
	 * Clasifica el origen del lead segun su atribucion.
	 *
	 * Distingue busqueda pagada (intencion activa: te estaban buscando)
	 * de social pagado (interrupcion: te apareciste) — meterlos en la
	 * misma bolsa es el error de atribucion mas comun.
	 *
	 * @param array $payload Payload con UTMs.
	 * @return string paid_search|paid_social|organic|direct
	 */
	public static function classify_source( array $payload ): string {
		$source = strtolower( (string) ( $payload['utm_source'] ?? '' ) );
		$medium = strtolower( (string) ( $payload['utm_medium'] ?? '' ) );

		if ( ! empty( $payload['gclid'] ) ) {
			return 'paid_search';
		}
		if ( ! empty( $payload['fbclid'] ) ) {
			return 'paid_social';
		}

		$is_paid = in_array( $medium, array( 'cpc', 'ppc', 'paid', 'paidsocial', 'paid_social' ), true );
		if ( $is_paid ) {
			$social = array( 'facebook', 'instagram', 'meta', 'tiktok', 'linkedin' );
			return in_array( $source, $social, true ) ? 'paid_social' : 'paid_search';
		}

		if ( in_array( $medium, array( 'organic' ), true )
			|| in_array( $source, array( 'google', 'bing' ), true ) ) {
			return 'organic';
		}

		return 'direct';
	}

	/**
	 * Banda legible del score.
	 *
	 * @param int $score Score 0..100.
	 * @return string frio|tibio|caliente|prioritario
	 */
	public static function band( int $score ): string {
		$b = self::bands();
		if ( $score >= $b['prioritario'] ) {
			return 'prioritario';
		}
		if ( $score >= $b['caliente'] ) {
			return 'caliente';
		}
		if ( $score >= $b['tibio'] ) {
			return 'tibio';
		}
		return 'frio';
	}

	/**
	 * Etiqueta de la banda con su icono, para la observacion del CRM.
	 *
	 * @param string $band Banda.
	 * @return string
	 */
	public static function band_label( string $band ): string {
		$labels = array(
			'prioritario' => '🔥 Prioritario',
			'caliente'    => '🔥 Caliente',
			'tibio'       => '🟡 Tibio',
			'frio'        => '🔵 Frío',
		);
		return $labels[ $band ] ?? $labels['frio'];
	}

	/**
	 * Texto que se agrega a la observacion del lead en el CRM.
	 *
	 * @param int $score Score.
	 * @return string Ej. "🔥 Caliente (67)".
	 */
	public static function annotation( int $score ): string {
		return self::band_label( self::band( $score ) ) . ' (' . $score . ')';
	}

	// ---------- heuristicas de calidad ----------

	/**
	 * Telefono con largo plausible (7 a 15 digitos, rango E.164).
	 *
	 * @param string $phone Telefono normalizado.
	 * @return bool
	 */
	public static function is_valid_phone( string $phone ): bool {
		$digits = preg_replace( '/\D/', '', $phone );
		$len    = is_string( $digits ) ? strlen( $digits ) : 0;
		return $len >= 7 && $len <= 15;
	}

	/**
	 * Nombre plausible: mas de 2 caracteres y con alguna vocal
	 * (descarta "asdasd", "xx", "...").
	 *
	 * @param string $name Nombre.
	 * @return bool
	 */
	public static function is_plausible_name( string $name ): bool {
		$name = trim( $name );
		if ( mb_strlen( $name ) < 3 ) {
			return false;
		}
		return 1 === preg_match( '/[aeiouáéíóúü]/i', $name );
	}

	/**
	 * Datos evidentemente falsos: telefono de digito repetido o
	 * secuencial, o nombre no plausible.
	 *
	 * @param array $payload Payload.
	 * @return bool
	 */
	public static function looks_fake( array $payload ): bool {
		$digits = preg_replace( '/\D/', '', (string) ( $payload['phone'] ?? '' ) );
		$digits = is_string( $digits ) ? $digits : '';

		if ( '' !== $digits ) {
			// Todos los digitos iguales (999999999) tras quitar el
			// codigo de pais, o secuencia 123456789.
			$tail = substr( $digits, -9 );
			if ( strlen( $tail ) >= 7 ) {
				if ( 1 === preg_match( '/^(\d)\1+$/', $tail ) ) {
					return true;
				}
				if ( false !== strpos( '01234567890', $tail ) ) {
					return true;
				}
			}
		}

		$name = (string) ( $payload['fname'] ?? '' );
		if ( '' !== trim( $name ) && ! self::is_plausible_name( $name ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Email de dominio desechable.
	 *
	 * @param string $email Email.
	 * @return bool
	 */
	public static function is_disposable_email( string $email ): bool {
		$at = strrpos( $email, '@' );
		if ( false === $at ) {
			return false;
		}
		$domain = strtolower( substr( $email, $at + 1 ) );

		/**
		 * Filtra la lista de dominios de correo temporal.
		 *
		 * @param string[] $domains Dominios bloqueados.
		 */
		$domains = (array) apply_filters( 'wppe_bridge_disposable_email_domains', self::DISPOSABLE_DOMAINS );

		return in_array( $domain, array_map( 'strtolower', $domains ), true );
	}
}
