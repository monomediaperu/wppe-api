<?php
/**
 * Whitelist Client (v1.1.0).
 *
 * Cliente del endpoint remoto `https://api.wp.pe/bridge/whitelist.json`
 * que devuelve la lista de dominios autorizados por Mono Media para
 * usar el plugin sin modo demo.
 *
 * Shape esperado del endpoint:
 * ```json
 * {
 *   "version": 1,
 *   "updated_at": "2026-04-29T18:00:00Z",
 *   "domains": ["anden.com.pe", "*.miempresa.com", "cliente2.cl"]
 * }
 * ```
 *
 * Cache local en `wp_options` (option `wppe_bridge_whitelist_cache`)
 * para sobrevivir a apagones del endpoint:
 * ```php
 * array(
 *   'version'         => int,
 *   'updated_at'      => string ISO-8601 (del endpoint),
 *   'domains'         => array<int,string>,
 *   'fetched_at'      => int unix timestamp local,
 *   'last_fetch_ok'   => bool,
 *   'last_fetch_msg'  => string (error msg si fail),
 * )
 * ```
 *
 * TTL diferenciado: cuando el sitio NO esta en la whitelist, refresca
 * cada 1h (rapido, para que cuando Mono Media lo agregue se active
 * pronto). Cuando SI esta, refresca cada 24h (no urgente).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whitelist Client — fetch + cache del endpoint remoto.
 */
final class WPPE_Bridge_Whitelist_Client {

	/**
	 * URL del endpoint publico de Mono Media. Filterable via
	 * `wppe_bridge_whitelist_url` (util para staging y tests).
	 */
	public const DEFAULT_ENDPOINT = 'https://api.wp.pe/bridge/whitelist.json';

	/**
	 * Option name del cache.
	 */
	public const OPTION_CACHE = 'wppe_bridge_whitelist_cache';

	/**
	 * TTL cuando el sitio NO esta en la whitelist (1 hora).
	 */
	public const TTL_NOT_LISTED = 3600;

	/**
	 * TTL cuando el sitio SI esta en la whitelist (24 horas).
	 */
	public const TTL_LISTED = 86400;

	/**
	 * Backoff tras un fetch fallido (5 min). Hardening v2.11.0: sin
	 * esto, un `api.wp.pe` caido/lento hacia que CADA request re-
	 * intentara el fetch bloqueante de 5s (DoS de workers PHP via el
	 * endpoint publico del widget). Con el backoff, un fallo no se
	 * reintenta hasta pasados estos segundos, sin importar cuantos
	 * requests lleguen.
	 */
	public const RETRY_AFTER_FAILURE = 300;

	/**
	 * Timeout HTTP del fetch (segundos). Conservador para no colgar
	 * paths criticos (admin pageload, worker tick).
	 */
	public const HTTP_TIMEOUT_SECONDS = 5;

	/**
	 * User-agent del fetch (sirve para que Mono Media identifique
	 * trafico del plugin en logs del endpoint).
	 */
	public const USER_AGENT = 'WP-Pe-Bridge/2.12.0 (+https://wp.pe/bridge)';

	/**
	 * Hook cron del refresh diario de la whitelist.
	 */
	public const CRON_HOOK_REFRESH = 'wppe_bridge_whitelist_refresh_tick';

	/**
	 * Devuelve la lista de dominios actualmente conocida por el cliente.
	 *
	 * Si el cache esta stale (segun TTL, ver {@see is_cache_stale()}),
	 * intenta un fetch sincronico. Si el fetch falla, devuelve el
	 * cache previo (incluso vencido) — preferimos data stale a no data.
	 *
	 * Si NUNCA hubo fetch exitoso (cache vacio + nunca lo hubo), hace
	 * un fetch sync y, si tambien falla, retorna array vacio.
	 *
	 * @return array<int,string>
	 */
	public static function get_domains(): array {
		$cache = self::get_cache();

		// Determinar si el sitio actual ya esta en la lista para
		// elegir TTL.
		$listed = false;
		if ( is_array( $cache ) && ! empty( $cache['domains'] ) && class_exists( 'WPPE_Bridge_License_Manager' ) ) {
			$host   = WPPE_Bridge_License_Manager::current_host();
			$listed = WPPE_Bridge_License_Manager::host_matches_managed( $host, $cache['domains'] );
		}

		if ( self::is_cache_stale( $cache, $listed ) ) {
			$fresh = self::fetch_now();
			if ( null !== $fresh ) {
				return $fresh['domains'];
			}
			// Fetch fallo — usar cache previo (incluso vencido).
		}

		if ( is_array( $cache ) && isset( $cache['domains'] ) && is_array( $cache['domains'] ) ) {
			return $cache['domains'];
		}

		return array();
	}

	/**
	 * Lee el cache crudo del option. Devuelve `null` si no existe o
	 * si su shape es invalido.
	 *
	 * @return array<string,mixed>|null
	 */
	public static function get_cache(): ?array {
		$raw = get_option( self::OPTION_CACHE, null );
		if ( ! is_array( $raw ) ) {
			return null;
		}
		// Validacion minima de shape.
		if ( ! isset( $raw['domains'] ) || ! is_array( $raw['domains'] ) ) {
			return null;
		}
		return $raw;
	}

	/**
	 * Determina si el cache esta stale (vencido) segun TTL diferenciado.
	 *
	 * @param array<string,mixed>|null $cache  Cache crudo.
	 * @param bool                     $listed True si el sitio aparece en cache.
	 * @return bool
	 */
	public static function is_cache_stale( ?array $cache, bool $listed ): bool {
		if ( null === $cache ) {
			return true;
		}
		// phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.RequestedUTC -- test mocks via $GLOBALS['wppe_test_now']; en runtime equivale a time().
		$now = function_exists( 'current_time' ) ? (int) current_time( 'timestamp', 1 ) : time();

		// Backoff tras fallo (hardening v2.11.0): si el ultimo intento
		// fallo, no reintentar hasta RETRY_AFTER_FAILURE. Evita el fetch
		// bloqueante en cada request cuando el endpoint remoto esta
		// caido. `last_attempt_at` lo setea mark_fetch_failed.
		if ( isset( $cache['last_fetch_ok'] ) && false === $cache['last_fetch_ok'] ) {
			$attempt = isset( $cache['last_attempt_at'] ) ? (int) $cache['last_attempt_at'] : 0;
			if ( $attempt > 0 && ( $now - $attempt ) < self::RETRY_AFTER_FAILURE ) {
				return false;
			}
		}

		$fetched = isset( $cache['fetched_at'] ) ? (int) $cache['fetched_at'] : 0;
		if ( $fetched <= 0 ) {
			return true;
		}
		$ttl = $listed ? self::TTL_LISTED : self::TTL_NOT_LISTED;
		return ( $now - $fetched ) >= $ttl;
	}

	/**
	 * Devuelve la URL del endpoint (con filter para staging/tests).
	 *
	 * @return string
	 */
	public static function endpoint_url(): string {
		$url = self::DEFAULT_ENDPOINT;
		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'wppe_bridge_whitelist_url', $url );
			if ( is_string( $filtered ) && '' !== $filtered ) {
				$url = $filtered;
			}
		}
		return $url;
	}

	/**
	 * Fuerza un fetch HTTP del endpoint. Si exitoso, persiste en cache
	 * y devuelve el array decodificado. Si falla, NO toca el cache
	 * previo (preferimos data stale a no data) y devuelve `null`.
	 *
	 * Tambien registra `last_fetch_ok` y `last_fetch_msg` en el cache
	 * cuando el option ya existe, para diagnostico desde admin.
	 *
	 * @return array<string,mixed>|null Cache fresco o null si fallo.
	 */
	public static function fetch_now(): ?array {
		$url = self::endpoint_url();

		if ( ! function_exists( 'wp_remote_get' ) ) {
			return null;
		}

		$response = wp_remote_get(
			$url,
			array(
				'timeout'    => self::HTTP_TIMEOUT_SECONDS,
				'user-agent' => self::USER_AGENT,
				'headers'    => array(
					'Accept' => 'application/json',
				),
			)
		);

		if ( function_exists( 'is_wp_error' ) && is_wp_error( $response ) ) {
			self::mark_fetch_failed( 'wp_error: ' . $response->get_error_message() );
			return null;
		}

		$code = function_exists( 'wp_remote_retrieve_response_code' )
			? (int) wp_remote_retrieve_response_code( $response )
			: 0;

		if ( $code < 200 || $code >= 300 ) {
			self::mark_fetch_failed( 'http_' . $code );
			return null;
		}

		$body = function_exists( 'wp_remote_retrieve_body' )
			? (string) wp_remote_retrieve_body( $response )
			: '';

		$decoded = json_decode( $body, true );
		if ( ! is_array( $decoded ) || ! isset( $decoded['domains'] ) || ! is_array( $decoded['domains'] ) ) {
			self::mark_fetch_failed( 'invalid_shape' );
			return null;
		}

		// Verificacion de firma Ed25519 (v2.11.0, guardrail anti
		// alteracion): si hay clave publica configurada, el JSON DEBE
		// venir firmado y la firma DEBE validar; si no, se trata como
		// fetch fallido (se conserva el cache previo). Sin clave
		// configurada la verificacion se omite (rollout suave — se
		// activa cuando el servidor empiece a firmar). El material
		// firmado es `version|updated_at|domains_csv` — deterministico,
		// sin canonicalizacion JSON fragil.
		if ( ! self::signature_valid( $decoded ) ) {
			self::mark_fetch_failed( 'invalid_signature' );
			return null;
		}

		// Anti-rollback (hardening v2.11.0): rechazar una whitelist con
		// `version` menor a la ya cacheada. Sin esto, un atacante de red
		// (o un mirror comprometido) puede re-servir un JSON viejo pero
		// VALIDAMENTE firmado para reintroducir un dominio ya removido de
		// la lista (ej. un ex-cliente que dejo de pagar). Solo aplica
		// cuando hay firma activa — sin firma, `version` no es confiable.
		if ( '' !== self::signing_pubkey() ) {
			$prev = self::get_cache();
			if ( is_array( $prev ) && isset( $prev['version'] )
				&& ( isset( $decoded['version'] ) ? (int) $decoded['version'] : 0 ) < (int) $prev['version'] ) {
				self::mark_fetch_failed( 'stale_version' );
				return null;
			}
		}

		// Normalizar dominios: lower + trim, descartar vacios.
		$domains = array();
		foreach ( $decoded['domains'] as $d ) {
			if ( ! is_string( $d ) ) {
				continue;
			}
			$d = strtolower( trim( $d ) );
			if ( '' !== $d ) {
				$domains[] = $d;
			}
		}

		// phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.RequestedUTC -- test mocks via $GLOBALS['wppe_test_now']; en runtime equivale a time().
		$now = function_exists( 'current_time' ) ? (int) current_time( 'timestamp', 1 ) : time();

		$cache = array(
			'version'         => isset( $decoded['version'] ) ? (int) $decoded['version'] : 1,
			'updated_at'      => isset( $decoded['updated_at'] ) ? (string) $decoded['updated_at'] : '',
			'domains'         => $domains,
			'fetched_at'      => $now,
			'last_fetch_ok'   => true,
			'last_fetch_msg'  => '',
			'last_attempt_at' => $now,
		);

		update_option( self::OPTION_CACHE, $cache );

		return $cache;
	}

	/**
	 * Clave publica Ed25519 (base64) para verificar la firma de la
	 * whitelist. Resolucion: constante `WPPE_BRIDGE_WHITELIST_PUBKEY`
	 * (wp-config / build) o filter `wppe_bridge_whitelist_pubkey`.
	 * Cadena vacia = verificacion desactivada.
	 *
	 * NO es un secreto (es la clave PUBLICA); la privada vive en el
	 * pipeline de publicacion de api.wp.pe y firma el JSON al
	 * generarlo.
	 *
	 * @return string Base64 o ''.
	 */
	public static function signing_pubkey(): string {
		$key = defined( 'WPPE_BRIDGE_WHITELIST_PUBKEY' ) ? (string) WPPE_BRIDGE_WHITELIST_PUBKEY : '';
		/**
		 * Filtra la clave publica de verificacion de la whitelist.
		 *
		 * @param string $key Base64 de la clave Ed25519 publica.
		 */
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- hook literal con prefijo correcto.
		return (string) apply_filters( 'wppe_bridge_whitelist_pubkey', $key );
	}

	/**
	 * Material firmado, con codificacion INYECTIVA (hardening v2.11.0).
	 *
	 * Antes: `version|updated_at|domains_csv`. Ese formato con
	 * delimitadores era ambiguo — `["a,b"]` y `["a","b"]` producian el
	 * mismo string, y un `|` en un campo desplazaba fronteras. Ahora
	 * cada segmento va prefijado por su longitud (`len:valor;`), de modo
	 * que dos payloads logicamente distintos NUNCA colisionan. El
	 * firmante server-side debe usar exactamente esta construccion.
	 *
	 * @param array $decoded JSON decodificado del endpoint.
	 * @return string
	 */
	public static function signature_material( array $decoded ): string {
		$seg = static function ( string $value ): string {
			return strlen( $value ) . ':' . $value . ';';
		};

		$version    = isset( $decoded['version'] ) ? (string) $decoded['version'] : '';
		$updated_at = isset( $decoded['updated_at'] ) ? (string) $decoded['updated_at'] : '';

		$material = $seg( $version ) . $seg( $updated_at );
		foreach ( (array) ( $decoded['domains'] ?? array() ) as $d ) {
			if ( is_string( $d ) ) {
				$material .= $seg( $d );
			}
		}
		return $material;
	}

	/**
	 * Valida la firma Ed25519 del payload. true si no hay clave
	 * configurada (verificacion off) o si la firma es valida.
	 *
	 * @param array $decoded JSON decodificado.
	 * @return bool
	 */
	public static function signature_valid( array $decoded ): bool {
		$pubkey_b64 = self::signing_pubkey();
		if ( '' === $pubkey_b64 ) {
			return true;
		}
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			// Sin sodium no podemos verificar: fail-closed seria dejar
			// sin servicio a un sitio legitimo por un PHP exotico;
			// fail-open anula el guardrail. Decision: fail-closed —
			// PHP 8.1+ (nuestro minimo) incluye sodium por default.
			return false;
		}

		$signature = false;
		if ( isset( $decoded['signature'] ) && is_string( $decoded['signature'] ) ) {
			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- decodifica una firma Ed25519, no codigo.
			$signature = base64_decode( $decoded['signature'], true );
		}
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- decodifica la clave publica, no codigo.
		$pubkey = base64_decode( $pubkey_b64, true );

		if ( ! is_string( $signature ) || ! is_string( $pubkey )
			|| SODIUM_CRYPTO_SIGN_BYTES !== strlen( $signature )
			|| SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES !== strlen( $pubkey ) ) {
			return false;
		}

		try {
			return sodium_crypto_sign_verify_detached( $signature, self::signature_material( $decoded ), $pubkey );
		} catch ( SodiumException $e ) {
			return false;
		}
	}

	/**
	 * Marca el cache existente con metadata de fallo (`last_fetch_ok =
	 * false`, `last_fetch_msg`) sin tocar dominios ni `fetched_at`.
	 *
	 * Si el cache no existia, no crea uno (no queremos persistir un
	 * cache vacio que parezca exitoso).
	 *
	 * @param string $msg Mensaje breve del error.
	 * @return void
	 */
	private static function mark_fetch_failed( string $msg ): void {
		// phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.RequestedUTC -- test mocks via $GLOBALS['wppe_test_now']; en runtime equivale a time().
		$now = function_exists( 'current_time' ) ? (int) current_time( 'timestamp', 1 ) : time();

		$cache = self::get_cache();
		if ( null === $cache ) {
			// Sin cache previo creamos uno MINIMO con `last_attempt_at`
			// para armar el backoff (hardening v2.11.0). No trae dominios
			// (last_fetch_ok=false + domains=[] no habilita a nadie), asi
			// que no "parece exitoso" — solo evita el re-fetch por request.
			$cache = array(
				'version'    => 0,
				'updated_at' => '',
				'domains'    => array(),
				'fetched_at' => 0,
			);
		}
		$cache['last_fetch_ok']   = false;
		$cache['last_fetch_msg']  = $msg;
		$cache['last_attempt_at'] = $now;
		update_option( self::OPTION_CACHE, $cache );
	}

	/**
	 * Devuelve datos legibles del cache para mostrar en admin
	 * (Settings page, Help page).
	 *
	 * @return array{
	 *   has_cache: bool,
	 *   domains_count: int,
	 *   fetched_at: int,
	 *   updated_at: string,
	 *   last_fetch_ok: bool,
	 *   last_fetch_msg: string
	 * }
	 */
	public static function status(): array {
		$cache = self::get_cache();
		if ( null === $cache ) {
			return array(
				'has_cache'      => false,
				'domains_count'  => 0,
				'fetched_at'     => 0,
				'updated_at'     => '',
				'last_fetch_ok'  => false,
				'last_fetch_msg' => 'no_cache',
			);
		}
		return array(
			'has_cache'      => true,
			'domains_count'  => count( $cache['domains'] ),
			'fetched_at'     => (int) ( $cache['fetched_at'] ?? 0 ),
			'updated_at'     => (string) ( $cache['updated_at'] ?? '' ),
			'last_fetch_ok'  => (bool) ( $cache['last_fetch_ok'] ?? false ),
			'last_fetch_msg' => (string) ( $cache['last_fetch_msg'] ?? '' ),
		);
	}

	/**
	 * Punto de entrada del cron `wppe_bridge_whitelist_refresh_tick`
	 * (registrado en Plugin::register_hooks).
	 *
	 * Diario. No bloquea — si falla, el siguiente tick reintentara.
	 *
	 * @return void
	 */
	public static function cron_refresh(): void {
		self::fetch_now();
	}
}
