<?php
/**
 * Adapter para Elementor Pro Forms.
 *
 * Hook nativo: `elementor_pro/forms/new_record`.
 * Args del callback: ($record, $handler).
 *
 * - `$record` es una instancia de
 *   ElementorPro\Modules\Forms\Classes\Form_Record con metodos
 *   `get_fields()` y `get_form_settings()`.
 * - `$handler` es el ajax handler — no lo usamos.
 *
 * Decision D2 del CLAUDE.md: nunca leer tablas internas de Elementor.
 * Solo hooks publicos.
 *
 * Disponibilidad: Elementor Forms es un widget de Elementor Pro
 * (no del core gratuito). Por eso chequeamos `ELEMENTOR_PRO_VERSION`
 * y la clase del modulo.
 *
 * @package WPPE_Bridge
 * @since 2.8.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Adapter para Elementor Pro Forms.
 */
final class WPPE_Bridge_Elementor_Forms_Adapter extends WPPE_Bridge_Form_Adapter_Base {

	/**
	 * Slug del plugin de forms.
	 *
	 * @return string
	 */
	public static function plugin_slug(): string {
		return 'elementor';
	}

	/**
	 * Detecta si Elementor Pro Forms esta activo.
	 *
	 * Chequeo: constante `ELEMENTOR_PRO_VERSION` (definida por el
	 * loader de Elementor Pro) o la clase del modulo Forms. Tolera
	 * versiones que renombren el namespace.
	 *
	 * Filter `wppe_bridge_elementor_is_available` permite a tests
	 * (o integraciones de tercero) forzar el resultado.
	 *
	 * @return bool
	 */
	public static function is_available(): bool {
		$detected = defined( 'ELEMENTOR_PRO_VERSION' ) || class_exists( 'ElementorPro\\Modules\\Forms\\Module' );
		/**
		 * Filtra la deteccion de Elementor Pro.
		 *
		 * @param bool $detected Resultado de la deteccion automatica.
		 */
		return (bool) apply_filters( 'wppe_bridge_elementor_is_available', $detected );
	}

	/**
	 * Suscribe el hook nativo de Elementor Pro Forms.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'elementor_pro/forms/new_record', array( self::class, 'on_submission' ), 10, 2 );
	}

	/**
	 * Auto-registro condicional.
	 *
	 * @return void
	 */
	public static function maybe_register(): void {
		if ( self::is_available() ) {
			self::register();
		}
	}

	/**
	 * Callback del hook `elementor_pro/forms/new_record`.
	 *
	 * El `$record` es un objeto Form_Record con metodos:
	 *  - `get_form_settings($key)`: setting del widget (id, form_name, etc).
	 *  - `get_fields($args)`: array de fields con ['id', 'type', 'value', ...].
	 *
	 * Form ID estable: Elementor permite un "Form ID" custom en el widget
	 * (setting `form_name`). Si esta seteado lo usamos — es lo que el
	 * operador configurara en el panel de Mapeo. Sino, fallback al widget
	 * id (`id` del setting), que es un hash de 7 caracteres ej "a1b2c3d".
	 *
	 * Entry ID: Elementor no asigna ID propio al record (no guarda en
	 * tabla nativa por default). Usamos timestamp + random para tener
	 * un identificador unico que el dedup pueda atrapar (`form_id +
	 * email + phone + landing_url` hashea igual independiente del
	 * entry_id, asi que esto es solo para tracing en logs).
	 *
	 * @param object|null $record  Form_Record de Elementor o null en tests.
	 * @param object|null $handler Ajax_Handler de Elementor (no usado).
	 * @return void
	 */
	public static function on_submission( $record, $handler = null ): void {
		unset( $handler ); // No usado.

		if ( ! is_object( $record ) ) {
			return;
		}

		$form_id   = self::extract_form_id( $record );
		$form_data = self::extract_form_data( $record );

		// Entry ID sintetico: Elementor no provee ID estable salvo que
		// el cliente tenga Form Database addon. Generamos uno para
		// trazabilidad en logs (no afecta dedup — el hash usa email/
		// phone/landing_url, no entry_id).
		$entry_id = sprintf( 'el-%d-%s', time(), wp_generate_password( 6, false ) );

		self::handle_submission( $form_data, $entry_id, $form_id );
	}

	/**
	 * Extrae el form_id del record. Prefiere `form_name` (configurable
	 * por el operador en el widget) sobre el widget `id` (auto-generado).
	 *
	 * @param object $record Form_Record de Elementor.
	 * @return string
	 */
	public static function extract_form_id( $record ): string {
		if ( ! is_object( $record ) || ! method_exists( $record, 'get_form_settings' ) ) {
			return '';
		}

		$form_name = (string) $record->get_form_settings( 'form_name' );
		if ( '' !== $form_name ) {
			return $form_name;
		}

		$widget_id = (string) $record->get_form_settings( 'id' );
		return $widget_id;
	}

	/**
	 * Extrae los fields del record como array `[custom_id|id => value]`.
	 *
	 * Elementor permite al usuario asignar un "ID" custom a cada field
	 * (ej. "email", "phone"). Si lo asigno, ese es el key. Si no,
	 * Elementor genera uno automatico tipo "field_abc1234".
	 *
	 * `get_fields()` con args `['type' => '!step']` filtra los multi-step
	 * markers (los "step" no tienen value).
	 *
	 * @param object $record Form_Record de Elementor.
	 * @return array
	 */
	public static function extract_form_data( $record ): array {
		if ( ! is_object( $record ) || ! method_exists( $record, 'get_field' ) ) {
			return array();
		}

		// get_field() de Elementor acepta args para filtrar.
		$fields = $record->get_field( array() );
		if ( ! is_array( $fields ) ) {
			return array();
		}

		$out = array();
		foreach ( $fields as $id => $field ) {
			// Skip step markers que no tienen value real.
			if ( is_array( $field ) && isset( $field['type'] ) && 'step' === $field['type'] ) {
				continue;
			}

			$value = '';
			if ( is_array( $field ) && array_key_exists( 'value', $field ) ) {
				$value = $field['value'];
			} elseif ( is_array( $field ) && array_key_exists( 'raw_value', $field ) ) {
				$value = $field['raw_value'];
			}

			$out[ (string) $id ] = $value;
		}

		return $out;
	}
}
