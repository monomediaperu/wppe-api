/**
 * Submit Lock: deshabilita el boton submit al primer click para
 * prevenir doble envio (causa #1 de duplicados, CLAUDE.md seccion 6).
 *
 * Cubre Fluent Forms, Gravity Forms y Elementor con selectores CSS.
 * Re-habilita el boton:
 *   1. Tras 30s como red de seguridad (si todo falla silenciosamente).
 *   2. Cuando el plugin nativo emite evento de fin de envio:
 *      - Fluent (jQuery): fluentform_submission_success, _failed.
 *      - Elementor (DOM): submit_success, submit_error.
 *      - Gravity (jQuery): gform_post_render (re-render tras AJAX).
 *
 * @package WPPE_Bridge
 */
( function () {
	'use strict';

	var SAFETY_TIMEOUT_MS = 30000;
	var SELECTORS = [
		'.fluentform form',
		'.gform_wrapper form',
		'.elementor-form'
	];
	var BUTTON_SELECTOR = 'button[type="submit"], input[type="submit"]';

	/**
	 * Lista de forms relevantes en la pagina actual.
	 */
	function findForms() {
		var forms = [];
		try {
			var nodes = document.querySelectorAll( SELECTORS.join( ',' ) );
			for ( var i = 0; i < nodes.length; i++ ) {
				forms.push( nodes[ i ] );
			}
		} catch ( e ) {
			// querySelectorAll no soportado: imposible en navegadores modernos.
		}
		return forms;
	}

	/**
	 * Deshabilita el boton temporalmente y agenda su re-habilitacion.
	 *
	 * @param {HTMLElement} button
	 */
	function lockButton( button ) {
		if ( ! button || button.disabled ) {
			return;
		}
		button.disabled = true;
		button.setAttribute( 'data-wppe-bridge-locked', '1' );

		setTimeout( function () {
			unlockButton( button );
		}, SAFETY_TIMEOUT_MS );
	}

	/**
	 * Re-habilita un boton si fue lockeado por nosotros.
	 *
	 * @param {HTMLElement} button
	 */
	function unlockButton( button ) {
		if ( ! button ) {
			return;
		}
		if ( button.getAttribute( 'data-wppe-bridge-locked' ) === '1' ) {
			button.disabled = false;
			button.removeAttribute( 'data-wppe-bridge-locked' );
		}
	}

	/**
	 * Re-habilita todos los botones lockeados de la pagina.
	 */
	function unlockAll() {
		var locked = document.querySelectorAll( 'button[data-wppe-bridge-locked="1"], input[data-wppe-bridge-locked="1"]' );
		for ( var i = 0; i < locked.length; i++ ) {
			unlockButton( locked[ i ] );
		}
	}

	/**
	 * Engancha listeners de fin de envio especificos por plugin para
	 * re-habilitar mas rapido que el timeout de seguridad.
	 */
	function bindNativeEvents() {
		// Fluent y Gravity emiten eventos jQuery; los enganchamos solo
		// si jQuery esta disponible en la pagina.
		if ( typeof window.jQuery === 'function' ) {
			window.jQuery( document ).on( 'fluentform_submission_success fluentform_submission_failed', unlockAll );
			window.jQuery( document ).on( 'gform_post_render', unlockAll );
		}

		// Elementor emite eventos DOM nativos en el form.
		document.addEventListener( 'submit_success', unlockAll );
		document.addEventListener( 'submit_error', unlockAll );
	}

	function init() {
		var forms = findForms();
		if ( 0 === forms.length ) {
			return;
		}

		for ( var i = 0; i < forms.length; i++ ) {
			var form = forms[ i ];
			form.addEventListener( 'submit', function ( ev ) {
				var button = ev.target.querySelector( BUTTON_SELECTOR );
				if ( button ) {
					lockButton( button );
				}
			}, false );
		}

		bindNativeEvents();
	}

	if ( document.readyState !== 'loading' ) {
		init();
	} else {
		document.addEventListener( 'DOMContentLoaded', init );
	}
}() );
