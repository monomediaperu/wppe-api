/**
 * Captura de UTMs / GCLID / fbclid del visitante.
 *
 * Al cargar cualquier pagina:
 * 1. Lee querystring (?utm_source=..., ?gclid=..., ?fbclid=...).
 * 2. Si encuentra al menos un parametro de tracking, persiste todos
 *    los conocidos + landing_url en cookie + localStorage por 90 dias.
 * 3. Si NO hay parametros nuevos pero existe localStorage:
 *    re-hidrata la cookie (cubre el caso navegador que limpia cookies
 *    pero no localStorage).
 *
 * El adapter PHP (Form_Adapter_Base::capture_utms) lee la cookie en
 * el submit del form, asi que el flujo es: visitante llega con UTMs
 * → JS guarda → visitante envia form (incluso dias despues si la
 * cookie no expiro) → adapter recibe → encola en queue con UTMs
 * reales → llegan a Sperant.
 *
 * @package WPPE_Bridge
 */
( function () {
	'use strict';

	var COOKIE_KEY = 'wppe_bridge_utms';
	var STORAGE_KEY = 'wppe_bridge_utms';
	var TTL_DAYS = 90;
	var TRACKING_KEYS = [
		'utm_source',
		'utm_medium',
		'utm_campaign',
		'utm_term',
		'utm_content',
		'gclid',
		'fbclid'
	];

	/**
	 * Lee parametros de tracking de la URL actual.
	 * Devuelve objeto solo con las claves presentes (no vacias).
	 */
	function readFromUrl() {
		var params = {};
		try {
			var url = new URL( window.location.href );
			for ( var i = 0; i < TRACKING_KEYS.length; i++ ) {
				var key = TRACKING_KEYS[ i ];
				var value = url.searchParams.get( key );
				if ( value && value.length > 0 ) {
					params[ key ] = value;
				}
			}
			// landing_url: la URL actual sin querystring.
			if ( Object.keys( params ).length > 0 ) {
				params.landing_url = url.origin + url.pathname;
			}
		} catch ( e ) {
			// URL no parseable; ignorar silenciosamente.
		}

		// Cookie `_fbp` del Meta Pixel (si esta cargado en la pagina).
		// Se captura solo si ya hay UTMs en la URL para no poluir
		// localStorage con `fbp` huerfano.
		if ( Object.keys( params ).length > 0 ) {
			var fbp = readCookie( '_fbp' );
			if ( fbp ) {
				params.fbp = fbp;
			}
		}
		return params;
	}

	/**
	 * Lee el valor de una cookie por nombre.
	 */
	function readCookie( name ) {
		try {
			var match = document.cookie.match( new RegExp( '(?:^|; )' + name.replace( /([.$?*|{}()\[\]\\\/+^])/g, '\\$1' ) + '=([^;]*)' ) );
			return match ? decodeURIComponent( match[1] ) : null;
		} catch ( e ) {
			return null;
		}
	}

	/**
	 * Lee desde localStorage. Devuelve objeto o null.
	 */
	function readFromStorage() {
		try {
			var raw = window.localStorage.getItem( STORAGE_KEY );
			if ( ! raw ) {
				return null;
			}
			var parsed = JSON.parse( raw );
			return parsed && typeof parsed === 'object' ? parsed : null;
		} catch ( e ) {
			return null;
		}
	}

	/**
	 * Persiste el objeto en cookie + localStorage.
	 */
	function persist( params ) {
		var json = JSON.stringify( params );

		// Cookie con TTL en dias.
		try {
			var expires = new Date();
			expires.setTime( expires.getTime() + ( TTL_DAYS * 24 * 60 * 60 * 1000 ) );
			document.cookie = COOKIE_KEY + '=' + encodeURIComponent( json ) +
				'; expires=' + expires.toUTCString() +
				'; path=/; samesite=Lax';
		} catch ( e ) {
			// Modo donde cookies estan deshabilitadas; ignorar.
		}

		// localStorage como fallback.
		try {
			window.localStorage.setItem( STORAGE_KEY, json );
		} catch ( e ) {
			// Modo privado u otra restriccion; ignorar.
		}
	}

	/**
	 * Detecta si ya hay cookie wppe_bridge_utms seteada (no vacia).
	 */
	function hasCookie() {
		try {
			return document.cookie.split( ';' ).some( function ( c ) {
				return c.trim().indexOf( COOKIE_KEY + '=' ) === 0;
			} );
		} catch ( e ) {
			return false;
		}
	}

	function run() {
		var fromUrl = readFromUrl();
		if ( Object.keys( fromUrl ).length > 0 ) {
			// Llegada con UTMs nuevos: piso lo anterior y persisto.
			persist( fromUrl );
			return;
		}

		// Sin UTMs en URL: si ya hay cookie, no hago nada.
		if ( hasCookie() ) {
			return;
		}

		// Sin cookie pero con localStorage: re-hidratar cookie.
		var fromStorage = readFromStorage();
		if ( fromStorage && Object.keys( fromStorage ).length > 0 ) {
			persist( fromStorage );
		}
	}

	if ( document.readyState !== 'loading' ) {
		run();
	} else {
		document.addEventListener( 'DOMContentLoaded', run );
	}
}() );
