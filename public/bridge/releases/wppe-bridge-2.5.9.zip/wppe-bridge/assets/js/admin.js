/**
 * Scripts del panel admin del plugin.
 *
 * @package WPPE_Bridge
 */
( function () {
	'use strict';

	function ready( fn ) {
		if ( document.readyState !== 'loading' ) {
			fn();
		} else {
			document.addEventListener( 'DOMContentLoaded', fn );
		}
	}

	/**
	 * v2.5.5/v2.5.6 — Toggle dinamico de campos del CRM en la pagina
	 * Configuracion + selector visual (cards).
	 *
	 * Al hacer click en una card del CRM destino, mostramos los bloques
	 * del CRM nuevo y ocultamos los del anterior, sin requerir guardado.
	 * Para los inputs Sperant ocultados, quitamos `name` y `required`
	 * para que (a) el browser no bloquee el submit por required vacio
	 * cuando el user solo queria cambiar de CRM, y (b) el campo vacio
	 * no viaje en el POST. Al volver a Sperant, restauramos desde
	 * `data-original-*`.
	 *
	 * Para el aviso "no-sperant", rellenamos label + href de la sub-pagina
	 * usando los data-attrs de la card seleccionada (`data-config-label`
	 * y `data-config-url`).
	 *
	 * v2.5.6: el dropdown legacy se reemplazo por un grid de cards estilo
	 * FluentSMTP. Un `<input type="hidden">` con el mismo `name` del
	 * dropdown anterior persiste el slug seleccionado. JS lo actualiza al
	 * hacer click y dispara un evento `change` propio para reusar el
	 * mismo handler.
	 *
	 * Idempotente y safe — si el selector o los bloques no existen
	 * (otra pantalla del plugin), no hace nada.
	 */
	function setupCrmToggle() {
		var hiddenInput = document.getElementById( 'wppe_bridge_active_destination' );
		if ( ! hiddenInput ) {
			return;
		}

		var sperantBlocks    = document.querySelectorAll( '[data-sperant-block="1"]' );
		var nonSperantBlocks = document.querySelectorAll( '[data-non-sperant-block="1"]' );
		if ( ! sperantBlocks.length && ! nonSperantBlocks.length ) {
			return;
		}

		// v2.5.6 — click en card del selector visual sincroniza el hidden
		// input + dispara el toggle. Soporta `Enter`/`Space` con teclado
		// para accesibilidad (cards tienen role=radio, tabindex=0).
		var cards = document.querySelectorAll( '.wppe-bridge-crm-card' );
		for ( var c = 0; c < cards.length; c++ ) {
			cards[c].addEventListener( 'click', handleCardSelect );
			cards[c].addEventListener( 'keydown', function ( evt ) {
				if ( ' ' === evt.key || 'Enter' === evt.key ) {
					evt.preventDefault();
					handleCardSelect.call( evt.currentTarget );
				}
			} );
		}

		function handleCardSelect() {
			var card = this;
			if ( '1' === card.getAttribute( 'data-coming-soon' ) ) {
				return;
			}
			var slug = card.getAttribute( 'data-slug' );
			if ( ! slug ) {
				return;
			}

			// Marcar la card elegida + desmarcar el resto.
			for ( var i = 0; i < cards.length; i++ ) {
				var ck = cards[i];
				if ( ck === card ) {
					ck.classList.add( 'is-selected' );
					ck.setAttribute( 'aria-checked', 'true' );
				} else {
					ck.classList.remove( 'is-selected' );
					ck.setAttribute( 'aria-checked', 'false' );
				}
			}

			// Sincronizar hidden input + ejecutar el toggle de campos.
			hiddenInput.value = slug;
			applyToggle( slug, card );

			// v2.5.6: si veniamos de fresh install (banner visible),
			// ocultar el banner ahora que el user eligio. El guardado
			// posterior persiste la option y el banner ya no aparece
			// en futuras cargas.
			var emptyBanner = document.querySelector( '[data-wppe-bridge-empty-state]' );
			if ( emptyBanner ) {
				emptyBanner.style.display = 'none';
			}
		}

		function applyToggle( slug, sourceEl ) {
			var isSperant = ( 'sperant' === slug );

			// Toggle visibility de bloques Sperant. Cuando se ocultan,
			// stripeamos name+required de cualquier input/select interno
			// para que (a) no envien valores y (b) no bloqueen submit.
			for ( var i = 0; i < sperantBlocks.length; i++ ) {
				var blk    = sperantBlocks[i];
				blk.style.display = isSperant ? '' : 'none';
				var fields = blk.querySelectorAll( '[data-original-name]' );
				for ( var j = 0; j < fields.length; j++ ) {
					var f = fields[j];
					if ( isSperant ) {
						f.setAttribute( 'name', f.getAttribute( 'data-original-name' ) );
						if ( '1' === f.getAttribute( 'data-original-required' ) ) {
							f.setAttribute( 'required', 'required' );
						}
					} else {
						f.removeAttribute( 'name' );
						f.removeAttribute( 'required' );
					}
				}
			}

			// Toggle aviso non-sperant + relleno dinamico de label/URL
			// desde data-attrs de la card seleccionada.
			var label = sourceEl ? ( sourceEl.getAttribute( 'data-config-label' ) || slug ) : slug;
			var url   = sourceEl ? ( sourceEl.getAttribute( 'data-config-url' ) || '' ) : '';

			for ( var k = 0; k < nonSperantBlocks.length; k++ ) {
				var nblk = nonSperantBlocks[k];
				nblk.style.display = isSperant ? 'none' : '';
				var msg = nblk.querySelector( '[data-wppe-noncrm-msg]' );
				if ( msg ) {
					msg.innerHTML = buildNonSperantMessage( label, url );
				}
			}
		}
	}

	/**
	 * Construye el HTML del aviso "campos especificos en sub-pagina"
	 * para un CRM no-Sperant. Si hay URL de sub-pagina, incluye link;
	 * si no (caso defensivo), solo menciona el menu lateral.
	 *
	 * Mantiene paridad con el render server-side de views/settings.php
	 * para que el toggle JS no introduzca un texto distinto al inicial.
	 *
	 * @param {string} label Nombre legible del CRM (ej. "Odoo").
	 * @param {string} url   URL absoluta de la sub-pagina, o vacio.
	 * @returns {string} HTML escapado (label/URL son atributos seguros).
	 */
	function buildNonSperantMessage( label, url ) {
		var safeLabel = escapeHtml( label );
		if ( url ) {
			return 'Los campos especificos de <strong>' + safeLabel + '</strong> (credenciales, URL, etc.) se configuran en su sub-pagina dedicada: <a href="' + escapeAttr( url ) + '">Configuracion ' + safeLabel + '</a>. En esta pantalla solo se administran ajustes globales (TTL deduplicacion, codigo de pais).';
		}
		return 'Los campos especificos de <strong>' + safeLabel + '</strong> se configuran en su sub-pagina dedicada (ver menu lateral). En esta pantalla solo se administran ajustes globales.';
	}

	function escapeHtml( s ) {
		return String( s )
			.replace( /&/g, '&amp;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' )
			.replace( /"/g, '&quot;' )
			.replace( /'/g, '&#039;' );
	}

	function escapeAttr( s ) {
		return String( s ).replace( /"/g, '&quot;' );
	}

	ready( function () {
		// v2.5.5: registrar PRIMERO para que el toggle CRM funcione aunque
		// no exista el btn de sync (no-sperant rendering, otras pantallas).
		setupCrmToggle();

		var btn    = document.getElementById( 'wppe-bridge-sync-catalogs' );
		var status = document.getElementById( 'wppe-bridge-sync-status' );

		if ( ! btn || ! status || typeof window.wppeBridgeAdmin === 'undefined' ) {
			return;
		}

		btn.addEventListener( 'click', function () {
			btn.disabled = true;
			status.textContent = window.wppeBridgeAdmin.i18n.syncing;
			status.style.color = '#666';

			var data = new FormData();
			data.append( 'action', window.wppeBridgeAdmin.actions.syncCatalogs );
			data.append( 'nonce', window.wppeBridgeAdmin.nonce );

			fetch( window.wppeBridgeAdmin.ajaxUrl, {
				method:      'POST',
				credentials: 'same-origin',
				body:        data,
			} )
			.then( function ( res ) {
				return res.json();
			} )
			.then( function ( payload ) {
				btn.disabled = false;
				if ( ! payload || ! payload.success ) {
					status.textContent = ( payload && payload.data && payload.data.message ) || window.wppeBridgeAdmin.i18n.error;
					status.style.color = '#dc3232';
					return;
				}

				var counts = payload.data.counts || {};
				var summary = window.wppeBridgeAdmin.i18n.synced
					.replace( '%input_channels%', counts.input_channels || 0 )
					.replace( '%sources%', counts.sources || 0 )
					.replace( '%interest_types%', counts.interest_types || 0 )
					.replace( '%projects%', counts.projects || 0 );

				// Si hubo errores, agregarlos al texto del status para
				// que el admin sepa exactamente cual catalogo fallo.
				if ( payload.data.has_errors && payload.data.errors ) {
					var errParts = [];
					for ( var k in payload.data.errors ) {
						if ( Object.prototype.hasOwnProperty.call( payload.data.errors, k ) ) {
							errParts.push( k + ': ' + payload.data.errors[k] );
						}
					}
					if ( errParts.length ) {
						summary += ' — ' + errParts.join( ', ' );
					}
				}

				status.textContent = summary;
				status.style.color = payload.data.has_errors ? '#dba617' : '#46b450';

				// Recargar despues de 1.5s para reflejar la tabla con counts.
				setTimeout( function () {
					window.location.reload();
				}, 1500 );
			} )
			.catch( function () {
				btn.disabled = false;
				status.textContent = window.wppeBridgeAdmin.i18n.error;
				status.style.color = '#dc3232';
			} );
		} );

		// ---------- Sync catalogos GHL (v2.1.0 PR-2) ----------
		// Boton paralelo al de Sperant. Endpoint distinto y dataset
		// distinto pero misma UX: disabled durante sync, status texto
		// con resultado, recarga al final para reflejar la tabla.
		var ghlBtn    = document.getElementById( 'wppe-bridge-ghl-sync-btn' );
		var ghlStatus = document.getElementById( 'wppe-bridge-ghl-sync-status' );
		if ( ghlBtn && ghlStatus && window.wppeBridgeAdmin && window.wppeBridgeAdmin.actions && window.wppeBridgeAdmin.actions.syncGhlCatalogs ) {
			ghlBtn.addEventListener( 'click', function () {
				ghlBtn.disabled = true;
				ghlStatus.textContent = window.wppeBridgeAdmin.i18n.syncing;
				ghlStatus.style.color = '#666';

				var data = new FormData();
				data.append( 'action', window.wppeBridgeAdmin.actions.syncGhlCatalogs );
				// El nonce viene del data-attr del boton (ya tiene el mismo
				// NONCE_ACTION que el sync de Sperant — comparten action key).
				data.append( 'nonce', ghlBtn.getAttribute( 'data-nonce' ) || window.wppeBridgeAdmin.nonce );

				fetch( window.wppeBridgeAdmin.ajaxUrl, {
					method:      'POST',
					credentials: 'same-origin',
					body:        data,
				} )
				.then( function ( res ) { return res.json(); } )
				.then( function ( payload ) {
					ghlBtn.disabled = false;
					if ( ! payload || ! payload.success ) {
						ghlStatus.textContent = ( payload && payload.data && payload.data.message ) || window.wppeBridgeAdmin.i18n.error;
						ghlStatus.style.color = '#dc3232';
						return;
					}

					var counts  = payload.data.counts || {};
					var summary = ( window.wppeBridgeAdmin.i18n.syncedGhl || 'Sincronizado' )
						.replace( '%pipelines%', counts.pipelines || 0 )
						.replace( '%custom_fields%', counts.custom_fields || 0 )
						.replace( '%tags%', counts.tags || 0 );

					if ( payload.data.has_errors && payload.data.errors ) {
						var errParts = [];
						for ( var k in payload.data.errors ) {
							if ( Object.prototype.hasOwnProperty.call( payload.data.errors, k ) ) {
								errParts.push( k + ': ' + payload.data.errors[k] );
							}
						}
						if ( errParts.length ) {
							summary += ' — ' + errParts.join( ', ' );
						}
					}

					ghlStatus.textContent = summary;
					ghlStatus.style.color = payload.data.has_errors ? '#dba617' : '#46b450';

					setTimeout( function () { window.location.reload(); }, 1500 );
				} )
				.catch( function () {
					ghlBtn.disabled = false;
					ghlStatus.textContent = window.wppeBridgeAdmin.i18n.error;
					ghlStatus.style.color = '#dc3232';
				} );
			} );
		}

		// ---------- Sync catalogos Odoo (v2.5.0 PR-2) ----------
		// Boton paralelo al de Sperant/GHL. 7 catalogos:
		// teams/users/utm.source/utm.medium/utm.campaign/tags/countries.
		var odooBtn    = document.getElementById( 'wppe-bridge-odoo-sync-btn' );
		var odooStatus = document.getElementById( 'wppe-bridge-odoo-sync-status' );
		if ( odooBtn && odooStatus && window.wppeBridgeAdmin && window.wppeBridgeAdmin.actions && window.wppeBridgeAdmin.actions.syncOdooCatalogs ) {
			odooBtn.addEventListener( 'click', function () {
				odooBtn.disabled = true;
				odooStatus.textContent = window.wppeBridgeAdmin.i18n.syncing;
				odooStatus.style.color = '#666';

				var data = new FormData();
				data.append( 'action', window.wppeBridgeAdmin.actions.syncOdooCatalogs );
				data.append( 'nonce', odooBtn.getAttribute( 'data-nonce' ) || window.wppeBridgeAdmin.nonce );

				fetch( window.wppeBridgeAdmin.ajaxUrl, {
					method:      'POST',
					credentials: 'same-origin',
					body:        data,
				} )
				.then( function ( res ) { return res.json(); } )
				.then( function ( payload ) {
					odooBtn.disabled = false;
					if ( ! payload || ! payload.success ) {
						odooStatus.textContent = ( payload && payload.data && payload.data.message ) || window.wppeBridgeAdmin.i18n.error;
						odooStatus.style.color = '#dc3232';
						return;
					}

					var counts  = payload.data.counts || {};
					var summary = ( window.wppeBridgeAdmin.i18n.syncedOdoo || 'Sincronizado' )
						.replace( '%teams%', counts.teams || 0 )
						.replace( '%users%', counts.users || 0 )
						.replace( '%utm_sources%', counts.utm_sources || 0 )
						.replace( '%utm_mediums%', counts.utm_mediums || 0 )
						.replace( '%utm_campaigns%', counts.utm_campaigns || 0 )
						.replace( '%tags%', counts.tags || 0 )
						.replace( '%countries%', counts.countries || 0 );

					if ( payload.data.has_errors && payload.data.errors ) {
						var errParts = [];
						for ( var k in payload.data.errors ) {
							if ( Object.prototype.hasOwnProperty.call( payload.data.errors, k ) ) {
								errParts.push( k + ': ' + payload.data.errors[k] );
							}
						}
						if ( errParts.length ) {
							summary += ' — ' + errParts.join( ', ' );
						}
					}

					odooStatus.textContent = summary;
					odooStatus.style.color = payload.data.has_errors ? '#dba617' : '#46b450';

					setTimeout( function () { window.location.reload(); }, 1500 );
				} )
				.catch( function () {
					odooBtn.disabled = false;
					odooStatus.textContent = window.wppeBridgeAdmin.i18n.error;
					odooStatus.style.color = '#dc3232';
				} );
			} );
		}

		// ---------- Sync catalogos HubSpot (v2.6.0 PR-2) ----------
		// Boton paralelo al de Sperant/GHL/Odoo. 2 catalogos:
		// owners + contact_properties (este ultimo deriva el enum
		// dinamico de lifecyclestage_options server-side, no es
		// un endpoint separado).
		var hubspotBtn    = document.getElementById( 'wppe-bridge-hubspot-sync-btn' );
		var hubspotStatus = document.getElementById( 'wppe-bridge-hubspot-sync-status' );
		if ( hubspotBtn && hubspotStatus && window.wppeBridgeAdmin && window.wppeBridgeAdmin.actions && window.wppeBridgeAdmin.actions.syncHubspotCatalogs ) {
			hubspotBtn.addEventListener( 'click', function () {
				hubspotBtn.disabled = true;
				hubspotStatus.textContent = window.wppeBridgeAdmin.i18n.syncing;
				hubspotStatus.style.color = '#666';

				var data = new FormData();
				data.append( 'action', window.wppeBridgeAdmin.actions.syncHubspotCatalogs );
				data.append( 'nonce', hubspotBtn.getAttribute( 'data-nonce' ) || window.wppeBridgeAdmin.nonce );

				fetch( window.wppeBridgeAdmin.ajaxUrl, {
					method:      'POST',
					credentials: 'same-origin',
					body:        data,
				} )
				.then( function ( res ) { return res.json(); } )
				.then( function ( payload ) {
					hubspotBtn.disabled = false;
					if ( ! payload || ! payload.success ) {
						hubspotStatus.textContent = ( payload && payload.data && payload.data.message ) || window.wppeBridgeAdmin.i18n.error;
						hubspotStatus.style.color = '#dc3232';
						return;
					}

					var counts  = payload.data.counts || {};
					var summary = ( window.wppeBridgeAdmin.i18n.syncedHubspot || 'Sincronizado' )
						.replace( '%owners%', counts.owners || 0 )
						.replace( '%contact_properties%', counts.contact_properties || 0 )
						.replace( '%lifecyclestage_options%', counts.lifecyclestage_options || 0 );

					if ( payload.data.has_errors && payload.data.errors ) {
						var errParts = [];
						for ( var k in payload.data.errors ) {
							if ( Object.prototype.hasOwnProperty.call( payload.data.errors, k ) ) {
								errParts.push( k + ': ' + payload.data.errors[k] );
							}
						}
						if ( errParts.length ) {
							summary += ' — ' + errParts.join( ', ' );
						}
					}

					hubspotStatus.textContent = summary;
					hubspotStatus.style.color = payload.data.has_errors ? '#dba617' : '#46b450';

					setTimeout( function () { window.location.reload(); }, 1500 );
				} )
				.catch( function () {
					hubspotBtn.disabled = false;
					hubspotStatus.textContent = window.wppeBridgeAdmin.i18n.error;
					hubspotStatus.style.color = '#dc3232';
				} );
			} );
		}

		// ---------- Buscar actualizaciones del plugin (v2.5.x) ----------
		// Strip "Versión instalada / Versión disponible" en Inicio. El
		// boton dispara force_refresh del Updater (invalida ambos
		// transients propio + update_plugins de WP) y refresca el strip
		// inline sin recargar la pagina.
		var updateBtn = document.getElementById( 'wppe-bridge-check-updates-btn' );
		if ( updateBtn && window.wppeBridgeAdmin && window.wppeBridgeAdmin.actions && window.wppeBridgeAdmin.actions.checkUpdates ) {
			updateBtn.addEventListener( 'click', function () {
				var statusText = document.getElementById( 'wppe-bridge-version-status-text' );
				updateBtn.disabled = true;
				if ( statusText ) {
					statusText.textContent = window.wppeBridgeAdmin.i18n.checkingUpdates || 'Consultando...';
					statusText.style.color = '#666';
				}

				var data = new FormData();
				data.append( 'action', window.wppeBridgeAdmin.actions.checkUpdates );
				data.append( 'nonce', updateBtn.getAttribute( 'data-nonce' ) || window.wppeBridgeAdmin.nonce );

				fetch( window.wppeBridgeAdmin.ajaxUrl, {
					method:      'POST',
					credentials: 'same-origin',
					body:        data,
				} )
				.then( function ( res ) { return res.json(); } )
				.then( function ( payload ) {
					updateBtn.disabled = false;
					if ( ! payload || ! payload.success || ! payload.data ) {
						if ( statusText ) {
							statusText.textContent = ( payload && payload.data && payload.data.message ) || window.wppeBridgeAdmin.i18n.error;
							statusText.style.color = '#dc3232';
						}
						return;
					}

					// Recarga la pagina — la card se regenera server-side
					// con los nuevos counts/badge/CTA. Mas simple que
					// reconstruir el strip por DOM en JS y mantener
					// fidelidad de styling, dado que es una operacion
					// rara (no se hace 10x por segundo).
					setTimeout( function () { window.location.reload(); }, 400 );
				} )
				.catch( function () {
					updateBtn.disabled = false;
					if ( statusText ) {
						statusText.textContent = window.wppeBridgeAdmin.i18n.error;
						statusText.style.color = '#dc3232';
					}
				} );
			} );
		}

		// ---------- Import manual de catalogos (v1.0.4) ----------
		// Cada boton .wppe-bridge-import-btn dispara un POST AJAX
		// con el JSON pegado en el textarea adyacente.
		var importBtns = document.querySelectorAll( '.wppe-bridge-import-btn' );
		for ( var i = 0; i < importBtns.length; i++ ) {
			importBtns[i].addEventListener( 'click', handleImportClick );
		}

		function handleImportClick( evt ) {
			var btn       = evt.currentTarget;
			var catalog   = btn.getAttribute( 'data-catalog' );
			var card      = btn.closest( '.wppe-bridge-import-card' );
			var textarea  = card ? card.querySelector( 'textarea' ) : null;
			var statusEl  = card ? card.querySelector( '.wppe-bridge-import-status' ) : null;

			if ( ! textarea || ! statusEl ) {
				return;
			}

			var json = textarea.value.trim();
			if ( '' === json ) {
				statusEl.textContent = window.wppeBridgeAdmin.i18n.importEmpty || 'Pega el JSON antes.';
				statusEl.style.color = '#dba617';
				return;
			}

			// Validacion local rapida del JSON antes de mandar.
			try {
				JSON.parse( json );
			} catch ( e ) {
				statusEl.textContent = ( window.wppeBridgeAdmin.i18n.importInvalidJson || 'JSON invalido' ) + ': ' + e.message;
				statusEl.style.color = '#dc3232';
				return;
			}

			btn.disabled        = true;
			statusEl.textContent = window.wppeBridgeAdmin.i18n.importLoading || 'Importando...';
			statusEl.style.color = '#666';

			var data = new FormData();
			data.append( 'action', window.wppeBridgeAdmin.actions.importCatalog );
			data.append( 'nonce', window.wppeBridgeAdmin.nonce );
			data.append( 'catalog', catalog );
			data.append( 'json', json );

			fetch( window.wppeBridgeAdmin.ajaxUrl, {
				method:      'POST',
				credentials: 'same-origin',
				body:        data,
			} )
			.then( function ( res ) { return res.json(); } )
			.then( function ( payload ) {
				btn.disabled = false;
				if ( ! payload || ! payload.success ) {
					var msg = ( payload && payload.data && payload.data.message ) || window.wppeBridgeAdmin.i18n.error;
					statusEl.textContent = msg;
					statusEl.style.color = '#dc3232';
					return;
				}
				statusEl.textContent = payload.data.message || ( '✓ ' + payload.data.count );
				statusEl.style.color = '#46b450';
				// Limpieza visual instantanea (v1.2.2). Antes el textarea
				// quedaba con la data pegada hasta que la pagina recargaba
				// 1.2s despues — daba sensacion de "no se importo".
				textarea.value = '';
				// Recarga para reflejar la tabla con el nuevo origen "Manual".
				setTimeout( function () {
					window.location.reload();
				}, 1200 );
			} )
			.catch( function () {
				btn.disabled = false;
				statusEl.textContent = window.wppeBridgeAdmin.i18n.error;
				statusEl.style.color = '#dc3232';
			} );
		}

		// ---------- Panel subdomain: live preview de las URLs de import (v1.1.2) ----------
		// Refleja en vivo el subdomain configurado en cada card de
		// "Importar catalogos manualmente". Aplica el mismo sanitizer
		// que `Settings_Page::sanitize_panel_subdomain` para que el
		// preview sea consistente con lo que se guardara.
		var subdomainInput = document.getElementById( 'wppe_bridge_panel_subdomain' );
		if ( subdomainInput ) {
			var panelDomain  = subdomainInput.getAttribute( 'data-panel-domain' ) || 'sperant.com';
			var feedback     = document.getElementById( 'wppe-bridge-subdomain-feedback' );
			var urlWraps     = document.querySelectorAll( '.wppe-bridge-panel-url-wrap' );

			function sanitizeSubdomain( raw ) {
				if ( typeof raw !== 'string' ) {
					return '';
				}
				var s = raw.trim().toLowerCase();
				if ( ! s ) {
					return '';
				}
				// URL completa: extraer host.
				if ( s.indexOf( '://' ) !== -1 ) {
					try {
						s = new URL( s ).hostname;
					} catch ( e ) {
						return '';
					}
				}
				// <sub>.sperant.com -> extraer sub.
				var suffix = '.' + panelDomain;
				if ( s.length > suffix.length && s.slice( -suffix.length ) === suffix ) {
					s = s.slice( 0, -suffix.length );
				}
				if ( ! s ) {
					return '';
				}
				// Solo a-z0-9-, no leading/trailing hyphen.
				if ( ! /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test( s ) ) {
					return '';
				}
				return s;
			}

			function updatePreview() {
				var raw      = subdomainInput.value;
				var sub      = sanitizeSubdomain( raw );
				var hasInput = !! raw.trim();

				// Feedback visual junto al input.
				if ( feedback ) {
					if ( sub ) {
						feedback.style.color = '#46b450';
						feedback.textContent = '✓ ' + sub + '.' + panelDomain;
					} else if ( hasInput ) {
						feedback.style.color = '#dc3232';
						feedback.textContent = '✗ Invalido (usa solo letras minusculas, numeros y guiones)';
					} else {
						feedback.textContent = '';
					}
				}

				// Actualizar cada card de import.
				urlWraps.forEach( function ( wrap ) {
					var endpoint    = wrap.getAttribute( 'data-endpoint' ) || '';
					var link        = wrap.querySelector( '.wppe-bridge-panel-link' );
					var code        = wrap.querySelector( '.wppe-bridge-panel-link-code' );
					var placeholder = wrap.querySelector( '.wppe-bridge-panel-placeholder' );

					if ( sub && link && code && placeholder ) {
						var fullUrl = 'https://' + sub + '.' + panelDomain + '/' + endpoint;
						link.setAttribute( 'href', fullUrl );
						code.textContent = fullUrl;
						link.style.display = '';
						placeholder.style.display = 'none';
					} else if ( link && placeholder ) {
						link.style.display = 'none';
						placeholder.style.display = '';
					}
				} );
			}

			subdomainInput.addEventListener( 'input', updatePreview );
			// Run once en DOMContentLoaded para reflejar el estado salvado
			// y manejar el caso de subdomain ya configurado (server-rendered).
			updatePreview();

			// ---------- Click en tip "subdomain" → scroll + focus + highlight (v1.2.2) ----------
			// Cuando el operador clickea el link "subdomain del panel
			// Sperant" en el tip amarillo arriba de las cards de import,
			// scrolleamos suavemente al campo, lo enfocamos, y le damos
			// un highlight de 2s para que sea obvio donde tipear.
			var tipLinks = document.querySelectorAll( 'a[href="#wppe_bridge_panel_subdomain"]' );
			for ( var li = 0; li < tipLinks.length; li++ ) {
				tipLinks[li].addEventListener( 'click', function ( evt ) {
					evt.preventDefault();
					subdomainInput.scrollIntoView( { behavior: 'smooth', block: 'center' } );
					setTimeout( function () {
						subdomainInput.focus();
						var origBoxShadow = subdomainInput.style.boxShadow;
						subdomainInput.style.transition = 'box-shadow 0.3s ease-in-out';
						subdomainInput.style.boxShadow  = '0 0 0 3px #ffd966';
						setTimeout( function () {
							subdomainInput.style.boxShadow = origBoxShadow;
						}, 2000 );
					}, 400 );
				} );
			}
		}
	} );
}() );
