<?php
/**
 * Modulo opcional Submit Lock (D4.4).
 *
 * Previene la causa #1 de duplicados (CLAUDE.md seccion 6): doble
 * click impaciente del usuario. Solucion JS-only universal: detecta
 * forms de Fluent / Gravity / Elementor por selector CSS y deshabilita
 * el boton submit al primer click. Re-habilita despues de N segundos
 * o cuando el plugin nativo emite un evento de fin de envio.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Modulo Submit Lock: enqueue del JS frontend cuando esta enabled.
 */
final class WPPE_Bridge_Module_Submit_Lock {

	/**
	 * Slug del modulo.
	 */
	public const SLUG = 'submit_lock';

	/**
	 * Option key de enabled.
	 */
	public const OPTION_ENABLED = 'wppe_bridge_module_submit_lock_enabled';

	/**
	 * Handle del asset JS.
	 */
	public const ASSET_HANDLE = 'wppe-bridge-submit-lock';

	/**
	 * Lee si el modulo esta enabled.
	 *
	 * @return bool
	 */
	public static function is_enabled(): bool {
		return (bool) get_option( self::OPTION_ENABLED, false );
	}

	/**
	 * Registra hooks runtime. Llamado desde Plugin::register_hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue_frontend' ) );
	}

	/**
	 * Enqueua el JS frontend. Carga global; el JS internamente filtra
	 * por presencia de forms relevantes en la pagina.
	 *
	 * @return void
	 */
	public static function enqueue_frontend(): void {
		wp_enqueue_script(
			self::ASSET_HANDLE,
			WPPE_BRIDGE_PLUGIN_URL . 'assets/js/submit-lock.js',
			array(),
			WPPE_BRIDGE_VERSION,
			true
		);
	}
}
