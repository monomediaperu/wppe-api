<?php
/**
 * Modulo opcional Thank You Pixel (D4.4).
 *
 * Inyecta el snippet del browser pixel de Meta via `wp_footer` solo
 * en las paginas marcadas como "thank you" desde la sub-pagina admin.
 * Sincroniza `event_id` con el modulo Meta CAPI server-side via
 * cookie `wppe_bridge_last_queue_id` que setea `Queue::insert` en el
 * submit, lo que permite que Meta deduplique los dos eventos.
 *
 * Configuracion (en sub-pagina `WP.pe Bridge > Thank You Pixel`):
 * - Multi-select de paginas WP a tratar como "thank you".
 *
 * El Pixel ID y el `event_name` se leen del modulo Meta CAPI (option
 * compartida) — un solo Pixel = un solo punto de configuracion.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Modulo Thank You Pixel: dispara browser pixel en thank you pages.
 */
final class WPPE_Bridge_Module_Thank_You_Pixel {

	public const SLUG = 'thank_you_pixel';

	public const OPTION_ENABLED = 'wppe_bridge_module_thank_you_pixel_enabled';
	public const OPTION_PAGES   = 'wppe_bridge_thank_you_pixel_pages';

	/**
	 * Nombre de la cookie que Queue::insert setea con el queue_id mas
	 * reciente, para que la JS de TYP la use como `eventID`.
	 */
	public const COOKIE_NAME = 'wppe_bridge_last_queue_id';

	/**
	 * TTL de la cookie en segundos (5 minutos: suficiente para que el
	 * usuario llegue a la TYP, corto para que no contamine sesiones
	 * posteriores).
	 */
	public const COOKIE_TTL_SECONDS = 300;

	/**
	 * Lee si el modulo esta enabled.
	 *
	 * @return bool
	 */
	public static function is_enabled(): bool {
		return (bool) get_option( self::OPTION_ENABLED, false );
	}

	/**
	 * Lee la lista de page IDs configurados como thank you pages.
	 *
	 * @return array<int,int>
	 */
	public static function get_pages(): array {
		$raw = get_option( self::OPTION_PAGES, array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$ids = array();
		foreach ( $raw as $value ) {
			$id = (int) $value;
			if ( $id > 0 ) {
				$ids[] = $id;
			}
		}
		return $ids;
	}

	/**
	 * Suscribe el render al hook `wp_footer` y el setter de cookie
	 * al action `wppe_bridge_lead_queued` (lo dispara Queue::enqueue).
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		add_action( 'wp_footer', array( self::class, 'render_pixel' ), 99 );
		add_action( 'wppe_bridge_lead_queued', array( self::class, 'set_event_id_cookie' ), 10, 1 );
	}

	/**
	 * Setea la cookie `wppe_bridge_last_queue_id` con el queue_id
	 * recien insertado, para que la JS de TYP la lea al cargar la
	 * thank you page y la use como `eventID`.
	 *
	 * Hookeado desde register() solo si el modulo esta enabled.
	 *
	 * @param int $queue_id ID del queue item.
	 * @return void
	 */
	public static function set_event_id_cookie( $queue_id ): void {
		$id = (int) $queue_id;
		if ( $id <= 0 ) {
			return;
		}
		// Si ya se mandaron headers (output prematuro o tests), no
		// podemos setear cookie — fallar silente.
		if ( headers_sent() ) {
			return;
		}
		setcookie(
			self::COOKIE_NAME,
			(string) $id,
			array(
				'expires'  => time() + self::COOKIE_TTL_SECONDS,
				'path'     => '/',
				'secure'   => is_ssl(),
				'httponly' => false, // JS la necesita leer.
				'samesite' => 'Lax',
			)
		);
	}

	/**
	 * Decide si la page actual califica para inyectar el pixel.
	 *
	 * Aislado en metodo publico para testeabilidad.
	 *
	 * @param int            $current_page_id ID de la page actual.
	 * @param array<int,int> $configured_ids  IDs configurados.
	 * @return bool
	 */
	public static function should_inject( int $current_page_id, array $configured_ids ): bool {
		if ( $current_page_id <= 0 || empty( $configured_ids ) ) {
			return false;
		}
		return in_array( $current_page_id, $configured_ids, true );
	}

	/**
	 * Renderiza el snippet del pixel via wp_footer.
	 *
	 * Guards (defensa en profundidad):
	 * - Pixel ID configurado en Meta CAPI.
	 * - Pagina actual ∈ OPTION_PAGES.
	 *
	 * @return void
	 */
	public static function render_pixel(): void {
		$pixel_id = (string) get_option( WPPE_Bridge_Module_Meta_Capi::OPTION_PIXEL_ID, '' );
		if ( '' === $pixel_id ) {
			return;
		}

		$page_id = (int) get_queried_object_id();
		if ( ! self::should_inject( $page_id, self::get_pages() ) ) {
			return;
		}

		$event_name = WPPE_Bridge_Module_Meta_Capi::get_event_name();
		$event_id   = self::resolve_event_id();

		// fbq se asume cargado por el snippet base del Pixel del cliente
		// (theme o plugin generico). Si no esta, este snippet falla
		// silente — preferible a duplicar la inyeccion del init.
		?>
<!-- WP.pe Bridge — Thank You Pixel -->
<script>
(function(){
	if (typeof fbq !== 'function') { return; }
	fbq('track', <?php echo wp_json_encode( $event_name ); ?>, {}, { eventID: <?php echo wp_json_encode( $event_id ); ?> });
})();
</script>
		<?php
	}

	/**
	 * Resuelve el `event_id` para sincronizar con Meta CAPI.
	 *
	 * Prioriza la cookie `wppe_bridge_last_queue_id` (la que setea
	 * Queue::insert en el submit). Si no existe, genera un UUID v4
	 * propio para que el evento siga siendo valido en Meta — peor
	 * caso es que ese evento no se deduplica con CAPI.
	 *
	 * @return string
	 */
	public static function resolve_event_id(): string {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Cookie value se castea a int y valida abajo; es un id numerico interno.
		$raw = isset( $_COOKIE[ self::COOKIE_NAME ] ) ? $_COOKIE[ self::COOKIE_NAME ] : '';
		if ( is_string( $raw ) && '' !== $raw ) {
			$queue_id = (int) $raw;
			if ( $queue_id > 0 ) {
				return 'wppe-bridge-' . $queue_id;
			}
		}
		return self::generate_uuid_v4();
	}

	/**
	 * Genera un UUID v4 simple (RFC 4122 compliant) sin dependencias.
	 *
	 * @return string
	 */
	public static function generate_uuid_v4(): string {
		$bytes    = random_bytes( 16 );
		$bytes[6] = chr( ( ord( $bytes[6] ) & 0x0f ) | 0x40 );
		$bytes[8] = chr( ( ord( $bytes[8] ) & 0x3f ) | 0x80 );
		return vsprintf(
			'%s%s-%s-%s-%s-%s%s%s',
			str_split( bin2hex( $bytes ), 4 )
		);
	}
}
