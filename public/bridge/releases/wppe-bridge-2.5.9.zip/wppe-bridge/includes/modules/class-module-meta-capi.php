<?php
/**
 * Modulo opcional Meta CAPI (D4.4).
 *
 * Server-side Meta Conversions API: cuando el Worker emite
 * `wppe_bridge_lead_sent` exitosamente, este modulo dispara un
 * evento Lead a la Graph API de Meta con los datos del lead
 * hasheados con SHA-256 (spec oficial de Meta para PII matching).
 *
 * Configuracion (en sub-pagina `WP.pe Bridge > Meta CAPI`):
 * - Pixel ID (a.k.a. dataset ID en Events Manager).
 * - Access Token (long-lived, generado en Events Manager).
 * - Test Event Code (opcional, para que aparezca en Test Events).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Modulo Meta CAPI: dispara Lead event server-side.
 */
final class WPPE_Bridge_Module_Meta_Capi {

	public const SLUG = 'meta_capi';

	public const OPTION_ENABLED         = 'wppe_bridge_module_meta_capi_enabled';
	public const OPTION_PIXEL_ID        = 'wppe_bridge_meta_capi_pixel_id';
	public const OPTION_ACCESS_TOKEN    = 'wppe_bridge_meta_capi_access_token';
	public const OPTION_TEST_EVENT_CODE = 'wppe_bridge_meta_capi_test_event_code';

	/**
	 * Option compartida con Thank You Pixel: tipo de evento Meta a
	 * disparar en ambos lados (server-side + browser). Para que el
	 * dedup nativo de Meta funcione, los dos eventos deben tener
	 * `event_name` y `event_id` identicos.
	 */
	public const OPTION_EVENT_NAME = 'wppe_bridge_meta_event_name';

	/**
	 * Default cuando la option no esta seteada (instalacion fresca).
	 */
	public const EVENT_NAME_DEFAULT = 'Lead';

	/**
	 * Whitelist de eventos estandar de Meta relevantes para inmobiliaria.
	 * Spec: https://developers.facebook.com/docs/meta-pixel/reference#standard-events
	 */
	public const ALLOWED_EVENT_NAMES = array(
		'Lead',
		'CompleteRegistration',
		'Contact',
		'SubmitApplication',
		'Schedule',
	);

	/**
	 * Version de la Graph API de Meta.
	 */
	public const GRAPH_API_VERSION = 'v18.0';

	/**
	 * Timeout HTTP al hit a Graph API (segundos).
	 */
	public const HTTP_TIMEOUT_SECONDS = 10;

	/**
	 * Lee el `event_name` configurado, con fallback a default si la
	 * option esta vacia o tiene un valor fuera del whitelist (defensa
	 * en profundidad — el sanitizer ya filtra al guardar).
	 *
	 * @return string
	 */
	public static function get_event_name(): string {
		$value = (string) get_option( self::OPTION_EVENT_NAME, self::EVENT_NAME_DEFAULT );
		return in_array( $value, self::ALLOWED_EVENT_NAMES, true ) ? $value : self::EVENT_NAME_DEFAULT;
	}

	/**
	 * Lee si el modulo esta enabled.
	 *
	 * @return bool
	 */
	public static function is_enabled(): bool {
		return (bool) get_option( self::OPTION_ENABLED, false );
	}

	/**
	 * Suscribe el handler al action `wppe_bridge_lead_sent`.
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		add_action( 'wppe_bridge_lead_sent', array( self::class, 'on_lead_sent' ), 10, 3 );
	}

	/**
	 * Handler del action `wppe_bridge_lead_sent`.
	 *
	 * @param array $payload  Payload normalizado enviado a Sperant.
	 * @param int   $queue_id ID del queue item.
	 * @param array $response Respuesta uniforme del SperantClient.
	 * @return void
	 */
	public static function on_lead_sent( $payload, $queue_id, $response ): void {
		unset( $response );
		if ( ! is_array( $payload ) ) {
			return;
		}

		$pixel_id = (string) get_option( self::OPTION_PIXEL_ID, '' );
		$token    = (string) get_option( self::OPTION_ACCESS_TOKEN, '' );

		if ( '' === $pixel_id || '' === $token ) {
			WPPE_Bridge_Logger::warn(
				'meta_capi_missing_config',
				array(
					'has_pixel_id' => '' !== $pixel_id,
					'has_token'    => '' !== $token,
				),
				(int) $queue_id
			);
			return;
		}

		$event = self::build_event( $payload, (int) $queue_id );

		$body = array( 'data' => array( $event ) );

		$test_event_code = (string) get_option( self::OPTION_TEST_EVENT_CODE, '' );
		if ( '' !== $test_event_code ) {
			$body['test_event_code'] = $test_event_code;
		}

		$url = sprintf(
			'https://graph.facebook.com/%s/%s/events?access_token=%s',
			self::GRAPH_API_VERSION,
			rawurlencode( $pixel_id ),
			rawurlencode( $token )
		);

		$resp = wp_remote_post(
			$url,
			array(
				'method'  => 'POST',
				'timeout' => self::HTTP_TIMEOUT_SECONDS,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $resp ) ) {
			WPPE_Bridge_Logger::warn(
				'meta_capi_network_error',
				array( 'error' => $resp->get_error_message() ),
				(int) $queue_id
			);
			return;
		}

		$status = (int) wp_remote_retrieve_response_code( $resp );
		if ( $status < 200 || $status >= 300 ) {
			WPPE_Bridge_Logger::warn(
				'meta_capi_http_error',
				array(
					'status' => $status,
					'body'   => (string) wp_remote_retrieve_body( $resp ),
				),
				(int) $queue_id
			);
			return;
		}

		WPPE_Bridge_Logger::info( 'meta_capi_lead_sent', array( 'event_id' => $event['event_id'] ), (int) $queue_id );
	}

	/**
	 * Construye el evento Meta CAPI con PII hasheada.
	 *
	 * Spec: https://developers.facebook.com/docs/marketing-api/conversions-api/
	 *
	 * @param array $payload  Payload normalizado.
	 * @param int   $queue_id ID del queue item.
	 * @return array
	 */
	public static function build_event( array $payload, int $queue_id ): array {
		$user_data = array();

		if ( ! empty( $payload['email'] ) && is_string( $payload['email'] ) ) {
			$user_data['em'] = array( self::hash_email( $payload['email'] ) );
		}
		if ( ! empty( $payload['phone'] ) && is_string( $payload['phone'] ) ) {
			$user_data['ph'] = array( self::hash_phone( $payload['phone'] ) );
		}
		if ( ! empty( $payload['fname'] ) && is_string( $payload['fname'] ) ) {
			$user_data['fn'] = array( self::hash_name( $payload['fname'] ) );
		}
		if ( ! empty( $payload['lname'] ) && is_string( $payload['lname'] ) ) {
			$user_data['ln'] = array( self::hash_name( $payload['lname'] ) );
		}
		if ( ! empty( $payload['client_ip'] ) && is_string( $payload['client_ip'] ) ) {
			$user_data['client_ip_address'] = $payload['client_ip'];
		}
		if ( ! empty( $payload['client_user_agent'] ) && is_string( $payload['client_user_agent'] ) ) {
			$user_data['client_user_agent'] = $payload['client_user_agent'];
		}
		if ( ! empty( $payload['fbclid'] ) && is_string( $payload['fbclid'] ) ) {
			$user_data['fbc'] = self::build_fbc( $payload['fbclid'] );
		}
		if ( ! empty( $payload['fbp'] ) && is_string( $payload['fbp'] ) ) {
			$user_data['fbp'] = $payload['fbp'];
		}

		return array(
			'event_name'       => self::get_event_name(),
			'event_time'       => time(),
			'event_id'         => 'wppe-bridge-' . $queue_id,
			'action_source'    => 'website',
			'event_source_url' => isset( $payload['landing_url'] ) ? (string) $payload['landing_url'] : '',
			'user_data'        => $user_data,
			'custom_data'      => array(
				'lead_event_source' => 'WP.pe Bridge',
			),
		);
	}

	/**
	 * Hashea email: lowercase + trim + sha256.
	 *
	 * @param string $email Email.
	 * @return string
	 */
	public static function hash_email( string $email ): string {
		return hash( 'sha256', strtolower( trim( $email ) ) );
	}

	/**
	 * Hashea phone: solo digitos (sin +) + sha256.
	 *
	 * @param string $phone Telefono.
	 * @return string
	 */
	public static function hash_phone( string $phone ): string {
		$digits = preg_replace( '/\D/', '', $phone );
		return hash( 'sha256', null === $digits ? '' : $digits );
	}

	/**
	 * Hashea nombre / apellido: lowercase + trim + sha256.
	 *
	 * @param string $name Nombre o apellido.
	 * @return string
	 */
	public static function hash_name( string $name ): string {
		return hash( 'sha256', mb_strtolower( trim( $name ), 'UTF-8' ) );
	}

	/**
	 * Construye el `fbc` parameter de Meta a partir de `fbclid`.
	 * Formato: fb.{subdomain_index}.{creation_time}.{fbclid}
	 * Spec: https://developers.facebook.com/docs/marketing-api/conversions-api/parameters/fbp-and-fbc
	 *
	 * @param string $fbclid Token fbclid del URL.
	 * @return string
	 */
	public static function build_fbc( string $fbclid ): string {
		return sprintf( 'fb.1.%d.%s', time() * 1000, $fbclid );
	}
}
