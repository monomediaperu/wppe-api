<?php
/**
 * Modulo opcional UTM Capture (D4.4).
 *
 * Captura UTMs/GCLID/fbclid de la URL al cargar cualquier pagina,
 * persiste en cookie `wppe_bridge_utms` (JSON) + localStorage por
 * 90 dias. El adapter base ya lee esa cookie (ver Form_Adapter_Base::
 * capture_utms), asi que con esto el flujo end-to-end queda con UTMs
 * reales en lugar de fallback 'direct'.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Modulo UTM Capture: enqueue del JS frontend cuando esta enabled.
 */
final class WPPE_Bridge_Module_Utm_Capture {

	/**
	 * Slug del modulo (usado como key en wp_options).
	 */
	public const SLUG = 'utm_capture';

	/**
	 * Option key de enabled.
	 */
	public const OPTION_ENABLED = 'wppe_bridge_module_utm_capture_enabled';

	/**
	 * Handle del asset JS (debe ser unico).
	 */
	public const ASSET_HANDLE = 'wppe-bridge-utm-capture';

	/**
	 * Lee si el modulo esta enabled.
	 *
	 * @return bool
	 */
	public static function is_enabled(): bool {
		return (bool) get_option( self::OPTION_ENABLED, false );
	}

	/**
	 * Registra hooks runtime. Llamado desde Plugin::register_hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue_frontend' ) );
	}

	/**
	 * Enqueua el JS frontend en cualquier pagina del sitio (no solo
	 * donde hay form, porque queremos capturar UTMs aunque el
	 * visitante navegue por varias paginas antes de llegar al form).
	 *
	 * @return void
	 */
	public static function enqueue_frontend(): void {
		wp_enqueue_script(
			self::ASSET_HANDLE,
			WPPE_BRIDGE_PLUGIN_URL . 'assets/js/utm-capture.js',
			array(),
			WPPE_BRIDGE_VERSION,
			true
		);
	}
}
