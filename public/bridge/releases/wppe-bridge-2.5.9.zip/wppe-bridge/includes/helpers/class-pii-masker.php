<?php
/**
 * Helpers para enmascarar PII en la UI del panel admin.
 *
 * Regla 10.8 del CLAUDE.md: NUNCA mostrar PII en plaintext donde no
 * sea estrictamente necesario. La pagina de Logs muestra emails y
 * telefonos enmascarados; el detalle completo aparece solo cuando
 * el admin hace click en "ver payload".
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Helpers PII para la UI.
 */
final class WPPE_Bridge_Pii_Masker {

	/**
	 * Enmascara un email: primer caracter + asteriscos + dominio.
	 * Ej: "maria@example.com" -> "m***@example.com".
	 * Si no es email valido, retorna cadena vacia.
	 *
	 * @param string $email Email crudo.
	 * @return string
	 */
	public static function mask_email( string $email ): string {
		$at = strpos( $email, '@' );
		if ( false === $at || 0 === $at ) {
			return '';
		}
		$local  = substr( $email, 0, $at );
		$domain = substr( $email, $at );
		if ( '' === $local || strlen( $local ) < 1 ) {
			return '';
		}
		return $local[0] . '***' . $domain;
	}

	/**
	 * Enmascara un telefono: preserva prefijo internacional (`+XX`) y
	 * los ultimos 4 digitos, asteriscos al medio.
	 * Ej: "+51999888777" -> "+51****8777".
	 * Si es muy corto (<8), retorna asteriscos.
	 *
	 * @param string $phone Telefono crudo (idealmente E.164).
	 * @return string
	 */
	public static function mask_phone( string $phone ): string {
		$phone = trim( $phone );
		if ( '' === $phone ) {
			return '';
		}
		if ( strlen( $phone ) < 8 ) {
			return str_repeat( '*', strlen( $phone ) );
		}

		// Detectar prefijo internacional: si empieza con `+` y 2
		// digitos, preserva esos 3 caracteres. Cubre +51 (Peru), +1
		// (USA, perdiendo el primer digito del numero local), +52
		// (Mexico), etc. Para prefijos de 3 digitos como +591
		// (Bolivia), el primer digito local queda enmascarado —
		// trade-off aceptable para masking.
		$prefix = '';
		$rest   = $phone;
		if ( '+' === $phone[0] && preg_match( '/^\+\d{2}/', $phone ) ) {
			$prefix = substr( $phone, 0, 3 );
			$rest   = substr( $phone, 3 );
		}

		$last4 = substr( $rest, -4 );
		$mid   = substr( $rest, 0, -4 );
		$mask  = str_repeat( '*', strlen( $mid ) );
		return $prefix . $mask . $last4;
	}
}
