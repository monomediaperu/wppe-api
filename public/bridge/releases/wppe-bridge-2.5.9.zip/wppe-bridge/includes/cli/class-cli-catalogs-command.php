<?php
/**
 * Comando WP-CLI: wp wppe-bridge catalogs ...
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Comandos de catalogos.
 */
final class WPPE_Bridge_Cli_Catalogs_Command {

	/**
	 * Sincroniza catalogos contra Sperant y los persiste.
	 *
	 * ## EXAMPLES
	 *
	 *     wp wppe-bridge catalogs sync
	 *
	 * @param array $args       (no uso).
	 * @param array $assoc_args (no uso).
	 * @return void
	 */
	public function sync( $args, $assoc_args ) {
		unset( $args, $assoc_args );

		$token = (string) get_option( 'wppe_bridge_api_token', '' );
		if ( '' === $token ) {
			\WP_CLI::error( 'No hay token configurado. Setealo desde el panel admin o con `wp option update wppe_bridge_api_token <token>`.' );
		}

		\WP_CLI::log( 'Sincronizando catalogos...' );
		$result = WPPE_Sperant_Client::sync_catalogs();
		update_option( 'wppe_bridge_catalogs', $result );

		$counts = array();
		foreach ( array( 'input_channels', 'sources', 'interest_types', 'projects' ) as $k ) {
			$counts[ $k ] = isset( $result[ $k ] ) && is_array( $result[ $k ] ) ? count( $result[ $k ] ) : 0;
		}

		$has_errors = isset( $result['_errors'] ) && ! empty( $result['_errors'] );

		\WP_CLI::log(
			sprintf(
				'Resultado: input_channels=%d sources=%d interest_types=%d projects=%d',
				$counts['input_channels'],
				$counts['sources'],
				$counts['interest_types'],
				$counts['projects']
			)
		);

		if ( $has_errors ) {
			\WP_CLI::warning( 'Algunos catalogos fallaron:' );
			foreach ( $result['_errors'] as $key => $err ) {
				\WP_CLI::log( sprintf( '  - %s: %s', $key, $err ) );
			}
		} else {
			\WP_CLI::success( 'Sincronizacion completa.' );
		}
	}
}
