<?php
/**
 * Comando WP-CLI: wp wppe-bridge logs ...
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Comandos de logs.
 */
final class WPPE_Bridge_Cli_Logs_Command {

	/**
	 * Muestra los ultimos logs (con masking PII).
	 *
	 * ## OPTIONS
	 *
	 * [--level=<level>]
	 * : Filtra por nivel: info | warn | error.
	 *
	 * [--limit=<n>]
	 * : Cuantos. Default: 50.
	 *
	 * [--format=<format>]
	 * : table | json | csv. Default: table.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - json
	 *   - csv
	 * ---
	 *
	 * ## EXAMPLES
	 *
	 *     wp wppe-bridge logs tail
	 *     wp wppe-bridge logs tail --level=error --limit=10
	 *
	 * @param array $args       (no uso).
	 * @param array $assoc_args [level, limit, format].
	 * @return void
	 */
	public function tail( $args, $assoc_args ) {
		unset( $args );
		$level  = isset( $assoc_args['level'] ) ? (string) $assoc_args['level'] : null;
		$limit  = isset( $assoc_args['limit'] ) ? max( 1, (int) $assoc_args['limit'] ) : 50;
		$format = isset( $assoc_args['format'] ) ? (string) $assoc_args['format'] : 'table';

		$rows = WPPE_Bridge_Logger::recent( $limit, $level );
		if ( empty( $rows ) ) {
			\WP_CLI::log( 'No hay logs.' );
			return;
		}

		$items = array();
		foreach ( $rows as $row ) {
			$items[] = array(
				'id'         => (int) $row->id,
				'created_at' => (string) $row->created_at,
				'level'      => (string) $row->level,
				'queue_id'   => null === $row->queue_id ? '' : (string) $row->queue_id,
				'message'    => (string) $row->message,
				// El context ya esta enmascarado por el Logger; lo
				// truncamos para tabla.
				'context'    => self::truncate( (string) $row->context, 120 ),
			);
		}

		\WP_CLI\Utils\format_items( $format, $items, array( 'id', 'created_at', 'level', 'queue_id', 'message', 'context' ) );
	}

	/**
	 * Trunca un string para visualizacion en tabla.
	 *
	 * @param string $s   Input.
	 * @param int    $max Longitud maxima.
	 * @return string
	 */
	private static function truncate( string $s, int $max ): string {
		if ( strlen( $s ) <= $max ) {
			return $s;
		}
		return substr( $s, 0, $max - 3 ) . '...';
	}
}
