<?php
/**
 * Comandos WP-CLI del plugin.
 *
 * Registra comandos bajo el namespace `wppe-bridge`. Las clases
 * concretas viven en archivos separados por familia (queue, catalogs,
 * logs, doctor).
 *
 * Uso:
 *   wp wppe-bridge queue list
 *   wp wppe-bridge queue retry <id>
 *   wp wppe-bridge queue retry-failed [--yes]
 *   wp wppe-bridge catalogs sync
 *   wp wppe-bridge logs tail [--level=<level>] [--limit=<n>]
 *   wp wppe-bridge doctor [--check-api]
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registrador de comandos WP-CLI.
 */
final class WPPE_Bridge_CLI_Commands {

	/**
	 * Carga las clases de comandos y las registra en WP-CLI.
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! class_exists( 'WP_CLI' ) ) {
			return;
		}

		$base = WPPE_BRIDGE_PLUGIN_DIR . 'includes/cli/';
		require_once $base . 'class-cli-doctor.php';
		require_once $base . 'class-cli-queue-command.php';
		require_once $base . 'class-cli-catalogs-command.php';
		require_once $base . 'class-cli-logs-command.php';
		require_once $base . 'class-cli-doctor-command.php';

		\WP_CLI::add_command( 'wppe-bridge queue', 'WPPE_Bridge_Cli_Queue_Command' );
		\WP_CLI::add_command( 'wppe-bridge catalogs', 'WPPE_Bridge_Cli_Catalogs_Command' );
		\WP_CLI::add_command( 'wppe-bridge logs', 'WPPE_Bridge_Cli_Logs_Command' );
		\WP_CLI::add_command( 'wppe-bridge doctor', 'WPPE_Bridge_Cli_Doctor_Command' );
	}
}
