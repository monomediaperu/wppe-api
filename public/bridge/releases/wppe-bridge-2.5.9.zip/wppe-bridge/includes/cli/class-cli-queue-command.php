<?php
/**
 * Comando WP-CLI: wp wppe-bridge queue ...
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Comandos de queue.
 */
final class WPPE_Bridge_Cli_Queue_Command {

	/**
	 * Lista items de la queue.
	 *
	 * ## OPTIONS
	 *
	 * [--status=<status>]
	 * : Filtra por status (pending, sent, failed_temp, failed_permanent, deduped).
	 *
	 * [--limit=<n>]
	 * : Cuantos a traer. Default: 25.
	 *
	 * [--format=<format>]
	 * : table | json | csv. Default: table.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - json
	 *   - csv
	 * ---
	 *
	 * ## EXAMPLES
	 *
	 *     wp wppe-bridge queue list
	 *     wp wppe-bridge queue list --status=failed_permanent --limit=50
	 *     wp wppe-bridge queue list --format=json
	 *
	 * @param array $args       Args posicionales.
	 * @param array $assoc_args Args asociativos.
	 * @return void
	 */
	public function list( $args, $assoc_args ) {
		unset( $args );
		$status = isset( $assoc_args['status'] ) ? (string) $assoc_args['status'] : null;
		$limit  = isset( $assoc_args['limit'] ) ? max( 1, (int) $assoc_args['limit'] ) : 25;
		$format = isset( $assoc_args['format'] ) ? (string) $assoc_args['format'] : 'table';

		$rows = WPPE_Bridge_Queue::paginate(
			array(
				'status'   => $status,
				'per_page' => $limit,
				'page'     => 1,
			)
		);

		if ( empty( $rows ) ) {
			\WP_CLI::log( 'No hay items.' );
			return;
		}

		$items = array();
		foreach ( $rows as $row ) {
			$payload = is_string( $row->payload ) ? json_decode( $row->payload, true ) : null;
			$email   = is_array( $payload ) && isset( $payload['email'] ) ? (string) $payload['email'] : '';
			$items[] = array(
				'id'         => (int) $row->id,
				'created_at' => (string) $row->created_at,
				'form'       => sprintf( '%s#%s', $row->form_plugin, $row->form_id ),
				'email'      => WPPE_Bridge_Pii_Masker::mask_email( $email ),
				'status'     => (string) $row->status,
				'attempts'   => (int) $row->attempts,
			);
		}

		\WP_CLI\Utils\format_items( $format, $items, array( 'id', 'created_at', 'form', 'email', 'status', 'attempts' ) );
	}

	/**
	 * Reencola un item especifico.
	 *
	 * ## OPTIONS
	 *
	 * <id>
	 * : ID del queue item.
	 *
	 * ## EXAMPLES
	 *
	 *     wp wppe-bridge queue retry 42
	 *
	 * @param array $args       [id].
	 * @param array $assoc_args (no uso).
	 * @return void
	 */
	public function retry( $args, $assoc_args ) {
		unset( $assoc_args );
		$id = isset( $args[0] ) ? (int) $args[0] : 0;
		if ( $id <= 0 ) {
			\WP_CLI::error( 'Falta <id>.' );
		}

		if ( WPPE_Bridge_Queue::queue_for_retry( $id ) ) {
			\WP_CLI::success( sprintf( 'Item #%d marcado para reintento.', $id ) );
		} else {
			\WP_CLI::error( sprintf( 'No se pudo reencolar #%d (existe?).', $id ) );
		}
	}

	/**
	 * Reencola todos los items en estado failed_temp y failed_permanent.
	 *
	 * ## OPTIONS
	 *
	 * [--limit=<n>]
	 * : Cuantos reencolar como maximo. Default: 100.
	 *
	 * [--yes]
	 * : Saltea la confirmacion.
	 *
	 * ## EXAMPLES
	 *
	 *     wp wppe-bridge queue retry-failed
	 *     wp wppe-bridge queue retry-failed --yes
	 *     wp wppe-bridge queue retry-failed --limit=10
	 *
	 * @subcommand retry-failed
	 * @param array $args       (no uso).
	 * @param array $assoc_args [limit, yes].
	 * @return void
	 */
	public function retry_failed( $args, $assoc_args ) {
		unset( $args );
		$limit = isset( $assoc_args['limit'] ) ? max( 1, (int) $assoc_args['limit'] ) : 100;

		$count_temp = WPPE_Bridge_Queue::count_by_status( WPPE_Bridge_Queue::STATUS_FAILED_TEMP );
		$count_perm = WPPE_Bridge_Queue::count_by_status( WPPE_Bridge_Queue::STATUS_FAILED_PERMANENT );
		$total      = $count_temp + $count_perm;

		if ( 0 === $total ) {
			\WP_CLI::log( 'No hay items fallidos.' );
			return;
		}

		\WP_CLI::confirm(
			sprintf(
				'Reencolar hasta %d items fallidos (%d temp + %d perm)?',
				min( $limit, $total ),
				$count_temp,
				$count_perm
			),
			$assoc_args
		);

		$retried = 0;
		foreach ( array( WPPE_Bridge_Queue::STATUS_FAILED_TEMP, WPPE_Bridge_Queue::STATUS_FAILED_PERMANENT ) as $status ) {
			if ( $retried >= $limit ) {
				break;
			}
			$rows = WPPE_Bridge_Queue::paginate(
				array(
					'status'   => $status,
					'per_page' => $limit - $retried,
					'page'     => 1,
				)
			);
			foreach ( $rows as $row ) {
				if ( WPPE_Bridge_Queue::queue_for_retry( (int) $row->id ) ) {
					++$retried;
				}
			}
		}

		\WP_CLI::success( sprintf( '%d items reencolados.', $retried ) );
	}

	/**
	 * Borra items de la queue que matchean PII especifica (ARCO — derecho
	 * de cancelacion de Ley 29733 LPDP). v2.5.9.
	 *
	 * Por defecto NO toca items con status `pending` ni `failed_temp` —
	 * son leads que aun no llegaron al CRM y borrarlos significaria
	 * perderlos. Para borrar tambien esos, pasar `--include-in-flight`.
	 *
	 * Por defecto corre en modo preview (cuenta sin borrar). Para ejecutar
	 * de verdad hay que pasar `--yes` (defensa contra typos).
	 *
	 * ## OPTIONS
	 *
	 * [--email=<email>]
	 * : Email a borrar (case-insensitive, ya normalizado lower en payload).
	 *
	 * [--phone=<phone>]
	 * : Telefono a borrar (formato E.164, ej. +51999888777).
	 *
	 * [--document=<dni>]
	 * : Documento a borrar (solo digitos, sin guiones ni espacios).
	 *
	 * [--include-in-flight]
	 * : Tambien borra items con status pending y failed_temp. Por defecto
	 *   se preservan (son leads en proceso). Usar con cuidado.
	 *
	 * [--yes]
	 * : Ejecuta el borrado. Sin este flag, solo muestra cuantos rows
	 *   matchean (dry-run).
	 *
	 * ## EXAMPLES
	 *
	 *     # Preview: cuantas rows tiene esa email en la queue.
	 *     wp wppe-bridge queue forget --email=ana@example.com
	 *
	 *     # Ejecutar (borra terminados; preserva pending+failed_temp).
	 *     wp wppe-bridge queue forget --email=ana@example.com --yes
	 *
	 *     # Borrar todo incluyendo leads en proceso.
	 *     wp wppe-bridge queue forget --document=12345678 --include-in-flight --yes
	 *
	 * @param array $args       Args posicionales.
	 * @param array $assoc_args Args asociativos.
	 * @return void
	 */
	public function forget( $args, $assoc_args ) {
		unset( $args );

		$email    = isset( $assoc_args['email'] ) ? trim( (string) $assoc_args['email'] ) : '';
		$phone    = isset( $assoc_args['phone'] ) ? trim( (string) $assoc_args['phone'] ) : '';
		$document = isset( $assoc_args['document'] ) ? trim( (string) $assoc_args['document'] ) : '';

		$fields_provided = array_filter(
			array(
				'email'    => $email,
				'phone'    => $phone,
				'document' => $document,
			)
		);

		if ( empty( $fields_provided ) ) {
			\WP_CLI::error( 'Debes pasar al menos uno de --email, --phone, --document.' );
			return;
		}

		$include_in_flight = isset( $assoc_args['include-in-flight'] );
		$confirm           = isset( $assoc_args['yes'] );

		if ( ! $confirm ) {
			// Preview mode: contamos sin borrar para que el operador vea
			// el blast radius antes de confirmar.
			$counts = array();
			foreach ( $fields_provided as $field => $value ) {
				$counts[ $field ] = self::count_matches( $field, $value, $include_in_flight );
			}
			\WP_CLI::log( 'PREVIEW MODE (sin --yes). Filas que matchean:' );
			foreach ( $counts as $field => $n ) {
				\WP_CLI::log( sprintf( '  %s: %d', $field, $n ) );
			}
			\WP_CLI::log( '' );
			\WP_CLI::log(
				$include_in_flight
					? 'Modo: INCLUYE pending + failed_temp (leads en proceso seran borrados).'
					: 'Modo: SOLO terminados (sent/deduped/failed_permanent/paused). Pending+failed_temp se preservan.'
			);
			\WP_CLI::log( '' );
			\WP_CLI::log( 'Para ejecutar, agregar --yes.' );
			return;
		}

		// Ejecutar.
		$total = 0;
		foreach ( $fields_provided as $field => $value ) {
			$deleted = WPPE_Bridge_Queue::forget_by_pii( $field, $value, $include_in_flight );
			$total  += $deleted;
			\WP_CLI::log( sprintf( '  %s=%s → %d filas borradas.', $field, $value, $deleted ) );
		}

		// Log de auditoria (sin PII en el message — solo conteo).
		if ( class_exists( 'WPPE_Bridge_Logger' ) ) {
			WPPE_Bridge_Logger::warn(
				'arco_forget_executed',
				array(
					'fields_count'      => count( $fields_provided ),
					'fields'            => array_keys( $fields_provided ),
					'total_deleted'     => $total,
					'include_in_flight' => $include_in_flight,
				),
				null
			);
		}

		\WP_CLI::success( sprintf( 'Total: %d filas borradas (ARCO).', $total ) );
	}

	/**
	 * Cuenta cuantos rows matchean un field+value sin borrarlos (preview).
	 * Reproduce la logica de Queue::forget_by_pii con DELETE -> COUNT.
	 *
	 * @param string $field             email|phone|document.
	 * @param string $value             Valor.
	 * @param bool   $include_in_flight Incluir pending+failed_temp.
	 * @return int
	 */
	private static function count_matches( string $field, string $value, bool $include_in_flight ): int {
		global $wpdb;
		$table            = $wpdb->prefix . 'wppebridge_queue';
		$normalized_value = ( 'email' === $field ) ? strtolower( $value ) : $value;
		$json_fragment    = '"' . $field . '":"' . $normalized_value . '"';
		$like             = '%' . $wpdb->esc_like( $json_fragment ) . '%';

		$statuses_to_skip = $include_in_flight
			? array()
			: array( 'pending', 'failed_temp' );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- table name from $wpdb->prefix, preview count sin alternativa.
		if ( empty( $statuses_to_skip ) ) {
			$count = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$table} WHERE payload LIKE %s",
					$like
				)
			);
		} else {
			$placeholders = implode( ',', array_fill( 0, count( $statuses_to_skip ), '%s' ) );
			$args         = array_merge( array( $like ), $statuses_to_skip );
			$count        = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$table} WHERE payload LIKE %s AND status NOT IN ({$placeholders})",
					$args
				)
			);
		}
		// phpcs:enable

		return $count;
	}
}
