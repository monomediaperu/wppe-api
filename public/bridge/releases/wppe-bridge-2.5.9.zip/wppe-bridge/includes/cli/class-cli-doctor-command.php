<?php
/**
 * Comando WP-CLI: wp wppe-bridge doctor
 *
 * Wrapper de presentacion sobre WPPE_Bridge_Cli_Doctor (logica pura).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Comando doctor.
 */
final class WPPE_Bridge_Cli_Doctor_Command {

	/**
	 * Diagnostica la configuracion del plugin.
	 *
	 * ## OPTIONS
	 *
	 * [--check-api]
	 * : Hace 1 GET a Sperant para validar el token. Default: false.
	 *
	 * ## EXAMPLES
	 *
	 *     wp wppe-bridge doctor
	 *     wp wppe-bridge doctor --check-api
	 *
	 * @param array $args       (no uso).
	 * @param array $assoc_args [check-api].
	 * @return void
	 */
	public function __invoke( $args, $assoc_args ) {
		unset( $args );
		$check_api = isset( $assoc_args['check-api'] );

		$checks = WPPE_Bridge_Cli_Doctor::run_all( $check_api );

		$has_error = false;
		$has_warn  = false;

		foreach ( $checks as $check ) {
			$icon = '?';
			switch ( $check['level'] ) {
				case WPPE_Bridge_Cli_Doctor::LEVEL_OK:
					$icon = '✓';
					break;
				case WPPE_Bridge_Cli_Doctor::LEVEL_WARN:
					$icon     = '!';
					$has_warn = true;
					break;
				case WPPE_Bridge_Cli_Doctor::LEVEL_ERROR:
					$icon      = '✗';
					$has_error = true;
					break;
			}
			\WP_CLI::log( sprintf( ' %s %-22s  %s', $icon, $check['label'], $check['message'] ) );
		}

		\WP_CLI::log( '' );
		if ( $has_error ) {
			\WP_CLI::error( 'Hay errores de configuracion.' );
		}
		if ( $has_warn ) {
			\WP_CLI::warning( 'Diagnostico con advertencias.' );
			return;
		}
		\WP_CLI::success( 'Configuracion OK.' );
	}
}
