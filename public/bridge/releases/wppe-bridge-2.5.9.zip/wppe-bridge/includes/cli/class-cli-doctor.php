<?php
/**
 * Doctor: chequeo de configuracion del plugin.
 *
 * Logica pura testeable. El wrapper WP-CLI vive en
 * class-cli-doctor-command.php y solo formatea el output.
 *
 * Cada check devuelve un array:
 *   [
 *     'level'   => 'ok' | 'warn' | 'error',
 *     'label'   => string (nombre humano),
 *     'message' => string (descripcion del estado),
 *   ]
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Doctor — checks de configuracion del plugin.
 */
final class WPPE_Bridge_Cli_Doctor {

	public const LEVEL_OK    = 'ok';
	public const LEVEL_WARN  = 'warn';
	public const LEVEL_ERROR = 'error';

	/**
	 * Corre todos los checks. Si `$check_api`=true, agrega el check
	 * de conectividad real a Sperant (1 GET).
	 *
	 * @param bool $check_api Hacer hit HTTP a la API.
	 * @return array<int,array{level:string,label:string,message:string}>
	 */
	public static function run_all( bool $check_api = false ): array {
		$checks   = array();
		$checks[] = self::check_token();
		$checks[] = self::check_base_url();
		$checks[] = self::check_worker_cron();
		$checks[] = self::check_logs_cleanup_cron();
		$checks[] = self::check_catalogs();
		$checks[] = self::check_field_mapping();
		$checks[] = self::check_queue_pending();
		if ( $check_api ) {
			$checks[] = self::check_api_connectivity();
		}
		return $checks;
	}

	/**
	 * Token configurado?
	 *
	 * @return array
	 */
	public static function check_token(): array {
		$token = (string) get_option( 'wppe_bridge_api_token', '' );
		if ( '' === $token ) {
			return array(
				'level'   => self::LEVEL_ERROR,
				'label'   => 'Token Sperant',
				'message' => 'No configurado. La integracion no funcionara.',
			);
		}
		return array(
			'level'   => self::LEVEL_OK,
			'label'   => 'Token Sperant',
			'message' => sprintf( 'Configurado (%d chars).', strlen( $token ) ),
		);
	}

	/**
	 * URL base de la API.
	 *
	 * @return array
	 */
	public static function check_base_url(): array {
		$url = (string) get_option( 'wppe_bridge_api_base_url', '' );
		if ( '' === $url ) {
			return array(
				'level'   => self::LEVEL_WARN,
				'label'   => 'URL base API',
				'message' => 'Vacia (deberia ser https://api.sperant.com).',
			);
		}
		return array(
			'level'   => self::LEVEL_OK,
			'label'   => 'URL base API',
			'message' => $url,
		);
	}

	/**
	 * Cron del worker schedulado?
	 *
	 * @return array
	 */
	public static function check_worker_cron(): array {
		$next = wp_next_scheduled( WPPE_Bridge_Activator::CRON_HOOK );
		if ( false === $next ) {
			return array(
				'level'   => self::LEVEL_ERROR,
				'label'   => 'Cron worker',
				'message' => 'NO schedulado. Reactivar el plugin.',
			);
		}
		$delta = $next - time();
		return array(
			'level'   => self::LEVEL_OK,
			'label'   => 'Cron worker',
			'message' => sprintf( 'Schedulado en %ds.', $delta ),
		);
	}

	/**
	 * Cron de logs cleanup schedulado?
	 *
	 * @return array
	 */
	public static function check_logs_cleanup_cron(): array {
		$next = wp_next_scheduled( WPPE_Bridge_Activator::CRON_HOOK_LOGS_CLEANUP );
		if ( false === $next ) {
			return array(
				'level'   => self::LEVEL_WARN,
				'label'   => 'Cron logs cleanup',
				'message' => 'NO schedulado.',
			);
		}
		$delta = $next - time();
		return array(
			'level'   => self::LEVEL_OK,
			'label'   => 'Cron logs cleanup',
			'message' => sprintf( 'Schedulado en %ds.', $delta ),
		);
	}

	/**
	 * Catalogos sincronizados?
	 *
	 * @return array
	 */
	public static function check_catalogs(): array {
		$catalogs = get_option( 'wppe_bridge_catalogs', array() );
		if ( ! is_array( $catalogs ) || empty( $catalogs ) ) {
			return array(
				'level'   => self::LEVEL_WARN,
				'label'   => 'Catalogos',
				'message' => 'No sincronizados. Hacelo desde el panel admin.',
			);
		}
		$total = 0;
		$ok    = 0;
		foreach ( array( 'input_channels', 'sources', 'interest_types', 'projects' ) as $key ) {
			if ( isset( $catalogs[ $key ] ) && is_array( $catalogs[ $key ] ) ) {
				$count  = count( $catalogs[ $key ] );
				$total += $count;
				if ( $count > 0 ) {
					++$ok;
				}
			}
		}
		if ( 0 === $ok ) {
			return array(
				'level'   => self::LEVEL_WARN,
				'label'   => 'Catalogos',
				'message' => 'Sincronizados pero todos vacios.',
			);
		}
		return array(
			'level'   => self::LEVEL_OK,
			'label'   => 'Catalogos',
			'message' => sprintf( '%d/4 catalogos con datos (%d entries).', $ok, $total ),
		);
	}

	/**
	 * Field mapping configurado para algun form?
	 *
	 * @return array
	 */
	public static function check_field_mapping(): array {
		$mapping = get_option( 'wppe_bridge_field_mapping', array() );
		if ( ! is_array( $mapping ) || empty( $mapping ) ) {
			return array(
				'level'   => self::LEVEL_WARN,
				'label'   => 'Field mapping',
				'message' => 'Sin forms configurados. Hacelo desde el panel admin > Mapeo.',
			);
		}
		$total_forms = 0;
		foreach ( $mapping as $plugin_forms ) {
			if ( is_array( $plugin_forms ) ) {
				$total_forms += count( $plugin_forms );
			}
		}
		if ( 0 === $total_forms ) {
			return array(
				'level'   => self::LEVEL_WARN,
				'label'   => 'Field mapping',
				'message' => 'Estructura existe pero sin forms.',
			);
		}
		return array(
			'level'   => self::LEVEL_OK,
			'label'   => 'Field mapping',
			'message' => sprintf( '%d form(s) con mapeo.', $total_forms ),
		);
	}

	/**
	 * Items pendientes en la queue (informativo).
	 *
	 * @return array
	 */
	public static function check_queue_pending(): array {
		$count = WPPE_Bridge_Queue::count_by_status( WPPE_Bridge_Queue::STATUS_PENDING );
		if ( 0 === $count ) {
			return array(
				'level'   => self::LEVEL_OK,
				'label'   => 'Queue pendientes',
				'message' => '0 items.',
			);
		}
		if ( $count > 100 ) {
			return array(
				'level'   => self::LEVEL_WARN,
				'label'   => 'Queue pendientes',
				'message' => sprintf( '%d items (mucho — el worker puede no estar corriendo).', $count ),
			);
		}
		return array(
			'level'   => self::LEVEL_OK,
			'label'   => 'Queue pendientes',
			'message' => sprintf( '%d items.', $count ),
		);
	}

	/**
	 * Conectividad: 1 GET a /v3/input_channels para validar token.
	 *
	 * @return array
	 */
	public static function check_api_connectivity(): array {
		$catalogs = WPPE_Sperant_Client::sync_catalogs();
		// Si todos los GETs fallaron con HTTP 0 (red), reportar error.
		// Si fallaron con 401, token invalido.
		// Si OK al menos uno, reportar OK.
		$errors    = isset( $catalogs['_errors'] ) && is_array( $catalogs['_errors'] ) ? $catalogs['_errors'] : array();
		$total_err = count( $errors );

		if ( 4 === $total_err ) {
			$first = reset( $errors );
			return array(
				'level'   => self::LEVEL_ERROR,
				'label'   => 'Conectividad API',
				'message' => sprintf( 'Todos los catalogos fallaron. Primer error: %s', (string) $first ),
			);
		}
		if ( $total_err > 0 ) {
			return array(
				'level'   => self::LEVEL_WARN,
				'label'   => 'Conectividad API',
				'message' => sprintf( 'Conexion parcial: %d/4 catalogos fallaron.', $total_err ),
			);
		}
		return array(
			'level'   => self::LEVEL_OK,
			'label'   => 'Conectividad API',
			'message' => 'OK (4/4 GETs exitosos).',
		);
	}
}
