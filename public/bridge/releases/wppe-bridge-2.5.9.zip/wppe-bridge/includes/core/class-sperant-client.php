<?php
/**
 * Cliente HTTP para la API Sperant.
 *
 * Envuelve wp_remote_* con auth, timeouts, parsing y clasificacion
 * de errores. Auth via header `Authorization: <token>` (sin prefijo
 * "Bearer", ver CLAUDE.md seccion 5). Timeout generoso (15s) para
 * no falsear timeouts cuando Sperant SI recibio el lead.
 *
 * Cada llamada devuelve un array uniforme:
 *   [
 *     'status'      => int     // HTTP status code, 0 si error de red
 *     'body'        => array   // Body JSON-decodificado, [] si no hay
 *     'raw'         => string  // Body crudo
 *     'error_class' => string  // 'success'|'transient'|'permanent'
 *   ]
 *
 * El Worker usa `error_class` para aplicar la politica de reintentos
 * D5 sin tener que conocer codigos HTTP especificos.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Wrapper estatico sobre wp_remote_* para llamar a la API Sperant.
 */
final class WPPE_Sperant_Client {

	/**
	 * Timeout HTTP en segundos. Generoso para evitar timeouts falsos
	 * (ver CLAUDE.md seccion 6, mitigacion de causa 2).
	 */
	public const HTTP_TIMEOUT_SECONDS = 15;

	/**
	 * Endpoint de creacion de cliente (D10 del CLAUDE.md).
	 */
	public const ENDPOINT_CLIENTS = '/v3/clients';

	/**
	 * Endpoints de catalogos sincronizables.
	 *
	 * @var array<string,string>
	 */
	public const CATALOG_ENDPOINTS = array(
		'input_channels' => '/v3/input_channels',
		'sources'        => '/v3/sources',
		'interest_types' => '/v3/interest_types',
		'projects'       => '/v3/projects',
	);

	/**
	 * Clases de error usadas por el Worker para decidir reintento.
	 */
	public const ERROR_CLASS_SUCCESS   = 'success';
	public const ERROR_CLASS_TRANSIENT = 'transient';
	public const ERROR_CLASS_PERMANENT = 'permanent';

	/**
	 * Hace POST /v3/clients.
	 *
	 * @param array $payload Payload ya normalizado.
	 * @return array{status:int,body:array,raw:string,error_class:string}
	 */
	public static function create_client( array $payload ): array {
		return self::request( 'POST', self::ENDPOINT_CLIENTS, $payload );
	}

	/**
	 * Sincroniza catalogos (D7). Hace GET a cada endpoint y devuelve
	 * el resultado bajo la key correspondiente. Si un GET falla, esa
	 * key contiene array vacio y el error queda en `_errors`.
	 *
	 * Sperant retorna JSON:API estandar:
	 *   {data: [{type, id, attributes: {id, name, ...}, links?, meta?}]}
	 *
	 * Aplanamos a `[{id, name, ...}, ...]` para que el admin (Mapping
	 * page) y el contador de Configuracion los consuman directo sin
	 * conocer el wrapper. Aceptamos tambien shape plano por si en el
	 * futuro Sperant lo cambia o algun mock devuelve algo distinto.
	 *
	 * @return array{
	 *   input_channels:array,
	 *   sources:array,
	 *   interest_types:array,
	 *   projects:array,
	 *   _errors:array<string,string>
	 * }
	 */
	public static function sync_catalogs(): array {
		$result = array(
			'input_channels' => array(),
			'sources'        => array(),
			'interest_types' => array(),
			'projects'       => array(),
			'_errors'        => array(),
		);

		foreach ( self::CATALOG_ENDPOINTS as $key => $path ) {
			$response = self::request( 'GET', $path );
			if ( self::ERROR_CLASS_SUCCESS === $response['error_class'] ) {
				$body           = is_array( $response['body'] ) ? $response['body'] : array();
				$result[ $key ] = self::flatten_jsonapi_collection( $body );
			} else {
				$result['_errors'][ $key ] = sprintf( 'HTTP %d', $response['status'] );
			}
		}

		return $result;
	}

	/**
	 * Aplana una respuesta de Sperant API al shape `[{id, name, ...}]`
	 * que el resto del plugin consume.
	 *
	 * Casos soportados:
	 * 1. JSON:API estandar: `{data: [{type, id, attributes: {id, name}}]}`
	 *    -> retorna array de los `attributes`.
	 * 2. JSON:API con paginacion: `{data: [...], links, meta}` -> idem.
	 * 3. Shape ya plano: `[{id, name}]` -> retorna tal cual (forward-compat).
	 * 4. Lo que no encaje en ningun formato -> array vacio.
	 *
	 * Items sin `id` se descartan (defensa).
	 *
	 * @param mixed $response Respuesta cruda parseada del endpoint.
	 * @return array<int,array<string,mixed>>
	 */
	public static function flatten_jsonapi_collection( $response ): array {
		if ( ! is_array( $response ) ) {
			return array();
		}

		// Caso 1+2: respuesta envuelta en `data` (JSON:API).
		$items = isset( $response['data'] ) && is_array( $response['data'] ) ? $response['data'] : $response;

		// Si `items` no es lista (puede ser un objeto JSON:API individual,
		// improbable en colecciones), envolver.
		if ( isset( $items['type'] ) && isset( $items['id'] ) ) {
			$items = array( $items );
		}

		$out = array();
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			// Caso JSON:API: extraer attributes.
			if ( isset( $item['attributes'] ) && is_array( $item['attributes'] ) ) {
				$attrs = $item['attributes'];
				// Asegurar que `id` este presente (JSON:API puede tenerlo solo en raiz).
				if ( ! isset( $attrs['id'] ) && isset( $item['id'] ) ) {
					$attrs['id'] = $item['id'];
				}
				if ( isset( $attrs['id'] ) ) {
					$out[] = $attrs;
				}
				continue;
			}

			// Caso plano: usar item directamente si tiene id.
			if ( isset( $item['id'] ) ) {
				$out[] = $item;
			}
		}

		return $out;
	}

	/**
	 * Hace una request a Sperant. Construye headers, serializa payload
	 * y delega en wp_remote_request.
	 *
	 * @param string     $method  GET|POST|PUT|DELETE.
	 * @param string     $path    Path con leading slash (ej. /v3/clients).
	 * @param array|null $payload Body a serializar (solo para POST/PUT).
	 * @return array{status:int,body:array,raw:string,error_class:string}
	 */
	private static function request( string $method, string $path, ?array $payload = null ): array {
		$base_url = (string) get_option( 'wppe_bridge_api_base_url', 'https://api.sperant.com' );

		/**
		 * Filtra la URL base de la API. Util para devs/tests/mocks
		 * sin tocar la UI de Configuracion (que esta restringida a
		 * una whitelist de entornos oficiales).
		 *
		 * @param string $base_url URL leida del option.
		 */
		if ( function_exists( 'apply_filters' ) ) {
			$base_url = (string) apply_filters( 'wppe_bridge_api_base_url', $base_url );
		}

		$token = (string) get_option( 'wppe_bridge_api_token', '' );

		$args = array(
			'method'  => $method,
			'timeout' => self::HTTP_TIMEOUT_SECONDS,
			'headers' => array(
				'Authorization' => $token,
				'Content-Type'  => 'application/json',
				'Accept'        => 'application/json',
			),
		);

		if ( null !== $payload ) {
			$args['body'] = wp_json_encode( $payload );
		}

		$response = wp_remote_request( rtrim( $base_url, '/' ) . $path, $args );

		return self::parse_response( $response );
	}

	/**
	 * Normaliza la respuesta de wp_remote_request a la forma uniforme.
	 * Maneja WP_Error (network/timeout) como transient.
	 *
	 * @param mixed $response Lo que devolvio wp_remote_request.
	 * @return array{status:int,body:array,raw:string,error_class:string}
	 */
	private static function parse_response( $response ): array {
		if ( is_wp_error( $response ) ) {
			return array(
				'status'      => 0,
				'body'        => array(),
				'raw'         => '',
				'error_class' => self::ERROR_CLASS_TRANSIENT,
			);
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$raw    = (string) wp_remote_retrieve_body( $response );
		$body   = array();

		if ( '' !== $raw ) {
			$decoded = json_decode( $raw, true );
			if ( is_array( $decoded ) ) {
				$body = $decoded;
			}
		}

		return array(
			'status'      => $status,
			'body'        => $body,
			'raw'         => $raw,
			'error_class' => self::error_class_for_status( $status ),
		);
	}

	/**
	 * Clasifica un status HTTP segun la politica D5 del CLAUDE.md.
	 * - 2xx -> success.
	 * - 429 (rate limit) y 5xx -> transient (reintentar con backoff).
	 * - Resto de 4xx -> permanent (no reintentar).
	 * - 0 (sin status, ya fue tratado como WP_Error antes) -> transient.
	 *
	 * @param int $status HTTP status code.
	 * @return string
	 */
	private static function error_class_for_status( int $status ): string {
		if ( $status >= 200 && $status < 300 ) {
			return self::ERROR_CLASS_SUCCESS;
		}
		if ( 429 === $status || ( $status >= 500 && $status < 600 ) ) {
			return self::ERROR_CLASS_TRANSIENT;
		}
		if ( $status >= 400 && $status < 500 ) {
			return self::ERROR_CLASS_PERMANENT;
		}
		return self::ERROR_CLASS_TRANSIENT;
	}
}
