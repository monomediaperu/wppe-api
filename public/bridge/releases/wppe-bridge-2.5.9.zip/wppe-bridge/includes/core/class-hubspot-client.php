<?php
/**
 * Cliente HTTP para la API HubSpot CRM v3.
 *
 * Envuelve `wp_remote_*` con auth, timeouts, parsing y clasificacion
 * de errores. Auth via header `Authorization: Bearer <access_token>`
 * (Private App access token, D-HS-2). El token se ingresa una vez en
 * Configuracion HubSpot y vive en `wp_options['wppe_bridge_hubspot_access_token']`.
 *
 * **Endpoint principal (D-HS-1):** `POST /crm/v3/objects/contacts/batch/upsert`
 * con `idProperty=email`, single-input array. HubSpot dedupea
 * nativamente por email — si el contact ya existe, actualiza; si no,
 * crea. Idempotente sin manejar 409s manualmente.
 *
 * Cada llamada devuelve un array uniforme:
 *   [
 *     'status'      => int     // HTTP status code, 0 si error de red
 *     'body'        => array   // Body JSON-decodificado, [] si no hay
 *     'raw'         => string  // Body crudo
 *     'error_class' => string  // 'success'|'transient'|'permanent'
 *     'error_name'  => string  // body['category'] si lo hubo (HubSpot error category)
 *   ]
 *
 * El Worker usa `error_class` para D5 sin tener que conocer detalles
 * HubSpot. La `error_name` se preserva para el logger y el admin
 * notice (ej. "VALIDATION_ERROR" es mas accionable que "HTTP 400").
 *
 * Asimetria intencional con SperantClient/GhlClient/OdooClient:
 * cada uno guarda token en su propio namespace de option
 * (`wppe_bridge_hubspot_access_token` aqui). Refactor simetrico se
 * difiere a v3.0.0.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Wrapper estatico sobre wp_remote_* para llamar a la API HubSpot.
 */
final class WPPE_Hubspot_Client {

	/**
	 * Timeout HTTP en segundos. Generoso para evitar timeouts falsos
	 * (CLAUDE.md sec 6, mitigacion de causa 2).
	 */
	public const HTTP_TIMEOUT_SECONDS = 15;

	/**
	 * Base URL de la API HubSpot. Tests pueden override via filter
	 * `wppe_bridge_hubspot_base_url`.
	 */
	public const BASE_URL = 'https://api.hubapi.com';

	/**
	 * Endpoint de batch upsert de contactos. D-HS-1: usamos batch
	 * upsert con single-input para idempotencia nativa por email.
	 *
	 * Shape del payload:
	 *   {
	 *     "inputs": [{
	 *       "idProperty": "email",
	 *       "id": "user@example.com",
	 *       "properties": { firstname, lastname, phone, ... }
	 *     }]
	 *   }
	 *
	 * Response 200 success:
	 *   { status: "COMPLETE", results: [{ id, properties, ... }], ... }
	 *
	 * Response 207 si TODOS los inputs fallan:
	 *   { status: "COMPLETE", results: [], errors: [...] }
	 *
	 * Response 4xx si la request en si esta mal (auth/validacion request).
	 */
	public const ENDPOINT_BATCH_UPSERT_CONTACTS = '/crm/v3/objects/contacts/batch/upsert';

	/**
	 * Property nombre que usamos como id natural para upsert. HubSpot
	 * permite `email` u otros uniques (custom). Email es el comun.
	 */
	public const UPSERT_ID_PROPERTY = 'email';

	/**
	 * Endpoint de lista de owners (`/crm/v3/owners`). Returns
	 * users con seat de Sales asignado en el portal. Scope minimo:
	 * `crm.objects.owners.read` (en HubSpot Starter ya viene activo
	 * por default cuando das los scopes de contacts).
	 *
	 * Shape: `{ results: [{id, email, firstName, lastName, userId, type, archived, ...}] }`.
	 */
	public const ENDPOINT_LIST_OWNERS = '/crm/v3/owners';

	/**
	 * Endpoint de lista de contact properties (schemas). Devuelve
	 * todas las properties — native (ej. `firstname`, `lastname`,
	 * `lifecyclestage`) y custom (creadas por el portal). Scope
	 * minimo: `crm.schemas.contacts.read`.
	 *
	 * Shape: `{ results: [{name, label, type, fieldType, options: [...], ...}] }`.
	 *
	 * `options` es array no vacio solo para enum types (ej.
	 * `lifecyclestage`, `hs_lead_status`, picklists custom). Cada
	 * option tiene `{label, value, displayOrder, hidden}`.
	 */
	public const ENDPOINT_LIST_PROPERTIES_CONTACTS = '/crm/v3/properties/contacts';

	/**
	 * Property `name` interno del campo lifecyclestage en HubSpot.
	 * El mismo string sirve para Free/Starter/Pro/Enterprise — solo
	 * cambia la lista de `options` segun el portal lo haya customizado.
	 */
	public const PROPERTY_NAME_LIFECYCLESTAGE = 'lifecyclestage';

	/**
	 * Limite default de records por catalogo. Owners y properties
	 * no son tantos en una cuenta tipica (~50-200 properties incluso
	 * en cuentas Pro maduras). Filter `wppe_bridge_hubspot_catalog_limit`
	 * para devs/tests.
	 */
	public const CATALOG_DEFAULT_LIMIT = 500;

	/**
	 * Clases de error usadas por el Worker para decidir reintento.
	 */
	public const ERROR_CLASS_SUCCESS   = 'success';
	public const ERROR_CLASS_TRANSIENT = 'transient';
	public const ERROR_CLASS_PERMANENT = 'permanent';

	/**
	 * Hace POST /crm/v3/objects/contacts/batch/upsert con un solo input.
	 *
	 * El `Hubspot_Destination` ya hizo el mapeo del payload normalizado
	 * del bridge a properties HubSpot (`firstname`, `lastname`,
	 * `email`, `phone`, etc).
	 *
	 * Critico: `properties.email` debe existir (lo usamos como
	 * `idProperty` para upsert). Si el caller no lo manda, HubSpot
	 * retorna VALIDATION_ERROR permanente. El Destination valida
	 * antes de llamar.
	 *
	 * @param array<string,mixed> $properties Properties del contact ya
	 *                                         mapeadas al shape HubSpot.
	 * @return array{status:int,body:array,raw:string,error_class:string,error_name:string}
	 */
	public static function upsert_contact( array $properties ): array {
		$email = isset( $properties['email'] ) ? (string) $properties['email'] : '';

		$payload = array(
			'inputs' => array(
				array(
					'idProperty' => self::UPSERT_ID_PROPERTY,
					'id'         => $email,
					'properties' => $properties,
				),
			),
		);

		$response = self::request( 'POST', self::ENDPOINT_BATCH_UPSERT_CONTACTS, $payload );

		// El batch endpoint puede devolver 200/207. Si el shape indica
		// que todos los inputs fallaron (results vacio + errors poblado),
		// reclasificar como permanent. Defensa contra "HTTP 200 pero
		// HubSpot rechazo el contact" (ej. propiedad invalida).
		if ( self::ERROR_CLASS_SUCCESS === $response['error_class'] ) {
			$results = isset( $response['body']['results'] ) && is_array( $response['body']['results'] ) ? $response['body']['results'] : array();
			$errors  = isset( $response['body']['errors'] ) && is_array( $response['body']['errors'] ) ? $response['body']['errors'] : array();
			if ( empty( $results ) && ! empty( $errors ) ) {
				$response['error_class'] = self::ERROR_CLASS_PERMANENT;
				$response['error_name']  = self::extract_first_batch_error_category( $errors );
			}
		}

		return $response;
	}

	/**
	 * Lista owners (`GET /crm/v3/owners`). Devuelve los users con
	 * seat de Sales asignado en el portal. Util para que el admin
	 * elija un "Owner default" para los leads del web.
	 *
	 * HubSpot Starter expone este endpoint sin restricciones (a
	 * diferencia de Free, donde Owners no existe). Si la cuenta es
	 * Free, este endpoint puede retornar 403/404 — el caller maneja
	 * como permanent y el admin no puede usar "Owner default" (deja
	 * la option vacia y HubSpot aplica round-robin del portal).
	 *
	 * Devuelve `id, email, firstName, lastName` para que el dropdown
	 * admin muestre "Maria Lopez (maria@x.com)" y distinga homonimos.
	 *
	 * @return array{status:int,body:array,raw:string,error_class:string,error_name:string,items:array<int,array<string,mixed>>}
	 */
	public static function list_owners(): array {
		$response          = self::request(
			'GET',
			self::ENDPOINT_LIST_OWNERS,
			null,
			array( 'limit' => self::resolve_catalog_limit() )
		);
		$response['items'] = self::extract_collection( $response['body'] );
		return $response;
	}

	/**
	 * Lista contact properties (`GET /crm/v3/properties/contacts`).
	 * Incluye native (firstname, lastname, email, phone,
	 * lifecyclestage, ...) y custom creadas por el portal.
	 *
	 * Util para:
	 *  - Dropdown del Mapping_Page mostrando todas las properties
	 *    disponibles (no solo las que hardcodemos).
	 *  - Descubrir los `options` de `lifecyclestage` (incluye custom
	 *    stages si el cliente las agrego en CRM Settings).
	 *
	 * Cada item incluye `{name, label, type, fieldType, options: [...]}`.
	 * `options` es array no vacio solo para enum types.
	 *
	 * @return array{status:int,body:array,raw:string,error_class:string,error_name:string,items:array<int,array<string,mixed>>}
	 */
	public static function list_contact_properties(): array {
		$response          = self::request(
			'GET',
			self::ENDPOINT_LIST_PROPERTIES_CONTACTS,
			null,
			array( 'limit' => self::resolve_catalog_limit() )
		);
		$response['items'] = self::extract_collection( $response['body'] );
		return $response;
	}

	/**
	 * Extrae las `options` del property `lifecyclestage` desde una
	 * lista de contact_properties. Sirve para que el admin elija el
	 * default global desde el dropdown con los stages REALES del
	 * portal (incluyendo custom stages si los hay).
	 *
	 * Si el cliente customizo lifecyclestage agregando "trialing" o
	 * "churned", esos aparecen aqui — sin esto los hardcodearíamos
	 * mal. Cae graciosamente a la whitelist estandard
	 * `WPPE_Hubspot_Destination::ALLOWED_LIFECYCLESTAGES` cuando
	 * el catalogo no esta sincronizado todavia.
	 *
	 * Cada option: `{label: "Lead", value: "lead", displayOrder, hidden}`.
	 * Filtramos los `hidden=true` (deprecated/internal).
	 *
	 * @param array<int,array<string,mixed>> $contact_properties Lista
	 *                                                            del response de
	 *                                                            list_contact_properties.
	 * @return array<int,array{label:string,value:string,displayOrder:int}>
	 */
	public static function extract_lifecyclestage_options( array $contact_properties ): array {
		foreach ( $contact_properties as $prop ) {
			if ( ! is_array( $prop ) || ( $prop['name'] ?? '' ) !== self::PROPERTY_NAME_LIFECYCLESTAGE ) {
				continue;
			}
			$options = isset( $prop['options'] ) && is_array( $prop['options'] ) ? $prop['options'] : array();
			$out     = array();
			foreach ( $options as $opt ) {
				if ( ! is_array( $opt ) ) {
					continue;
				}
				if ( ! empty( $opt['hidden'] ) ) {
					continue;
				}
				$value = isset( $opt['value'] ) ? (string) $opt['value'] : '';
				$label = isset( $opt['label'] ) ? (string) $opt['label'] : $value;
				if ( '' === $value ) {
					continue;
				}
				$out[] = array(
					'label'        => $label,
					'value'        => $value,
					'displayOrder' => isset( $opt['displayOrder'] ) ? (int) $opt['displayOrder'] : 0,
				);
			}
			return $out;
		}
		return array();
	}

	/**
	 * Sincroniza los 2 catalogos HubSpot (owners + contact_properties)
	 * y devuelve un resultado unificado. Mismo patron que
	 * `Sperant_Client::sync_catalogs()` / `Ghl_Client::sync_catalogs()` /
	 * `Odoo_Client::sync_catalogs()`: si un endpoint falla, su key
	 * contiene array vacio y el error queda en `_errors[<key>]`.
	 *
	 * Tambien extrae `lifecyclestage_options` desde contact_properties
	 * (no es un endpoint separado — es derivado para que el Mapping_Page
	 * lo use sin parsear properties otra vez).
	 *
	 * Shape:
	 *   [
	 *     'owners'                  => [...],
	 *     'contact_properties'      => [...],
	 *     'lifecyclestage_options'  => [...],
	 *     '_errors'                 => ['owners' => 'HTTP 403', ...],
	 *     '_synced_at'              => 1730000000,
	 *   ]
	 *
	 * En cuenta HubSpot Free, owners puede fallar con 403. El bloque
	 * de "config global" del Mapping_Page maneja este caso mostrando
	 * "Owner default no disponible (cuenta Free o sin scope)".
	 *
	 * @return array{
	 *   owners:array,
	 *   contact_properties:array,
	 *   lifecyclestage_options:array,
	 *   _errors:array<string,string>,
	 *   _synced_at:int
	 * }
	 */
	public static function sync_catalogs(): array {
		$result = array(
			'owners'                 => array(),
			'contact_properties'     => array(),
			'lifecyclestage_options' => array(),
			'_errors'                => array(),
			'_synced_at'             => time(),
		);

		$owners_response = self::list_owners();
		if ( self::ERROR_CLASS_SUCCESS === $owners_response['error_class'] ) {
			$result['owners'] = $owners_response['items'];
		} else {
			$result['_errors']['owners'] = self::format_sync_error( $owners_response );
		}

		$props_response = self::list_contact_properties();
		if ( self::ERROR_CLASS_SUCCESS === $props_response['error_class'] ) {
			$result['contact_properties']     = $props_response['items'];
			$result['lifecyclestage_options'] = self::extract_lifecyclestage_options( $props_response['items'] );
		} else {
			$result['_errors']['contact_properties'] = self::format_sync_error( $props_response );
		}

		return $result;
	}

	/**
	 * Limite resuelto via filter `wppe_bridge_hubspot_catalog_limit`.
	 * Override util para dev/test/cuentas con muchas properties.
	 *
	 * @return int
	 */
	public static function resolve_catalog_limit(): int {
		$limit = self::CATALOG_DEFAULT_LIMIT;
		if ( function_exists( 'apply_filters' ) ) {
			$limit = (int) apply_filters( 'wppe_bridge_hubspot_catalog_limit', $limit );
		}
		return max( 1, $limit );
	}

	/**
	 * Extrae la coleccion de records desde una response HubSpot.
	 * Todos los list endpoints v3 devuelven `{ results: [...], paging: {...} }`.
	 *
	 * Filtramos items sin `id` o sin `name` (para properties) por defensa
	 * contra shape inesperado.
	 *
	 * @param mixed $body Body parseado.
	 * @return array<int,array<string,mixed>>
	 */
	private static function extract_collection( $body ): array {
		if ( ! is_array( $body ) || ! isset( $body['results'] ) || ! is_array( $body['results'] ) ) {
			return array();
		}
		$out = array();
		foreach ( $body['results'] as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			// Owners traen `id`. Properties traen `name` (no `id`).
			// Aceptamos cualquiera de los dos.
			if ( ! isset( $item['id'] ) && ! isset( $item['name'] ) ) {
				continue;
			}
			$out[] = $item;
		}
		return $out;
	}

	/**
	 * Construye un mensaje legible de error para `_errors` del
	 * sync_catalogs. Prefiere `error_name` (HubSpot category) que es
	 * mas accionable que el HTTP status, fallback a `HTTP <status>`.
	 *
	 * @param array $response Response uniforme.
	 * @return string
	 */
	private static function format_sync_error( array $response ): string {
		$error_name = isset( $response['error_name'] ) ? (string) $response['error_name'] : '';
		if ( '' !== $error_name ) {
			return $error_name;
		}
		$status = (int) ( $response['status'] ?? 0 );
		if ( 0 === $status ) {
			return 'Network error or timeout';
		}
		return sprintf( 'HTTP %d', $status );
	}

	/**
	 * Hace una request a HubSpot. Construye headers, serializa payload
	 * y delega en wp_remote_request.
	 *
	 * @param string     $method  GET|POST|PUT|DELETE.
	 * @param string     $path    Path con leading slash.
	 * @param array|null $payload Body a serializar (POST/PUT).
	 * @param array      $query   Query params para GET.
	 * @return array{status:int,body:array,raw:string,error_class:string,error_name:string}
	 */
	private static function request( string $method, string $path, ?array $payload = null, array $query = array() ): array {
		$base_url = self::BASE_URL;

		/**
		 * Filtra la URL base de la API HubSpot. Util para devs/tests/mocks
		 * sin tocar la option (que en HubSpot no existe — base URL
		 * hardcoded por diseno, mismo patron que GHL).
		 *
		 * @param string $base_url URL base default.
		 */
		if ( function_exists( 'apply_filters' ) ) {
			$base_url = (string) apply_filters( 'wppe_bridge_hubspot_base_url', $base_url );
		}

		$token = (string) get_option( 'wppe_bridge_hubspot_access_token', '' );

		$args = array(
			'method'  => $method,
			'timeout' => self::HTTP_TIMEOUT_SECONDS,
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
				'Accept'        => 'application/json',
			),
		);

		if ( null !== $payload ) {
			$args['body'] = wp_json_encode( $payload );
		}

		$url = rtrim( $base_url, '/' ) . $path;
		if ( ! empty( $query ) ) {
			$url .= ( false === strpos( $path, '?' ) ? '?' : '&' ) . http_build_query( $query );
		}

		$response = wp_remote_request( $url, $args );

		return self::parse_response( $response );
	}

	/**
	 * Normaliza la respuesta de wp_remote_request a la forma uniforme.
	 * Maneja WP_Error (network/timeout) como transient.
	 *
	 * @param mixed $response Lo que devolvio wp_remote_request.
	 * @return array{status:int,body:array,raw:string,error_class:string,error_name:string}
	 */
	private static function parse_response( $response ): array {
		if ( is_wp_error( $response ) ) {
			return array(
				'status'      => 0,
				'body'        => array(),
				'raw'         => '',
				'error_class' => self::ERROR_CLASS_TRANSIENT,
				'error_name'  => '',
			);
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$raw    = (string) wp_remote_retrieve_body( $response );
		$body   = array();

		if ( '' !== $raw ) {
			$decoded = json_decode( $raw, true );
			if ( is_array( $decoded ) ) {
				$body = $decoded;
			}
		}

		return array(
			'status'      => $status,
			'body'        => $body,
			'raw'         => $raw,
			'error_class' => self::error_class_for_status( $status ),
			'error_name'  => self::extract_error_category( $body ),
		);
	}

	/**
	 * Clasifica un status HTTP segun la politica D5 del CLAUDE.md.
	 * - 2xx -> success.
	 * - 429 (rate limit) y 5xx -> transient (reintentar con backoff).
	 * - Resto de 4xx -> permanent (no reintentar).
	 * - 0 (sin status, ya fue tratado como WP_Error antes) -> transient.
	 *
	 * Nota HubSpot: el batch endpoint puede devolver 207 Multi-Status
	 * cuando algunos inputs OK y otros no. Lo tratamos como success a
	 * nivel HTTP — la decision permanent/transient para el caso "todos
	 * los inputs fallaron" se hace en `upsert_contact` analizando
	 * `results`/`errors` del body.
	 *
	 * @param int $status HTTP status code.
	 * @return string
	 */
	private static function error_class_for_status( int $status ): string {
		if ( ( $status >= 200 && $status < 300 ) || 207 === $status ) {
			return self::ERROR_CLASS_SUCCESS;
		}
		if ( 429 === $status || ( $status >= 500 && $status < 600 ) ) {
			return self::ERROR_CLASS_TRANSIENT;
		}
		if ( $status >= 400 && $status < 500 ) {
			return self::ERROR_CLASS_PERMANENT;
		}
		return self::ERROR_CLASS_TRANSIENT;
	}

	/**
	 * Extrae el `category` del body de error de HubSpot (4xx top-level).
	 * HubSpot estandariza errores asi:
	 *   { status: "error", category: "VALIDATION_ERROR", message: "...", ... }
	 *
	 * Retorna string vacio si el body no trae `category` (success path,
	 * o body malformado).
	 *
	 * @param array $body Body parseado.
	 * @return string
	 */
	private static function extract_error_category( array $body ): string {
		if ( isset( $body['category'] ) && is_string( $body['category'] ) ) {
			return $body['category'];
		}
		return '';
	}

	/**
	 * Extrae la primera `category` del array `errors` de un response
	 * batch (cuando todos los inputs fallaron). Util para que el admin
	 * vea el motivo concreto en logs (ej. "VALIDATION_ERROR" en lugar
	 * de "HTTP 200 pero raro").
	 *
	 * Shape de cada entry en `errors`:
	 *   { status: "error", category: "...", message: "...", context: {...} }
	 *
	 * @param array $errors Array bajo `body.errors`.
	 * @return string
	 */
	private static function extract_first_batch_error_category( array $errors ): string {
		foreach ( $errors as $err ) {
			if ( is_array( $err ) && isset( $err['category'] ) && is_string( $err['category'] ) ) {
				return $err['category'];
			}
		}
		return '';
	}
}
