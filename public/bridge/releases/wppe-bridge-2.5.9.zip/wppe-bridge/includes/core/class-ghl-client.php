<?php
/**
 * Cliente HTTP para la API GoHighLevel (HighLevel).
 *
 * Envuelve wp_remote_* con auth, timeouts, parsing y clasificacion
 * de errores. Auth via header `Authorization: Bearer <PIT>` (Private
 * Integration Token) + header obligatorio `Version: 2021-07-28` (la
 * API 401 silencioso si el header Version falta — hallazgo confirmado
 * en doc oficial 2026-05).
 *
 * Cada llamada devuelve un array uniforme:
 *   [
 *     'status'      => int     // HTTP status code, 0 si error de red
 *     'body'        => array   // Body JSON-decodificado, [] si no hay
 *     'raw'         => string  // Body crudo
 *     'error_class' => string  // 'success'|'transient'|'permanent'
 *   ]
 *
 * El Worker usa `error_class` para aplicar la politica de reintentos
 * D5 sin tener que conocer codigos HTTP especificos.
 *
 * Asimetria intencional con SperantClient (Camino A, sec 12 CLAUDE.md):
 * Sperant guarda token en `wppe_bridge_api_token` (option sin sufijo),
 * GHL en `wppe_bridge_ghl_token` (namespace propio). El refactor
 * simetrico se difiere a v3.0.0 cuando haya >2 destinos en produccion.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Wrapper estatico sobre wp_remote_* para llamar a la API GHL.
 */
final class WPPE_Ghl_Client {

	/**
	 * Timeout HTTP en segundos. Generoso para evitar timeouts falsos
	 * (ver CLAUDE.md seccion 6, mitigacion de causa 2).
	 */
	public const HTTP_TIMEOUT_SECONDS = 15;

	/**
	 * Base URL de la API GHL. No configurable (a diferencia de Sperant)
	 * porque GHL no tiene sandbox/staging publico — un solo endpoint
	 * para todos los entornos. Tests pueden override via filter
	 * `wppe_bridge_ghl_base_url`.
	 */
	public const BASE_URL = 'https://services.leadconnectorhq.com';

	/**
	 * Version header obligatorio. Si falta, la API responde 401
	 * silencioso (no menciona la causa).
	 */
	public const API_VERSION = '2021-07-28';

	/**
	 * Endpoint de upsert de contacto. Usamos upsert (no plain create)
	 * porque /contacts/ retorna 400 ante duplicado, mientras que
	 * /contacts/upsert hace match-or-update y retorna {new, contact}
	 * que sirve como ancla de idempotencia. Decision D-GHL-1.
	 */
	public const ENDPOINT_UPSERT_CONTACT = '/contacts/upsert';

	/**
	 * Endpoint de lista de pipelines (con sus stages anidados). Acepta
	 * `locationId` como query param (no path). Scope requerido:
	 * `opportunities.readonly`.
	 */
	public const ENDPOINT_LIST_PIPELINES = '/opportunities/pipelines';

	/**
	 * Endpoint de lista de custom fields de una location. `locationId`
	 * va como path param. Scope requerido: `locations.readonly`.
	 *
	 * Reemplazar `{locationId}` con el ID real al construir la URL.
	 */
	public const ENDPOINT_LIST_CUSTOM_FIELDS = '/locations/%s/customFields';

	/**
	 * Endpoint de lista de tags de una location. Mismo patron que
	 * custom fields. Scope requerido: `locations.readonly`.
	 */
	public const ENDPOINT_LIST_TAGS = '/locations/%s/tags';

	/**
	 * Endpoint de creacion de opportunity. Body requiere `pipelineId`,
	 * `locationId`, `contactId`, `name`, `status`. Scope requerido:
	 * `opportunities.write`. Decision D-GHL-2 (toggle ON por default).
	 */
	public const ENDPOINT_CREATE_OPPORTUNITY = '/opportunities/';

	/**
	 * Clases de error usadas por el Worker para decidir reintento.
	 */
	public const ERROR_CLASS_SUCCESS   = 'success';
	public const ERROR_CLASS_TRANSIENT = 'transient';
	public const ERROR_CLASS_PERMANENT = 'permanent';

	/**
	 * Hace POST /contacts/upsert.
	 *
	 * Payload tipico:
	 *   [
	 *     'locationId' => '...',
	 *     'firstName'  => '...',
	 *     'lastName'   => '...',
	 *     'email'      => '...',
	 *     'phone'      => '+51999...',
	 *     'tags'       => ['lead-web'],
	 *     'customFields' => [...],
	 *     // 'createNewIfDuplicateAllowed' => false (default acepta dedup)
	 *   ]
	 *
	 * Response 200 success: { new: bool, contact: {id, ...}, traceId }
	 *
	 * @param array $payload Payload ya normalizado.
	 * @return array{status:int,body:array,raw:string,error_class:string}
	 */
	public static function upsert_contact( array $payload ): array {
		return self::request( 'POST', self::ENDPOINT_UPSERT_CONTACT, $payload );
	}

	/**
	 * Hace POST /opportunities/.
	 *
	 * Payload tipico:
	 *   [
	 *     'locationId'       => '...',
	 *     'pipelineId'       => 'VDm7RPYC2GLUvdpKmBfC',
	 *     'pipelineStageId'  => 'stage-id',  // opcional, default = 1ra stage
	 *     'contactId'        => 'mTkSCb1UBjb5tk4OvB69',
	 *     'name'             => 'Lead web - Maria Lopez',
	 *     'status'           => 'open',  // open|won|lost|abandoned|all
	 *     'monetaryValue'    => 0,       // opcional
	 *     'assignedTo'       => '...',   // opcional, user id
	 *   ]
	 *
	 * Response 201 success: { opportunity: { id, contactId, ... } }
	 *
	 * @param array $payload Payload con campos minimos.
	 * @return array{status:int,body:array,raw:string,error_class:string}
	 */
	public static function create_opportunity( array $payload ): array {
		return self::request( 'POST', self::ENDPOINT_CREATE_OPPORTUNITY, $payload );
	}

	/**
	 * Hace GET /opportunities/pipelines?locationId=... y devuelve la
	 * lista plana de pipelines (cada uno con sus stages anidados).
	 *
	 * Shape esperado del API GHL:
	 *   { "pipelines": [{ id, name, stages: [{id, name, position}], ... }] }
	 *
	 * Retorno de este metodo: el array bajo `pipelines` ya desempaquetado.
	 *
	 * @return array{status:int,body:array,raw:string,error_class:string,items:array}
	 */
	public static function list_pipelines(): array {
		$location_id       = (string) get_option( 'wppe_bridge_ghl_location_id', '' );
		$response          = self::request(
			'GET',
			self::ENDPOINT_LIST_PIPELINES,
			null,
			array( 'locationId' => $location_id )
		);
		$response['items'] = self::extract_collection( $response['body'], 'pipelines' );
		return $response;
	}

	/**
	 * Hace GET /locations/{locationId}/customFields y devuelve la lista
	 * plana de custom fields.
	 *
	 * Shape API GHL: { "customFields": [{ id, name, fieldKey, dataType, ... }] }
	 *
	 * @return array{status:int,body:array,raw:string,error_class:string,items:array}
	 */
	public static function list_custom_fields(): array {
		$location_id       = (string) get_option( 'wppe_bridge_ghl_location_id', '' );
		$response          = self::request(
			'GET',
			sprintf( self::ENDPOINT_LIST_CUSTOM_FIELDS, rawurlencode( $location_id ) )
		);
		$response['items'] = self::extract_collection( $response['body'], 'customFields' );
		return $response;
	}

	/**
	 * Hace GET /locations/{locationId}/tags y devuelve la lista plana
	 * de tags existentes.
	 *
	 * Shape API GHL: { "tags": [{ id, name, locationId }] }
	 *
	 * @return array{status:int,body:array,raw:string,error_class:string,items:array}
	 */
	public static function list_tags(): array {
		$location_id       = (string) get_option( 'wppe_bridge_ghl_location_id', '' );
		$response          = self::request(
			'GET',
			sprintf( self::ENDPOINT_LIST_TAGS, rawurlencode( $location_id ) )
		);
		$response['items'] = self::extract_collection( $response['body'], 'tags' );
		return $response;
	}

	/**
	 * Sincroniza los 3 catalogos GHL (pipelines, custom fields, tags)
	 * y devuelve un resultado unificado. Mismo patron que
	 * Sperant_Client::sync_catalogs(): si un endpoint falla, su key
	 * contiene array vacio y el error queda en `_errors`.
	 *
	 * @return array{
	 *   pipelines:array,
	 *   custom_fields:array,
	 *   tags:array,
	 *   _errors:array<string,string>,
	 *   _synced_at:int
	 * }
	 */
	public static function sync_catalogs(): array {
		$result = array(
			'pipelines'     => array(),
			'custom_fields' => array(),
			'tags'          => array(),
			'_errors'       => array(),
			'_synced_at'    => time(),
		);

		$endpoints = array(
			'pipelines'     => array( self::class, 'list_pipelines' ),
			'custom_fields' => array( self::class, 'list_custom_fields' ),
			'tags'          => array( self::class, 'list_tags' ),
		);

		foreach ( $endpoints as $key => $callable ) {
			$response = call_user_func( $callable );
			if ( self::ERROR_CLASS_SUCCESS === $response['error_class'] ) {
				$result[ $key ] = $response['items'];
			} else {
				$result['_errors'][ $key ] = sprintf( 'HTTP %d', $response['status'] );
			}
		}

		return $result;
	}

	/**
	 * Extrae una coleccion del body de respuesta GHL.
	 *
	 * GHL envuelve sus colecciones bajo una key top-level (`pipelines`,
	 * `customFields`, `tags`). Este helper desempaca esa key y devuelve
	 * la lista. Si el shape es distinto al esperado (ej. el API cambio,
	 * o el body llego vacio por error), retorna array vacio.
	 *
	 * @param mixed  $body Body parseado de la respuesta.
	 * @param string $key  Key de la coleccion (`pipelines`, `customFields`, `tags`).
	 * @return array<int,array<string,mixed>>
	 */
	public static function extract_collection( $body, string $key ): array {
		if ( ! is_array( $body ) || ! isset( $body[ $key ] ) || ! is_array( $body[ $key ] ) ) {
			return array();
		}
		// Defensa: descartar items que no son arrays (bytes raros, null en
		// medio de la lista, etc.).
		return array_values(
			array_filter(
				$body[ $key ],
				static function ( $item ) {
					return is_array( $item ) && isset( $item['id'] );
				}
			)
		);
	}

	/**
	 * Hace una request a GHL. Construye headers, serializa payload
	 * y delega en wp_remote_request.
	 *
	 * @param string     $method  GET|POST|PUT|DELETE.
	 * @param string     $path    Path con leading slash (ej. /contacts/upsert).
	 * @param array|null $payload Body a serializar (solo para POST/PUT).
	 * @param array      $query   Query params para GET (key => value).
	 * @return array{status:int,body:array,raw:string,error_class:string}
	 */
	private static function request( string $method, string $path, ?array $payload = null, array $query = array() ): array {
		$base_url = self::BASE_URL;

		/**
		 * Filtra la URL base de la API GHL. Util para devs/tests/mocks
		 * sin tocar la option (que en GHL no existe — base URL
		 * hardcoded por diseno).
		 *
		 * @param string $base_url URL base default.
		 */
		if ( function_exists( 'apply_filters' ) ) {
			$base_url = (string) apply_filters( 'wppe_bridge_ghl_base_url', $base_url );
		}

		$token = (string) get_option( 'wppe_bridge_ghl_token', '' );

		$args = array(
			'method'  => $method,
			'timeout' => self::HTTP_TIMEOUT_SECONDS,
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'Version'       => self::API_VERSION,
				'Content-Type'  => 'application/json',
				'Accept'        => 'application/json',
			),
		);

		if ( null !== $payload ) {
			$args['body'] = wp_json_encode( $payload );
		}

		$url = rtrim( $base_url, '/' ) . $path;
		if ( ! empty( $query ) ) {
			$url .= ( false === strpos( $path, '?' ) ? '?' : '&' ) . http_build_query( $query );
		}

		$response = wp_remote_request( $url, $args );

		return self::parse_response( $response );
	}

	/**
	 * Normaliza la respuesta de wp_remote_request a la forma uniforme.
	 * Maneja WP_Error (network/timeout) como transient.
	 *
	 * @param mixed $response Lo que devolvio wp_remote_request.
	 * @return array{status:int,body:array,raw:string,error_class:string}
	 */
	private static function parse_response( $response ): array {
		if ( is_wp_error( $response ) ) {
			return array(
				'status'      => 0,
				'body'        => array(),
				'raw'         => '',
				'error_class' => self::ERROR_CLASS_TRANSIENT,
			);
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$raw    = (string) wp_remote_retrieve_body( $response );
		$body   = array();

		if ( '' !== $raw ) {
			$decoded = json_decode( $raw, true );
			if ( is_array( $decoded ) ) {
				$body = $decoded;
			}
		}

		return array(
			'status'      => $status,
			'body'        => $body,
			'raw'         => $raw,
			'error_class' => self::error_class_for_status( $status ),
		);
	}

	/**
	 * Clasifica un status HTTP segun la politica D5 del CLAUDE.md.
	 * - 2xx -> success.
	 * - 429 (rate limit) y 5xx -> transient (reintentar con backoff).
	 * - Resto de 4xx -> permanent (no reintentar).
	 * - 0 (sin status, ya fue tratado como WP_Error antes) -> transient.
	 *
	 * Nota GHL: el endpoint /contacts/ plain retorna 400 ante duplicado
	 * cuando la location bloquea dedup — pero como nosotros usamos
	 * /contacts/upsert (D-GHL-1), no vamos a ver ese caso. Los 400 reales
	 * son validacion (payload mal formado) y son permanentes.
	 *
	 * @param int $status HTTP status code.
	 * @return string
	 */
	private static function error_class_for_status( int $status ): string {
		if ( $status >= 200 && $status < 300 ) {
			return self::ERROR_CLASS_SUCCESS;
		}
		if ( 429 === $status || ( $status >= 500 && $status < 600 ) ) {
			return self::ERROR_CLASS_TRANSIENT;
		}
		if ( $status >= 400 && $status < 500 ) {
			return self::ERROR_CLASS_PERMANENT;
		}
		return self::ERROR_CLASS_TRANSIENT;
	}
}
