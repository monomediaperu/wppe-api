<?php
/**
 * Worker que procesa la queue.
 *
 * Suscrito al hook cron `wppe_bridge_worker_tick` (cada minuto).
 * Aplica D5 del CLAUDE.md: 4xx (excepto 429) -> failed_permanent;
 * 429 + 5xx + timeout -> retry con backoff exponencial.
 *
 * Concurrencia (W2): toma un lock via transient con TTL de 5 min al
 * inicio. Si ya hay otro tick corriendo, retorna sin tocar la queue.
 * Esto previene que dos crons paralelos tomen los mismos items y
 * dupliquen leads en Sperant.
 *
 * Hooks emitidos (CLAUDE.md seccion 4.3):
 * - filter `wppe_bridge_before_send` antes del POST.
 * - action `wppe_bridge_lead_sent` despues de POST exitoso.
 * - action `wppe_bridge_lead_failed` despues de fallo permanente.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Worker async que procesa la cola en cron ticks.
 */
final class WPPE_Bridge_Worker {

	/**
	 * Maximo de items por tick.
	 */
	public const BATCH_SIZE = 25;

	/**
	 * Key del transient de lock (con prefix del plugin).
	 */
	public const LOCK_KEY = 'wppe_bridge_worker_lock';

	/**
	 * TTL del lock (segundos). 5 min: muy por encima de un tick
	 * normal (segundos), suficiente para que un worker colgado
	 * eventualmente libere el lock por expiracion.
	 */
	public const LOCK_TTL_SECONDS = 300;

	/**
	 * Option name del timestamp del ultimo tick exitoso del worker.
	 *
	 * Lo escribe `process_queue()` al finalizar (incluyendo cuando no
	 * hay items que procesar — sigue siendo evidencia de que el cron
	 * corrio). Lo consume `Environment_Diagnostics::card_wp_cron()`
	 * para detectar workers que dejaron de ejecutarse.
	 */
	public const OPTION_LAST_TICK_AT = 'wppe_bridge_worker_last_tick_at';

	/**
	 * Punto de entrada del cron tick.
	 *
	 * @return void
	 */
	public static function process_queue(): void {
		if ( ! self::acquire_lock() ) {
			return;
		}
		try {
			// Marcar que el worker corrio (incluso si no hay items o si
			// la licencia bloquea). Lo importante es que WP-Cron disparo
			// el hook — ese es el heartbeat que mira el checker en
			// admin Inicio. No tocar este orden: si lo movemos al final
			// dentro del finally, queda dependiente de que ningun
			// throw aborte la actualizacion.
			self::record_tick();

			// License gate (v1.1.0). Si el sitio esta en estado
			// 'blocked' (externo, no whitelisted, demo agotado) NO
			// procesamos la queue. Items quedan en pending hasta
			// que el dominio aparezca en whitelist remota — el
			// siguiente tick los procesa normalmente.
			if ( class_exists( 'WPPE_Bridge_License_Manager' )
				&& ! WPPE_Bridge_License_Manager::can_send_lead() ) {
				WPPE_Bridge_Logger::warn(
					'worker_blocked_no_license',
					array(
						'state'      => WPPE_Bridge_License_Manager::state(),
						'demo_count' => WPPE_Bridge_License_Manager::demo_leads_count(),
						'demo_limit' => WPPE_Bridge_License_Manager::demo_lead_limit(),
					),
					null
				);
				return;
			}

			// v2.5.6: destination gate. Si el user todavia no eligio un
			// CRM destino (fresh install), no procesamos la queue. Los
			// items quedan en pending hasta que el user elija desde el
			// selector visual de Configuracion. Logueamos INFO (no warn)
			// porque es un estado esperado en fresh installs, no un
			// error operativo.
			if ( ! WPPE_Bridge_Destination_Factory::is_configured() ) {
				WPPE_Bridge_Logger::info(
					'worker_skipped_no_destination',
					array( 'reason' => 'no_active_destination_selected' ),
					null
				);
				return;
			}

			$batch = WPPE_Bridge_Queue::next_batch( self::BATCH_SIZE );
			foreach ( $batch as $item ) {
				// Re-check entre items porque el contador puede haberse
				// incrementado con el anterior y empujado al estado
				// blocked.
				if ( class_exists( 'WPPE_Bridge_License_Manager' )
					&& ! WPPE_Bridge_License_Manager::can_send_lead() ) {
					WPPE_Bridge_Logger::warn(
						'worker_blocked_mid_batch',
						array(
							'state'      => WPPE_Bridge_License_Manager::state(),
							'demo_count' => WPPE_Bridge_License_Manager::demo_leads_count(),
						),
						(int) $item->id
					);
					break;
				}
				self::process_item( $item );
			}
			WPPE_Bridge_Dedup::purge_expired();
		} finally {
			self::release_lock();
		}
	}

	/**
	 * Procesa un item individual: aplica filter, llama el destino
	 * activo via Factory, decide status segun el Destination_Result
	 * (D5) y emite hooks.
	 *
	 * Los hooks publicos (`wppe_bridge_lead_sent`, `_lead_failed`)
	 * reciben el shape legacy `{status, body, raw, error_class}` para
	 * preservar compat con modulos opcionales (Meta CAPI etc).
	 *
	 * @param object $item Row de la queue.
	 * @return void
	 */
	private static function process_item( object $item ): void {
		$queue_id = (int) $item->id;
		$payload  = self::decode_payload( $item->payload );

		try {
			/**
			 * Filtra el payload justo antes del POST al destino.
			 *
			 * @param array $payload  Payload normalizado.
			 * @param int   $queue_id ID de queue.
			 */
			$payload = apply_filters( 'wppe_bridge_before_send', $payload, $queue_id );
			$result  = WPPE_Bridge_Destination_Factory::get()->send( $payload );
		} catch ( \Throwable $e ) {
			WPPE_Bridge_Logger::error(
				'process_item_exception',
				array( 'exception' => $e->getMessage() ),
				$queue_id
			);
			$result = new WPPE_Bridge_Destination_Result(
				false,
				0,
				array(),
				$e->getMessage(),
				false
			);
		}

		$legacy = $result->to_legacy_array();

		if ( $result->success ) {
			WPPE_Bridge_Queue::mark( $queue_id, WPPE_Bridge_Queue::STATUS_SENT, $result->response );

			// Si el sitio esta en estado demo, incrementar el contador
			// post-send-exitoso. Solo cuenta sends reales — fallos no
			// consumen demo budget.
			if ( class_exists( 'WPPE_Bridge_License_Manager' )
				&& WPPE_Bridge_License_Manager::STATE_DEMO === WPPE_Bridge_License_Manager::state() ) {
				$new_count = WPPE_Bridge_License_Manager::increment_demo_counter();
				WPPE_Bridge_Logger::info(
					'demo_counter_incremented',
					array(
						'count' => $new_count,
						'limit' => WPPE_Bridge_License_Manager::demo_lead_limit(),
					),
					$queue_id
				);
			}

			WPPE_Bridge_Logger::info( 'lead_sent', array( 'status' => $result->http_code ), $queue_id );
			/**
			 * Fires after a lead is successfully sent to the active CRM.
			 *
			 * @param array $payload  Payload enviado.
			 * @param int   $queue_id ID de queue.
			 * @param array $response Respuesta uniforme legacy
			 *                        (shape {status, body, raw, error_class}).
			 */
			do_action( 'wppe_bridge_lead_sent', $payload, $queue_id, $legacy );
			return;
		}

		if ( $result->permanent ) {
			WPPE_Bridge_Queue::mark( $queue_id, WPPE_Bridge_Queue::STATUS_FAILED_PERMANENT, $result->response );
			WPPE_Bridge_Logger::error(
				'lead_failed_permanent',
				array(
					'status' => $result->http_code,
					'error'  => $result->error,
				),
				$queue_id
			);
			/**
			 * Fires after a lead fails permanently (4xx no-retry).
			 *
			 * @param array $payload  Payload enviado.
			 * @param int   $queue_id ID de queue.
			 * @param array $response Respuesta uniforme legacy.
			 */
			do_action( 'wppe_bridge_lead_failed', $payload, $queue_id, $legacy );
			return;
		}

		// Transient: agendamos retry.
		// v1.2.6: pasamos el `legacy` (response decoded + status + error_class)
		// para que se guarde tambien en el row de queue. Antes solo lo logueabamos
		// — el operador no podia inspeccionar el body de Sperant en failed_temp.
		$next_attempt = (int) $item->attempts + 1;
		$status_after = WPPE_Bridge_Queue::schedule_retry( $queue_id, $next_attempt, $legacy );
		WPPE_Bridge_Logger::warn(
			'lead_retry_scheduled',
			array(
				'status'       => $result->http_code,
				'attempt'      => $next_attempt,
				'final_status' => $status_after,
				'error'        => $result->error,
			),
			$queue_id
		);
		if ( WPPE_Bridge_Queue::STATUS_FAILED_PERMANENT === $status_after ) {
			// Backoff agotado (intento > 4) -> failed_permanent.
			// Dispatcheamos lead_failed igual que en 4xx para que el
			// admin se entere.
			do_action( 'wppe_bridge_lead_failed', $payload, $queue_id, $legacy );
		}
	}

	/**
	 * Decodifica el campo `payload` JSON del row de queue.
	 *
	 * @param mixed $raw Valor crudo (string JSON o ya array).
	 * @return array
	 */
	private static function decode_payload( $raw ): array {
		if ( is_array( $raw ) ) {
			return $raw;
		}
		if ( ! is_string( $raw ) || '' === $raw ) {
			return array();
		}
		$decoded = json_decode( $raw, true );
		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * Persiste el timestamp del ultimo tick. Se invoca al inicio de
	 * `process_queue()` despues de tomar el lock y antes de procesar
	 * la queue — la idea es registrar que el cron disparo el hook,
	 * independiente de que el batch tenga items o de la licencia.
	 *
	 * Aislado para ser facil de mockear desde tests
	 * (`$GLOBALS['wppe_test_now']`).
	 *
	 * @return void
	 */
	private static function record_tick(): void {
		// phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.RequestedUTC -- test mocks via $GLOBALS['wppe_test_now']; en runtime equivale a time().
		$now = function_exists( 'current_time' ) ? (int) current_time( 'timestamp', 1 ) : time();
		update_option( self::OPTION_LAST_TICK_AT, $now );
	}

	/**
	 * Intenta tomar el lock global. True si ganamos.
	 *
	 * @return bool
	 */
	private static function acquire_lock(): bool {
		if ( false !== get_transient( self::LOCK_KEY ) ) {
			return false;
		}
		set_transient( self::LOCK_KEY, time(), self::LOCK_TTL_SECONDS );
		return true;
	}

	/**
	 * Libera el lock global.
	 *
	 * @return void
	 */
	private static function release_lock(): void {
		delete_transient( self::LOCK_KEY );
	}
}
