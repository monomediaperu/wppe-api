<?php
/**
 * License Manager (v1.1.0).
 *
 * Determina si un sitio puede enviar leads al CRM, en base a 3 estados:
 *
 * - **managed**: hosting Mono Media. Detectado de cualquiera de:
 *   - Constante `WPPE_MANAGED` definida y truthy en wp-config.
 *   - Host actual matchea allowlist *local* (`*.wp.pe`, `*.mono.media`).
 *   - Host actual matchea allowlist *remota* via {@see Whitelist_Client}.
 *
 * - **demo**: sitio externo no managed. Permite enviar hasta
 *   {@see DEMO_LEAD_LIMIT} leads como prueba. Cada send exitoso
 *   incrementa el contador.
 *
 * - **blocked**: sitio externo, contador demo agotado. Worker no
 *   envia leads (queue queda en pending hasta que el dominio aparezca
 *   en la whitelist remota — momento en que el siguiente tick lo
 *   procesa normalmente).
 *
 * Decisiones tecnicas (CLAUDE.md sec 4.x extension):
 *
 * - **Whitelist remota como fuente de verdad**: Mono Media controla
 *   `https://api.wp.pe/bridge/whitelist.json`. Agregar/quitar
 *   clientes externos se hace alli, sin release del plugin, sin
 *   distribuir keys individuales.
 *
 * - **Cache local + TTL diferenciado**: si el sitio no esta listado
 *   refrescamos cada 1h (rapido para activar cuando se agregue);
 *   si esta listado, cada 24h (no urgente). Cron diario adicional
 *   garantiza que el cache se mantenga fresco mas alla de las
 *   gatilladas lazy.
 *
 * - **Allowlist local hardcodeada como fallback**: `*.wp.pe`,
 *   `*.mono.media` son siempre managed sin necesidad de fetch
 *   remoto (asi sitios internos de Mono Media funcionan offline).
 *
 * - **Filterable**: los puntos clave de detection
 *   (`wppe_bridge_managed_domains_local`, `wppe_bridge_is_managed`,
 *   `wppe_bridge_demo_lead_limit`, `wppe_bridge_current_host`)
 *   exponen filter para tests, mu-plugins y mocks.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * License Manager — state machine + whitelist + demo counter.
 */
final class WPPE_Bridge_License_Manager {

	/**
	 * Estados posibles del sitio.
	 */
	public const STATE_MANAGED = 'managed';
	public const STATE_DEMO    = 'demo';
	public const STATE_BLOCKED = 'blocked';

	/**
	 * Limite de leads en modo demo.
	 */
	public const DEMO_LEAD_LIMIT = 10;

	/**
	 * Constante que el cliente WP.pe define en wp-config para marcar
	 * la instalacion como "hosting Mono Media".
	 */
	public const WPPE_MANAGED_CONSTANT = 'WPPE_MANAGED';

	/**
	 * Option name del contador demo.
	 */
	public const OPTION_DEMO_COUNTER = 'wppe_bridge_demo_leads_count';

	/**
	 * Allowlist *local* hardcodeada — siempre managed sin necesidad de
	 * la whitelist remota. Util para sitios internos de Mono Media,
	 * dev/staging, y como fallback total si el endpoint cae para
	 * siempre.
	 *
	 * Soporta wildcard `*.example.com` y match exacto. Filterable
	 * via `wppe_bridge_managed_domains_local`.
	 *
	 * @return array<int,string>
	 */
	public static function default_local_managed_domains(): array {
		return array(
			'wp.pe',
			'*.wp.pe',
			'mono.media',
			'*.mono.media',
		);
	}

	/**
	 * Devuelve la allowlist local efectiva (defaults + filtros).
	 *
	 * @return array<int,string>
	 */
	public static function local_managed_domains(): array {
		$defaults = self::default_local_managed_domains();
		if ( ! function_exists( 'apply_filters' ) ) {
			return $defaults;
		}
		$filtered = apply_filters( 'wppe_bridge_managed_domains_local', $defaults );
		if ( ! is_array( $filtered ) ) {
			return $defaults;
		}
		$out = array();
		foreach ( $filtered as $d ) {
			if ( ! is_string( $d ) ) {
				continue;
			}
			$d = strtolower( trim( $d ) );
			if ( '' !== $d ) {
				$out[] = $d;
			}
		}
		return $out;
	}

	/**
	 * Devuelve la allowlist *remota* (cached, posiblemente vencida).
	 *
	 * Si el cliente no esta cargado o el cache esta vacio, devuelve
	 * array vacio (no bloquea — local + demo siguen funcionando).
	 *
	 * @return array<int,string>
	 */
	public static function remote_managed_domains(): array {
		if ( ! class_exists( 'WPPE_Bridge_Whitelist_Client' ) ) {
			return array();
		}
		$domains = WPPE_Bridge_Whitelist_Client::get_domains();
		return is_array( $domains ) ? $domains : array();
	}

	/**
	 * Verifica si un host concreto matchea una allowlist (exacto o
	 * wildcard `*.suffix`).
	 *
	 * @param string            $host    Host a verificar.
	 * @param array<int,string> $domains Lista de dominios.
	 * @return bool
	 */
	public static function host_matches_managed( string $host, array $domains ): bool {
		$host = strtolower( trim( $host ) );
		if ( '' === $host ) {
			return false;
		}
		foreach ( $domains as $entry ) {
			if ( ! is_string( $entry ) || '' === $entry ) {
				continue;
			}
			$entry = strtolower( $entry );
			if ( 0 === strpos( $entry, '*.' ) ) {
				$suffix = substr( $entry, 2 );
				if ( '' === $suffix ) {
					continue;
				}
				$needle = '.' . $suffix;
				if ( strlen( $host ) > strlen( $needle )
					&& substr( $host, -strlen( $needle ) ) === $needle ) {
					return true;
				}
				continue;
			}
			if ( $host === $entry ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Devuelve el host actual del sitio. Combina `home_url()` con
	 * `$_SERVER['HTTP_HOST']` como fallback. Filterable para tests.
	 *
	 * @return string
	 */
	public static function current_host(): string {
		$host = '';
		if ( function_exists( 'home_url' ) ) {
			$url   = (string) home_url();
			$parts = function_exists( 'wp_parse_url' ) ? wp_parse_url( $url ) : parse_url( $url ); // phpcs:ignore WordPress.WP.AlternativeFunctions.parse_url_parse_url -- fallback CLI/tests sin WP cargado.
			if ( is_array( $parts ) && isset( $parts['host'] ) ) {
				$host = (string) $parts['host'];
			}
		}
		if ( '' === $host && isset( $_SERVER['HTTP_HOST'] ) && is_string( $_SERVER['HTTP_HOST'] ) ) {
			$host = function_exists( 'sanitize_text_field' )
				? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) )
				: (string) $_SERVER['HTTP_HOST']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		}
		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'wppe_bridge_current_host', $host );
			if ( is_string( $filtered ) ) {
				$host = $filtered;
			}
		}
		return strtolower( $host );
	}

	/**
	 * True si el sitio esta gestionado por Mono Media.
	 *
	 * Criterios (cualquiera positivo gatilla):
	 *   1. Constante `WPPE_MANAGED` truthy.
	 *   2. Host matchea allowlist local.
	 *   3. Host matchea whitelist remota (via Whitelist_Client cache).
	 *
	 * Filterable via `wppe_bridge_is_managed` (override final).
	 *
	 * @return bool
	 */
	public static function is_managed(): bool {
		$by_constant = defined( self::WPPE_MANAGED_CONSTANT ) && (bool) constant( self::WPPE_MANAGED_CONSTANT );

		$result = $by_constant;

		if ( ! $result ) {
			$host     = self::current_host();
			$by_local = self::host_matches_managed( $host, self::local_managed_domains() );
			$result   = $by_local;

			if ( ! $result ) {
				$by_remote = self::host_matches_managed( $host, self::remote_managed_domains() );
				$result    = $by_remote;
			}
		}

		if ( function_exists( 'apply_filters' ) ) {
			$result = (bool) apply_filters( 'wppe_bridge_is_managed', $result );
		}
		return $result;
	}

	/**
	 * Devuelve el limite de leads en modo demo. Filterable.
	 *
	 * @return int
	 */
	public static function demo_lead_limit(): int {
		$default = self::DEMO_LEAD_LIMIT;
		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'wppe_bridge_demo_lead_limit', $default );
			$n        = (int) $filtered;
			if ( $n > 0 ) {
				return $n;
			}
		}
		return $default;
	}

	/**
	 * Cuenta de leads enviados en modo demo (entero >= 0).
	 *
	 * @return int
	 */
	public static function demo_leads_count(): int {
		$n = (int) get_option( self::OPTION_DEMO_COUNTER, 0 );
		return max( 0, $n );
	}

	/**
	 * Leads restantes en demo. Cero si limite alcanzado.
	 *
	 * @return int
	 */
	public static function demo_leads_remaining(): int {
		return max( 0, self::demo_lead_limit() - self::demo_leads_count() );
	}

	/**
	 * Incrementa el contador. Llamar UNA vez por cada lead enviado
	 * exitosamente cuando el sitio esta en estado demo.
	 *
	 * @return int Nuevo conteo.
	 */
	public static function increment_demo_counter(): int {
		$new = self::demo_leads_count() + 1;
		update_option( self::OPTION_DEMO_COUNTER, $new );
		return $new;
	}

	/**
	 * Resetea el contador a 0. Se invoca cuando el sitio se mueve a
	 * estado managed (entro a la whitelist) — asi cuando el cliente
	 * eventualmente vuelva a quedar fuera (raro, pero posible) tiene
	 * credito demo fresco.
	 *
	 * @return void
	 */
	public static function reset_demo_counter(): void {
		update_option( self::OPTION_DEMO_COUNTER, 0 );
	}

	/**
	 * Resuelve el estado actual del sitio.
	 *
	 *   1. managed (constante / local / remoto)
	 *   2. demo (counter < limit)
	 *   3. blocked
	 *
	 * @return string Una de las constantes STATE_*.
	 */
	public static function state(): string {
		if ( self::is_managed() ) {
			return self::STATE_MANAGED;
		}
		if ( self::demo_leads_remaining() > 0 ) {
			return self::STATE_DEMO;
		}
		return self::STATE_BLOCKED;
	}

	/**
	 * True si el sitio puede enviar un lead AHORA (no bloqueado).
	 *
	 * @return bool
	 */
	public static function can_send_lead(): bool {
		return self::STATE_BLOCKED !== self::state();
	}
}
