<?php
/**
 * Resuelve `input_channel_id` de Sperant a partir del `utm_source` del
 * visitante, usando una tabla de mapeo global persistida en
 * `wp_options['wppe_bridge_utm_to_input_channel_map']`.
 *
 * **Problema que resuelve (reporte de cliente, v2.5.1):**
 *
 * El admin solo puede configurar un `input_channel_id` default por form
 * (en Mapeo). Resultado: TODOS los leads del web caen al mismo "Canal"
 * en Sperant (tipicamente "Pagina Web"), aunque el visitante venga de
 * Google Ads, Facebook Ads u otra fuente. Atribucion del canal queda
 * uniforme y se rompe el reporting.
 *
 * **Solucion:**
 *
 * Tabla de mapeo GLOBAL `utm_source -> input_channel_id` configurable
 * desde la pagina de Mapeo (no per-form — el reporte del cliente es
 * global, y los canales Sperant son los mismos para cualquier form del
 * sitio).
 *
 * Comportamiento:
 *
 * - Match case-insensitive con trim. "GOOGLE" / "google" / "  Google  "
 *   todos matchean a la misma regla.
 * - Si hay match -> override del `input_channel_id` del payload.
 * - Si NO hay match (o el visitante no trae UTMs) -> NO se toca el
 *   payload (preserva el default global del Mapping_Page, que sigue
 *   funcionando como hasta ahora — fallback Pagina Web).
 *
 * **Orden de precedencia:**
 *
 * 1. Si el form-field `input_channel_id` esta mapeado a un campo del
 *    form (caso raro), gana sin importar UTM mapping.
 * 2. Si hay match en UTM mapping, gana sobre el default.
 * 3. Si no hay match, queda el default del Mapping_Page (comportamiento
 *    legacy preservado).
 *
 * **Filter para overrides programaticos:**
 *
 * `wppe_bridge_resolve_input_channel($id, $utm_source, $payload)` —
 * util para clientes con logica compleja (ej. matching por dominio
 * referrer en lugar de utm_source). Si el filter retorna `null`, NO
 * se inyecta (preserva default).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Resuelve input_channel_id Sperant desde utm_source del visitante.
 */
final class WPPE_Bridge_Utm_Channel_Mapper {

	/**
	 * Option key donde vive el mapeo global. Shape:
	 *   [
	 *     ['utm_source' => 'google',   'input_channel_id' => 2],
	 *     ['utm_source' => 'facebook', 'input_channel_id' => 3],
	 *     ...
	 *   ]
	 *
	 * El admin la edita desde la pagina de Mapeo (no per-form).
	 */
	public const OPTION_KEY = 'wppe_bridge_utm_to_input_channel_map';

	/**
	 * Resuelve el `input_channel_id` para un `utm_source` dado.
	 *
	 * Pasos:
	 *  1. Trim + lowercase del `utm_source`.
	 *  2. Lookup en la tabla persistida (case-insensitive en ambos
	 *     lados — el admin podria haber guardado "Google" con
	 *     mayuscula).
	 *  3. Si match, retorna el `input_channel_id` (int > 0).
	 *  4. Si no match, retorna null (caller mantiene el default).
	 *  5. Aplica filter `wppe_bridge_resolve_input_channel` al final
	 *     para permitir overrides programaticos.
	 *
	 * @param string $utm_source Valor de `utm_source` del payload (puede
	 *                            estar vacio si el visitante vino directo).
	 * @param array  $payload    Payload completo del lead (pasado al filter
	 *                            por si necesita context — ej. matching por
	 *                            referrer en clientes custom).
	 * @return int|null `input_channel_id` (int > 0) si hay match; null
	 *                   si no aplica (caller preserva default existente).
	 */
	public static function resolve( string $utm_source, array $payload = array() ): ?int {
		$resolved = self::lookup_in_map( $utm_source );

		// Filter para overrides programaticos. Si el filter retorna 0,
		// null, false o un valor no-int positivo, descartamos.
		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'wppe_bridge_resolve_input_channel', $resolved, $utm_source, $payload );
			$resolved = self::coerce_positive_int( $filtered );
		}

		return $resolved;
	}

	/**
	 * Hace el lookup en la option `wppe_bridge_utm_to_input_channel_map`.
	 * Aislado para testeo y para que `resolve` siga limpio.
	 *
	 * @param string $utm_source Value de `utm_source` ya capturado del payload.
	 * @return int|null
	 */
	private static function lookup_in_map( string $utm_source ): ?int {
		$key = self::normalize( $utm_source );
		if ( '' === $key ) {
			return null;
		}

		$map = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $map ) || empty( $map ) ) {
			return null;
		}

		foreach ( $map as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}
			$entry_source = isset( $entry['utm_source'] ) ? self::normalize( (string) $entry['utm_source'] ) : '';
			if ( '' === $entry_source ) {
				continue;
			}
			if ( $entry_source !== $key ) {
				continue;
			}
			$id = isset( $entry['input_channel_id'] ) ? (int) $entry['input_channel_id'] : 0;
			if ( $id > 0 ) {
				return $id;
			}
		}

		return null;
	}

	/**
	 * Normaliza un string para comparacion case-insensitive con trim.
	 *
	 * @param string $str Input crudo.
	 * @return string
	 */
	private static function normalize( string $str ): string {
		$str = trim( $str );
		if ( '' === $str ) {
			return '';
		}
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $str, 'UTF-8' ) : strtolower( $str );
	}

	/**
	 * Coerce un valor a `int|null` aceptando solo positivos. Defensivo
	 * para el retorno del filter (devs pueden retornar string, false, etc).
	 *
	 * @param mixed $value Valor crudo (puede ser int, string numeric, false, null, etc).
	 * @return int|null
	 */
	private static function coerce_positive_int( $value ): ?int {
		if ( null === $value || false === $value ) {
			return null;
		}
		if ( is_int( $value ) && $value > 0 ) {
			return $value;
		}
		if ( is_string( $value ) && ctype_digit( $value ) ) {
			$casted = (int) $value;
			return $casted > 0 ? $casted : null;
		}
		if ( is_numeric( $value ) ) {
			$casted = (int) $value;
			return $casted > 0 ? $casted : null;
		}
		return null;
	}

	/**
	 * Persiste un nuevo mapeo. Sanitiza y dedup por `utm_source`
	 * normalizado (ultima entrada gana si hay duplicados).
	 *
	 * Usado por el Mapping_Page handler. Aislado aqui para que tenga
	 * unica fuente de verdad (validacion + sanitizacion + persistencia).
	 *
	 * @param array<int,array{utm_source:string,input_channel_id:int|string}> $entries Lista de filas crudas del POST.
	 * @return bool True si el option fue actualizado.
	 */
	public static function save( array $entries ): bool {
		$out  = array();
		$seen = array();

		foreach ( $entries as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}
			$source = isset( $entry['utm_source'] ) ? (string) $entry['utm_source'] : '';
			$source = function_exists( 'sanitize_text_field' ) ? sanitize_text_field( $source ) : trim( $source );
			$source = trim( $source );
			if ( '' === $source ) {
				continue;
			}

			$id_raw = isset( $entry['input_channel_id'] ) ? $entry['input_channel_id'] : 0;
			$id     = self::coerce_positive_int( $id_raw );
			if ( null === $id ) {
				continue;
			}

			$normalized = self::normalize( $source );
			if ( isset( $seen[ $normalized ] ) ) {
				// Dedup: ultima entrada gana, sobrescribe la anterior.
				$idx                             = $seen[ $normalized ];
				$out[ $idx ]['utm_source']       = $source;
				$out[ $idx ]['input_channel_id'] = $id;
				continue;
			}
			$seen[ $normalized ] = count( $out );
			$out[]               = array(
				'utm_source'       => $source,
				'input_channel_id' => $id,
			);
		}

		return (bool) update_option( self::OPTION_KEY, $out );
	}

	/**
	 * Lee el mapeo actual. Defensivo: array vacio si la option no
	 * existe o esta corrupta.
	 *
	 * @return array<int,array{utm_source:string,input_channel_id:int}>
	 */
	public static function get_all(): array {
		$map = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $map ) ) {
			return array();
		}
		// Sanity check: filtrar entries malformadas.
		$out = array();
		foreach ( $map as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}
			$source = isset( $entry['utm_source'] ) ? (string) $entry['utm_source'] : '';
			$id     = isset( $entry['input_channel_id'] ) ? (int) $entry['input_channel_id'] : 0;
			if ( '' === trim( $source ) || $id <= 0 ) {
				continue;
			}
			$out[] = array(
				'utm_source'       => $source,
				'input_channel_id' => $id,
			);
		}
		return $out;
	}
}
