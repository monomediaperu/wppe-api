<?php
/**
 * Deduplicacion local por hash con TTL.
 *
 * Decision D4 del CLAUDE.md. Hash = sha256(form_id + email + phone + landing_url).
 * Tabla wp_wppebridge_dedup con TTL configurable (default 60s).
 * La atomicidad anti-race se delega a MySQL via INSERT IGNORE: si dos
 * procesos paralelos intentan reservar el mismo hash, solo uno
 * inserta efectivamente; el otro recibe affected_rows=0 y pierde la
 * carrera (status `deduped`).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Deduplicacion local por hash con TTL.
 */
final class WPPE_Bridge_Dedup {

	/**
	 * Nombre de la tabla (sin prefix de WP).
	 */
	private const TABLE = 'wppebridge_dedup';

	/**
	 * Calcula el hash deterministico de un payload normalizado.
	 *
	 * Material concatenado con `|` para evitar colisiones de
	 * concatenacion (ej. campos que terminan/empiezan iguales).
	 *
	 * @param array $payload Debe contener al menos form_id, email,
	 *                       phone y landing_url. Campos ausentes se
	 *                       tratan como cadena vacia.
	 * @return string Hash sha256 hex (64 chars).
	 */
	public static function hash( array $payload ): string {
		$material = (string) ( $payload['form_id'] ?? '' )
			. '|' . (string) ( $payload['email'] ?? '' )
			. '|' . (string) ( $payload['phone'] ?? '' )
			. '|' . (string) ( $payload['landing_url'] ?? '' );
		return hash( 'sha256', $material );
	}

	/**
	 * Intenta reservar el hash. Devuelve true si la reserva fue
	 * exitosa (es nuevo o el anterior expiro), false si ya existia
	 * y aun no expiro.
	 *
	 * Estrategia anti-race:
	 * 1. DELETE de la entrada si existe Y ya expiro.
	 * 2. INSERT IGNORE; affected_rows=1 si ganamos, =0 si alguien mas
	 *    ya estaba (no expirado).
	 *
	 * @param string $hash         Hash devuelto por self::hash().
	 * @param int    $ttl_seconds  TTL en segundos.
	 * @return bool
	 */
	public static function try_reserve( string $hash, int $ttl_seconds ): bool {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;

		$now        = current_time( 'mysql', true );
		$now_ts     = (int) strtotime( $now );
		$expires_at = gmdate( 'Y-m-d H:i:s', $now_ts + max( 0, $ttl_seconds ) );

		// Limpiar entrada expirada si existe (idempotente).
		$wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				"DELETE FROM {$table} WHERE hash = %s AND expires_at < %s",
				$hash,
				$now
			)
		);

		// Intento atomico de reserva.
		$rows = $wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				"INSERT IGNORE INTO {$table} (hash, expires_at) VALUES (%s, %s)",
				$hash,
				$expires_at
			)
		);

		return 1 === (int) $rows;
	}

	/**
	 * Limpia entradas expiradas. Llamado periodicamente desde el worker.
	 *
	 * @return int Filas eliminadas.
	 */
	public static function purge_expired(): int {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;
		$now   = current_time( 'mysql', true );
		$rows  = $wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				"DELETE FROM {$table} WHERE expires_at < %s",
				$now
			)
		);
		return max( 0, (int) $rows );
	}
}
