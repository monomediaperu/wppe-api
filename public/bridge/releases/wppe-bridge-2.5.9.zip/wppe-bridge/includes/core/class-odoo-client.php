<?php
/**
 * Cliente HTTP para la API de Odoo via JSON-RPC clasico.
 *
 * Envuelve `wp_remote_request` con:
 *  - Construccion del envelope JSON-RPC `{jsonrpc, method, id, params}`.
 *  - Auth en 2 pasos: `common.authenticate(db, login, api_key, {})`
 *    devuelve un uid integer estable que se cachea en
 *    `wppe_bridge_odoo_uid_cache` (D-Odoo-2). Solo se re-autentica
 *    cuando un `execute_kw` falla con AccessDenied/AccessError.
 *  - Mapeo de errores tipicos a `error_class` (D-Odoo-1, investigacion
 *    confirmada vs docs Odoo + codigo): JSON-RPC clasico devuelve
 *    HTTP 200 + body `error.data.name` con la clase Python de la
 *    excepcion. AccessError/AccessDenied/ValidationError/UserError
 *    son permanentes; psycopg2/OperationalError/ConcurrentUpdate son
 *    transient. HTTP 5xx es transient. WP_Error es transient.
 *
 * Cubre Odoo v15-v19 con un unico code path. JSON-2 (`/json/2/...`,
 * v19+) queda para v22 cuando `/jsonrpc` se deprecado oficialmente.
 *
 * Cada llamada (authenticate, execute_kw, create_lead) devuelve un
 * array uniforme:
 *   [
 *     'status'      => int     // HTTP status code, 0 si error de red
 *     'body'        => array   // Body JSON-decodificado, [] si no hay
 *     'raw'         => string  // Body crudo
 *     'error_class' => string  // 'success'|'transient'|'permanent'
 *     'result'      => mixed   // body['result'] si lo hubo (uid, lead id, ...)
 *     'error_name'  => string  // body['error']['data']['name'] si lo hubo
 *   ]
 *
 * El Worker usa `error_class` para D5 sin tener que conocer detalles
 * Odoo.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Wrapper estatico sobre wp_remote_* para llamar a Odoo via JSON-RPC.
 */
final class WPPE_Odoo_Client {

	/**
	 * Timeout HTTP en segundos. Generoso para evitar timeouts falsos
	 * (ver CLAUDE.md sec 6, mitigacion de causa 2).
	 */
	public const HTTP_TIMEOUT_SECONDS = 15;

	/**
	 * Path del endpoint JSON-RPC clasico. Estable v8-v19.
	 */
	public const ENDPOINT = '/jsonrpc';

	/**
	 * Servicios Odoo expuestos via JSON-RPC.
	 */
	public const SERVICE_COMMON = 'common';
	public const SERVICE_OBJECT = 'object';

	/**
	 * Metodo Odoo de autenticacion. Devuelve uid integer o false.
	 */
	public const METHOD_AUTHENTICATE = 'authenticate';

	/**
	 * Metodo Odoo generico de invocacion sobre un modelo.
	 */
	public const METHOD_EXECUTE_KW = 'execute_kw';

	/**
	 * Modelo target para crear leads.
	 */
	public const MODEL_CRM_LEAD = 'crm.lead';

	/**
	 * Clases de error usadas por el Worker para decidir reintento.
	 */
	public const ERROR_CLASS_SUCCESS   = 'success';
	public const ERROR_CLASS_TRANSIENT = 'transient';
	public const ERROR_CLASS_PERMANENT = 'permanent';

	/**
	 * Lista de `error.data.name` Odoo que clasificamos como permanentes
	 * (no reintentar). Substring match — la clase Python completa suele
	 * traer el namespace `odoo.exceptions.<X>`.
	 *
	 * @var array<int,string>
	 */
	private const PERMANENT_ERROR_NAMES = array(
		'AccessError',
		'AccessDenied',
		'ValidationError',
		'UserError',
		'MissingError',
		'except_orm',
	);

	/**
	 * Lista de `error.data.name` Odoo que clasificamos como transient.
	 * Substring match.
	 *
	 * @var array<int,string>
	 */
	private const TRANSIENT_ERROR_NAMES = array(
		'psycopg2',
		'OperationalError',
		'ConcurrentUpdate',
		'TransactionRollbackError',
	);

	/**
	 * Lista de `error.data.name` Odoo que indican re-auth necesario
	 * (uid invalido/api_key revocada/usuario deshabilitado).
	 * Substring match.
	 *
	 * @var array<int,string>
	 */
	private const REAUTH_ERROR_NAMES = array(
		'AccessDenied',
	);

	/**
	 * Limite default de records por catalogo. Odoo Online maneja bien
	 * search_read hasta varios miles, pero >500 implica latencia notable
	 * y muy raramente una inmobiliaria necesita >500 salespeople o tags.
	 * Override via filter `wppe_bridge_odoo_catalog_limit`.
	 */
	public const CATALOG_DEFAULT_LIMIT = 500;

	/**
	 * Crea un lead `crm.lead` en Odoo.
	 *
	 * Wrapping de `execute_kw('crm.lead', 'create', [$values])`. El
	 * caller (Destination) ya hizo el mapeo de keys del payload
	 * normalizado del bridge a keys de `crm.lead` Odoo (`name`,
	 * `email_from`, `phone`, `contact_name`, `type`, etc).
	 *
	 * @param array<string,mixed> $values Values listos para `crm.lead`.
	 * @return array{status:int,body:array,raw:string,error_class:string,result:mixed,error_name:string}
	 */
	public static function create_lead( array $values ): array {
		return self::execute_kw( self::MODEL_CRM_LEAD, 'create', array( $values ) );
	}

	/**
	 * Crea un tag `crm.tag` en Odoo. Usado por `Odoo_Destination` cuando
	 * un tag default global o per-form no existe en el catalogo cacheado
	 * — Odoo no auto-crea tags al recibir `crm.lead.create` con un name
	 * que no existe (rechaza con `ValidationError`), asi que tenemos que
	 * crearlo first y luego pasar el id en `tag_ids`.
	 *
	 * Retorna shape uniforme. Si exitoso, `result` contiene el id integer
	 * del tag recien creado. El destination es best-effort: si esta llamada
	 * falla (network, AccessError de un user sin permisos para crear
	 * crm.tag), loggeamos `info` y omitimos el tag — el lead se crea sin el.
	 *
	 * No hace search-then-create antes para evitar 2x roundtrips. La race
	 * (dos leads simultaneos crean el mismo tag) es aceptable: Odoo no
	 * tiene unique constraint en `crm.tag.name`, los duplicados quedan
	 * visibles para que el admin merge manualmente. Caso raro en practica.
	 *
	 * @param string $name Nombre del tag (post-trim, no vacio).
	 * @return array{status:int,body:array,raw:string,error_class:string,result:mixed,error_name:string}
	 */
	public static function create_tag( string $name ): array {
		return self::execute_kw( 'crm.tag', 'create', array( array( 'name' => $name ) ) );
	}

	/**
	 * Helper generico para `search_read` sobre cualquier modelo Odoo.
	 *
	 * Wrapping de `execute_kw($model, 'search_read', [$domain],
	 * {fields, limit})`. Construye una response uniforme con el array
	 * de items extraido de `result` (filtrando entries sin `id` para
	 * defensa ante shape inesperado).
	 *
	 * Para los catalogos del bridge usamos limit=500 (CATALOG_DEFAULT_LIMIT).
	 * Una inmobiliaria mediana raramente tiene >500 salespeople, tags
	 * o sources. Si aparece esa necesidad, agregar paginacion en una
	 * iteracion siguiente (search con offset hasta agotar).
	 *
	 * @param string                      $model  Modelo Odoo (ej. 'crm.team').
	 * @param array<int,array<int,mixed>> $domain Filtros estilo Odoo
	 *                                            (ej. [['active', '=', true]]).
	 *                                            Pasar `[]` para "todos".
	 * @param array<int,string>           $fields Campos a leer (default `['id','name']`).
	 * @param int|null                    $limit  Override del limit (default
	 *                                             CATALOG_DEFAULT_LIMIT con filter).
	 * @return array{status:int,body:array,raw:string,error_class:string,result:mixed,error_name:string,items:array<int,array<string,mixed>>}
	 */
	public static function list_records( string $model, array $domain = array(), array $fields = array( 'id', 'name' ), ?int $limit = null ): array {
		$resolved_limit = self::resolve_catalog_limit( $limit );
		$kwargs         = array(
			'fields' => $fields,
			'limit'  => $resolved_limit,
		);

		$response          = self::execute_kw( $model, 'search_read', array( $domain ), $kwargs );
		$response['items'] = self::extract_records_collection( $response );
		return $response;
	}

	/**
	 * Lista equipos de venta (`crm.team`). Sin filtro — los equipos
	 * suelen ser pocos y no tienen flag `active` en algunos modulos.
	 *
	 * @return array
	 */
	public static function list_teams(): array {
		return self::list_records( 'crm.team', array(), array( 'id', 'name' ) );
	}

	/**
	 * Lista vendedores (`res.users`). Filtro `active=true` para excluir
	 * usuarios deshabilitados — asignar un lead a un user inactivo
	 * resulta en notifications muertas y tickets.
	 *
	 * Devuelve `id, name, login`. `login` es el email — util para que el
	 * admin distinga "Maria Lopez" cuando hay 3 personas con ese nombre.
	 *
	 * @return array
	 */
	public static function list_users(): array {
		return self::list_records(
			'res.users',
			array( array( 'active', '=', true ) ),
			array( 'id', 'name', 'login' )
		);
	}

	/**
	 * Lista fuentes UTM (`utm.source`). Cada record es `{id, name}`.
	 * Inyecta como `source_id` en el payload `crm.lead` (PR-3).
	 *
	 * @return array
	 */
	public static function list_utm_sources(): array {
		return self::list_records( 'utm.source', array(), array( 'id', 'name' ) );
	}

	/**
	 * Lista medios UTM (`utm.medium`). Inyecta como `medium_id`.
	 *
	 * @return array
	 */
	public static function list_utm_mediums(): array {
		return self::list_records( 'utm.medium', array(), array( 'id', 'name' ) );
	}

	/**
	 * Lista campanas UTM (`utm.campaign`). Inyecta como `campaign_id`.
	 *
	 * @return array
	 */
	public static function list_utm_campaigns(): array {
		return self::list_records( 'utm.campaign', array(), array( 'id', 'name' ) );
	}

	/**
	 * Lista tags CRM (`crm.tag`). Inyecta como `tag_ids` ([(6,0,[ids])]).
	 *
	 * @return array
	 */
	public static function list_tags(): array {
		return self::list_records( 'crm.tag', array(), array( 'id', 'name' ) );
	}

	/**
	 * Lista paises (`res.country`). Util para mapear `country_id` cuando
	 * el form tiene un campo "Pais". Devolvemos `code` (ISO 2 letters)
	 * ademas de id+name para que el admin identifique paises homonimos
	 * (ej. "Korea, Republic of" vs "Korea, Democratic People's Republic of").
	 *
	 * Limite especial 300 — Odoo trae ~250 paises out-of-the-box, pero
	 * no queremos cortar si un cliente agrego variantes regionales.
	 *
	 * @return array
	 */
	public static function list_countries(): array {
		return self::list_records(
			'res.country',
			array(),
			array( 'id', 'name', 'code' ),
			300
		);
	}

	/**
	 * Sincroniza los 7 catalogos Odoo y devuelve un resultado unificado.
	 * Mismo patron que Ghl_Client::sync_catalogs y Sperant_Client::sync_catalogs:
	 * si un endpoint falla, su key contiene array vacio y el error queda
	 * en `_errors[<key>]`. Permite continuar con los demas catalogos
	 * aunque uno especifico falle (ej. el cliente no tiene el modulo
	 * `utm` instalado y `utm.source` retorna AccessError).
	 *
	 * Shape:
	 *   [
	 *     'teams'         => [...],
	 *     'users'         => [...],
	 *     'utm_sources'   => [...],
	 *     'utm_mediums'   => [...],
	 *     'utm_campaigns' => [...],
	 *     'tags'          => [...],
	 *     'countries'     => [...],
	 *     '_errors'       => ['utm_sources' => 'AccessError', ...],
	 *     '_synced_at'    => 1730000000,
	 *   ]
	 *
	 * @return array{
	 *   teams:array,users:array,utm_sources:array,utm_mediums:array,
	 *   utm_campaigns:array,tags:array,countries:array,
	 *   _errors:array<string,string>,_synced_at:int
	 * }
	 */
	public static function sync_catalogs(): array {
		$result = array(
			'teams'         => array(),
			'users'         => array(),
			'utm_sources'   => array(),
			'utm_mediums'   => array(),
			'utm_campaigns' => array(),
			'tags'          => array(),
			'countries'     => array(),
			'_errors'       => array(),
			'_synced_at'    => time(),
		);

		$endpoints = array(
			'teams'         => array( self::class, 'list_teams' ),
			'users'         => array( self::class, 'list_users' ),
			'utm_sources'   => array( self::class, 'list_utm_sources' ),
			'utm_mediums'   => array( self::class, 'list_utm_mediums' ),
			'utm_campaigns' => array( self::class, 'list_utm_campaigns' ),
			'tags'          => array( self::class, 'list_tags' ),
			'countries'     => array( self::class, 'list_countries' ),
		);

		foreach ( $endpoints as $key => $callable ) {
			$response = call_user_func( $callable );
			if ( self::ERROR_CLASS_SUCCESS === $response['error_class'] ) {
				$result[ $key ] = $response['items'];
				continue;
			}
			$result['_errors'][ $key ] = self::format_sync_error( $response );
		}

		return $result;
	}

	/**
	 * Extrae la coleccion de records desde una response de `search_read`.
	 *
	 * `search_read` retorna `result` como una lista plana de dicts. Si
	 * llego un valor inesperado (false, scalar, dict suelto), retornamos
	 * array vacio. Tambien filtramos items sin `id` por defensa contra
	 * shape inesperado.
	 *
	 * @param array<string,mixed> $response Response uniforme del client.
	 * @return array<int,array<string,mixed>>
	 */
	private static function extract_records_collection( array $response ): array {
		if ( self::ERROR_CLASS_SUCCESS !== ( $response['error_class'] ?? '' ) ) {
			return array();
		}
		$result = $response['result'] ?? null;
		if ( ! is_array( $result ) ) {
			return array();
		}
		return array_values(
			array_filter(
				$result,
				static function ( $item ) {
					return is_array( $item ) && isset( $item['id'] );
				}
			)
		);
	}

	/**
	 * Construye un mensaje corto para `_errors[<key>]` desde una
	 * response fallida. Prefiere `error_name` (ej.
	 * `odoo.exceptions.AccessError`) que es lo mas accionable para el
	 * admin (le dice de un vistazo si es permisos o validacion). Fallback
	 * a `HTTP <status>` o `Network error`.
	 *
	 * @param array<string,mixed> $response Response uniforme.
	 * @return string
	 */
	private static function format_sync_error( array $response ): string {
		$name = (string) ( $response['error_name'] ?? '' );
		if ( '' !== $name ) {
			return $name;
		}
		$status = (int) ( $response['status'] ?? 0 );
		if ( 0 === $status ) {
			return 'Network error or timeout';
		}
		return sprintf( 'HTTP %d', $status );
	}

	/**
	 * Resuelve el limit a usar para una llamada `list_records`. Default
	 * `CATALOG_DEFAULT_LIMIT`, pero el caller puede sobreescribir y los
	 * tests/devs pueden meterse via filter.
	 *
	 * @param int|null $explicit Override pasado por el caller.
	 * @return int
	 */
	private static function resolve_catalog_limit( ?int $explicit ): int {
		$limit = null !== $explicit ? $explicit : self::CATALOG_DEFAULT_LIMIT;
		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'wppe_bridge_odoo_catalog_limit', $limit );
			if ( is_int( $filtered ) && $filtered > 0 ) {
				$limit = $filtered;
			}
		}
		return $limit;
	}

	/**
	 * Ejecuta `<service>=object, <method>=execute_kw` contra el modelo
	 * indicado. Maneja autenticacion automatica:
	 *  - Lee uid cacheado (`wppe_bridge_odoo_uid_cache`).
	 *  - Si no hay cache, autentica y guarda.
	 *  - Si la llamada falla con AccessDenied (uid invalidado, api_key
	 *    revocada, etc), invalida cache, re-autentica y reintenta UNA
	 *    sola vez. Si la 2da llamada vuelve a fallar, retorna permanente.
	 *
	 * @param string              $model  Nombre del modelo Odoo (ej. 'crm.lead').
	 * @param string              $method Metodo del modelo (ej. 'create', 'search', 'read').
	 * @param array<int,mixed>    $args   Args posicionales (ej. [[values]] para create).
	 * @param array<string,mixed> $kwargs Kwargs (default vacio).
	 * @return array{status:int,body:array,raw:string,error_class:string,result:mixed,error_name:string}
	 */
	public static function execute_kw( string $model, string $method, array $args, array $kwargs = array() ): array {
		$uid = self::get_or_authenticate_uid();
		if ( 0 === $uid ) {
			// Auth fallo — credenciales invalidas. Sin uid, no hay caso.
			return self::build_auth_failed_response();
		}

		$response = self::call_execute_kw( $uid, $model, $method, $args, $kwargs );

		// Re-auth y retry si el body indica que el uid cacheado quedo
		// invalido (api_key rotada, usuario deshabilitado).
		if ( self::needs_reauth( $response ) ) {
			self::clear_uid_cache();
			$uid = self::authenticate_fresh();
			if ( 0 === $uid ) {
				return self::build_auth_failed_response();
			}
			$response = self::call_execute_kw( $uid, $model, $method, $args, $kwargs );
		}

		return $response;
	}

	/**
	 * Autentica contra Odoo via `common.authenticate`. No usa cache —
	 * siempre hace el round-trip. Util para test-connection en admin.
	 *
	 * @return array{status:int,body:array,raw:string,error_class:string,result:mixed,error_name:string}
	 */
	public static function authenticate(): array {
		$db      = (string) get_option( 'wppe_bridge_odoo_db', '' );
		$login   = (string) get_option( 'wppe_bridge_odoo_login', '' );
		$api_key = (string) get_option( 'wppe_bridge_odoo_api_key', '' );

		$response = self::request(
			array(
				'service' => self::SERVICE_COMMON,
				'method'  => self::METHOD_AUTHENTICATE,
				'args'    => array( $db, $login, $api_key, new \stdClass() ),
			)
		);

		// Auth con creds invalidas: HTTP 200, body{result: false} (Odoo
		// no levanta excepcion, solo retorna false). Reclasificar como
		// permanente — el operador tiene que rotar credenciales.
		if (
			self::ERROR_CLASS_SUCCESS === $response['error_class']
			&& false === $response['result']
		) {
			$response['error_class'] = self::ERROR_CLASS_PERMANENT;
		}

		// Si hubo uid valido, cachearlo.
		if (
			self::ERROR_CLASS_SUCCESS === $response['error_class']
			&& is_int( $response['result'] )
			&& $response['result'] > 0
		) {
			self::set_cached_uid( (int) $response['result'] );
		}

		return $response;
	}

	/**
	 * Limpia el uid cacheado. Util cuando el operador cambia
	 * credenciales en la sub-pagina admin.
	 *
	 * @return void
	 */
	public static function clear_uid_cache(): void {
		if ( function_exists( 'delete_option' ) ) {
			delete_option( 'wppe_bridge_odoo_uid_cache' );
			return;
		}
		// Fallback para entornos test sin delete_option stubbeado:
		// resetear via update_option.
		if ( function_exists( 'update_option' ) ) {
			update_option( 'wppe_bridge_odoo_uid_cache', 0 );
		}
	}

	// ---------- internos: request / parse ----------

	/**
	 * Hace una request JSON-RPC al endpoint `/jsonrpc` de Odoo.
	 *
	 * @param array<string,mixed> $params Contenido del campo `params`
	 *                                    del envelope (service, method, args).
	 * @return array{status:int,body:array,raw:string,error_class:string,result:mixed,error_name:string}
	 */
	private static function request( array $params ): array {
		$envelope = array(
			'jsonrpc' => '2.0',
			'method'  => 'call',
			'id'      => self::next_request_id(),
			'params'  => $params,
		);

		$args = array(
			'method'  => 'POST',
			'timeout' => self::HTTP_TIMEOUT_SECONDS,
			'headers' => array(
				'Content-Type' => 'application/json',
				'Accept'       => 'application/json',
			),
			'body'    => wp_json_encode( $envelope ),
		);

		$url = self::base_url() . self::ENDPOINT;

		$response = wp_remote_request( $url, $args );

		return self::parse_response( $response );
	}

	/**
	 * Hace `execute_kw(db, uid, api_key, model, method, args, kwargs)`.
	 * Aislado para que `execute_kw()` pueda invocarlo dos veces
	 * (primer intento + retry post-reauth).
	 *
	 * @param int                 $uid    UID retornado por authenticate.
	 * @param string              $model  Modelo Odoo.
	 * @param string              $method Metodo.
	 * @param array<int,mixed>    $args   Args posicionales.
	 * @param array<string,mixed> $kwargs Kwargs.
	 * @return array{status:int,body:array,raw:string,error_class:string,result:mixed,error_name:string}
	 */
	private static function call_execute_kw( int $uid, string $model, string $method, array $args, array $kwargs ): array {
		$db      = (string) get_option( 'wppe_bridge_odoo_db', '' );
		$api_key = (string) get_option( 'wppe_bridge_odoo_api_key', '' );

		// Odoo espera un dict (objeto JSON `{}`) cuando no hay kwargs.
		// Un array vacio PHP se serializa como `[]` que rompe la firma
		// — convertir a stdClass para forzar `{}`.
		$kwargs_payload = empty( $kwargs ) ? new \stdClass() : $kwargs;

		return self::request(
			array(
				'service' => self::SERVICE_OBJECT,
				'method'  => self::METHOD_EXECUTE_KW,
				'args'    => array( $db, $uid, $api_key, $model, $method, $args, $kwargs_payload ),
			)
		);
	}

	/**
	 * Devuelve el uid cacheado o autentica si no hay cache.
	 *
	 * @return int UID > 0 si autenticacion exitosa, 0 si fallo.
	 */
	private static function get_or_authenticate_uid(): int {
		$cached = (int) get_option( 'wppe_bridge_odoo_uid_cache', 0 );
		if ( $cached > 0 ) {
			return $cached;
		}
		return self::authenticate_fresh();
	}

	/**
	 * Autentica explicitamente (forzando round-trip) y retorna el uid
	 * o 0 si fallo.
	 *
	 * @return int
	 */
	private static function authenticate_fresh(): int {
		$response = self::authenticate();
		if (
			self::ERROR_CLASS_SUCCESS === $response['error_class']
			&& is_int( $response['result'] )
			&& $response['result'] > 0
		) {
			return (int) $response['result'];
		}
		return 0;
	}

	/**
	 * Cachea el uid en wp_options.
	 *
	 * @param int $uid UID retornado por authenticate.
	 * @return void
	 */
	private static function set_cached_uid( int $uid ): void {
		if ( function_exists( 'update_option' ) ) {
			update_option( 'wppe_bridge_odoo_uid_cache', $uid );
		}
	}

	/**
	 * Determina si una respuesta indica que el uid cacheado es
	 * invalido (necesita re-auth). Substring match contra
	 * REAUTH_ERROR_NAMES.
	 *
	 * @param array<string,mixed> $response Response uniforme.
	 * @return bool
	 */
	private static function needs_reauth( array $response ): bool {
		$error_name = isset( $response['error_name'] ) ? (string) $response['error_name'] : '';
		if ( '' === $error_name ) {
			return false;
		}
		foreach ( self::REAUTH_ERROR_NAMES as $needle ) {
			if ( false !== strpos( $error_name, $needle ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Construye una response sintetica para el caso "auth fallo, no
	 * pudimos siquiera obtener un uid". Permanent — el operador tiene
	 * que arreglar credenciales.
	 *
	 * @return array{status:int,body:array,raw:string,error_class:string,result:mixed,error_name:string}
	 */
	private static function build_auth_failed_response(): array {
		return array(
			'status'      => 0,
			'body'        => array(),
			'raw'         => '',
			'error_class' => self::ERROR_CLASS_PERMANENT,
			'result'      => null,
			'error_name'  => 'WPPE_OdooAuthFailed',
		);
	}

	/**
	 * Normaliza la respuesta de `wp_remote_request` a la forma uniforme.
	 *
	 * Reglas (D-Odoo investigacion):
	 *  - WP_Error: transient con status 0.
	 *  - HTTP 4xx (no 429): permanent infraestructural (raro en JSON-RPC
	 *    Odoo, suele responder 200 con error en body).
	 *  - HTTP 429 / 5xx: transient.
	 *  - HTTP 2xx con `error` en body: clasificar por `error.data.name`.
	 *  - HTTP 2xx con `result`: success.
	 *
	 * @param mixed $response Lo que devolvio wp_remote_request.
	 * @return array{status:int,body:array,raw:string,error_class:string,result:mixed,error_name:string}
	 */
	private static function parse_response( $response ): array {
		if ( is_wp_error( $response ) ) {
			return array(
				'status'      => 0,
				'body'        => array(),
				'raw'         => '',
				'error_class' => self::ERROR_CLASS_TRANSIENT,
				'result'      => null,
				'error_name'  => '',
			);
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$raw    = (string) wp_remote_retrieve_body( $response );
		$body   = array();

		if ( '' !== $raw ) {
			$decoded = json_decode( $raw, true );
			if ( is_array( $decoded ) ) {
				$body = $decoded;
			}
		}

		// Caso HTTP no-2xx: clasificacion por status (5xx infra). Odoo
		// JSON-RPC normalmente devuelve 200 + error en body, asi que
		// llegar aca implica un balanceador, proxy, o el servidor caido.
		if ( $status < 200 || $status >= 300 ) {
			return array(
				'status'      => $status,
				'body'        => $body,
				'raw'         => $raw,
				'error_class' => self::error_class_for_http_status( $status ),
				'result'      => null,
				'error_name'  => '',
			);
		}

		// HTTP 2xx con `error` en body: clasificar por error.data.name.
		if ( isset( $body['error'] ) && is_array( $body['error'] ) ) {
			$error_name  = self::extract_error_name( $body['error'] );
			$error_class = self::error_class_for_jsonrpc_error( $error_name );

			return array(
				'status'      => $status,
				'body'        => $body,
				'raw'         => $raw,
				'error_class' => $error_class,
				'result'      => null,
				'error_name'  => $error_name,
			);
		}

		// HTTP 2xx con `result`: success. `result` puede ser cualquier
		// valor (int para uid/lead_id, list para search, dict para read,
		// false para auth fallida — caller decide como interpretarlo).
		$result = array_key_exists( 'result', $body ) ? $body['result'] : null;

		return array(
			'status'      => $status,
			'body'        => $body,
			'raw'         => $raw,
			'error_class' => self::ERROR_CLASS_SUCCESS,
			'result'      => $result,
			'error_name'  => '',
		);
	}

	/**
	 * Extrae el nombre de la excepcion del body de error JSON-RPC
	 * Odoo. Path tipico: `error.data.name` (ej.
	 * `odoo.exceptions.ValidationError`). Fallback a `error.message`
	 * si `data.name` no esta.
	 *
	 * @param array<string,mixed> $error Subarray `error` del body.
	 * @return string
	 */
	private static function extract_error_name( array $error ): string {
		if ( isset( $error['data'] ) && is_array( $error['data'] ) ) {
			if ( isset( $error['data']['name'] ) && is_string( $error['data']['name'] ) ) {
				return $error['data']['name'];
			}
		}
		if ( isset( $error['message'] ) && is_string( $error['message'] ) ) {
			return $error['message'];
		}
		return '';
	}

	/**
	 * Clasifica un status HTTP non-2xx en transient/permanent.
	 * Politica D5 CLAUDE.md: 429+5xx transient, resto 4xx permanent.
	 *
	 * @param int $status HTTP status code.
	 * @return string
	 */
	private static function error_class_for_http_status( int $status ): string {
		if ( 429 === $status || ( $status >= 500 && $status < 600 ) ) {
			return self::ERROR_CLASS_TRANSIENT;
		}
		if ( $status >= 400 && $status < 500 ) {
			return self::ERROR_CLASS_PERMANENT;
		}
		// status=0 (no llego a tener status) ya quedo cubierto antes en
		// is_wp_error. Si llegamos aca con un status raro (1xx, 3xx),
		// lo tratamos como transient para tener oportunidad de reintento.
		return self::ERROR_CLASS_TRANSIENT;
	}

	/**
	 * Clasifica un `error.data.name` Odoo (substring match contra las
	 * listas PERMANENT_ERROR_NAMES y TRANSIENT_ERROR_NAMES). Orden de
	 * evaluacion: transient primero (porque algunas clases python
	 * incluyen "Error" como sustring y caerian en permanent por mistake).
	 *
	 * Default cuando el name no matchea ninguna lista: permanent. Es
	 * la opcion segura — preferimos no reintentar errores desconocidos
	 * que floodear el CRM con leads que nunca van a entrar.
	 *
	 * @param string $error_name Valor de error.data.name (ej.
	 *                           'odoo.exceptions.ValidationError').
	 * @return string
	 */
	private static function error_class_for_jsonrpc_error( string $error_name ): string {
		if ( '' === $error_name ) {
			return self::ERROR_CLASS_PERMANENT;
		}

		foreach ( self::TRANSIENT_ERROR_NAMES as $needle ) {
			if ( false !== strpos( $error_name, $needle ) ) {
				return self::ERROR_CLASS_TRANSIENT;
			}
		}

		foreach ( self::PERMANENT_ERROR_NAMES as $needle ) {
			if ( false !== strpos( $error_name, $needle ) ) {
				return self::ERROR_CLASS_PERMANENT;
			}
		}

		// Default conservador — ver docblock.
		return self::ERROR_CLASS_PERMANENT;
	}

	/**
	 * Construye la URL base. Lee la option `wppe_bridge_odoo_base_url`
	 * y aplica el filter `wppe_bridge_odoo_base_url` para tests/mocks.
	 *
	 * Aceptar ambos: con y sin trailing slash. Strip del trailing slash
	 * antes de concatenar el path para evitar `//jsonrpc`.
	 *
	 * @return string
	 */
	private static function base_url(): string {
		$url = (string) get_option( 'wppe_bridge_odoo_base_url', '' );
		if ( function_exists( 'apply_filters' ) ) {
			$url = (string) apply_filters( 'wppe_bridge_odoo_base_url', $url );
		}
		return rtrim( $url, '/' );
	}

	/**
	 * Genera un id JSON-RPC unico por request (counter en memoria).
	 * No tenemos que matchear request<->response (es sincrono), pero
	 * Odoo lo retorna en el body y queda util para debug.
	 *
	 * @return int
	 */
	private static function next_request_id(): int {
		static $counter = 0;
		++$counter;
		return $counter;
	}
}
