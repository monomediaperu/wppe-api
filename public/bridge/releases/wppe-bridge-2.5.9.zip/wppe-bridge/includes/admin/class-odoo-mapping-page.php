<?php
/**
 * Pagina admin de mapeo de campos Odoo.
 *
 * UI para configurar:
 *
 * 1. Por cada form Fluent/Gravity/Elementor: mapeo de campos del form
 *    a fields `crm.lead` Odoo (`name`, `contact_name`, `email_from`,
 *    `phone`, etc.). Persiste en `wppe_bridge_odoo_field_mapping`.
 *
 * 2. Configuracion global (no por-form):
 *    - Default sales team (`team_id`).
 *    - Default salesperson (`user_id`) — opcional.
 *    - Default tags (`tag_ids`).
 *
 *    Persiste en wp_options:
 *    - wppe_bridge_odoo_default_team_id
 *    - wppe_bridge_odoo_default_user_id
 *    - wppe_bridge_odoo_default_tags
 *
 * **Scope PR-2:** Esta sub-pagina persiste todas las opciones pero el
 * Worker / Destination todavia NO las inyecta al payload — eso llega
 * en PR-3 (junto con el matching name-based de UTMs hacia
 * `utm.source/medium/campaign` y la inyeccion de `country_id`).
 * Aviso visible en la UI: "configuracion lista para v2.5.0 (PR-3)".
 *
 * Asimetrica con GHL (Camino A, sec 12 CLAUDE.md): Odoo tiene su
 * propia sub-pagina porque sus catalogos (teams/users/utm.* nativos/
 * countries) son estructuralmente distintos a los de GHL (pipelines/
 * customFields/tags) y a los de Sperant (input_channels/sources/
 * interest_types/projects).
 *
 * UTMs: NO se mapean explicitamente — Odoo tiene `utm.source/medium/
 * campaign` nativos y el matching se hace por nombre case-insensitive
 * en el momento del envio (PR-3). Si el visitante trae
 * `utm_source=google` y existe un record `utm.source` llamado "Google",
 * el destination le inyecta el `source_id` correspondiente. Si no
 * matchea ningun record, lo deja en blanco (no auto-creamos para
 * evitar polucionar el catalogo del cliente).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pagina admin de mapeo de campos del form a campos `crm.lead` Odoo.
 */
final class WPPE_Bridge_Odoo_Mapping_Page {

	/**
	 * Slug de la sub-pagina admin.
	 */
	public const PAGE_SLUG = 'wppe-bridge-odoo-mapping';

	/**
	 * Action del POST handler para mapeo de campos por-form.
	 */
	public const ACTION_SAVE_FORM_MAPPING = 'wppe_bridge_save_odoo_form_mapping';

	/**
	 * Action del POST handler para configuracion global.
	 */
	public const ACTION_SAVE_GLOBAL_CONFIG = 'wppe_bridge_save_odoo_global_config';

	/**
	 * Nonce action para mapeo por-form.
	 */
	public const NONCE_FORM_MAPPING = 'wppe_bridge_save_odoo_form_mapping';

	/**
	 * Nonce action para config global.
	 */
	public const NONCE_GLOBAL_CONFIG = 'wppe_bridge_save_odoo_global_config';

	/**
	 * Lista de keys de `crm.lead` Odoo que el admin puede mapear desde
	 * campos del form. Subset de los campos top-level del modelo que
	 * tienen sentido configurar desde un formulario web inmobiliario.
	 *
	 * `name` se incluye porque el admin a veces quiere que el form
	 * controle el titulo del lead (ej. "Cotizacion {proyecto}"). Si no
	 * se mapea, el Destination lo deriva (ver `resolve_lead_name` en
	 * Destination::map_payload_to_lead_values).
	 *
	 * @var array<int,string>
	 */
	public const PAYLOAD_KEYS = array(
		'name',
		'contact_name',
		'partner_name',
		'email_from',
		'phone',
		'mobile',
		'function',
		'street',
		'city',
		'zip',
		'description',
		'website',
		// `country`: lookup key del bridge, NO un campo literal de
		// `crm.lead`. El admin mapea un form field "Pais" -> `country`,
		// el destination busca el value contra `res.country` (ISO code o
		// name case-insensitive con accent strip) e inyecta `country_id`
		// FK. La key `country` se strippea antes del POST a Odoo —
		// Odoo rechazaria `country` como ValidationError si llegara.
		// PR-3 / v2.5.0.
		'country',
	);

	/**
	 * Subset de PAYLOAD_KEYS que aporta "identidad" al lead — al menos
	 * uno tiene que estar mapeado para que el lead sea utilizable por
	 * vendedores. Sin esto, el destination crea el lead pero solo con
	 * `name = "Web lead - {timestamp}"` (utilizable pero sin gancho
	 * para que el vendedor sepa a quien llamar).
	 *
	 * @var array<int,string>
	 */
	public const IDENTITY_KEYS = array(
		'contact_name',
		'email_from',
		'phone',
		'name',
	);

	/**
	 * Valores aceptados para el toggle per-form `type` (D-Odoo-8).
	 * `inherit` reusa el default global de Configuracion Odoo.
	 *
	 * @var array<int,string>
	 */
	public const FORM_TYPE_CHOICES = array( 'inherit', 'opportunity', 'lead' );

	/**
	 * Registra los handlers admin_post_*.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_post_' . self::ACTION_SAVE_FORM_MAPPING, array( self::class, 'handle_save_form_mapping' ) );
		add_action( 'admin_post_' . self::ACTION_SAVE_GLOBAL_CONFIG, array( self::class, 'handle_save_global_config' ) );
	}

	/**
	 * Renderiza la pagina.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$discovery_result  = WPPE_Bridge_Form_Discovery::discover_all_with_reasons();
		$discovered        = $discovery_result['forms'];
		$discovery_reasons = $discovery_result['reasons'];

		$catalogs        = get_option( 'wppe_bridge_odoo_catalogs', array() );
		$catalogs        = is_array( $catalogs ) ? $catalogs : array();
		$catalogs_errors = isset( $catalogs['_errors'] ) && is_array( $catalogs['_errors'] ) ? $catalogs['_errors'] : array();
		$synced_at       = isset( $catalogs['_synced_at'] ) ? (int) $catalogs['_synced_at'] : 0;

		$mapping = get_option( 'wppe_bridge_odoo_field_mapping', array() );
		$mapping = is_array( $mapping ) ? $mapping : array();

		// Config global.
		$default_team_id = (string) get_option( 'wppe_bridge_odoo_default_team_id', '' );
		$default_user_id = (string) get_option( 'wppe_bridge_odoo_default_user_id', '' );
		$default_tags    = get_option( 'wppe_bridge_odoo_default_tags', array() );
		$default_tags    = is_array( $default_tags ) ? $default_tags : array();

		$selected_plugin = isset( $_GET['plugin'] ) ? sanitize_key( wp_unslash( $_GET['plugin'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$selected_form   = isset( $_GET['form'] ) ? sanitize_text_field( wp_unslash( $_GET['form'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$selected_form_data = null;
		if ( '' !== $selected_form && '' !== $selected_plugin && isset( $discovered[ $selected_plugin ] ) ) {
			foreach ( $discovered[ $selected_plugin ] as $form ) {
				if ( (string) $form['id'] === $selected_form ) {
					$selected_form_data = $form;
					break;
				}
			}
		}

		$existing_mapping = array(
			'fields' => array(),
			'tags'   => array(),
			'type'   => 'inherit',
		);
		if ( '' !== $selected_plugin && '' !== $selected_form && isset( $mapping[ $selected_plugin ][ $selected_form ] ) ) {
			$existing_mapping = array_merge( $existing_mapping, (array) $mapping[ $selected_plugin ][ $selected_form ] );
		}

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/odoo-mapping.php';
	}

	/**
	 * Handler del POST que guarda el mapeo de un form especifico.
	 *
	 * @return void
	 */
	public static function handle_save_form_mapping(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_FORM_MAPPING );

		$post   = wp_unslash( $_POST );
		$plugin = isset( $post['plugin'] ) ? sanitize_key( $post['plugin'] ) : '';
		$form   = isset( $post['form'] ) ? sanitize_text_field( $post['form'] ) : '';

		if ( '' === $plugin || '' === $form ) {
			wp_safe_redirect( self::redirect_url( $plugin, $form, 'error_missing_form' ) );
			exit;
		}

		$entry = self::build_form_entry_from_post( is_array( $post ) ? $post : array() );

		// Validacion: el form debe mapear al menos un IDENTITY_KEY para
		// que el lead sea utilizable. Sin esto, el destination crea un
		// lead solo con `name = "Web lead - {timestamp}"`, que entra al
		// CRM pero ningun vendedor puede actuar sobre el.
		$missing = self::validate_required_fields( $entry );
		if ( ! empty( $missing ) ) {
			wp_safe_redirect( self::redirect_url( $plugin, $form, 'error_required', $missing ) );
			exit;
		}

		$current = get_option( 'wppe_bridge_odoo_field_mapping', array() );
		if ( ! is_array( $current ) ) {
			$current = array();
		}
		if ( ! isset( $current[ $plugin ] ) || ! is_array( $current[ $plugin ] ) ) {
			$current[ $plugin ] = array();
		}
		$current[ $plugin ][ $form ] = $entry;

		update_option( 'wppe_bridge_odoo_field_mapping', $current );

		wp_safe_redirect( self::redirect_url( $plugin, $form, 'saved' ) );
		exit;
	}

	/**
	 * Handler del POST que guarda la config global (team/user/tags default).
	 *
	 * @return void
	 */
	public static function handle_save_global_config(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_GLOBAL_CONFIG );

		$post = wp_unslash( $_POST );

		$team_id = isset( $post['default_team_id'] ) ? sanitize_text_field( $post['default_team_id'] ) : '';
		$user_id = isset( $post['default_user_id'] ) ? sanitize_text_field( $post['default_user_id'] ) : '';

		update_option(
			'wppe_bridge_odoo_default_team_id',
			self::sanitize_id_against_catalog( $team_id, 'teams' )
		);
		update_option(
			'wppe_bridge_odoo_default_user_id',
			self::sanitize_id_against_catalog( $user_id, 'users' )
		);

		// Tags default. Acepta CSV o array de inputs repetidos.
		$raw_tags = $post['default_tags'] ?? '';
		if ( is_string( $raw_tags ) ) {
			$raw_tags = array_map( 'trim', explode( ',', $raw_tags ) );
		}
		$tags = array();
		foreach ( (array) $raw_tags as $tag ) {
			$tag = sanitize_text_field( (string) $tag );
			if ( '' !== $tag ) {
				$tags[] = $tag;
			}
		}
		// Deduplicar preservando orden.
		$tags = array_values( array_unique( $tags ) );
		update_option( 'wppe_bridge_odoo_default_tags', $tags );

		wp_safe_redirect( self::redirect_url( '', '', 'global_saved' ) );
		exit;
	}

	/**
	 * Valida que el `id` exista en el catalogo. Retorna el id como
	 * string si valido, vacio si no encontrado o vacio. Coerce a string
	 * para comparacion (los ids Odoo son integers, pero los persistimos
	 * como string para uniformidad con GHL/Sperant).
	 *
	 * @param string $value Id propuesto.
	 * @param string $key   Key del catalogo (`teams`, `users`, `tags`,
	 *                       `utm_sources`, etc).
	 * @return string
	 */
	public static function sanitize_id_against_catalog( string $value, string $key ): string {
		$value = trim( $value );
		if ( '' === $value ) {
			return '';
		}
		$catalogs = get_option( 'wppe_bridge_odoo_catalogs', array() );
		$items    = isset( $catalogs[ $key ] ) && is_array( $catalogs[ $key ] ) ? $catalogs[ $key ] : array();
		foreach ( $items as $item ) {
			if ( is_array( $item ) && isset( $item['id'] ) && (string) $item['id'] === $value ) {
				return $value;
			}
		}
		return '';
	}

	/**
	 * Valida que el form mapping tenga al menos un IDENTITY_KEY mapeado.
	 *
	 * @param array{fields:array<string,string>} $entry Entry construido.
	 * @return array<int,string> Lista de keys de identidad faltantes
	 *                            (vacio si OK).
	 */
	public static function validate_required_fields( array $entry ): array {
		$fields = isset( $entry['fields'] ) && is_array( $entry['fields'] ) ? $entry['fields'] : array();
		foreach ( $fields as $payload_key ) {
			if ( in_array( $payload_key, self::IDENTITY_KEYS, true ) ) {
				return array();
			}
		}
		// No se encontro ningun identity key — devolver la lista
		// completa como "los que faltan" (al menos uno de estos).
		return self::IDENTITY_KEYS;
	}

	/**
	 * Construye la entrada `{fields, tags, type}` del POST.
	 *
	 * - `fields`: mapeo `form_field => payload_key` (descartando keys
	 *   no listadas en PAYLOAD_KEYS).
	 * - `tags`: lista de strings con tags adicionales para este form
	 *   (override por-form que se concatena a los default globales en
	 *   Destination::send. PR-3).
	 * - `type`: `inherit`/`opportunity`/`lead` (override per-form del
	 *   default global, D-Odoo-8). Si invalido, default `inherit`.
	 *
	 * @param array $post POST sanitizado.
	 * @return array{fields:array<string,string>,tags:array<int,string>,type:string}
	 */
	public static function build_form_entry_from_post( array $post ): array {
		$fields    = array();
		$field_map = isset( $post['field_map'] ) && is_array( $post['field_map'] ) ? $post['field_map'] : array();

		foreach ( $field_map as $form_field => $payload_key ) {
			$form_field  = sanitize_text_field( (string) $form_field );
			$payload_key = is_string( $payload_key ) ? trim( $payload_key ) : '';
			if ( '' === $form_field || '' === $payload_key ) {
				continue;
			}
			if ( ! in_array( $payload_key, self::PAYLOAD_KEYS, true ) ) {
				continue;
			}
			$fields[ $form_field ] = $payload_key;
		}

		// Tags override por-form.
		$raw_tags = $post['form_tags'] ?? '';
		if ( is_string( $raw_tags ) ) {
			$raw_tags = array_map( 'trim', explode( ',', $raw_tags ) );
		}
		$tags = array();
		foreach ( (array) $raw_tags as $tag ) {
			$tag = sanitize_text_field( (string) $tag );
			if ( '' !== $tag ) {
				$tags[] = $tag;
			}
		}
		$tags = array_values( array_unique( $tags ) );

		// Type override per-form.
		$type = isset( $post['form_type'] ) ? sanitize_text_field( (string) $post['form_type'] ) : 'inherit';
		if ( ! in_array( $type, self::FORM_TYPE_CHOICES, true ) ) {
			$type = 'inherit';
		}

		return array(
			'fields' => $fields,
			'tags'   => $tags,
			'type'   => $type,
		);
	}

	/**
	 * Construye URL de redirect post-save con flash messages.
	 *
	 * @param string            $plugin  Plugin slug (vacio si volvemos
	 *                                    a la vista global).
	 * @param string            $form    Form ID (vacio si volvemos a la
	 *                                    vista global).
	 * @param string            $flash   Codigo de mensaje.
	 * @param array<int,string> $missing Identity keys faltantes para
	 *                                    flash error_required.
	 * @return string
	 */
	private static function redirect_url( string $plugin, string $form, string $flash, array $missing = array() ): string {
		$args = array(
			'page'  => self::PAGE_SLUG,
			'flash' => $flash,
		);
		if ( '' !== $plugin ) {
			$args['plugin'] = $plugin;
		}
		if ( '' !== $form ) {
			$args['form'] = $form;
		}
		if ( ! empty( $missing ) ) {
			$args['missing'] = implode( ',', array_map( 'sanitize_key', $missing ) );
		}
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}
}
