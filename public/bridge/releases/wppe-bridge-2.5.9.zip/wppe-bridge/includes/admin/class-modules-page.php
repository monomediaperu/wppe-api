<?php
/**
 * Pagina admin de modulos opcionales (D4.4).
 *
 * Toggle on/off de cada modulo (UTM Capture, Submit Lock, Meta CAPI,
 * Thank You Pixel). Cada modulo extiende su propia configuracion
 * cuando se necesita (ej. Meta CAPI necesita Pixel ID + Access Token).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pagina admin de modulos opcionales.
 */
final class WPPE_Bridge_Modules_Page {

	/**
	 * Nonce action.
	 */
	public const NONCE_ACTION = 'wppe_bridge_modules_save';

	/**
	 * Action para el POST handler.
	 */
	public const ACTION_SAVE = 'wppe_bridge_save_modules';

	/**
	 * Modulos disponibles. Cada entrada:
	 *   key                 string  Slug interno.
	 *   option              string  wp_options key del enabled flag.
	 *   label               string  Label legible.
	 *   description         string  Texto descriptivo.
	 *
	 * Cuando llegue un modulo nuevo (Submit Lock, Meta CAPI, Thank
	 * You Pixel), se agrega aqui una entrada y la pagina lo refleja
	 * automaticamente.
	 *
	 * @return array<int,array{key:string,option:string,label:string,description:string}>
	 */
	public static function modules(): array {
		return array(
			array(
				'key'         => WPPE_Bridge_Module_Utm_Capture::SLUG,
				'option'      => WPPE_Bridge_Module_Utm_Capture::OPTION_ENABLED,
				'label'       => __( 'UTM Capture', 'wppe-bridge' ),
				'description' => __( 'Captura UTMs / GCLID / fbclid del visitante en cookie + localStorage por 90 dias para que lleguen a Sperant aunque el form se envie en otra pagina.', 'wppe-bridge' ),
				'config_page' => null,
			),
			array(
				'key'         => WPPE_Bridge_Module_Submit_Lock::SLUG,
				'option'      => WPPE_Bridge_Module_Submit_Lock::OPTION_ENABLED,
				'label'       => __( 'Submit Lock', 'wppe-bridge' ),
				'description' => __( 'Deshabilita el boton submit al primer click para prevenir el envio doble (causa principal de leads duplicados). Cubre Fluent Forms, Gravity Forms y Elementor.', 'wppe-bridge' ),
				'config_page' => null,
			),
			array(
				'key'         => WPPE_Bridge_Module_Meta_Capi::SLUG,
				'option'      => WPPE_Bridge_Module_Meta_Capi::OPTION_ENABLED,
				'label'       => __( 'Meta CAPI', 'wppe-bridge' ),
				'description' => __( 'Envia un evento Lead server-side a Meta Conversions API cuando el lead se envia exitosamente a Sperant. Hashea email/telefono/nombre con SHA-256.', 'wppe-bridge' ),
				'config_page' => WPPE_Bridge_Meta_Capi_Settings_Page::PAGE_SLUG,
			),
			array(
				'key'         => WPPE_Bridge_Module_Thank_You_Pixel::SLUG,
				'option'      => WPPE_Bridge_Module_Thank_You_Pixel::OPTION_ENABLED,
				'label'       => __( 'Thank You Pixel', 'wppe-bridge' ),
				'description' => __( 'Inyecta el browser pixel de Meta en las paginas de gracias seleccionadas, sincronizado con Meta CAPI server-side via event_id para que Meta deduplique los dos eventos.', 'wppe-bridge' ),
				'config_page' => WPPE_Bridge_Thank_You_Pixel_Settings_Page::PAGE_SLUG,
			),
		);
	}

	/**
	 * Registra el handler del POST.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_post_' . self::ACTION_SAVE, array( self::class, 'handle_save' ) );
	}

	/**
	 * Renderiza la pagina.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$modules = self::modules();
		$flash   = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';  // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/modules.php';
	}

	/**
	 * Handler del POST: actualiza cada flag de modulo.
	 *
	 * @return void
	 */
	public static function handle_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_ACTION );

		$post    = wp_unslash( $_POST );
		$enabled = isset( $post['enabled'] ) && is_array( $post['enabled'] ) ? $post['enabled'] : array();

		foreach ( self::modules() as $module ) {
			$is_on = isset( $enabled[ $module['key'] ] ) && '1' === (string) $enabled[ $module['key'] ];
			update_option( $module['option'], $is_on );
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'  => WPPE_Bridge_Admin_Menu::SLUG . '-modules',
					'flash' => 'saved',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
}
