<?php
/**
 * Admin notice global para leads en `failed_permanent` (v2.4.0).
 *
 * Cuando hay leads que fallaron permanentemente y no fueron atendidos
 * (no se reintentaron, no se eliminaron, no se pausaron), muestra un
 * notice rojo persistente al top de wp-admin con el conteo y un CTA
 * a la pagina de Logs filtrada por `failed_permanent`.
 *
 * **D-Alert-1: Persistente** mientras haya leads en `failed_permanent`.
 * Cuando todos esten resueltos (eliminados, reintentados con exito,
 * pausados explicitamente), el notice desaparece solo. No tiene boton
 * de dismiss porque seria perfecto para ignorar problemas reales.
 *
 * **D-Alert-2: Solo en pantallas de wp-admin del plugin + Dashboard**
 * para no spamear todas las paginas. El admin lo ve cuando entra al
 * Dashboard a hacer cualquier cosa (alta visibilidad sin invasion).
 *
 * **"Global"** (D-Notif-4 reinterpretada): el notice lo ve cualquier
 * usuario con capability `manage_options`. No es per-user — es
 * site-wide del estado del plugin. Si tu equipo tiene 3 admins, los 3
 * lo ven hasta que alguien lo resuelva.
 *
 * **Cache**: el count se cachea en transient `wppe_bridge_failed_count`
 * con TTL 5 min. La query es simple (`COUNT(*)`) pero corre en cada
 * page load — el cache evita N queries por sesion del admin. Cuando
 * el admin reintenta/elimina/pausa, el handler invalida el transient
 * para que el conteo se actualice en el siguiente page load.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin notice global persistente para errores no atendidos.
 */
final class WPPE_Bridge_Admin_Notice {

	/**
	 * Transient que cachea el count de failed_permanent.
	 */
	public const CACHE_KEY = 'wppe_bridge_failed_count';

	/**
	 * TTL del cache (5 min).
	 */
	public const CACHE_TTL_SECONDS = 5 * MINUTE_IN_SECONDS;

	/**
	 * Bootstrap. Llamado desde Plugin::register_hooks (solo en is_admin).
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_notices', array( self::class, 'render' ) );

		// Invalidar el cache cuando hay cambios relevantes.
		add_action( 'wppe_bridge_lead_failed', array( self::class, 'invalidate_cache' ) );
		add_action( 'wppe_bridge_lead_sent', array( self::class, 'invalidate_cache' ) );
	}

	/**
	 * Renderiza el notice si corresponde.
	 *
	 * Skipea si:
	 *  - El user no tiene `manage_options`.
	 *  - No estamos en una pantalla relevante (plugin o dashboard).
	 *  - No hay leads en failed_permanent.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! self::is_relevant_screen() ) {
			return;
		}

		$count = self::failed_permanent_count();
		if ( $count <= 0 ) {
			return;
		}

		$logs_url = function_exists( 'admin_url' )
			? admin_url( 'admin.php?page=wppe-bridge-logs&status=failed_permanent' )
			: '#';

		?>
		<div class="notice notice-error is-dismissible" id="wppe-bridge-failed-notice">
			<p>
				<strong>WP.pe Bridge:</strong>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: count of failed leads */
						_n(
							'%d lead fallo al enviar al CRM y no fue atendido.',
							'%d leads fallaron al enviar al CRM y no fueron atendidos.',
							$count,
							'wppe-bridge'
						),
						$count
					)
				);
				?>
				<a href="<?php echo esc_url( $logs_url ); ?>" class="button button-small" style="margin-left:1em">
					<?php esc_html_e( 'Ver y resolver →', 'wppe-bridge' ); ?>
				</a>
			</p>
		</div>
		<?php
	}

	/**
	 * Cuenta items en `failed_permanent` con cache transient (5 min).
	 *
	 * @return int
	 */
	public static function failed_permanent_count(): int {
		$cached = get_transient( self::CACHE_KEY );
		if ( false !== $cached ) {
			return (int) $cached;
		}

		$count = class_exists( 'WPPE_Bridge_Queue' )
			? WPPE_Bridge_Queue::count_by_status( WPPE_Bridge_Queue::STATUS_FAILED_PERMANENT )
			: 0;

		set_transient( self::CACHE_KEY, (int) $count, self::CACHE_TTL_SECONDS );
		return (int) $count;
	}

	/**
	 * Invalida el cache. Llamado cuando hay cambios relevantes
	 * (lead failed, lead sent — para que el siguiente page load
	 * tenga el numero correcto).
	 *
	 * @return void
	 */
	public static function invalidate_cache(): void {
		delete_transient( self::CACHE_KEY );
	}

	/**
	 * Determina si la pantalla actual es relevante para mostrar el
	 * notice (D-Alert-2: solo plugin + Dashboard).
	 *
	 * @return bool
	 */
	public static function is_relevant_screen(): bool {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}
		$screen = get_current_screen();
		if ( null === $screen ) {
			return false;
		}

		// Dashboard principal.
		if ( 'dashboard' === $screen->id ) {
			return true;
		}

		// Cualquier pantalla del plugin (slug del menu top-level esta
		// en el screen id como `toplevel_page_wppe-bridge` o similar).
		if ( false !== strpos( (string) $screen->id, 'wppe-bridge' ) ) {
			return true;
		}

		return false;
	}
}
