<?php
/**
 * Sub-pagina admin oculta para configurar Thank You Pixel.
 *
 * Accesible via link "Configurar" desde la lista de Modulos. No
 * aparece en el menu principal — solo es alcanzable cuando el modulo
 * Thank You Pixel esta activado y el admin abre su configuracion.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sub-pagina de configuracion Thank You Pixel.
 */
final class WPPE_Bridge_Thank_You_Pixel_Settings_Page {

	/**
	 * Slug de la pagina (subpage de WP.pe Bridge).
	 */
	public const PAGE_SLUG = 'wppe-bridge-thank-you-pixel';

	/**
	 * Settings group de WP Settings API.
	 */
	public const OPTION_GROUP = 'wppe_bridge_thank_you_pixel_settings';

	/**
	 * Lista de option keys con sus sanitizers.
	 */
	public const OPTIONS = array(
		WPPE_Bridge_Module_Thank_You_Pixel::OPTION_PAGES => 'sanitize_pages',
	);

	/**
	 * Registra hooks: settings.
	 *
	 * @return void
	 */
	public static function register_settings(): void {
		foreach ( self::OPTIONS as $key => $cb ) {
			register_setting(
				self::OPTION_GROUP,
				$key,
				array( 'sanitize_callback' => array( self::class, $cb ) )
			);
		}
	}

	/**
	 * Renderiza la pagina.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$selected_pages = WPPE_Bridge_Module_Thank_You_Pixel::get_pages();
		$all_pages      = get_pages( array( 'sort_column' => 'post_title' ) );
		if ( ! is_array( $all_pages ) ) {
			$all_pages = array();
		}

		$pixel_id   = (string) get_option( WPPE_Bridge_Module_Meta_Capi::OPTION_PIXEL_ID, '' );
		$event_name = WPPE_Bridge_Module_Meta_Capi::get_event_name();

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/thank-you-pixel-settings.php';
	}

	// ---------- sanitizers ----------

	/**
	 * Sanitiza la lista de pages: solo IDs de pages existentes
	 * (post_type=page) sobreviven. Cualquier valor que no sea page
	 * valido se descarta silenciosamente.
	 *
	 * Nota: en entorno de tests `get_post_type` puede no estar
	 * disponible — caemos a validar solo `(int) > 0` en ese caso.
	 *
	 * @param mixed $value Valor crudo del POST.
	 * @return array<int,int>
	 */
	public static function sanitize_pages( $value ): array {
		if ( ! is_array( $value ) ) {
			return array();
		}
		$clean = array();
		foreach ( $value as $raw ) {
			$id = (int) $raw;
			if ( $id <= 0 ) {
				continue;
			}
			if ( function_exists( 'get_post_type' ) ) {
				$post_type = get_post_type( $id );
				if ( 'page' !== $post_type ) {
					continue;
				}
			}
			$clean[] = $id;
		}
		return array_values( array_unique( $clean ) );
	}
}
