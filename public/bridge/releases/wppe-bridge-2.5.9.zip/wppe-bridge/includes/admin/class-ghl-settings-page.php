<?php
/**
 * Pagina admin de configuracion GHL.
 *
 * Sub-pagina especifica del destino GoHighLevel. Persiste dos options:
 *   - wppe_bridge_ghl_token        : Private Integration Token (PIT)
 *   - wppe_bridge_ghl_location_id  : Location ID de la sub-account GHL
 *
 * Asimetrica respecto a la sub-pagina principal "Configuracion" de
 * Sperant (Camino A, sec 12 CLAUDE.md): el dropdown de destino activo,
 * dedup TTL, country code y delete-on-uninstall siguen en la sub-pagina
 * Sperant (`wppe-bridge-config`). Esta sub-pagina GHL es complementaria
 * y solo aparece en el menu cuando active_destination = 'ghl'.
 *
 * El campo password (PIT) en UI nunca muestra el valor existente
 * (solo "configurado / no configurado") para evitar shoulder-surfing,
 * mismo patron que el token Sperant.
 *
 * **Scope PR-1:** solo persistencia. Test-connection button llega
 * en PR-2 cuando el Ghl_Client tenga `list_pipelines()` para usar
 * como ping de validacion.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pagina admin de configuracion especifica de GHL.
 */
final class WPPE_Bridge_Ghl_Settings_Page {

	/**
	 * Slug de la sub-pagina admin.
	 */
	public const PAGE_SLUG = 'wppe-bridge-ghl-config';

	/**
	 * Slug del settings group de WP Settings API.
	 */
	public const OPTION_GROUP = 'wppe_bridge_ghl_settings';

	/**
	 * Slug de la seccion principal.
	 */
	public const SECTION_GENERAL = 'wppe_bridge_ghl_section_general';

	/**
	 * Lista de option keys que registramos para WP Settings API.
	 *
	 * @var array<string,string>
	 */
	public const OPTIONS = array(
		'wppe_bridge_ghl_token'              => 'sanitize_token',
		'wppe_bridge_ghl_location_id'        => 'sanitize_location_id',
		'wppe_bridge_ghl_create_opportunity' => 'sanitize_create_opportunity',
	);

	/**
	 * Bootstrap: registra hooks de Settings API. Llamado desde
	 * Plugin::register_hooks via admin_init.
	 *
	 * @return void
	 */
	public static function register_settings(): void {
		foreach ( self::OPTIONS as $option_key => $sanitize_cb ) {
			register_setting(
				self::OPTION_GROUP,
				$option_key,
				array(
					'sanitize_callback' => array( self::class, $sanitize_cb ),
				)
			);
		}
	}

	/**
	 * Renderiza la pagina de Settings GHL.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Datos para la vista.
		$has_token   = '' !== (string) get_option( 'wppe_bridge_ghl_token', '' );
		$location_id = (string) get_option( 'wppe_bridge_ghl_location_id', '' );
		// Default = ON (D-GHL-2). Si la option no existe o es vacia,
		// se considera ON.
		$create_opportunity = self::is_create_opportunity_enabled();

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/ghl-settings.php';
	}

	/**
	 * Lee la option `wppe_bridge_ghl_create_opportunity` con default ON
	 * (D-GHL-2). El default ON significa: si la option no esta seteada
	 * (cliente recien instala v2.1.0), asumir que quiere crear Opportunity.
	 *
	 * @return bool
	 */
	public static function is_create_opportunity_enabled(): bool {
		$value = get_option( 'wppe_bridge_ghl_create_opportunity', '1' );
		// Tratar absent / '1' / 1 / true / 'true' / 'on' como ON.
		// Solo '0' / 0 / false / 'false' / '' explicito como OFF.
		if ( '0' === (string) $value || 0 === $value || false === $value ) {
			return false;
		}
		return true;
	}

	// ---------- sanitizers ----------

	/**
	 * Sanitiza el PIT: trim. Si llega vacio, conserva el valor previo
	 * (mismo patron que el token Sperant: no permitimos borrarlo
	 * accidentalmente desde la UI; para borrar via WP-CLI:
	 * `wp option delete wppe_bridge_ghl_token`).
	 *
	 * Si es la primer configuracion (sin token previo) y llega vacio,
	 * registra un settings_error para que WordPress muestre un notice
	 * de "obligatorio".
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_token( $value ): string {
		$new = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $new ) {
			$previous = (string) get_option( 'wppe_bridge_ghl_token', '' );
			if ( '' === $previous && function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_ghl_token',
					'wppe_bridge_ghl_token_required',
					__( 'El Private Integration Token (PIT) de GoHighLevel es obligatorio. Sin token, los leads no se enviaran al CRM.', 'wppe-bridge' )
				);
			}
			return $previous;
		}
		return $new;
	}

	/**
	 * Sanitiza el Location ID: trim + caracteres alfanumericos.
	 *
	 * Los Location IDs de GHL son strings de ~24 caracteres
	 * alfanumericos (formato similar a Mongo ObjectId pero no
	 * estrictamente). Aceptamos `[a-zA-Z0-9]` con longitud razonable.
	 *
	 * Si invalido, conserva el valor previo (mismo patron que el token).
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_location_id( $value ): string {
		$new = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $new ) {
			return (string) get_option( 'wppe_bridge_ghl_location_id', '' );
		}
		// Solo alfanumerico, longitud razonable (8-64 chars).
		if ( ! preg_match( '/^[a-zA-Z0-9]{8,64}$/', $new ) ) {
			if ( function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_ghl_location_id',
					'wppe_bridge_ghl_location_id_invalid',
					__( 'El Location ID debe ser alfanumerico, entre 8 y 64 caracteres. Verificar en GHL: Settings &rarr; Business Profile o en la URL del panel.', 'wppe-bridge' )
				);
			}
			return (string) get_option( 'wppe_bridge_ghl_location_id', '' );
		}
		return $new;
	}

	/**
	 * Sanitiza el toggle "Crear Opportunity" (D-GHL-2: ON por default).
	 *
	 * Boolean estricto pero almacenado como string '1'/'0' para
	 * compatibilidad con autoload de WP options. El checkbox HTML
	 * llega como `'1'` o ausente (nada).
	 *
	 * Importante: este sanitizer corre solo cuando el form de Settings
	 * GHL se envia. Si el checkbox no se renderiza (porque la sub-pagina
	 * no se visito todavia), la option permanece sin setear y
	 * `is_create_opportunity_enabled()` retorna ON por su default.
	 *
	 * @param mixed $value Valor del input (checkbox).
	 * @return string '1' (ON) | '0' (OFF).
	 */
	public static function sanitize_create_opportunity( $value ): string {
		// Checkbox checked llega como '1', desactivado llega como ausente
		// (null) o vacio.
		if ( '1' === $value || 1 === $value || true === $value || 'true' === $value || 'on' === $value ) {
			return '1';
		}
		return '0';
	}
}
