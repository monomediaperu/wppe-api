<?php
/**
 * Pagina admin de configuracion HubSpot.
 *
 * Sub-pagina especifica del destino HubSpot. Persiste 3 options:
 *   - wppe_bridge_hubspot_access_token         : Private App access token
 *   - wppe_bridge_hubspot_default_lifecyclestage: enum del funnel
 *   - wppe_bridge_hubspot_default_owner_id     : id del owner default
 *
 * Solo aparece en el menu cuando active_destination = 'hubspot'.
 *
 * El campo password (access token) en UI nunca muestra el valor
 * existente (solo "configurado / no configurado") para evitar
 * shoulder-surfing — mismo patron que GHL/Sperant/Odoo.
 *
 * **Scope PR-1:** solo persistencia. Validacion del owner_id contra
 * el catalogo de owners llega en PR-2 (cuando `Hubspot_Client` tenga
 * `list_owners()`).
 *
 * Naming sec 4.3 CLAUDE.md: clase `WPPE_Bridge_Hubspot_Settings_Page`
 * (con prefijo `Bridge` para classes de admin generico — distinto de
 * `WPPE_Hubspot_Destination` que es CRM-specific).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pagina admin de configuracion especifica de HubSpot.
 */
final class WPPE_Bridge_Hubspot_Settings_Page {

	/**
	 * Slug de la sub-pagina admin.
	 */
	public const PAGE_SLUG = 'wppe-bridge-hubspot-config';

	/**
	 * Slug del settings group de WP Settings API.
	 */
	public const OPTION_GROUP = 'wppe_bridge_hubspot_settings';

	/**
	 * Slug de la seccion principal.
	 */
	public const SECTION_GENERAL = 'wppe_bridge_hubspot_section_general';

	/**
	 * Lista de option keys que registramos para WP Settings API.
	 *
	 * @var array<string,string>
	 */
	public const OPTIONS = array(
		'wppe_bridge_hubspot_access_token'           => 'sanitize_access_token',
		'wppe_bridge_hubspot_default_lifecyclestage' => 'sanitize_lifecyclestage',
		'wppe_bridge_hubspot_default_owner_id'       => 'sanitize_owner_id',
	);

	/**
	 * Bootstrap: registra hooks de Settings API. Llamado desde
	 * Plugin::register_hooks via admin_init.
	 *
	 * @return void
	 */
	public static function register_settings(): void {
		foreach ( self::OPTIONS as $option_key => $sanitize_cb ) {
			register_setting(
				self::OPTION_GROUP,
				$option_key,
				array(
					'sanitize_callback' => array( self::class, $sanitize_cb ),
				)
			);
		}
	}

	/**
	 * Renderiza la pagina de Settings HubSpot.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Datos para la vista.
		$has_token      = '' !== (string) get_option( 'wppe_bridge_hubspot_access_token', '' );
		$lifecyclestage = (string) get_option( 'wppe_bridge_hubspot_default_lifecyclestage', '' );
		$owner_id       = (string) get_option( 'wppe_bridge_hubspot_default_owner_id', '' );
		$lifecycle_opts = WPPE_Hubspot_Destination::ALLOWED_LIFECYCLESTAGES;

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/hubspot-settings.php';
	}

	// ---------- sanitizers ----------

	/**
	 * Sanitiza el Private App access token: trim. Si llega vacio,
	 * conserva el valor previo (mismo patron que el token Sperant/GHL/
	 * Odoo: no permitimos borrarlo accidentalmente desde la UI; para
	 * borrar: `wp option delete wppe_bridge_hubspot_access_token`).
	 *
	 * Si es la primer configuracion (sin token previo) y llega vacio,
	 * registra un settings_error.
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_access_token( $value ): string {
		$new = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $new ) {
			$previous = (string) get_option( 'wppe_bridge_hubspot_access_token', '' );
			if ( '' === $previous && function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_hubspot_access_token',
					'wppe_bridge_hubspot_access_token_required',
					__( 'El Private App access token de HubSpot es obligatorio. Sin token, los leads no se enviaran al CRM.', 'wppe-bridge' )
				);
			}
			return $previous;
		}
		return $new;
	}

	/**
	 * Sanitiza lifecyclestage contra la whitelist de
	 * `WPPE_Hubspot_Destination::ALLOWED_LIFECYCLESTAGES`. Vacio
	 * permitido (significa "no inyectar default").
	 *
	 * Si llega un valor fuera de whitelist, registra error y conserva
	 * el valor previo (defensa contra typo o input maliciosp).
	 *
	 * @param mixed $value Valor del input (select).
	 * @return string
	 */
	public static function sanitize_lifecyclestage( $value ): string {
		$new = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $new ) {
			return '';
		}
		if ( ! in_array( $new, WPPE_Hubspot_Destination::ALLOWED_LIFECYCLESTAGES, true ) ) {
			if ( function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_hubspot_default_lifecyclestage',
					'wppe_bridge_hubspot_default_lifecyclestage_invalid',
					sprintf(
						/* translators: %s = valor recibido invalido */
						__( 'Lifecyclestage "%s" no es valido. Valores aceptados: subscriber, lead, marketingqualifiedlead, salesqualifiedlead, opportunity, customer, evangelist, other.', 'wppe-bridge' ),
						$new
					)
				);
			}
			return (string) get_option( 'wppe_bridge_hubspot_default_lifecyclestage', '' );
		}
		return $new;
	}

	/**
	 * Sanitiza el Owner ID: trim + solo digitos. Los HubSpot owner IDs
	 * son enteros (visibles en Settings -> Users & Teams -> URL al
	 * editar usuario, ej. `?user_id=12345`).
	 *
	 * Vacio permitido (significa "no inyectar — usar reglas de
	 * assignment del portal").
	 *
	 * Si invalido, conserva el valor previo + error notice.
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_owner_id( $value ): string {
		$new = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $new ) {
			return '';
		}
		if ( ! ctype_digit( $new ) ) {
			if ( function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_hubspot_default_owner_id',
					'wppe_bridge_hubspot_default_owner_id_invalid',
					__( 'El Owner ID debe ser solo digitos. Lo encuentras en HubSpot: Settings &rarr; Users &amp; Teams &rarr; click en el usuario &rarr; el ID aparece en la URL como ?user_id=...', 'wppe-bridge' )
				);
			}
			return (string) get_option( 'wppe_bridge_hubspot_default_owner_id', '' );
		}
		return $new;
	}
}
