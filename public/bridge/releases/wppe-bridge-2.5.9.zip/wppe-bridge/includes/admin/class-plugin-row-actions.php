<?php
/**
 * Agrega un link "Buscar actualización" en la fila de WP.pe Bridge
 * en wp-admin/plugins.php (v2.5.2).
 *
 * **Por que existe:**
 *
 * El cliente reporto que el aviso "Update available" de WordPress en
 * wp-admin/plugins.php a veces no aparece, porque WordPress chequea
 * updates solo 2 veces al dia via cron `wp_version_check`. Si el
 * release nuevo (ej. v2.5.1) sale poco despues del ultimo tick, el
 * cache (`update_plugins` site transient) sigue diciendo "no hay
 * updates" hasta el proximo tick, lo cual puede tardar horas.
 *
 * **Soluciones existentes:**
 *
 * 1. Card "Buscar actualizaciones" en wp-admin -> WP.pe Bridge ->
 *    Inicio (v2.5.x, #60).
 * 2. WP-CLI: `wp transient delete update_plugins && wp plugin update wppe-bridge`.
 * 3. Pantalla nativa de WP: Dashboard -> Updates -> "Check again".
 *
 * **Lo que agrega esta clase (v2.5.2):**
 *
 * Un link "Buscar actualizacion" directamente en la fila del plugin
 * en `wp-admin/plugins.php`. Sin salir de esa pantalla, el admin
 * fuerza el check y al volver ya ve el badge "Update available"
 * si lo hay.
 *
 * Hookea:
 *  - `plugin_action_links_{plugin_basename}`: agrega el link.
 *  - `admin_post_wppe_bridge_force_update_check`: handler que llama
 *    `Updater::force_refresh()` y redirect con flash.
 *  - `admin_notices`: lee el flash query param post-redirect y muestra
 *    el resultado (al dia / hay update / error fetch).
 *
 * Naming sec 4.3 CLAUDE.md: `WPPE_Bridge_Plugin_Row_Actions`.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Plugin Row Actions: link "Buscar actualizacion" en wp-admin/plugins.php.
 */
final class WPPE_Bridge_Plugin_Row_Actions {

	/**
	 * Action del POST handler.
	 */
	public const ACTION_FORCE_CHECK = 'wppe_bridge_force_update_check';

	/**
	 * Nonce action.
	 */
	public const NONCE_ACTION = 'wppe_bridge_force_update_check';

	/**
	 * Query param que indica que el handler ya corrio y la pantalla
	 * de plugins.php debe mostrar el resultado.
	 */
	public const FLASH_QUERY_PARAM = 'wppe_bridge_updates_checked';

	/**
	 * Bootstrap. Llamado desde Plugin::register_hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		$basename = WPPE_Bridge_Updater::plugin_basename();
		add_filter( 'plugin_action_links_' . $basename, array( self::class, 'add_action_link' ) );
		add_action( 'admin_post_' . self::ACTION_FORCE_CHECK, array( self::class, 'handle_force_check' ) );
		add_action( 'admin_notices', array( self::class, 'maybe_show_notice' ) );
	}

	/**
	 * Agrega el link "Buscar actualizacion" al array de action_links.
	 *
	 * Posicion: al final del array (despues de "Desactivar", "Editar",
	 * etc). Diseno minimalista — sin styling especial, hereda el del
	 * row para consistencia con los demas links de WordPress.
	 *
	 * @param array<string,string> $links Action links existentes (HTML
	 *                                     anchors).
	 * @return array<string,string>
	 */
	public static function add_action_link( $links ): array {
		if ( ! is_array( $links ) ) {
			$links = array();
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return $links;
		}

		$url = wp_nonce_url(
			add_query_arg(
				array( 'action' => self::ACTION_FORCE_CHECK ),
				function_exists( 'admin_url' ) ? admin_url( 'admin-post.php' ) : 'admin-post.php'
			),
			self::NONCE_ACTION
		);

		$links['wppe_bridge_force_check'] = sprintf(
			'<a href="%s" title="%s">%s</a>',
			esc_url( $url ),
			esc_attr__( 'Invalida el cache del Updater y vuelve a consultar el servidor de actualizaciones de WP.pe Bridge.', 'wppe-bridge' ),
			esc_html__( 'Buscar actualizacion', 'wppe-bridge' )
		);

		return $links;
	}

	/**
	 * Handler del POST que fuerza el check. Llama
	 * `Updater::force_refresh()`, detecta si hay update, y redirect a
	 * `plugins.php` con un flash query param que la pantalla `admin_notices`
	 * lee para mostrar el resultado.
	 *
	 * Estados de flash (`wppe_bridge_updates_checked`):
	 *  - `up_to_date`: remote == current (o lower). No hay update.
	 *  - `has_update`: remote > current. Notice incluye link a "Update now".
	 *  - `error`: no se pudo consultar el manifest (network / 5xx / JSON
	 *    invalido). Notice rojo con mensaje.
	 *
	 * @return void
	 */
	public static function handle_force_check(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_ACTION );

		WPPE_Bridge_Updater::force_refresh();
		$status = WPPE_Bridge_Updater::get_status();

		if ( null !== ( $status['error'] ?? null ) ) {
			$flash = 'error';
		} elseif ( ! empty( $status['has_update'] ) ) {
			$flash = 'has_update';
		} else {
			$flash = 'up_to_date';
		}

		$redirect = add_query_arg(
			array( self::FLASH_QUERY_PARAM => $flash ),
			function_exists( 'admin_url' ) ? admin_url( 'plugins.php' ) : 'plugins.php'
		);
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Renderiza el notice post-check si hay query param. Hookeado a
	 * `admin_notices` — pasa todo el tiempo en cada page load, pero el
	 * early-return cuando no hay param hace que sea barato.
	 *
	 * Solo se muestra en pantallas relevantes (Dashboard + plugins.php),
	 * para no spammar otras pantallas si el admin navega tras el
	 * redirect.
	 *
	 * @return void
	 */
	public static function maybe_show_notice(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$flash = isset( $_GET[ self::FLASH_QUERY_PARAM ] ) ? sanitize_key( wp_unslash( $_GET[ self::FLASH_QUERY_PARAM ] ) ) : '';
		if ( '' === $flash ) {
			return;
		}

		// Limitamos el notice a pantallas donde tiene sentido (Plugins +
		// Dashboard). Si el admin esta navegando otra pantalla con el
		// param en la URL por error, no spammeamos.
		if ( function_exists( 'get_current_screen' ) ) {
			$screen = get_current_screen();
			$base   = is_object( $screen ) && isset( $screen->base ) ? (string) $screen->base : '';
			if ( ! in_array( $base, array( 'plugins', 'dashboard' ), true ) ) {
				return;
			}
		}

		if ( 'has_update' === $flash ) {
			$status     = WPPE_Bridge_Updater::get_status();
			$remote     = (string) ( $status['remote'] ?? '' );
			$plugins_ok = function_exists( 'admin_url' ) ? admin_url( 'plugins.php' ) : 'plugins.php';
			printf(
				'<div class="notice notice-warning is-dismissible"><p>%s <a href="%s">%s</a></p></div>',
				esc_html(
					sprintf(
						/* translators: %s: version disponible (ej. "2.6.0"). */
						__( 'WP.pe Bridge: hay una actualizacion disponible (v%s). Click en "Actualizar ahora" debajo del plugin para instalarla.', 'wppe-bridge' ),
						$remote
					)
				),
				esc_url( $plugins_ok ),
				esc_html__( 'Ver plugins instalados', 'wppe-bridge' )
			);
			return;
		}

		if ( 'up_to_date' === $flash ) {
			$current = WPPE_Bridge_Updater::current_version();
			printf(
				'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
				esc_html(
					sprintf(
						/* translators: %s: version actual instalada (ej. "2.5.1"). */
						__( 'WP.pe Bridge: estas al dia (v%s).', 'wppe-bridge' ),
						$current
					)
				)
			);
			return;
		}

		if ( 'error' === $flash ) {
			$status = WPPE_Bridge_Updater::get_status();
			$msg    = (string) ( $status['error'] ?? __( 'Error al consultar el servidor de actualizaciones.', 'wppe-bridge' ) );
			printf(
				'<div class="notice notice-error is-dismissible"><p><strong>%s</strong> %s</p></div>',
				esc_html__( 'WP.pe Bridge:', 'wppe-bridge' ),
				esc_html( $msg )
			);
			return;
		}
	}
}
