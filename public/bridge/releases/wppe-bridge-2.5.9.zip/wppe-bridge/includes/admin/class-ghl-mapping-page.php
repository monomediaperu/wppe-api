<?php
/**
 * Pagina admin de mapeo de campos GHL.
 *
 * UI para configurar:
 *
 * 1. Por cada form Fluent/Gravity/Elementor: mapeo de campos del form
 *    a fields GHL (firstName, lastName, email, phone, etc.). Persiste
 *    en wp_options['wppe_bridge_ghl_field_mapping'].
 *
 * 2. Configuracion global (no por-form):
 *    - Pipeline default + stage default (para Opportunity en PR-3).
 *    - Mapeo de UTMs a Custom Fields (utm_source, utm_medium, etc.).
 *    - Tags default globales.
 *
 *    Persiste en wp_options:
 *    - wppe_bridge_ghl_default_pipeline_id
 *    - wppe_bridge_ghl_default_pipeline_stage_id
 *    - wppe_bridge_ghl_utm_field_mapping
 *    - wppe_bridge_ghl_default_tags
 *
 * **Scope PR-2:** Esta sub-pagina persiste todas las opciones pero
 * el Worker / Destination todavia NO las inyecta al payload — eso
 * llega en PR-3. Aviso visible en la UI: "configuracion lista para
 * v2.1.0 (PR-3)".
 *
 * Asimetrica con Mapping_Page Sperant (Camino A, sec 12 CLAUDE.md):
 * GHL tiene su propia sub-pagina porque sus catalogos
 * (pipelines/stages, custom fields, tags) son estructuralmente
 * distintos a los de Sperant (input_channels, sources, interest_types,
 * projects).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pagina admin de mapeo de campos del form a campos GHL.
 */
final class WPPE_Bridge_Ghl_Mapping_Page {

	/**
	 * Slug de la sub-pagina admin.
	 */
	public const PAGE_SLUG = 'wppe-bridge-ghl-mapping';

	/**
	 * Action del POST handler para mapeo de campos por-form.
	 */
	public const ACTION_SAVE_FORM_MAPPING = 'wppe_bridge_save_ghl_form_mapping';

	/**
	 * Action del POST handler para configuracion global
	 * (Opportunity defaults, UTM mapping, tags default).
	 */
	public const ACTION_SAVE_GLOBAL_CONFIG = 'wppe_bridge_save_ghl_global_config';

	/**
	 * Nonce action para mapeo por-form.
	 */
	public const NONCE_FORM_MAPPING = 'wppe_bridge_save_ghl_form_mapping';

	/**
	 * Nonce action para config global.
	 */
	public const NONCE_GLOBAL_CONFIG = 'wppe_bridge_save_ghl_global_config';

	/**
	 * Lista de payload keys GHL que el admin puede mapear desde campos
	 * del form. Subset de los campos top-level de POST /contacts/upsert
	 * que tienen sentido configurar desde un formulario web inmobiliario.
	 *
	 * @var array<int,string>
	 */
	public const PAYLOAD_KEYS = array(
		'firstName',
		'lastName',
		'email',
		'phone',
		'address1',
		'city',
		'state',
		'country',
		'postalCode',
		'companyName',
		'website',
	);

	/**
	 * Slugs de UTMs que mapeamos a Custom Fields.
	 *
	 * @var array<int,string>
	 */
	public const UTM_KEYS = array(
		'utm_source',
		'utm_medium',
		'utm_campaign',
		'utm_content',
		'utm_term',
		'gclid',
		'fbclid',
	);

	/**
	 * DataTypes de Custom Field GHL aceptables para guardar UTMs.
	 * UTMs son strings, asi que solo TEXT y LARGE_TEXT (D-PR2-5).
	 *
	 * @var array<int,string>
	 */
	public const UTM_ALLOWED_CF_DATATYPES = array( 'TEXT', 'LARGE_TEXT' );

	/**
	 * Registra los handlers admin_post_*.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_post_' . self::ACTION_SAVE_FORM_MAPPING, array( self::class, 'handle_save_form_mapping' ) );
		add_action( 'admin_post_' . self::ACTION_SAVE_GLOBAL_CONFIG, array( self::class, 'handle_save_global_config' ) );
	}

	/**
	 * Renderiza la pagina.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$discovery_result  = WPPE_Bridge_Form_Discovery::discover_all_with_reasons();
		$discovered        = $discovery_result['forms'];
		$discovery_reasons = $discovery_result['reasons'];

		$catalogs        = get_option( 'wppe_bridge_ghl_catalogs', array() );
		$catalogs        = is_array( $catalogs ) ? $catalogs : array();
		$catalogs_errors = isset( $catalogs['_errors'] ) && is_array( $catalogs['_errors'] ) ? $catalogs['_errors'] : array();
		$synced_at       = isset( $catalogs['_synced_at'] ) ? (int) $catalogs['_synced_at'] : 0;

		$mapping = get_option( 'wppe_bridge_ghl_field_mapping', array() );
		$mapping = is_array( $mapping ) ? $mapping : array();

		// Config global.
		$default_pipeline_id = (string) get_option( 'wppe_bridge_ghl_default_pipeline_id', '' );
		$default_stage_id    = (string) get_option( 'wppe_bridge_ghl_default_pipeline_stage_id', '' );
		$utm_field_mapping   = get_option( 'wppe_bridge_ghl_utm_field_mapping', array() );
		$utm_field_mapping   = is_array( $utm_field_mapping ) ? $utm_field_mapping : array();
		$default_tags        = get_option( 'wppe_bridge_ghl_default_tags', array() );
		$default_tags        = is_array( $default_tags ) ? $default_tags : array();

		$selected_plugin = isset( $_GET['plugin'] ) ? sanitize_key( wp_unslash( $_GET['plugin'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$selected_form   = isset( $_GET['form'] ) ? sanitize_text_field( wp_unslash( $_GET['form'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$selected_form_data = null;
		if ( '' !== $selected_form && '' !== $selected_plugin && isset( $discovered[ $selected_plugin ] ) ) {
			foreach ( $discovered[ $selected_plugin ] as $form ) {
				if ( (string) $form['id'] === $selected_form ) {
					$selected_form_data = $form;
					break;
				}
			}
		}

		$existing_mapping = array(
			'fields' => array(),
			'tags'   => array(),
		);
		if ( '' !== $selected_plugin && '' !== $selected_form && isset( $mapping[ $selected_plugin ][ $selected_form ] ) ) {
			$existing_mapping = array_merge( $existing_mapping, (array) $mapping[ $selected_plugin ][ $selected_form ] );
		}

		// Custom Fields filtrados a tipos aceptables para UTMs (D-PR2-5).
		$cf_for_utms = self::filter_text_custom_fields(
			isset( $catalogs['custom_fields'] ) && is_array( $catalogs['custom_fields'] ) ? $catalogs['custom_fields'] : array()
		);

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/ghl-mapping.php';
	}

	/**
	 * Filtra Custom Fields a los aceptables para guardar UTMs (D-PR2-5).
	 * Solo TEXT y LARGE_TEXT — datatypes especificos como PHONE, EMAIL,
	 * DATE, FILE_UPLOAD producirian basura o errores al recibir un
	 * utm_source.
	 *
	 * Tambien filtra a `model = contact` (los CFs de opportunity NO
	 * sirven para guardar UTMs en el contact).
	 *
	 * @param array $custom_fields Lista cruda de custom fields.
	 * @return array<int,array<string,mixed>>
	 */
	public static function filter_text_custom_fields( array $custom_fields ): array {
		return array_values(
			array_filter(
				$custom_fields,
				static function ( $cf ) {
					if ( ! is_array( $cf ) ) {
						return false;
					}
					$datatype = isset( $cf['dataType'] ) ? (string) $cf['dataType'] : '';
					if ( ! in_array( $datatype, self::UTM_ALLOWED_CF_DATATYPES, true ) ) {
						return false;
					}
					// Si viene `model`, exigir que sea contact. Si no viene
					// (algunas versiones del API GHL omiten el campo),
					// asumir contact (caso default).
					if ( isset( $cf['model'] ) && '' !== (string) $cf['model'] && 'contact' !== (string) $cf['model'] ) {
						return false;
					}
					return true;
				}
			)
		);
	}

	/**
	 * Handler del POST que guarda el mapeo de un form especifico.
	 *
	 * @return void
	 */
	public static function handle_save_form_mapping(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_FORM_MAPPING );

		$post   = wp_unslash( $_POST );
		$plugin = isset( $post['plugin'] ) ? sanitize_key( $post['plugin'] ) : '';
		$form   = isset( $post['form'] ) ? sanitize_text_field( $post['form'] ) : '';

		if ( '' === $plugin || '' === $form ) {
			wp_safe_redirect( self::redirect_url( $plugin, $form, 'error_missing_form' ) );
			exit;
		}

		$entry = self::build_form_entry_from_post( is_array( $post ) ? $post : array() );

		// Validacion: debe haber al menos un mapeo a firstName (GHL no
		// requiere firstName tecnicamente — solo locationId — pero el
		// contact sin firstName es inutil para vendedores. Forzamos
		// que el form tenga al menos un campo mapeado a firstName).
		$missing = self::validate_required_fields( $entry );
		if ( ! empty( $missing ) ) {
			wp_safe_redirect( self::redirect_url( $plugin, $form, 'error_required', $missing ) );
			exit;
		}

		$current = get_option( 'wppe_bridge_ghl_field_mapping', array() );
		if ( ! is_array( $current ) ) {
			$current = array();
		}
		if ( ! isset( $current[ $plugin ] ) || ! is_array( $current[ $plugin ] ) ) {
			$current[ $plugin ] = array();
		}
		$current[ $plugin ][ $form ] = $entry;

		update_option( 'wppe_bridge_ghl_field_mapping', $current );

		wp_safe_redirect( self::redirect_url( $plugin, $form, 'saved' ) );
		exit;
	}

	/**
	 * Handler del POST que guarda la configuracion global (Opp + UTMs + tags).
	 *
	 * @return void
	 */
	public static function handle_save_global_config(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_GLOBAL_CONFIG );

		$post = wp_unslash( $_POST );

		// Pipeline + stage default (validacion contra catalogo).
		$pipeline_id = isset( $post['default_pipeline_id'] ) ? sanitize_text_field( $post['default_pipeline_id'] ) : '';
		$stage_id    = isset( $post['default_pipeline_stage_id'] ) ? sanitize_text_field( $post['default_pipeline_stage_id'] ) : '';

		update_option( 'wppe_bridge_ghl_default_pipeline_id', self::sanitize_id_against_catalog( $pipeline_id, 'pipelines' ) );
		update_option( 'wppe_bridge_ghl_default_pipeline_stage_id', self::sanitize_stage_id( $stage_id, $pipeline_id ) );

		// UTM field mapping. Cada utm_* puede tener un CF id asignado.
		$utm_post    = isset( $post['utm_field_mapping'] ) && is_array( $post['utm_field_mapping'] ) ? $post['utm_field_mapping'] : array();
		$utm_mapping = array();
		$catalogs    = get_option( 'wppe_bridge_ghl_catalogs', array() );
		$cfs         = isset( $catalogs['custom_fields'] ) && is_array( $catalogs['custom_fields'] ) ? $catalogs['custom_fields'] : array();
		$cf_ids      = array_column( self::filter_text_custom_fields( $cfs ), 'id' );

		foreach ( self::UTM_KEYS as $utm_key ) {
			$cf_id = isset( $utm_post[ $utm_key ] ) ? sanitize_text_field( (string) $utm_post[ $utm_key ] ) : '';
			if ( '' !== $cf_id && in_array( $cf_id, $cf_ids, true ) ) {
				$utm_mapping[ $utm_key ] = $cf_id;
			}
		}
		update_option( 'wppe_bridge_ghl_utm_field_mapping', $utm_mapping );

		// Tags default. Acepta lista CSV o repetidos `default_tags[]`.
		$raw_tags = $post['default_tags'] ?? '';
		if ( is_string( $raw_tags ) ) {
			$raw_tags = array_map( 'trim', explode( ',', $raw_tags ) );
		}
		$tags = array();
		foreach ( (array) $raw_tags as $tag ) {
			$tag = sanitize_text_field( (string) $tag );
			if ( '' !== $tag ) {
				$tags[] = $tag;
			}
		}
		// Deduplicar preservando orden.
		$tags = array_values( array_unique( $tags ) );
		update_option( 'wppe_bridge_ghl_default_tags', $tags );

		wp_safe_redirect( self::redirect_url( '', '', 'global_saved' ) );
		exit;
	}

	/**
	 * Valida que el `pipeline_id` exista en el catalogo. Si no, retorna
	 * vacio (deja la opcion sin setear).
	 *
	 * @param string $value Pipeline id propuesto.
	 * @param string $key   Key del catalogo (siempre 'pipelines' por ahora).
	 * @return string
	 */
	public static function sanitize_id_against_catalog( string $value, string $key ): string {
		$value = trim( $value );
		if ( '' === $value ) {
			return '';
		}
		$catalogs = get_option( 'wppe_bridge_ghl_catalogs', array() );
		$items    = isset( $catalogs[ $key ] ) && is_array( $catalogs[ $key ] ) ? $catalogs[ $key ] : array();
		foreach ( $items as $item ) {
			if ( is_array( $item ) && isset( $item['id'] ) && (string) $item['id'] === $value ) {
				return $value;
			}
		}
		return '';
	}

	/**
	 * Valida que el `stage_id` exista dentro del pipeline indicado.
	 *
	 * @param string $stage_id    Stage id propuesto.
	 * @param string $pipeline_id Pipeline id donde debe vivir el stage.
	 * @return string
	 */
	public static function sanitize_stage_id( string $stage_id, string $pipeline_id ): string {
		$stage_id    = trim( $stage_id );
		$pipeline_id = trim( $pipeline_id );
		if ( '' === $stage_id || '' === $pipeline_id ) {
			return '';
		}
		$catalogs = get_option( 'wppe_bridge_ghl_catalogs', array() );
		$items    = isset( $catalogs['pipelines'] ) && is_array( $catalogs['pipelines'] ) ? $catalogs['pipelines'] : array();
		foreach ( $items as $pipeline ) {
			if ( ! is_array( $pipeline ) || ( $pipeline['id'] ?? '' ) !== $pipeline_id ) {
				continue;
			}
			$stages = isset( $pipeline['stages'] ) && is_array( $pipeline['stages'] ) ? $pipeline['stages'] : array();
			foreach ( $stages as $stage ) {
				if ( is_array( $stage ) && (string) ( $stage['id'] ?? '' ) === $stage_id ) {
					return $stage_id;
				}
			}
		}
		return '';
	}

	/**
	 * Valida que el form mapping tenga firstName mapeado.
	 *
	 * @param array{fields:array<string,string>} $entry Entry construido.
	 * @return array<int,string> Lista de keys faltantes.
	 */
	public static function validate_required_fields( array $entry ): array {
		$missing       = array();
		$fields        = isset( $entry['fields'] ) && is_array( $entry['fields'] ) ? $entry['fields'] : array();
		$has_firstname = false;
		foreach ( $fields as $payload_key ) {
			if ( 'firstName' === $payload_key ) {
				$has_firstname = true;
				break;
			}
		}
		if ( ! $has_firstname ) {
			$missing[] = 'firstName';
		}
		return $missing;
	}

	/**
	 * Construye la entrada `{fields, tags}` del POST.
	 *
	 * - `fields`: mapeo `form_field => payload_key` (firstName, email, ...).
	 * - `tags`: array de strings con tags adicionales para este form
	 *   (override por-form que se concatena a los default globales en
	 *   Destination::send. D-GHL-5 + PR-3).
	 *
	 * No tiene `defaults` como Sperant porque GHL no tiene catalogos
	 * por-form analogos — los defaults Opportunity/UTMs son globales.
	 *
	 * @param array $post POST sanitizado.
	 * @return array{fields:array<string,string>,tags:array<int,string>}
	 */
	public static function build_form_entry_from_post( array $post ): array {
		$fields    = array();
		$field_map = isset( $post['field_map'] ) && is_array( $post['field_map'] ) ? $post['field_map'] : array();

		foreach ( $field_map as $form_field => $payload_key ) {
			$form_field  = sanitize_text_field( (string) $form_field );
			$payload_key = is_string( $payload_key ) ? trim( $payload_key ) : '';
			if ( '' === $form_field || '' === $payload_key ) {
				continue;
			}
			if ( ! in_array( $payload_key, self::PAYLOAD_KEYS, true ) ) {
				continue;
			}
			$fields[ $form_field ] = $payload_key;
		}

		// Tags override por-form (CSV o array). PR-3.
		$raw_tags = $post['form_tags'] ?? '';
		if ( is_string( $raw_tags ) ) {
			$raw_tags = array_map( 'trim', explode( ',', $raw_tags ) );
		}
		$tags = array();
		foreach ( (array) $raw_tags as $tag ) {
			$tag = sanitize_text_field( (string) $tag );
			if ( '' !== $tag ) {
				$tags[] = $tag;
			}
		}
		$tags = array_values( array_unique( $tags ) );

		return array(
			'fields' => $fields,
			'tags'   => $tags,
		);
	}

	/**
	 * Construye URL de redirect post-save con flash messages.
	 *
	 * @param string            $plugin  Plugin slug (vacio si volvemos a la vista global).
	 * @param string            $form    Form ID (vacio si volvemos a la vista global).
	 * @param string            $flash   Codigo de mensaje.
	 * @param array<int,string> $missing Campos faltantes para flash error_required.
	 * @return string
	 */
	private static function redirect_url( string $plugin, string $form, string $flash, array $missing = array() ): string {
		$args = array(
			'page'  => self::PAGE_SLUG,
			'flash' => $flash,
		);
		if ( '' !== $plugin ) {
			$args['plugin'] = $plugin;
		}
		if ( '' !== $form ) {
			$args['form'] = $form;
		}
		if ( ! empty( $missing ) ) {
			$args['missing'] = implode( ',', array_map( 'sanitize_key', $missing ) );
		}
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}
}
