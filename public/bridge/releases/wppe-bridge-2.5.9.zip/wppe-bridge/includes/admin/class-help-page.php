<?php
/**
 * Pagina admin "Inicio" — landing del plugin con guia paso a paso.
 *
 * Combina:
 * 1. **Pasos genericos del plugin** (instalacion, mapeo, modulos,
 *    lead de prueba) — son agnosticos al CRM destino, viven aqui.
 * 2. **Pasos especificos del CRM activo** — vienen de
 *    `Destination::setup_guide()` del destino seleccionado en
 *    Configuracion. Cuando agreguemos GHL u otro CRM en v2.0+,
 *    esta pagina los muestra automaticamente sin tocar codigo.
 *
 * Cada paso generico tiene un **check** que verifica el estado real
 * en vivo (token configurado, catalogos sincronizados, forms
 * mapeados, modulos activados, lead de prueba enviado).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pagina "Inicio" — orquestador de la guia paso a paso.
 */
final class WPPE_Bridge_Help_Page {

	/**
	 * Estados posibles de cada paso generico.
	 */
	public const STATUS_DONE     = 'done';
	public const STATUS_PENDING  = 'pending';
	public const STATUS_OPTIONAL = 'optional';
	public const STATUS_WARN     = 'warn';

	/**
	 * Renderiza la pagina (solo permite si capability OK).
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$generic_steps = self::generic_steps();
		$crm_steps     = self::crm_specific_steps();
		$env_cards     = self::environment_cards();
		$active_label  = self::active_destination_label();
		$update_status = self::update_status();

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/help.php';
	}

	/**
	 * Estado de actualizacion del plugin para la card "Versión" en
	 * Inicio. Delegado a `WPPE_Bridge_Updater::get_status()`. Devuelve
	 * un fallback minimo si la clase Updater no esta cargada (tests
	 * que no la incluyen) — evita warnings en la view.
	 *
	 * @return array<string,mixed>
	 */
	public static function update_status(): array {
		if ( ! class_exists( 'WPPE_Bridge_Updater' ) ) {
			return array(
				'current'       => defined( 'WPPE_BRIDGE_VERSION' ) ? WPPE_BRIDGE_VERSION : '',
				'remote'        => null,
				'has_update'    => false,
				'last_check'    => null,
				'error'         => null,
				'changelog_url' => '',
				'zip_url'       => '',
			);
		}
		return WPPE_Bridge_Updater::get_status();
	}

	/**
	 * Lista de pasos genericos del plugin con checks de estado.
	 *
	 * Cada paso:
	 *   key, number, title, description, status (DONE|PENDING|OPTIONAL|WARN),
	 *   detail (string opcional con info contextual del check),
	 *   action_url, action_label.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function generic_steps(): array {
		$config_url  = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=' . WPPE_Bridge_Admin_Menu::SLUG . '-config' ) : '';
		$mapping_url = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=' . WPPE_Bridge_Admin_Menu::SLUG . '-mapping' ) : '';
		$modules_url = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=' . WPPE_Bridge_Admin_Menu::SLUG . '-modules' ) : '';
		$logs_url    = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=' . WPPE_Bridge_Admin_Menu::SLUG . '-logs' ) : '';

		return array(
			self::step_plugin_active(),
			self::step_form_plugin_detected( $mapping_url ),
			self::step_token_configured( $config_url ),
			self::step_catalogs_available( $config_url ),
			self::step_forms_mapped( $mapping_url ),
			self::step_modules_activated( $modules_url ),
			self::step_test_lead_sent( $logs_url ),
		);
	}

	/**
	 * Paso 1: plugin activado.
	 *
	 * @return array<string,mixed>
	 */
	private static function step_plugin_active(): array {
		return array(
			'key'          => 'plugin_active',
			'number'       => 1,
			'title'        => __( 'Plugin activado', 'wppe-bridge' ),
			'description'  => __( 'El plugin esta activo y los hooks de WordPress estan registrados. Si estas viendo esta pagina, este paso esta hecho.', 'wppe-bridge' ),
			'status'       => self::STATUS_DONE,
			'detail'       => sprintf(
				/* translators: %s = version del plugin */
				__( 'Version %s', 'wppe-bridge' ),
				defined( 'WPPE_BRIDGE_VERSION' ) ? WPPE_BRIDGE_VERSION : '?'
			),
			'action_url'   => null,
			'action_label' => null,
		);
	}

	/**
	 * Paso 2: plugin de forms detectado.
	 *
	 * @param string $mapping_url URL de la pagina de Mapeo.
	 * @return array<string,mixed>
	 */
	private static function step_form_plugin_detected( string $mapping_url ): array {
		$discovery_result = WPPE_Bridge_Form_Discovery::discover_all_with_reasons();
		$total_forms      = count( $discovery_result['forms']['fluent'] ) + count( $discovery_result['forms']['gravity'] );

		if ( $total_forms > 0 ) {
			return array(
				'key'          => 'form_plugin_detected',
				'number'       => 2,
				'title'        => __( 'Plugin de forms detectado', 'wppe-bridge' ),
				'description'  => __( 'Fluent Forms o Gravity Forms esta activo y al menos un form fue detectado.', 'wppe-bridge' ),
				'status'       => self::STATUS_DONE,
				'detail'       => sprintf(
					/* translators: %d = numero de forms */
					_n( '%d form detectado.', '%d forms detectados.', $total_forms, 'wppe-bridge' ),
					$total_forms
				),
				'action_url'   => $mapping_url,
				'action_label' => __( 'Ver forms detectados', 'wppe-bridge' ),
			);
		}

		// Determinar el motivo del fallo.
		$reasons     = $discovery_result['reasons'];
		$reason_text = sprintf(
			'Fluent: %s. Gravity: %s.',
			(string) ( $reasons['fluent'] ?? 'unknown' ),
			(string) ( $reasons['gravity'] ?? 'unknown' )
		);

		return array(
			'key'          => 'form_plugin_detected',
			'number'       => 2,
			'title'        => __( 'Plugin de forms detectado', 'wppe-bridge' ),
			'description'  => __( 'Necesitas Fluent Forms Pro o Gravity Forms instalado y activo, con al menos un form creado.', 'wppe-bridge' ),
			'status'       => self::STATUS_PENDING,
			'detail'       => $reason_text,
			'action_url'   => $mapping_url,
			'action_label' => __( 'Ver detalle en Mapeo', 'wppe-bridge' ),
		);
	}

	/**
	 * Paso 3: token / credenciales del CRM activo.
	 *
	 * @param string $config_url URL de Configuracion.
	 * @return array<string,mixed>
	 */
	private static function step_token_configured( string $config_url ): array {
		$has_token = '' !== (string) get_option( 'wppe_bridge_api_token', '' );

		return array(
			'key'          => 'token_configured',
			'number'       => 3,
			'title'        => __( 'Token / credenciales del CRM configuradas', 'wppe-bridge' ),
			'description'  => __( 'El plugin necesita autenticarse contra el CRM destino. Para Sperant es un token estatico que no caduca, ingresado una vez en Configuracion. Otros CRMs (futuros) pueden usar OAuth o API keys.', 'wppe-bridge' ),
			'status'       => $has_token ? self::STATUS_DONE : self::STATUS_PENDING,
			'detail'       => $has_token ? __( 'Token guardado.', 'wppe-bridge' ) : __( 'Sin token. La integracion no funcionara hasta configurarlo.', 'wppe-bridge' ),
			'action_url'   => $config_url,
			'action_label' => __( 'Ir a Configuracion', 'wppe-bridge' ),
		);
	}

	/**
	 * Paso 4: catalogos disponibles (sincronizados o importados manualmente).
	 *
	 * @param string $config_url URL de Configuracion.
	 * @return array<string,mixed>
	 */
	private static function step_catalogs_available( string $config_url ): array {
		$catalogs = get_option( 'wppe_bridge_catalogs', array() );
		$catalogs = is_array( $catalogs ) ? $catalogs : array();

		$keys   = array( 'input_channels', 'sources', 'interest_types', 'projects' );
		$counts = array();
		$total  = 0;
		foreach ( $keys as $k ) {
			$c            = isset( $catalogs[ $k ] ) && is_array( $catalogs[ $k ] ) ? count( $catalogs[ $k ] ) : 0;
			$counts[ $k ] = $c;
			$total       += $c;
		}

		$ok_count   = count( array_filter( $counts, static fn( $c ) => $c > 0 ) );
		$total_keys = count( $keys );

		// Calcular estado: 0 catalogos = pending; algunos = warn; todos = done.
		if ( 0 === $ok_count ) {
			$status = self::STATUS_PENDING;
			$detail = __( 'Ningun catalogo sincronizado todavia.', 'wppe-bridge' );
		} elseif ( $ok_count < $total_keys ) {
			$status = self::STATUS_WARN;
			$detail = sprintf(
				/* translators: 1: count of available catalogs, 2: total catalogs, 3: list of detail */
				__( '%1$d/%2$d catalogos disponibles. Detalle: canales=%3$d, fuentes=%4$d, intereses=%5$d, proyectos=%6$d.', 'wppe-bridge' ),
				$ok_count,
				$total_keys,
				$counts['input_channels'],
				$counts['sources'],
				$counts['interest_types'],
				$counts['projects']
			);
		} else {
			$status = self::STATUS_DONE;
			$detail = sprintf(
				/* translators: 1-4: counts per catalog */
				__( '%1$d canales, %2$d fuentes, %3$d intereses, %4$d proyectos.', 'wppe-bridge' ),
				$counts['input_channels'],
				$counts['sources'],
				$counts['interest_types'],
				$counts['projects']
			);
		}

		return array(
			'key'          => 'catalogs_available',
			'number'       => 4,
			'title'        => __( 'Catalogos disponibles', 'wppe-bridge' ),
			'description'  => __( 'Los catalogos (canales, fuentes, tipos de interes, proyectos) son los IDs del CRM que el plugin usa para etiquetar leads. Se sincronizan via API automaticamente. Si la API no expone alguno (caso conocido de Sperant: <code>sources</code>), podes importarlo manualmente desde el panel del cliente pegando el JSON.', 'wppe-bridge' ),
			'status'       => $status,
			'detail'       => $detail,
			'action_url'   => $config_url,
			'action_label' => __( 'Sincronizar / Importar', 'wppe-bridge' ),
		);
	}

	/**
	 * Paso 5: forms con mapeo configurado.
	 *
	 * @param string $mapping_url URL de Mapeo.
	 * @return array<string,mixed>
	 */
	private static function step_forms_mapped( string $mapping_url ): array {
		$mapping = get_option( 'wppe_bridge_field_mapping', array() );
		$mapping = is_array( $mapping ) ? $mapping : array();

		$total      = 0;
		$incomplete = 0;
		foreach ( $mapping as $forms_by_plugin ) {
			if ( ! is_array( $forms_by_plugin ) ) {
				continue;
			}
			foreach ( $forms_by_plugin as $entry ) {
				++$total;
				if ( ! is_array( $entry ) ) {
					++$incomplete;
					continue;
				}
				if ( class_exists( 'WPPE_Bridge_Mapping_Page' ) ) {
					$missing = WPPE_Bridge_Mapping_Page::validate_required_fields( $entry );
					if ( ! empty( $missing ) ) {
						++$incomplete;
					}
				}
			}
		}

		if ( 0 === $total ) {
			return array(
				'key'          => 'forms_mapped',
				'number'       => 5,
				'title'        => __( 'Forms mapeados', 'wppe-bridge' ),
				'description'  => __( 'Cada form que envia leads al CRM debe tener su mapeo: que campo del form va a que campo del CRM, mas los defaults (canal, fuente, tipo de interes, proyecto).', 'wppe-bridge' ),
				'status'       => self::STATUS_PENDING,
				'detail'       => __( 'Ningun form tiene mapeo configurado.', 'wppe-bridge' ),
				'action_url'   => $mapping_url,
				'action_label' => __( 'Configurar mapeo', 'wppe-bridge' ),
			);
		}

		// Hay forms mapeados — chequeamos si alguno esta incompleto.
		if ( $incomplete > 0 ) {
			return array(
				'key'          => 'forms_mapped',
				'number'       => 5,
				'title'        => __( 'Forms mapeados', 'wppe-bridge' ),
				'description'  => __( 'Hay forms con mapeo incompleto — les faltan campos obligatorios (fname, input_channel_id o interest_type_id). Sperant rechaza con 422 los leads sin estos campos.', 'wppe-bridge' ),
				'status'       => self::STATUS_WARN,
				'detail'       => sprintf(
					/* translators: 1: incompletos, 2: total */
					__( '%1$d de %2$d forms tienen mapeo incompleto.', 'wppe-bridge' ),
					$incomplete,
					$total
				),
				'action_url'   => $mapping_url,
				'action_label' => __( 'Completar mapeo', 'wppe-bridge' ),
			);
		}

		return array(
			'key'          => 'forms_mapped',
			'number'       => 5,
			'title'        => __( 'Forms mapeados', 'wppe-bridge' ),
			'description'  => __( 'Cada form que envia leads al CRM debe tener su mapeo: que campo del form va a que campo del CRM, mas los defaults (canal, fuente, tipo de interes, proyecto).', 'wppe-bridge' ),
			'status'       => self::STATUS_DONE,
			'detail'       => sprintf(
				/* translators: %d = numero de forms con mapeo completo */
				_n( '%d form con mapeo completo.', '%d forms con mapeo completo.', $total, 'wppe-bridge' ),
				$total
			),
			'action_url'   => $mapping_url,
			'action_label' => __( 'Ver / editar mapeos', 'wppe-bridge' ),
		);
	}

	/**
	 * Paso 6: modulos opcionales activados.
	 *
	 * @param string $modules_url URL de Modulos.
	 * @return array<string,mixed>
	 */
	private static function step_modules_activated( string $modules_url ): array {
		$module_options = array(
			'wppe_bridge_module_utm_capture_enabled',
			'wppe_bridge_module_submit_lock_enabled',
			'wppe_bridge_module_meta_capi_enabled',
			'wppe_bridge_module_thank_you_pixel_enabled',
		);

		$active = 0;
		foreach ( $module_options as $opt ) {
			if ( get_option( $opt, false ) ) {
				++$active;
			}
		}

		return array(
			'key'          => 'modules_activated',
			'number'       => 6,
			'title'        => __( 'Modulos opcionales (recomendado)', 'wppe-bridge' ),
			'description'  => __( 'Cuatro modulos opcionales mejoran la calidad de los leads y la atribucion: <strong>UTM Capture</strong> (captura UTMs reales del visitante), <strong>Submit Lock</strong> (previene envio doble), <strong>Meta CAPI</strong> (server-side a Meta Conversions API), <strong>Thank You Pixel</strong> (browser pixel sincronizado con CAPI). Recomendado activar al menos UTM Capture + Submit Lock siempre.', 'wppe-bridge' ),
			'status'       => $active > 0 ? self::STATUS_DONE : self::STATUS_OPTIONAL,
			'detail'       => sprintf(
				/* translators: 1: cuantos activos, 2: total */
				__( '%1$d/%2$d modulos activos.', 'wppe-bridge' ),
				$active,
				count( $module_options )
			),
			'action_url'   => $modules_url,
			'action_label' => __( 'Configurar modulos', 'wppe-bridge' ),
		);
	}

	/**
	 * Paso 7: lead de prueba enviado (busca en logs).
	 *
	 * @param string $logs_url URL de Logs.
	 * @return array<string,mixed>
	 */
	private static function step_test_lead_sent( string $logs_url ): array {
		// Buscar en logs si hay algun lead con __BRIDGE_TEST__ en context.
		// Si la tabla no existe (caso pre-activacion), retornamos pending.
		global $wpdb;
		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
			return array(
				'key'          => 'test_lead_sent',
				'number'       => 7,
				'title'        => __( 'Lead de prueba enviado', 'wppe-bridge' ),
				'description'  => __( 'Manda un lead de prueba con prefijo <code>__BRIDGE_TEST__</code> al form del cliente y verifica que llegue al CRM.', 'wppe-bridge' ),
				'status'       => self::STATUS_PENDING,
				'detail'       => __( 'No se pudo verificar (sin acceso a DB).', 'wppe-bridge' ),
				'action_url'   => $logs_url,
				'action_label' => __( 'Ver logs', 'wppe-bridge' ),
			);
		}

		$table = $wpdb->prefix . 'wppebridge_logs';
		// Tabla controlada por el plugin (prefijo + nombre constante),
		// no input externo. Sql interpolado intencional.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$found = $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}` WHERE message = 'lead_sent' AND context LIKE '%__BRIDGE_TEST__%'" );
		// phpcs:enable
		$count = max( 0, (int) $found );

		if ( $count > 0 ) {
			return array(
				'key'          => 'test_lead_sent',
				'number'       => 7,
				'title'        => __( 'Lead de prueba enviado', 'wppe-bridge' ),
				'description'  => __( 'Validacion end-to-end: un lead con datos de prueba llego al CRM correctamente.', 'wppe-bridge' ),
				'status'       => self::STATUS_DONE,
				'detail'       => sprintf(
					/* translators: %d = count */
					_n( '%d lead de prueba registrado en Logs.', '%d leads de prueba registrados en Logs.', $count, 'wppe-bridge' ),
					$count
				),
				'action_url'   => $logs_url,
				'action_label' => __( 'Ver logs', 'wppe-bridge' ),
			);
		}

		return array(
			'key'          => 'test_lead_sent',
			'number'       => 7,
			'title'        => __( 'Lead de prueba enviado', 'wppe-bridge' ),
			'description'  => __( 'Manda un lead de prueba con prefijo <code>__BRIDGE_TEST__</code> al form publico del sitio. Espera ~60 segundos (o ejecuta <code>wp wppe-bridge worker run</code>) y revisa Logs. Confirmar tambien que el cliente nuevo aparezca en el panel del CRM con los IDs correctos.', 'wppe-bridge' ),
			'status'       => self::STATUS_PENDING,
			'detail'       => __( 'Aun no se registro ningun lead con __BRIDGE_TEST__.', 'wppe-bridge' ),
			'action_url'   => $logs_url,
			'action_label' => __( 'Ver logs', 'wppe-bridge' ),
		);
	}

	/**
	 * Cards de diagnostico de entorno (PHP, web server, SMTP, hosting).
	 *
	 * Delegadas al `Environment_Diagnostics` para mantener este
	 * orquestador legible. Devuelve `array()` si la clase no esta
	 * cargada (tests que no la incluyen).
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function environment_cards(): array {
		if ( ! class_exists( 'WPPE_Bridge_Environment_Diagnostics' ) ) {
			return array();
		}
		return WPPE_Bridge_Environment_Diagnostics::cards();
	}

	/**
	 * Pasos especificos del CRM activo (delegado al Destination).
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function crm_specific_steps(): array {
		if ( ! class_exists( 'WPPE_Bridge_Destination_Factory' ) ) {
			return array();
		}
		$registry = WPPE_Bridge_Destination_Factory::registry();
		$slug     = WPPE_Bridge_Destination_Factory::active_slug();
		$class    = $registry[ $slug ] ?? null;
		if ( null === $class || ! method_exists( $class, 'setup_guide' ) ) {
			return array();
		}
		$steps = $class::setup_guide();
		return is_array( $steps ) ? $steps : array();
	}

	/**
	 * Label legible del CRM activo.
	 *
	 * @return string
	 */
	private static function active_destination_label(): string {
		if ( ! class_exists( 'WPPE_Bridge_Destination_Factory' ) ) {
			return 'Sperant';
		}
		$registry = WPPE_Bridge_Destination_Factory::registry();
		$slug     = WPPE_Bridge_Destination_Factory::active_slug();
		$class    = $registry[ $slug ] ?? null;
		if ( null === $class || ! method_exists( $class, 'label' ) ) {
			return $slug;
		}
		return (string) $class::label();
	}
}
