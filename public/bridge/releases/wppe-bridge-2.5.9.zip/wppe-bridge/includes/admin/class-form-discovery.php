<?php
/**
 * Discovery de forms instalados en el WordPress.
 *
 * Consulta Fluent Forms y Gravity Forms via sus APIs publicas para
 * listar forms disponibles y sus campos. La pagina de Mapping usa
 * esto para poblar dropdowns y mostrar el editor sin que el admin
 * tenga que conocer IDs.
 *
 * Si ningun plugin de forms esta activo, devuelve estructura vacia
 * y la UI mostrara mensaje explicativo + opcion de mapping manual.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Discovery de forms instalados.
 */
final class WPPE_Bridge_Form_Discovery {

	/**
	 * Estructura uniforme de un form descubierto:
	 *   [
	 *     'id'     => string,   // ID stringificado (Fluent: numero, Gravity: numero).
	 *     'title'  => string,   // Titulo legible.
	 *     'fields' => [
	 *       ['name' => string, 'label' => string],
	 *     ],
	 *   ]
	 */

	/**
	 * Codigos de razon que retorna `discover_*_with_reason` cuando
	 * encontro 0 forms. Permiten que el banner de Mapeo muestre por
	 * que no detecto en lugar de un mensaje generico.
	 */
	public const REASON_OK              = 'ok';
	public const REASON_PLUGIN_INACTIVE = 'plugin_inactive';
	public const REASON_TABLE_MISSING   = 'table_missing';
	public const REASON_NO_FORMS        = 'no_forms';
	public const REASON_API_MISSING     = 'api_missing';

	/**
	 * Descubre todos los forms disponibles. Retorna estructura
	 * agrupada por plugin slug.
	 *
	 * @return array<string,array<int,array>> ['fluent' => [...], 'gravity' => [...]]
	 */
	public static function discover_all(): array {
		return array(
			'fluent'  => self::discover_fluent(),
			'gravity' => self::discover_gravity(),
		);
	}

	/**
	 * Variante de discover_all que ademas retorna el motivo cuando
	 * un plugin no aporta forms. Usado por la pagina de Mapeo para
	 * mostrar mensajes informativos.
	 *
	 * @return array{
	 *   forms:array<string,array<int,array>>,
	 *   reasons:array<string,string>
	 * }
	 */
	public static function discover_all_with_reasons(): array {
		[ $fluent_forms, $fluent_reason ]   = self::discover_fluent_with_reason();
		[ $gravity_forms, $gravity_reason ] = self::discover_gravity_with_reason();
		return array(
			'forms'   => array(
				'fluent'  => $fluent_forms,
				'gravity' => $gravity_forms,
			),
			'reasons' => array(
				'fluent'  => $fluent_reason,
				'gravity' => $gravity_reason,
			),
		);
	}

	/**
	 * Detecta forms de Fluent Forms si el plugin esta activo.
	 *
	 * Usa `$wpdb` directo en lugar de `wpFluent()->table()->get()`
	 * porque el query builder interno de Fluent puede cambiar entre
	 * versiones (lo hizo en >=5.x). La estructura de la tabla
	 * `fluentform_forms` (columnas `id`, `title`, `form_fields`)
	 * esta documentada oficialmente y es estable. No viola D2 — esto
	 * NO es polling de submissions, es lookup puntual de metadata
	 * de forms desde el admin.
	 *
	 * @return array<int,array>
	 */
	public static function discover_fluent(): array {
		[ $forms, ] = self::discover_fluent_with_reason();
		return $forms;
	}

	/**
	 * Variante con motivo. Retorna `[forms[], reason]`.
	 *
	 * @return array{0:array<int,array>,1:string}
	 */
	public static function discover_fluent_with_reason(): array {
		if ( ! WPPE_Bridge_Fluent_Forms_Adapter::is_available() ) {
			return array( array(), self::REASON_PLUGIN_INACTIVE );
		}

		global $wpdb;
		$table = $wpdb->prefix . 'fluentform_forms';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( $exists !== $table ) {
			return array( array(), self::REASON_TABLE_MISSING );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( "SELECT id, title, form_fields FROM `{$table}` ORDER BY id ASC" );
		if ( ! is_array( $rows ) || empty( $rows ) ) {
			return array( array(), self::REASON_NO_FORMS );
		}

		$out = array();
		foreach ( $rows as $row ) {
			$row_arr = is_object( $row ) ? (array) $row : (array) $row;
			$id      = isset( $row_arr['id'] ) ? (string) $row_arr['id'] : '';
			$title   = isset( $row_arr['title'] ) ? (string) $row_arr['title'] : '';
			if ( '' === $id ) {
				continue;
			}
			$out[] = array(
				'id'     => $id,
				'title'  => '' !== $title ? $title : sprintf( 'Form #%s', $id ),
				'fields' => self::parse_fluent_fields( $row_arr['form_fields'] ?? '' ),
			);
		}

		if ( empty( $out ) ) {
			return array( array(), self::REASON_NO_FORMS );
		}
		return array( $out, self::REASON_OK );
	}

	/**
	 * Detecta forms de Gravity Forms si el plugin esta activo.
	 *
	 * @return array<int,array>
	 */
	public static function discover_gravity(): array {
		[ $forms, ] = self::discover_gravity_with_reason();
		return $forms;
	}

	/**
	 * Variante con motivo. Retorna `[forms[], reason]`.
	 *
	 * @return array{0:array<int,array>,1:string}
	 */
	public static function discover_gravity_with_reason(): array {
		if ( ! WPPE_Bridge_Gravity_Forms_Adapter::is_available() ) {
			return array( array(), self::REASON_PLUGIN_INACTIVE );
		}
		if ( ! class_exists( 'GFAPI' ) || ! method_exists( 'GFAPI', 'get_forms' ) ) {
			return array( array(), self::REASON_API_MISSING );
		}

		$forms = \GFAPI::get_forms();
		if ( ! is_array( $forms ) || empty( $forms ) ) {
			return array( array(), self::REASON_NO_FORMS );
		}

		$out = array();
		foreach ( $forms as $form ) {
			$form_arr = is_array( $form ) ? $form : (array) $form;
			$id       = isset( $form_arr['id'] ) ? (string) $form_arr['id'] : '';
			$title    = isset( $form_arr['title'] ) ? (string) $form_arr['title'] : '';
			if ( '' === $id ) {
				continue;
			}
			$out[] = array(
				'id'     => $id,
				'title'  => '' !== $title ? $title : sprintf( 'Form #%s', $id ),
				'fields' => self::parse_gravity_fields( $form_arr['fields'] ?? array() ),
			);
		}

		if ( empty( $out ) ) {
			return array( array(), self::REASON_NO_FORMS );
		}
		return array( $out, self::REASON_OK );
	}

	/**
	 * Parsea el campo `form_fields` de Fluent (JSON). El JSON tiene
	 * `fields[]` con `attributes.name` y `settings.label`. Tolerante
	 * a estructuras viejas.
	 *
	 * @param mixed $raw String JSON, array o null.
	 * @return array<int,array{name:string,label:string}>
	 */
	public static function parse_fluent_fields( $raw ): array {
		$decoded = is_string( $raw ) ? json_decode( $raw, true ) : ( is_array( $raw ) ? $raw : array() );
		if ( ! is_array( $decoded ) ) {
			return array();
		}

		$fields = isset( $decoded['fields'] ) && is_array( $decoded['fields'] ) ? $decoded['fields'] : array();
		$out    = array();
		foreach ( $fields as $f ) {
			if ( ! is_array( $f ) ) {
				continue;
			}
			$name  = '';
			$label = '';
			if ( isset( $f['attributes']['name'] ) && is_string( $f['attributes']['name'] ) ) {
				$name = $f['attributes']['name'];
			}
			if ( isset( $f['settings']['label'] ) && is_string( $f['settings']['label'] ) ) {
				$label = $f['settings']['label'];
			}
			if ( '' === $name ) {
				continue;
			}
			$out[] = array(
				'name'  => $name,
				'label' => '' !== $label ? $label : $name,
			);

			// Campos compound (input_name): expandir sub-fields virtuales
			// con dot-notation. Permite que el operador mapee
			// `names.first_name` → `fname` y `names.last_name` → `lname`
			// directamente desde el dropdown, sin tener que confiar en
			// el flatten automatico del adapter.
			$element = isset( $f['element'] ) && is_string( $f['element'] ) ? $f['element'] : '';
			if ( 'input_name' === $element && isset( $f['fields'] ) && is_array( $f['fields'] ) ) {
				foreach ( $f['fields'] as $sub_key => $sub_def ) {
					$sub_name  = isset( $sub_def['attributes']['name'] ) && is_string( $sub_def['attributes']['name'] )
						? $sub_def['attributes']['name']
						: (string) $sub_key;
					$sub_label = isset( $sub_def['settings']['label'] ) && is_string( $sub_def['settings']['label'] )
						? $sub_def['settings']['label']
						: $sub_name;
					if ( '' === $sub_name ) {
						continue;
					}
					$out[] = array(
						'name'  => $name . '.' . $sub_name,
						'label' => sprintf( '%s — %s', '' !== $label ? $label : $name, $sub_label ),
					);
				}
			}
		}
		return $out;
	}

	/**
	 * Convierte la lista de fields de Gravity a la estructura uniforme.
	 * Prefiere `adminLabel` (mas estable), fallback a `label`. El
	 * `name` que devolvemos es exactamente lo que el adapter Gravity
	 * usa para mapear (ver class-gravity-forms-adapter.php).
	 *
	 * @param mixed $fields Lista de fields (array o objetos GF_Field).
	 * @return array<int,array{name:string,label:string}>
	 */
	public static function parse_gravity_fields( $fields ): array {
		if ( ! is_array( $fields ) ) {
			return array();
		}
		$out = array();
		foreach ( $fields as $field ) {
			$f         = is_array( $field ) ? $field : (array) $field;
			$id        = isset( $f['id'] ) ? (string) $f['id'] : '';
			$admin_lbl = isset( $f['adminLabel'] ) && is_string( $f['adminLabel'] ) ? $f['adminLabel'] : '';
			$label     = isset( $f['label'] ) && is_string( $f['label'] ) ? $f['label'] : '';
			$name      = '' !== $admin_lbl ? $admin_lbl : ( '' !== $label ? $label : 'field_' . $id );
			$out[]     = array(
				'name'  => $name,
				'label' => '' !== $label ? $label : $name,
			);
		}
		return $out;
	}
}
