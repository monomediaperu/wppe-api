<?php
/**
 * Diagnostico del entorno (PHP, web server, SMTP, hosting WP.pe).
 *
 * Cards informativas, agnosticas al CRM, que aparecen en la sub-pagina
 * "Inicio" entre "Pasos de instalacion" y "Recursos". Sirven para que
 * el operador (equipo Mono Media o cliente externo) sepa si el stack
 * que corre el plugin es optimo, y reciba recomendaciones cuando no
 * lo es.
 *
 * Reusa los STATUS_* del Help_Page para que la vista renderice
 * uniformemente.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Generador de cards de diagnostico de entorno.
 */
final class WPPE_Bridge_Environment_Diagnostics {

	/**
	 * Constante que el cliente WP.pe define en `wp-config.php` para
	 * marcar la instalacion como "hosting administrado por Mono Media".
	 *
	 * Conocida y documentada — el plugin la respeta para ocultar la
	 * recomendacion de migrar a WP.pe cuando ya esta en WP.pe.
	 */
	public const WPPE_MANAGED_CONSTANT = 'WPPE_MANAGED';

	/**
	 * URL publica de MailNube (servicio SMTP de Mono Media).
	 */
	public const MAILNUBE_URL = 'https://mailnube.com';

	/**
	 * URL publica de WP.pe (hosting WordPress administrado de Mono Media).
	 */
	public const WPPE_URL = 'https://wp.pe';

	/**
	 * Hook cron del worker — duplicado de
	 * {@see WPPE_Bridge_Activator::CRON_HOOK} para mantener este
	 * archivo independiente del activator en tests.
	 */
	public const WORKER_TICK_HOOK = 'wppe_bridge_worker_tick';

	/**
	 * Umbral en segundos despues del cual consideramos que el worker
	 * dejo de correr. 5 minutos: el worker corre cada 1 minuto, asi
	 * que >5 min sin tick es signal real (no jitter del cron).
	 */
	public const STALE_TICK_THRESHOLD_SECONDS = 300;

	/**
	 * Plugins SMTP conocidos. Cada entrada: slug del basename del plugin
	 * tal como aparece en `active_plugins` -> nombre legible.
	 *
	 * Si alguno cambia su archivo principal en una nueva version, se
	 * puede agregar la nueva variante sin romper deteccion previa.
	 *
	 * @return array<string,string>
	 */
	public static function known_smtp_plugins(): array {
		return array(
			'wp-mail-smtp/wp_mail_smtp.php' => 'WP Mail SMTP',
			'fluent-smtp/fluent-smtp.php'   => 'FluentSMTP',
			'post-smtp/postman-smtp.php'    => 'Post SMTP',
			'mailin/sendinblue.php'         => 'Brevo (ex Sendinblue)',
			'brevo/brevo.php'               => 'Brevo',
			'easy-wp-smtp/easy-wp-smtp.php' => 'Easy WP SMTP',
		);
	}

	/**
	 * Genera todas las cards.
	 *
	 * Mismo shape que los pasos del Help_Page para que la vista
	 * renderice uniformemente.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function cards(): array {
		return array(
			self::card_php_version(),
			self::card_web_server(),
			self::card_wp_cron(),
			self::card_smtp_detection(),
			self::card_license_hosting(),
		);
	}

	/**
	 * Card PHP version. Thresholds:
	 * - <8.1 → PENDING (deprecated por WP, riesgo).
	 * - 8.1  → WARN (minimo soportado, recomendado upgrade).
	 * - ≥8.2 → DONE (recomendado).
	 *
	 * El detail muestra las 3 versiones (actual, minimo requerido,
	 * recomendado) en una mini-tabla — operadores pidieron que
	 * se vea claro contra que comparar (v1.2.6).
	 *
	 * @return array<string,mixed>
	 */
	public static function card_php_version(): array {
		$version = self::detect_php_version();
		$status  = self::evaluate_php_version( $version );

		// Detail de 3 lineas: actual + minimo + recomendado.
		$detail_table = sprintf(
			'<strong>%s:</strong> PHP %s<br><strong>%s:</strong> PHP 8.1<br><strong>%s:</strong> PHP 8.2 o superior',
			esc_html__( 'Tu version', 'wppe-bridge' ),
			esc_html( $version ),
			esc_html__( 'Minimo requerido', 'wppe-bridge' ),
			esc_html__( 'Recomendado', 'wppe-bridge' )
		);

		if ( WPPE_Bridge_Help_Page::STATUS_DONE === $status ) {
			$detail = $detail_table . '<br><em>' . esc_html__( 'OK — cumple con el minimo recomendado (8.2+).', 'wppe-bridge' ) . '</em>';
		} elseif ( WPPE_Bridge_Help_Page::STATUS_WARN === $status ) {
			$detail = $detail_table . '<br><em>' . esc_html__( 'Cumple el minimo, pero recomendamos actualizar a PHP 8.2 o superior por seguridad y velocidad.', 'wppe-bridge' ) . '</em>';
		} else {
			$detail = $detail_table . '<br><em>' . esc_html__( 'Version sin soporte. Actualiza a PHP 8.2 o superior con tu proveedor de hosting.', 'wppe-bridge' ) . '</em>';
		}

		return array(
			'key'          => 'php_version',
			'icon'         => '🐘',
			'title'        => __( 'Version de PHP', 'wppe-bridge' ),
			'description'  => __( 'El plugin requiere PHP 8.1 o superior. Versiones antiguas son inseguras y mas lentas. Si tu proveedor no ofrece PHP 8.2+, considera migrar.', 'wppe-bridge' ),
			'status'       => $status,
			'detail'       => $detail,
			'action_url'   => null,
			'action_label' => null,
		);
	}

	/**
	 * Card web server (Apache / nginx / LiteSpeed / desconocido).
	 *
	 * Tiers:
	 * - Apache    → WARN  (lento, considerar migrar).
	 * - nginx     → DONE  (correcto; LiteSpeed es mas rapido).
	 * - LiteSpeed → DONE  (optimo).
	 * - unknown   → OPTIONAL (no se pudo detectar).
	 *
	 * v1.2.6: el detail ahora muestra la version exacta detectada
	 * en una linea destacada + tabla de opciones por tier para
	 * que el operador entienda donde esta su servidor en el ranking.
	 *
	 * @return array<string,mixed>
	 */
	public static function card_web_server(): array {
		$detected = self::detect_web_server();
		$family   = $detected['family'];
		$raw      = $detected['raw'];

		$status     = WPPE_Bridge_Help_Page::STATUS_OPTIONAL;
		$icon_speed = '🖥';

		// Linea principal: que se detecto.
		$detected_line = sprintf(
			'<strong>%s:</strong> %s',
			esc_html__( 'Detectado', 'wppe-bridge' ),
			'' === $raw ? esc_html__( 'no se pudo identificar', 'wppe-bridge' ) : esc_html( $raw )
		);

		// Tabla de opciones (siempre visible para que se entienda
		// el ranking) — la fila del servidor actual queda <strong>.
		$options_lines = array(
			array( 'apache', '🐌 Apache', __( 'lento, evitar', 'wppe-bridge' ) ),
			array( 'nginx', '🚀 nginx', __( 'bueno', 'wppe-bridge' ) ),
			array( 'openlitespeed', '⚡ OpenLiteSpeed', __( 'rapido, gratis', 'wppe-bridge' ) ),
			array( 'litespeed_ee', '⚡⚡ LiteSpeed Enterprise', __( 'mas rapido, pagado', 'wppe-bridge' ) ),
		);

		$current_match = self::map_family_to_option_key( $family, $raw );

		$options_html = '<br><br><strong>' . esc_html__( 'Opciones (de menos a mas recomendado)', 'wppe-bridge' ) . ':</strong>';
		foreach ( $options_lines as $opt ) {
			$is_current    = $opt[0] === $current_match;
			$line          = sprintf( '%s — %s', $opt[1], $opt[2] );
			$options_html .= '<br>';
			if ( $is_current ) {
				$options_html .= '<strong>' . esc_html( $line ) . ' ← ' . esc_html__( 'tu servidor', 'wppe-bridge' ) . '</strong>';
			} else {
				$options_html .= esc_html( $line );
			}
		}

		// Status/icon segun family.
		if ( 'apache' === $family ) {
			$status     = WPPE_Bridge_Help_Page::STATUS_WARN;
			$icon_speed = '🐌';
		} elseif ( 'nginx' === $family ) {
			$status     = WPPE_Bridge_Help_Page::STATUS_DONE;
			$icon_speed = '🚀';
		} elseif ( 'litespeed' === $family ) {
			$status     = WPPE_Bridge_Help_Page::STATUS_DONE;
			$icon_speed = '⚡';
		}

		$detail = $detected_line . $options_html;

		return array(
			'key'          => 'web_server',
			'icon'         => $icon_speed,
			'title'        => __( 'Servidor web', 'wppe-bridge' ),
			'description'  => __( 'El plugin funciona en cualquier servidor web. Esta card te muestra cual estas usando y donde esta en el ranking de performance — para que sepas si vale la pena migrar.', 'wppe-bridge' ),
			'status'       => $status,
			'detail'       => $detail,
			'action_url'   => null,
			'action_label' => null,
		);
	}

	/**
	 * Mapea family + raw del SERVER_SOFTWARE a la key de la tabla de
	 * opciones de la card. Para LiteSpeed distingue OpenLiteSpeed
	 * (free, identificado por `lsws`) vs LiteSpeed Enterprise (paid,
	 * identificado por `LiteSpeed/X.Y` con numero de version).
	 *
	 * V2.5.7: cuando el sitio esta gestionado por Mono Nube (whitelist
	 * de License_Manager) y la familia es LiteSpeed, asumimos Enterprise
	 * directamente — todas las instalaciones Mono Nube corren LiteSpeed
	 * EE. Esto cubre el caso real reportado donde el `SERVER_SOFTWARE`
	 * de un cliente Mono Nube no traia el sufijo `/X.Y` esperado por el
	 * regex y caia silenciosamente a `openlitespeed` (incorrecto).
	 *
	 * @param string $family Family detectada (`detect_web_server`).
	 * @param string $raw    SERVER_SOFTWARE crudo.
	 * @return string|null   Key de la tabla, o null si no matchea.
	 */
	public static function map_family_to_option_key( string $family, string $raw ): ?string {
		$lower = strtolower( $raw );
		if ( 'apache' === $family ) {
			return 'apache';
		}
		if ( 'nginx' === $family ) {
			return 'nginx';
		}
		if ( 'litespeed' === $family ) {
			// `lsws` = OpenLiteSpeed (gratis). `LiteSpeed/X.Y` con
			// numero suele ser Enterprise.
			if ( false !== strpos( $lower, 'lsws' ) ) {
				return 'openlitespeed';
			}
			if ( preg_match( '#litespeed/\d#i', $raw ) ) {
				return 'litespeed_ee';
			}
			// v2.5.7: sin pista clara via header — si el sitio es Mono
			// Nube gestionado, asumimos Enterprise (todas las instalaciones
			// Mono Nube corren LiteSpeed EE). Resto cae al fallback historico.
			if ( class_exists( 'WPPE_Bridge_License_Manager' )
				&& WPPE_Bridge_License_Manager::is_managed() ) {
				return 'litespeed_ee';
			}
			// Sin pista clara: asumimos OpenLiteSpeed (mas comun).
			return 'openlitespeed';
		}
		return null;
	}

	/**
	 * Card SMTP. Detecta si hay un plugin SMTP conocido activo.
	 *
	 * - Plugin SMTP detectado → DONE.
	 * - Sin plugin SMTP        → OPTIONAL (con CTA a MailNube).
	 *
	 * @return array<string,mixed>
	 */
	public static function card_smtp_detection(): array {
		$active = self::detect_active_smtp_plugins();

		// Description larga con ejemplos (v1.2.6) — operadores no tecnicos
		// pidieron entender CUANDO importa esto y QUE pierden si no lo
		// tienen.
		$description = __( '<strong>¿Para que sirve?</strong> WordPress envia correos automaticos: notificaciones de form al admin, recuperacion de contrasena, alertas del plugin. Sin SMTP esos correos salen via PHP <code>mail()</code> del servidor — muchas veces caen en spam o no llegan.<br><br><strong>Ejemplo concreto:</strong> un visitante envia el form de contacto. WordPress te manda un email "Nuevo lead recibido" al admin. Sin SMTP ese email puede no llegar a tu bandeja.<br><br><strong>¿Cuando importa?</strong> Siempre. Mas urgente si el sitio depende de correos para operar (notificaciones de leads, confirmaciones, alertas).', 'wppe-bridge' );

		if ( ! empty( $active ) ) {
			$names = array_values( $active );
			return array(
				'key'          => 'smtp_detection',
				'icon'         => '📧',
				'title'        => __( 'SMTP saliente configurado', 'wppe-bridge' ),
				'description'  => $description,
				'status'       => WPPE_Bridge_Help_Page::STATUS_DONE,
				'detail'       => sprintf(
					/* translators: %s = nombre del plugin SMTP */
					__( 'Plugin SMTP detectado: <strong>%s</strong>. Los correos automaticos de WordPress salen por este plugin con buena reputacion de entrega.', 'wppe-bridge' ),
					esc_html( implode( ', ', $names ) )
				),
				'action_url'   => null,
				'action_label' => null,
			);
		}

		return array(
			'key'          => 'smtp_detection',
			'icon'         => '📧',
			'title'        => __( 'SMTP saliente configurado', 'wppe-bridge' ),
			'description'  => $description . '<br><br><strong>' . esc_html__( 'Recomendacion Mono Media:', 'wppe-bridge' ) . '</strong> contratar un plan SMTP en <a href="https://mailnube.com" target="_blank" rel="noopener">mailnube.com</a> — servicio optimizado para WP.pe y compatible con plugins SMTP estandar.',
			'status'       => WPPE_Bridge_Help_Page::STATUS_OPTIONAL,
			'detail'       => __( 'Sin plugin SMTP activo. WordPress usa <code>mail()</code> del servidor (entrega no garantizada — los correos pueden caer en spam o perderse).', 'wppe-bridge' ),
			'action_url'   => self::MAILNUBE_URL,
			'action_label' => __( 'Conocer MailNube →', 'wppe-bridge' ),
		);
	}

	/**
	 * Card "Hosting Mono Nube" — 3 estados.
	 *
	 *   1. **managed**  → DONE  ☁ "Hosting Mono Nube — sin limite"
	 *   2. **demo**     → WARN  🧪 "Modo demo X/10 — solicita autorizacion"
	 *   3. **blocked**  → PENDING 🔒 "Demo agotado — worker bloqueado"
	 *
	 * Los dominios autorizados se administran centralmente por Mono Media
	 * (Mono Nube es la infraestructura de hosting; Mono Media es la empresa
	 * operadora). v2.0.2: el detail ya no expone el conteo de dominios
	 * autorizados (era info interna que no aporta valor al cliente).
	 *
	 * @return array<string,mixed>
	 */
	public static function card_license_hosting(): array {
		$state = WPPE_Bridge_License_Manager::state();

		if ( WPPE_Bridge_License_Manager::STATE_MANAGED === $state ) {
			return array(
				'key'          => 'license_hosting',
				'icon'         => '☁',
				'title'        => __( 'Hosting Mono Nube', 'wppe-bridge' ),
				'description'  => __( 'Este dominio esta autorizado y gestionado en Mono Nube — el plugin envia leads sin limite. La autorizacion se actualiza automaticamente.', 'wppe-bridge' ),
				'status'       => WPPE_Bridge_Help_Page::STATUS_DONE,
				'detail'       => __( 'Dominio gestionado por Mono Nube.', 'wppe-bridge' ),
				'action_url'   => null,
				'action_label' => null,
			);
		}

		$count     = WPPE_Bridge_License_Manager::demo_leads_count();
		$limit     = WPPE_Bridge_License_Manager::demo_lead_limit();
		$remaining = WPPE_Bridge_License_Manager::demo_leads_remaining();
		$host      = WPPE_Bridge_License_Manager::current_host();

		$mailto = 'mailto:soporte@mono.media?subject=' . rawurlencode( 'Solicito agregar dominio a whitelist WP.pe Bridge: ' . $host );

		if ( WPPE_Bridge_License_Manager::STATE_DEMO === $state ) {
			return array(
				'key'          => 'license_hosting',
				'icon'         => '🧪',
				'title'        => __( 'Modo demo (sitio externo)', 'wppe-bridge' ),
				'description'  => sprintf(
					/* translators: %s = host actual del sitio */
					__( 'Tu dominio (<code>%s</code>) no esta en la whitelist de Mono Media. Modo demo: el plugin envia hasta el limite de leads de prueba al CRM. Para leads ilimitados, escribe a <a href="mailto:soporte@mono.media">soporte@mono.media</a> y solicitamos agregar tu dominio a la whitelist.', 'wppe-bridge' ),
					$host
				),
				'status'       => WPPE_Bridge_Help_Page::STATUS_WARN,
				'detail'       => sprintf(
					/* translators: 1: count, 2: limit, 3: remaining */
					__( 'Demo: %1$d/%2$d leads enviados (%3$d restantes).', 'wppe-bridge' ),
					$count,
					$limit,
					$remaining
				),
				'action_url'   => $mailto,
				'action_label' => __( 'Solicitar whitelist →', 'wppe-bridge' ),
			);
		}

		// blocked.
		return array(
			'key'          => 'license_hosting',
			'icon'         => '🔒',
			'title'        => __( 'Worker bloqueado — whitelist requerida', 'wppe-bridge' ),
			'description'  => sprintf(
				/* translators: %s = host actual */
				__( 'Limite del modo demo agotado. Tu dominio (<code>%s</code>) no esta en la whitelist de Mono Media. Los leads quedan en cola pero NO se envian al CRM. Para reactivar, escribe a <a href="mailto:soporte@mono.media">soporte@mono.media</a> para que agregemos tu dominio a la whitelist — el worker se reactivara automaticamente en pocos minutos cuando aparezca en la lista.', 'wppe-bridge' ),
				$host
			),
			'status'       => WPPE_Bridge_Help_Page::STATUS_PENDING,
			'detail'       => sprintf(
				/* translators: 1: count, 2: limit */
				__( 'Demo agotado (%1$d/%2$d). Worker no envia hasta que el dominio aparezca en whitelist remota.', 'wppe-bridge' ),
				$count,
				$limit
			),
			'action_url'   => $mailto,
			'action_label' => __( 'Solicitar whitelist →', 'wppe-bridge' ),
		);
	}

	/**
	 * Card "WP-Cron" — checker en vivo del heartbeat del worker.
	 *
	 * Diagnostica si WordPress puede ejecutar tareas en background, que
	 * es REQUISITO para que el plugin entregue leads al CRM. Sin
	 * WP-Cron corriendo los leads quedan en estado `pending` para
	 * siempre.
	 *
	 * Estados detectados:
	 *
	 *   1. **`ok`** → DONE: evento agendado, ultimo tick reciente.
	 *   2. **`never_run`** → WARN: evento agendado, pero el worker nunca
	 *      tickeo (recien activado, o WP-Cron deshabilitado sin cron real).
	 *   3. **`stale`** → WARN: ultimo tick hace >5 min. Probable que el
	 *      cron del servidor se haya caido.
	 *   4. **`disabled_no_external`** → PENDING: `DISABLE_WP_CRON === true`
	 *      y el ultimo tick es viejo (cron real no esta configurado).
	 *   5. **`no_event`** → PENDING: el evento `wppe_bridge_worker_tick`
	 *      no esta agendado. Algo limpio el cron de WP — solucion:
	 *      desactivar y reactivar el plugin.
	 *
	 * @return array<string,mixed>
	 */
	public static function card_wp_cron(): array {
		$state = self::detect_wp_cron_state();

		switch ( $state['state'] ) {
			case 'ok':
				return array(
					'key'          => 'wp_cron',
					'icon'         => '⏱',
					'title'        => __( 'WP-Cron del worker', 'wppe-bridge' ),
					'description'  => __( 'WP-Cron es <strong>requisito</strong>: el plugin encola los leads y un worker en background los envia al CRM cada minuto. Si WP-Cron no corre, los leads quedan en <code>pending</code> sin enviarse.', 'wppe-bridge' ),
					'status'       => WPPE_Bridge_Help_Page::STATUS_DONE,
					'detail'       => sprintf(
						/* translators: %s = relative time */
						__( 'Worker activo. Ultimo tick: hace %s.', 'wppe-bridge' ),
						self::format_relative_seconds( $state['seconds_since_last_tick'] )
					),
					'action_url'   => null,
					'action_label' => null,
				);

			case 'never_run':
				return array(
					'key'          => 'wp_cron',
					'icon'         => '⏳',
					'title'        => __( 'WP-Cron del worker — pendiente', 'wppe-bridge' ),
					'description'  => __( 'El evento <code>wppe_bridge_worker_tick</code> esta agendado pero todavia no corrio. Si recien activaste el plugin, espera ~1 minuto y recarga. Si esperaste mas y sigue asi, configura el cron de servidor (ver <code>INSTALL.md</code> seccion WP-Cron).', 'wppe-bridge' ),
					'status'       => WPPE_Bridge_Help_Page::STATUS_WARN,
					'detail'       => __( 'El worker nunca tickeo desde que se activo el plugin.', 'wppe-bridge' ),
					'action_url'   => null,
					'action_label' => null,
				);

			case 'stale':
				return array(
					'key'          => 'wp_cron',
					'icon'         => '⚠',
					'title'        => __( 'WP-Cron del worker — sin actividad reciente', 'wppe-bridge' ),
					'description'  => __( 'El worker corrio antes pero hace mas de 5 minutos que no tickea. Probable causa: el cron del servidor que dispara WP-Cron se cayo. Verificar con <code>crontab -l | grep wp-cron</code> y reagendar si falta. Los leads en <code>pending</code> NO se envian hasta que el worker vuelva a correr.', 'wppe-bridge' ),
					'status'       => WPPE_Bridge_Help_Page::STATUS_WARN,
					'detail'       => sprintf(
						/* translators: %s = relative time */
						__( 'Ultimo tick: hace %s. Esperado: cada 1 minuto.', 'wppe-bridge' ),
						self::format_relative_seconds( $state['seconds_since_last_tick'] )
					),
					'action_url'   => null,
					'action_label' => null,
				);

			case 'disabled_no_external':
				// Snippet con el path REAL del WordPress detectado (v1.2.7)
				// — antes hardcoded /var/www/html. En hostings como Enhance
				// el path lleva un UUID y el operador tenia que adivinarlo.
				$wppe_bridge_abspath = self::detect_wp_abspath();
				$wppe_bridge_snippet = sprintf(
					'* * * * * /usr/bin/php %swp-cron.php > /dev/null 2&gt;&amp;1',
					rtrim( $wppe_bridge_abspath, '/' ) . '/'
				);
				return array(
					'key'          => 'wp_cron',
					'icon'         => '🔧',
					'title'        => __( 'WP-Cron deshabilitado — falta cron de servidor', 'wppe-bridge' ),
					'description'  => sprintf(
						/* translators: %s = crontab snippet ya armado con path real */
						__( 'Tu <code>wp-config.php</code> tiene <code>DISABLE_WP_CRON</code> activado pero no detectamos que un cron real este disparando <code>wp-cron.php</code>. Configura este crontab en el servidor (path ya rellenado con tu instalacion):<br><br><code>%s</code><br><br><strong>Alternativa rapida:</strong> editar <code>wp-config.php</code> y cambiar <code>DISABLE_WP_CRON</code> a <code>false</code> — WordPress usara su cron interno (se dispara con cada visita al sitio).', 'wppe-bridge' ),
						$wppe_bridge_snippet
					),
					'status'       => WPPE_Bridge_Help_Page::STATUS_PENDING,
					'detail'       => null === $state['seconds_since_last_tick']
						? __( '<code>DISABLE_WP_CRON</code> activado y el worker nunca corrio.', 'wppe-bridge' )
						: sprintf(
							/* translators: %s = relative time */
							__( '<code>DISABLE_WP_CRON</code> activado y ultimo tick hace %s.', 'wppe-bridge' ),
							self::format_relative_seconds( $state['seconds_since_last_tick'] )
						),
					'action_url'   => null,
					'action_label' => null,
				);

			case 'no_event':
			default:
				return array(
					'key'          => 'wp_cron',
					'icon'         => '🚫',
					'title'        => __( 'Evento del worker no agendado', 'wppe-bridge' ),
					'description'  => __( 'El evento <code>wppe_bridge_worker_tick</code> no esta agendado en WP-Cron. Probable causa: alguna herramienta de mantenimiento limpio los cron jobs. Solucion: desactiva y reactiva el plugin desde Plugins → WP.pe Bridge para que el activator vuelva a registrarlo.', 'wppe-bridge' ),
					'status'       => WPPE_Bridge_Help_Page::STATUS_PENDING,
					'detail'       => __( 'Sin evento agendado. Los leads encolados NO se envian.', 'wppe-bridge' ),
					'action_url'   => null,
					'action_label' => null,
				);
		}
	}

	// ---------- detectores aislados (testeables) ----------

	/**
	 * Devuelve la version de PHP en uso.
	 *
	 * Aislado para que los tests puedan inyectar via filter.
	 *
	 * @return string
	 */
	public static function detect_php_version(): string {
		$default = PHP_VERSION;
		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'wppe_bridge_detect_php_version', $default );
			if ( is_string( $filtered ) && '' !== $filtered ) {
				return $filtered;
			}
		}
		return $default;
	}

	/**
	 * Evalua una version de PHP y devuelve el STATUS correspondiente.
	 *
	 * @param string $version Version semver (ej. '8.1.27', '7.4.33').
	 * @return string Constante de Help_Page::STATUS_*.
	 */
	public static function evaluate_php_version( string $version ): string {
		if ( '' === $version ) {
			return WPPE_Bridge_Help_Page::STATUS_OPTIONAL;
		}
		if ( version_compare( $version, '8.2.0', '>=' ) ) {
			return WPPE_Bridge_Help_Page::STATUS_DONE;
		}
		if ( version_compare( $version, '8.1.0', '>=' ) ) {
			return WPPE_Bridge_Help_Page::STATUS_WARN;
		}
		return WPPE_Bridge_Help_Page::STATUS_PENDING;
	}

	/**
	 * Detecta el servidor web a partir de `$_SERVER['SERVER_SOFTWARE']`.
	 *
	 * Devuelve `['family' => 'apache'|'nginx'|'litespeed'|'unknown', 'raw' => string]`.
	 *
	 * @return array{family:string,raw:string}
	 */
	public static function detect_web_server(): array {
		$raw = '';
		if ( isset( $_SERVER['SERVER_SOFTWARE'] ) && is_string( $_SERVER['SERVER_SOFTWARE'] ) ) {
			$raw = function_exists( 'sanitize_text_field' )
				? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) )
				: (string) $_SERVER['SERVER_SOFTWARE']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		}
		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'wppe_bridge_detect_web_server', $raw );
			if ( is_string( $filtered ) ) {
				$raw = $filtered;
			}
		}

		$lower = strtolower( $raw );
		if ( '' === $lower ) {
			return array(
				'family' => 'unknown',
				'raw'    => '',
			);
		}

		// Litespeed primero (incluye OpenLiteSpeed y LiteSpeed Enterprise).
		if ( false !== strpos( $lower, 'litespeed' ) || false !== strpos( $lower, 'lsws' ) ) {
			return array(
				'family' => 'litespeed',
				'raw'    => $raw,
			);
		}
		if ( false !== strpos( $lower, 'nginx' ) ) {
			return array(
				'family' => 'nginx',
				'raw'    => $raw,
			);
		}
		if ( false !== strpos( $lower, 'apache' ) ) {
			return array(
				'family' => 'apache',
				'raw'    => $raw,
			);
		}

		return array(
			'family' => 'unknown',
			'raw'    => $raw,
		);
	}

	/**
	 * Devuelve los nombres legibles de plugins SMTP conocidos que estan
	 * activos. Lee `active_plugins` de wp_options (incluye plugins
	 * activados solo en single-site; multisite network-wide queda
	 * para una iteracion futura si aparece demanda).
	 *
	 * @return array<string,string> map plugin_basename → label.
	 */
	public static function detect_active_smtp_plugins(): array {
		$active = get_option( 'active_plugins', array() );
		if ( ! is_array( $active ) ) {
			return array();
		}
		$known   = self::known_smtp_plugins();
		$matches = array();
		foreach ( $active as $basename ) {
			$key = (string) $basename;
			if ( isset( $known[ $key ] ) ) {
				$matches[ $key ] = $known[ $key ];
			}
		}
		return $matches;
	}

	/**
	 * Determina si la instalacion declara estar bajo hosting WP.pe via
	 * la constante {@see WPPE_MANAGED_CONSTANT}.
	 *
	 * Aislado para que los tests puedan inyectar via filter (no se
	 * puede `define` y `undef` entre tests).
	 *
	 * @return bool
	 */
	public static function is_wppe_managed(): bool {
		$default = defined( self::WPPE_MANAGED_CONSTANT ) && (bool) constant( self::WPPE_MANAGED_CONSTANT );
		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'wppe_bridge_is_wppe_managed', $default );
			return (bool) $filtered;
		}
		return $default;
	}

	/**
	 * Devuelve el path absoluto de la instalacion de WordPress.
	 *
	 * Usa la constante `ABSPATH` (definida por WordPress) y la
	 * filtra para tests. Si el constante no esta definida (caso de
	 * tests aislados), devuelve un placeholder neutro.
	 *
	 * @return string Path con trailing slash.
	 */
	public static function detect_wp_abspath(): string {
		$default = defined( 'ABSPATH' ) ? (string) ABSPATH : '/path/a/tu/wordpress/';
		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'wppe_bridge_detect_wp_abspath', $default );
			if ( is_string( $filtered ) && '' !== $filtered ) {
				return $filtered;
			}
		}
		return $default;
	}

	/**
	 * Determina si la constante `DISABLE_WP_CRON` esta en truthy.
	 *
	 * Acepta `true` (boolean) y `'true'` (string) — algunos paneles de
	 * hosting (Enhance entre ellos) escriben `define('DISABLE_WP_CRON', 'true')`
	 * con comillas. PHP lo trata como truthy igual y deshabilita cron,
	 * pero un check `=== true` lo perderia.
	 *
	 * Tambien tratamos `'1'` (string) como truthy. Y rechazamos
	 * `'false'` y `'0'` (strings explicitos) como falsy aunque PHP los
	 * considere truthy — son intencion clara del operador.
	 *
	 * Aislado por testabilidad — no se puede `define` y `undef` entre
	 * tests. Filter `wppe_bridge_detect_disable_wp_cron`.
	 *
	 * @return bool
	 */
	public static function detect_disable_wp_cron(): bool {
		$default = false;
		if ( defined( 'DISABLE_WP_CRON' ) ) {
			$raw = constant( 'DISABLE_WP_CRON' );
			if ( is_bool( $raw ) ) {
				$default = $raw;
			} elseif ( is_string( $raw ) ) {
				$lower = strtolower( trim( $raw ) );
				// Strings "false", "0", "" -> falsy. Lo demas truthy.
				$default = ! in_array( $lower, array( 'false', '0', '' ), true );
			} else {
				$default = (bool) $raw;
			}
		}
		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'wppe_bridge_detect_disable_wp_cron', $default );
			return (bool) $filtered;
		}
		return $default;
	}

	/**
	 * Determina si el evento del worker esta agendado en WP-Cron.
	 *
	 * Aislado para tests via filter `wppe_bridge_detect_worker_event_scheduled`.
	 *
	 * @return bool
	 */
	public static function detect_worker_event_scheduled(): bool {
		$default = function_exists( 'wp_next_scheduled' )
			? false !== wp_next_scheduled( self::WORKER_TICK_HOOK )
			: false;
		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'wppe_bridge_detect_worker_event_scheduled', $default );
			return (bool) $filtered;
		}
		return $default;
	}

	/**
	 * Lee el timestamp del ultimo tick del worker (option set por
	 * `WPPE_Bridge_Worker::record_tick()`). 0 = nunca corrio.
	 *
	 * @return int Unix timestamp UTC.
	 */
	public static function detect_worker_last_tick_at(): int {
		$default = (int) get_option( 'wppe_bridge_worker_last_tick_at', 0 );
		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'wppe_bridge_detect_worker_last_tick_at', $default );
			return (int) $filtered;
		}
		return $default;
	}

	/**
	 * Devuelve un snapshot del estado de WP-Cron para consumo de la
	 * card. Mantiene la logica de evaluacion separada del builder de
	 * texto para que sea facil de testear con casos.
	 *
	 * Shape:
	 *   - `state` (string): ok | never_run | stale | disabled_no_external | no_event.
	 *   - `disable_wp_cron` (bool).
	 *   - `event_scheduled` (bool).
	 *   - `last_tick_at` (int).
	 *   - `seconds_since_last_tick` (int|null).
	 *
	 * @return array<string,mixed>
	 */
	public static function detect_wp_cron_state(): array {
		$disable_wp_cron = self::detect_disable_wp_cron();
		$event_scheduled = self::detect_worker_event_scheduled();
		$last_tick_at    = self::detect_worker_last_tick_at();
		// phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.RequestedUTC -- test mocks via $GLOBALS['wppe_test_now']; en runtime equivale a time().
		$now = function_exists( 'current_time' ) ? (int) current_time( 'timestamp', 1 ) : time();

		$seconds_since = $last_tick_at > 0 ? max( 0, $now - $last_tick_at ) : null;

		$state = self::evaluate_wp_cron_state( $disable_wp_cron, $event_scheduled, $seconds_since );

		return array(
			'state'                   => $state,
			'disable_wp_cron'         => $disable_wp_cron,
			'event_scheduled'         => $event_scheduled,
			'last_tick_at'            => $last_tick_at,
			'seconds_since_last_tick' => $seconds_since,
		);
	}

	/**
	 * Evalua el estado del WP-Cron a partir de los detectores. Pura,
	 * sin side effects — perfecta para tabla de tests por caso.
	 *
	 * @param bool     $disable_wp_cron `DISABLE_WP_CRON` en wp-config.
	 * @param bool     $event_scheduled El evento del worker esta agendado.
	 * @param int|null $seconds_since   Segundos desde el ultimo tick (null = nunca).
	 * @return string Uno de los estados ok|never_run|stale|disabled_no_external|no_event.
	 */
	public static function evaluate_wp_cron_state( bool $disable_wp_cron, bool $event_scheduled, ?int $seconds_since ): string {
		// 1. Sin evento agendado: peor caso, ningun tick puede ocurrir.
		if ( ! $event_scheduled ) {
			return 'no_event';
		}

		// 2. Nunca tickeo. Diferenciamos por si DISABLE_WP_CRON o no.
		if ( null === $seconds_since ) {
			return $disable_wp_cron ? 'disabled_no_external' : 'never_run';
		}

		// 3. Tick reciente (<= umbral). Estado optimo.
		if ( $seconds_since <= self::STALE_TICK_THRESHOLD_SECONDS ) {
			return 'ok';
		}

		// 4. Tick viejo. Si DISABLE_WP_CRON, la causa es el cron real
		// que dejo de correr. Si no, podria ser cualquier cosa (sitio
		// sin trafico, error en el plugin) — lo marcamos como stale.
		return $disable_wp_cron ? 'disabled_no_external' : 'stale';
	}

	/**
	 * Formatea segundos como tiempo relativo legible (ej. "3 min",
	 * "2h", "1d 4h"). Aproximado: priorizamos legibilidad humana
	 * en admin, no precision absoluta.
	 *
	 * @param int|null $seconds Segundos. Null devuelve placeholder.
	 * @return string
	 */
	public static function format_relative_seconds( ?int $seconds ): string {
		if ( null === $seconds || $seconds < 0 ) {
			return '—';
		}
		if ( $seconds < 60 ) {
			return sprintf( /* translators: %d = seconds */ _n( '%d s', '%d s', $seconds, 'wppe-bridge' ), $seconds );
		}
		if ( $seconds < 3600 ) {
			$min = (int) floor( $seconds / 60 );
			return sprintf( /* translators: %d = minutes */ _n( '%d min', '%d min', $min, 'wppe-bridge' ), $min );
		}
		if ( $seconds < 86400 ) {
			$h = (int) floor( $seconds / 3600 );
			return sprintf( /* translators: %d = hours */ _n( '%d h', '%d h', $h, 'wppe-bridge' ), $h );
		}
		$d = (int) floor( $seconds / 86400 );
		$h = (int) floor( ( $seconds % 86400 ) / 3600 );
		if ( $h > 0 ) {
			return sprintf(
				/* translators: 1: days, 2: hours */
				__( '%1$dd %2$dh', 'wppe-bridge' ),
				$d,
				$h
			);
		}
		return sprintf( /* translators: %d = days */ _n( '%d d', '%d d', $d, 'wppe-bridge' ), $d );
	}
}
