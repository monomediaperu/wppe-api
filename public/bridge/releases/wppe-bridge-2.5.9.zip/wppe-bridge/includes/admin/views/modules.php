<?php
/**
 * Vista de la pagina admin "Modulos".
 *
 * Variables disponibles:
 *
 * @var array  $modules Lista de modulos disponibles.
 * @var string $flash   Codigo de flash ('saved' o '').
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Modulos', 'wppe-bridge' ); ?></h1>

	<?php if ( 'saved' === $flash ) : ?>
		<div class="notice notice-success is-dismissible">
			<p><?php esc_html_e( 'Modulos actualizados.', 'wppe-bridge' ); ?></p>
		</div>
	<?php endif; ?>

	<p>
		<?php esc_html_e( 'Activa solo los modulos que necesites. Cada uno se carga unicamente cuando esta encendido.', 'wppe-bridge' ); ?>
	</p>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="<?php echo esc_attr( WPPE_Bridge_Modules_Page::ACTION_SAVE ); ?>"/>
		<?php wp_nonce_field( WPPE_Bridge_Modules_Page::NONCE_ACTION ); ?>

		<table class="widefat striped" style="max-width:900px">
			<thead>
				<tr>
					<th style="width:200px"><?php esc_html_e( 'Modulo', 'wppe-bridge' ); ?></th>
					<th><?php esc_html_e( 'Descripcion', 'wppe-bridge' ); ?></th>
					<th style="width:120px;text-align:center"><?php esc_html_e( 'Configuracion', 'wppe-bridge' ); ?></th>
					<th style="width:80px;text-align:center"><?php esc_html_e( 'Activo', 'wppe-bridge' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $modules as $wppe_bridge_module ) :
					$wppe_bridge_is_on       = (bool) get_option( $wppe_bridge_module['option'], false );
					$wppe_bridge_config_page = isset( $wppe_bridge_module['config_page'] ) ? (string) $wppe_bridge_module['config_page'] : '';
					?>
					<tr>
						<td><strong><?php echo esc_html( $wppe_bridge_module['label'] ); ?></strong></td>
						<td><?php echo esc_html( $wppe_bridge_module['description'] ); ?></td>
						<td style="text-align:center">
							<?php
							if ( '' !== $wppe_bridge_config_page ) :
								$wppe_bridge_config_url = add_query_arg(
									array( 'page' => $wppe_bridge_config_page ),
									admin_url( 'admin.php' )
								);
								?>
								<a href="<?php echo esc_url( $wppe_bridge_config_url ); ?>" class="button button-small">
									<?php esc_html_e( 'Configurar', 'wppe-bridge' ); ?>
								</a>
							<?php else : ?>
								<em>—</em>
							<?php endif; ?>
						</td>
						<td style="text-align:center">
							<input
								type="checkbox"
								name="enabled[<?php echo esc_attr( $wppe_bridge_module['key'] ); ?>]"
								value="1"
								<?php checked( $wppe_bridge_is_on ); ?>
							/>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<?php submit_button( __( 'Guardar', 'wppe-bridge' ) ); ?>
	</form>
</div>
