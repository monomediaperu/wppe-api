<?php
/**
 * Vista de la pagina admin "Mapeo GHL".
 *
 * Variables disponibles (provistas por WPPE_Bridge_Ghl_Mapping_Page::render):
 *
 * @var array  $discovered           Forms detectados por plugin (fluent/gravity/elementor).
 * @var array  $discovery_reasons    Razones por las que algunos forms no se detectaron.
 * @var array  $catalogs             Catalogos GHL sincronizados.
 * @var array  $catalogs_errors      Errores parciales del ultimo sync.
 * @var int    $synced_at            Timestamp del ultimo sync (0 si nunca).
 * @var array  $mapping              Mapeo persistido por plugin->form->{fields}.
 * @var string $default_pipeline_id  ID del pipeline default para Opportunity.
 * @var string $default_stage_id     ID del stage default.
 * @var array  $utm_field_mapping    Map utm_key => custom_field_id.
 * @var array  $default_tags         Lista de tags default.
 * @var string $selected_plugin      Plugin slug seleccionado en URL.
 * @var string $selected_form        Form ID seleccionado en URL.
 * @var ?array $selected_form_data   Data del form seleccionado (null si no hay).
 * @var array  $existing_mapping     Mapeo persistido del form seleccionado.
 * @var array  $cf_for_utms          Custom Fields filtrados a TEXT/LARGE_TEXT (D-PR2-5).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

$wppe_bridge_flash   = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$wppe_bridge_missing = isset( $_GET['missing'] ) ? array_filter( array_map( 'sanitize_key', explode( ',', sanitize_text_field( wp_unslash( $_GET['missing'] ) ) ) ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

$wppe_bridge_pipelines  = isset( $catalogs['pipelines'] ) && is_array( $catalogs['pipelines'] ) ? $catalogs['pipelines'] : array();
$wppe_bridge_tags       = isset( $catalogs['tags'] ) && is_array( $catalogs['tags'] ) ? $catalogs['tags'] : array();
$wppe_bridge_has_synced = $synced_at > 0;
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Mapeo GoHighLevel', 'wppe-bridge' ); ?></h1>

	<?php if ( 'saved' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Mapeo del formulario guardado.', 'wppe-bridge' ); ?></p></div>
	<?php elseif ( 'global_saved' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Configuracion global guardada.', 'wppe-bridge' ); ?></p></div>
	<?php elseif ( 'error_required' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-error"><p>
			<?php esc_html_e( 'Faltan campos obligatorios:', 'wppe-bridge' ); ?>
			<code><?php echo esc_html( implode( ', ', $wppe_bridge_missing ) ); ?></code>.
			<?php esc_html_e( 'GHL acepta el contacto sin firstName, pero un lead web sin nombre es inutil para vendedores. Mapea al menos un campo del form a "firstName".', 'wppe-bridge' ); ?>
		</p></div>
	<?php elseif ( 'error_missing_form' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-error"><p><?php esc_html_e( 'Falta plugin o form ID en el POST.', 'wppe-bridge' ); ?></p></div>
	<?php endif; ?>


	<!-- ========================================================== -->
	<!-- Bloque 1: Sincronizacion de catalogos                       -->
	<!-- ========================================================== -->
	<h2><?php esc_html_e( 'Sincronizacion de catalogos', 'wppe-bridge' ); ?></h2>
	<p>
		<?php esc_html_e( 'Sincroniza pipelines (con stages anidados), Custom Fields y Tags desde la sub-account GHL configurada. Sin sync, los selectores de abajo aparecen vacios.', 'wppe-bridge' ); ?>
	</p>

	<table class="form-table" role="presentation">
		<tbody>
			<tr>
				<th scope="row"><?php esc_html_e( 'Estado', 'wppe-bridge' ); ?></th>
				<td>
					<?php if ( $wppe_bridge_has_synced ) : ?>
						<p>
							<span class="dashicons dashicons-yes-alt" style="color:#46b450"></span>
							<?php
							echo esc_html(
								sprintf(
									/* translators: %s: human-readable time diff */
									__( 'Ultima sincronizacion: hace %s', 'wppe-bridge' ),
									human_time_diff( $synced_at, time() )
								)
							);
							?>
						</p>
						<ul style="list-style:disc;margin-left:2em">
							<li>
								<strong><?php esc_html_e( 'Pipelines', 'wppe-bridge' ); ?>:</strong>
								<?php echo (int) count( $wppe_bridge_pipelines ); ?>
								<?php if ( isset( $catalogs_errors['pipelines'] ) ) : ?>
									<span style="color:#dc3232">— <?php echo esc_html( $catalogs_errors['pipelines'] ); ?></span>
								<?php endif; ?>
							</li>
							<li>
								<strong><?php esc_html_e( 'Custom Fields', 'wppe-bridge' ); ?>:</strong>
								<?php echo (int) count( isset( $catalogs['custom_fields'] ) && is_array( $catalogs['custom_fields'] ) ? $catalogs['custom_fields'] : array() ); ?>
								(<?php echo (int) count( $cf_for_utms ); ?>
								<?php esc_html_e( 'aceptables para UTMs — TEXT/LARGE_TEXT', 'wppe-bridge' ); ?>)
								<?php if ( isset( $catalogs_errors['custom_fields'] ) ) : ?>
									<span style="color:#dc3232">— <?php echo esc_html( $catalogs_errors['custom_fields'] ); ?></span>
								<?php endif; ?>
							</li>
							<li>
								<strong><?php esc_html_e( 'Tags', 'wppe-bridge' ); ?>:</strong>
								<?php echo (int) count( $wppe_bridge_tags ); ?>
								<?php if ( isset( $catalogs_errors['tags'] ) ) : ?>
									<span style="color:#dc3232">— <?php echo esc_html( $catalogs_errors['tags'] ); ?></span>
								<?php endif; ?>
							</li>
						</ul>
					<?php else : ?>
						<p>
							<span class="dashicons dashicons-warning" style="color:#dc3232"></span>
							<?php esc_html_e( 'No hay sincronizacion previa. Pulsa "Sincronizar catalogos" abajo.', 'wppe-bridge' ); ?>
						</p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Sincronizar', 'wppe-bridge' ); ?></th>
				<td>
					<button
						type="button"
						class="button button-primary"
						id="wppe-bridge-ghl-sync-btn"
						data-nonce="<?php echo esc_attr( wp_create_nonce( WPPE_Bridge_Admin_Ajax::NONCE_ACTION ) ); ?>"
					>
						<?php esc_html_e( 'Sincronizar catalogos GHL', 'wppe-bridge' ); ?>
					</button>
					<span id="wppe-bridge-ghl-sync-status" style="margin-left:1em"></span>
					<p class="description">
						<?php esc_html_e( 'Hace 3 GETs a la API GHL: pipelines, customFields, tags. Si alguno falla (token sin scope, etc.), los demas siguen sincronizando.', 'wppe-bridge' ); ?>
					</p>
				</td>
			</tr>
		</tbody>
	</table>

	<hr/>

	<!-- ========================================================== -->
	<!-- Bloque 2: Configuracion global (Opportunity + UTMs + Tags)  -->
	<!-- ========================================================== -->
	<h2><?php esc_html_e( 'Configuracion global', 'wppe-bridge' ); ?></h2>
	<p class="description">
		<?php esc_html_e( 'Ajustes que aplican a TODOS los forms. Cada form puede agregar tags adicionales en la seccion "Mapeo de campos por formulario" mas abajo.', 'wppe-bridge' ); ?>
	</p>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="<?php echo esc_attr( WPPE_Bridge_Ghl_Mapping_Page::ACTION_SAVE_GLOBAL_CONFIG ); ?>"/>
		<?php wp_nonce_field( WPPE_Bridge_Ghl_Mapping_Page::NONCE_GLOBAL_CONFIG ); ?>

		<table class="form-table" role="presentation">
			<tbody>
				<!-- Pipeline default -->
				<tr>
					<th scope="row">
						<label for="default_pipeline_id"><?php esc_html_e( 'Pipeline default (Opportunity)', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<select name="default_pipeline_id" id="default_pipeline_id">
							<option value=""><?php esc_html_e( '(sin pipeline)', 'wppe-bridge' ); ?></option>
							<?php foreach ( $wppe_bridge_pipelines as $wppe_bridge_pl ) : ?>
								<option
									value="<?php echo esc_attr( $wppe_bridge_pl['id'] ?? '' ); ?>"
									<?php selected( $default_pipeline_id, $wppe_bridge_pl['id'] ?? '' ); ?>
								>
									<?php echo esc_html( $wppe_bridge_pl['name'] ?? $wppe_bridge_pl['id'] ?? '' ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Si seleccionas un pipeline, todos los leads creados desde el bridge generan una Opportunity en ese pipeline (cuando el toggle "Crear Opportunity" en Configuracion GHL esta ON, default).', 'wppe-bridge' ); ?></p>
					</td>
				</tr>

				<!-- Stage default -->
				<tr>
					<th scope="row">
						<label for="default_pipeline_stage_id"><?php esc_html_e( 'Stage default', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<select name="default_pipeline_stage_id" id="default_pipeline_stage_id">
							<option value=""><?php esc_html_e( '(primera stage del pipeline)', 'wppe-bridge' ); ?></option>
							<?php foreach ( $wppe_bridge_pipelines as $wppe_bridge_pl ) : ?>
								<?php
								$wppe_bridge_pl_id     = $wppe_bridge_pl['id'] ?? '';
								$wppe_bridge_pl_stages = isset( $wppe_bridge_pl['stages'] ) && is_array( $wppe_bridge_pl['stages'] ) ? $wppe_bridge_pl['stages'] : array();
								?>
								<?php foreach ( $wppe_bridge_pl_stages as $wppe_bridge_st ) : ?>
									<option
										value="<?php echo esc_attr( $wppe_bridge_st['id'] ?? '' ); ?>"
										<?php selected( $default_stage_id, $wppe_bridge_st['id'] ?? '' ); ?>
										data-pipeline="<?php echo esc_attr( $wppe_bridge_pl_id ); ?>"
									>
										<?php echo esc_html( ( $wppe_bridge_pl['name'] ?? '' ) . ' &rsaquo; ' . ( $wppe_bridge_st['name'] ?? '' ) ); ?>
									</option>
								<?php endforeach; ?>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Stage en el que aterriza la Opportunity al crearse. Si dejas vacio, GHL usa la primera stage del pipeline.', 'wppe-bridge' ); ?></p>
					</td>
				</tr>

				<!-- UTM field mapping -->
				<tr>
					<th scope="row"><?php esc_html_e( 'UTMs &rarr; Custom Fields', 'wppe-bridge' ); ?></th>
					<td>
						<?php if ( empty( $cf_for_utms ) ) : ?>
							<p style="color:#dc3232">
								<span class="dashicons dashicons-warning"></span>
								<?php esc_html_e( 'No hay Custom Fields tipo TEXT/LARGE_TEXT en GHL. Crealos en la sub-account GHL primero (Settings -> Custom Fields), luego sincroniza catalogos aqui.', 'wppe-bridge' ); ?>
							</p>
						<?php else : ?>
							<table class="widefat striped" style="max-width:600px">
								<thead>
									<tr>
										<th><?php esc_html_e( 'UTM key', 'wppe-bridge' ); ?></th>
										<th><?php esc_html_e( 'Custom Field GHL', 'wppe-bridge' ); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ( WPPE_Bridge_Ghl_Mapping_Page::UTM_KEYS as $wppe_bridge_utm_key ) : ?>
										<tr>
											<td><code><?php echo esc_html( $wppe_bridge_utm_key ); ?></code></td>
											<td>
												<select name="utm_field_mapping[<?php echo esc_attr( $wppe_bridge_utm_key ); ?>]">
													<option value=""><?php esc_html_e( '(sin mapeo — UTM no se envia a GHL)', 'wppe-bridge' ); ?></option>
													<?php foreach ( $cf_for_utms as $wppe_bridge_cf ) : ?>
														<option
															value="<?php echo esc_attr( $wppe_bridge_cf['id'] ?? '' ); ?>"
															<?php selected( $utm_field_mapping[ $wppe_bridge_utm_key ] ?? '', $wppe_bridge_cf['id'] ?? '' ); ?>
														>
															<?php echo esc_html( ( $wppe_bridge_cf['name'] ?? '' ) . ' (' . ( $wppe_bridge_cf['dataType'] ?? '' ) . ')' ); ?>
														</option>
													<?php endforeach; ?>
												</select>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
							<p class="description">
								<?php esc_html_e( 'Solo se muestran Custom Fields tipo TEXT/LARGE_TEXT del modelo "contact" (D-PR2-5). PHONE/EMAIL/DATE/etc. estan filtrados porque guardar un utm_source en un campo PHONE produciria basura.', 'wppe-bridge' ); ?>
							</p>
						<?php endif; ?>
					</td>
				</tr>

				<!-- Tags default -->
				<tr>
					<th scope="row">
						<label for="default_tags"><?php esc_html_e( 'Tags default (globales)', 'wppe-bridge' ); ?></label>
					</th>
					<td>
						<input
							type="text"
							name="default_tags"
							id="default_tags"
							class="regular-text"
							value="<?php echo esc_attr( implode( ', ', $default_tags ) ); ?>"
							placeholder="lead-web, wppe-bridge"
							list="wppe-bridge-ghl-tags-suggest"
						/>
						<datalist id="wppe-bridge-ghl-tags-suggest">
							<?php foreach ( $wppe_bridge_tags as $wppe_bridge_tag ) : ?>
								<option value="<?php echo esc_attr( $wppe_bridge_tag['name'] ?? '' ); ?>"></option>
							<?php endforeach; ?>
						</datalist>
						<p class="description">
							<?php esc_html_e( 'Tags separados por coma. Aplican a todo contacto creado por el bridge. Cada form puede agregar tags adicionales en su mapeo individual mas abajo.', 'wppe-bridge' ); ?>
							<?php
							if ( ! empty( $wppe_bridge_tags ) ) {
								echo ' ' . esc_html(
									sprintf(
										/* translators: %d: count of tags suggested */
										__( 'Autocomplete con %d tags existentes en GHL. Tipear texto libre tambien funciona — GHL crea el tag al primer uso.', 'wppe-bridge' ),
										count( $wppe_bridge_tags )
									)
								);
							}
							?>
						</p>
					</td>
				</tr>
			</tbody>
		</table>

		<?php submit_button( __( 'Guardar configuracion global', 'wppe-bridge' ) ); ?>
	</form>

	<hr/>

	<!-- ========================================================== -->
	<!-- Bloque 3: Mapeo de campos por form                          -->
	<!-- ========================================================== -->
	<h2><?php esc_html_e( 'Mapeo de campos por formulario', 'wppe-bridge' ); ?></h2>

	<?php if ( null !== $selected_form_data ) : ?>
		<p>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . WPPE_Bridge_Ghl_Mapping_Page::PAGE_SLUG ) ); ?>">
				&larr; <?php esc_html_e( 'Volver a la lista de formularios', 'wppe-bridge' ); ?>
			</a>
		</p>
		<p>
			<strong><?php esc_html_e( 'Plugin', 'wppe-bridge' ); ?>:</strong> <?php echo esc_html( $selected_plugin ); ?>
			&nbsp;|&nbsp;
			<strong><?php esc_html_e( 'Form', 'wppe-bridge' ); ?>:</strong>
			<?php echo esc_html( $selected_form_data['title'] ?? $selected_form ); ?>
			(ID: <code><?php echo esc_html( $selected_form ); ?></code>)
		</p>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( WPPE_Bridge_Ghl_Mapping_Page::ACTION_SAVE_FORM_MAPPING ); ?>"/>
			<input type="hidden" name="plugin" value="<?php echo esc_attr( $selected_plugin ); ?>"/>
			<input type="hidden" name="form" value="<?php echo esc_attr( $selected_form ); ?>"/>
			<?php wp_nonce_field( WPPE_Bridge_Ghl_Mapping_Page::NONCE_FORM_MAPPING ); ?>

			<table class="widefat striped" style="max-width:800px">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Campo del formulario', 'wppe-bridge' ); ?></th>
						<th><?php esc_html_e( 'Campo GHL', 'wppe-bridge' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					$wppe_bridge_form_fields = isset( $selected_form_data['fields'] ) && is_array( $selected_form_data['fields'] ) ? $selected_form_data['fields'] : array();
					$wppe_bridge_existing    = isset( $existing_mapping['fields'] ) && is_array( $existing_mapping['fields'] ) ? $existing_mapping['fields'] : array();
					?>
					<?php foreach ( $wppe_bridge_form_fields as $wppe_bridge_ff ) : ?>
						<?php $wppe_bridge_ff_name = (string) ( $wppe_bridge_ff['name'] ?? '' ); ?>
						<?php
						if ( '' === $wppe_bridge_ff_name ) {
							continue; }
						?>
						<?php $wppe_bridge_current = $wppe_bridge_existing[ $wppe_bridge_ff_name ] ?? ''; ?>
						<tr>
							<td>
								<code><?php echo esc_html( $wppe_bridge_ff_name ); ?></code>
								<?php if ( ! empty( $wppe_bridge_ff['label'] ) ) : ?>
									<br><small><?php echo esc_html( $wppe_bridge_ff['label'] ); ?></small>
								<?php endif; ?>
							</td>
							<td>
								<select name="field_map[<?php echo esc_attr( $wppe_bridge_ff_name ); ?>]">
									<option value=""><?php esc_html_e( '— No mapear —', 'wppe-bridge' ); ?></option>
									<?php foreach ( WPPE_Bridge_Ghl_Mapping_Page::PAYLOAD_KEYS as $wppe_bridge_pk ) : ?>
										<option value="<?php echo esc_attr( $wppe_bridge_pk ); ?>" <?php selected( $wppe_bridge_current, $wppe_bridge_pk ); ?>>
											<?php echo esc_html( $wppe_bridge_pk ); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<p class="description">
				<?php esc_html_e( 'Mapea al menos un campo a "firstName" — sin nombre, el lead es inutil para vendedores. GHL acepta el contacto pero el bridge bloquea el guardado.', 'wppe-bridge' ); ?>
			</p>

			<h3><?php esc_html_e( 'Tags adicionales (override por-form)', 'wppe-bridge' ); ?></h3>
			<table class="form-table" role="presentation">
				<tbody>
					<tr>
						<th scope="row">
							<label for="form_tags"><?php esc_html_e( 'Tags para este form', 'wppe-bridge' ); ?></label>
						</th>
						<td>
							<?php
							$wppe_bridge_form_tags_existing = isset( $existing_mapping['tags'] ) && is_array( $existing_mapping['tags'] ) ? $existing_mapping['tags'] : array();
							?>
							<input
								type="text"
								name="form_tags"
								id="form_tags"
								class="regular-text"
								value="<?php echo esc_attr( implode( ', ', $wppe_bridge_form_tags_existing ) ); ?>"
								placeholder="proyecto-miraflores, landing-q2"
								list="wppe-bridge-ghl-tags-suggest"
							/>
							<p class="description">
								<?php esc_html_e( 'Tags separados por coma. Se concatenan a los tags default globales (deduplicados). Util para identificar de que form/landing vino el lead.', 'wppe-bridge' ); ?>
							</p>
						</td>
					</tr>
				</tbody>
			</table>

			<?php submit_button( __( 'Guardar mapeo del formulario', 'wppe-bridge' ) ); ?>
		</form>

	<?php else : ?>
		<p><?php esc_html_e( 'Seleccioná un formulario para configurar su mapeo:', 'wppe-bridge' ); ?></p>
		<?php foreach ( $discovered as $wppe_bridge_plugin_slug => $wppe_bridge_forms ) : ?>
			<?php
			if ( empty( $wppe_bridge_forms ) ) {
				continue; }
			?>
			<h3><?php echo esc_html( ucfirst( (string) $wppe_bridge_plugin_slug ) ); ?></h3>
			<ul>
				<?php foreach ( $wppe_bridge_forms as $wppe_bridge_f ) : ?>
					<li>
						<a href="
						<?php
						echo esc_url(
							add_query_arg(
								array(
									'page'   => WPPE_Bridge_Ghl_Mapping_Page::PAGE_SLUG,
									'plugin' => $wppe_bridge_plugin_slug,
									'form'   => $wppe_bridge_f['id'] ?? '',
								),
								admin_url( 'admin.php' )
							)
						);
						?>
									">
							<?php echo esc_html( $wppe_bridge_f['title'] ?? ( $wppe_bridge_f['id'] ?? '?' ) ); ?>
						</a>
						(ID: <code><?php echo esc_html( $wppe_bridge_f['id'] ?? '' ); ?></code>)
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endforeach; ?>

		<?php if ( empty( $discovered ) || ( empty( $discovered['fluent'] ?? array() ) && empty( $discovered['gravity'] ?? array() ) && empty( $discovered['elementor'] ?? array() ) ) ) : ?>
			<div class="notice notice-info inline"><p>
				<?php esc_html_e( 'No se detectaron formularios. Razones:', 'wppe-bridge' ); ?>
				<ul style="list-style:disc;margin-left:2em">
					<?php foreach ( $discovery_reasons as $wppe_bridge_plug => $wppe_bridge_reason ) : ?>
						<li><strong><?php echo esc_html( $wppe_bridge_plug ); ?>:</strong> <?php echo esc_html( $wppe_bridge_reason ); ?></li>
					<?php endforeach; ?>
				</ul>
			</p></div>
		<?php endif; ?>

	<?php endif; ?>
</div>
