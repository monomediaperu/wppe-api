<?php
/**
 * Vista de configuracion Thank You Pixel.
 *
 * @var array<int,int>     $selected_pages IDs ya marcados.
 * @var array<int,WP_Post> $all_pages      Todas las pages WP.
 * @var string             $pixel_id       Pixel ID (de Meta CAPI).
 * @var string             $event_name     Event name (de Meta CAPI).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

$wppe_bridge_back        = add_query_arg(
	array( 'page' => WPPE_Bridge_Admin_Menu::SLUG . '-modules' ),
	admin_url( 'admin.php' )
);
$wppe_bridge_meta_config = add_query_arg(
	array( 'page' => WPPE_Bridge_Meta_Capi_Settings_Page::PAGE_SLUG ),
	admin_url( 'admin.php' )
);
$wppe_bridge_pixel_field = WPPE_Bridge_Module_Thank_You_Pixel::OPTION_PAGES;
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Thank You Pixel', 'wppe-bridge' ); ?></h1>

	<p>
		<a href="<?php echo esc_url( $wppe_bridge_back ); ?>" class="button">
			← <?php esc_html_e( 'Volver a Modulos', 'wppe-bridge' ); ?>
		</a>
	</p>

	<p class="description">
		<?php esc_html_e( 'Selecciona las paginas que actuan como "thank you page". Cuando un visitante llegue a una de estas paginas, se disparara el browser pixel de Meta sincronizado con el evento server-side (Meta CAPI) para que Meta los deduplique.', 'wppe-bridge' ); ?>
	</p>

	<table class="form-table" role="presentation">
		<tbody>
			<tr>
				<th scope="row"><?php esc_html_e( 'Pixel ID', 'wppe-bridge' ); ?></th>
				<td>
					<?php if ( '' !== $pixel_id ) : ?>
						<code><?php echo esc_html( $pixel_id ); ?></code>
					<?php else : ?>
						<span class="dashicons dashicons-warning" style="color:#dc3232"></span>
						<em><?php esc_html_e( 'No configurado.', 'wppe-bridge' ); ?></em>
					<?php endif; ?>
					<p class="description">
						<?php
						printf(
							/* translators: %s: link to Meta CAPI settings */
							esc_html__( 'Se configura en %s.', 'wppe-bridge' ),
							'<a href="' . esc_url( $wppe_bridge_meta_config ) . '">' . esc_html__( 'Meta CAPI', 'wppe-bridge' ) . '</a>'
						);
						?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Tipo de evento', 'wppe-bridge' ); ?></th>
				<td>
					<code><?php echo esc_html( $event_name ); ?></code>
					<p class="description">
						<?php
						printf(
							/* translators: %s: link to Meta CAPI settings */
							esc_html__( 'Configurable en %s. Debe coincidir entre browser pixel y server-side para dedup.', 'wppe-bridge' ),
							'<a href="' . esc_url( $wppe_bridge_meta_config ) . '">' . esc_html__( 'Meta CAPI', 'wppe-bridge' ) . '</a>'
						);
						?>
					</p>
				</td>
			</tr>
		</tbody>
	</table>

	<form method="post" action="options.php">
		<?php settings_fields( WPPE_Bridge_Thank_You_Pixel_Settings_Page::OPTION_GROUP ); ?>

		<h2><?php esc_html_e( 'Paginas de gracias', 'wppe-bridge' ); ?></h2>

		<?php if ( empty( $all_pages ) ) : ?>
			<p>
				<em><?php esc_html_e( 'No hay paginas en este sitio. Crea una pagina de gracias primero y vuelve aqui.', 'wppe-bridge' ); ?></em>
			</p>
		<?php else : ?>
			<p>
				<input
					type="search"
					id="wppe-bridge-pages-filter"
					class="regular-text"
					placeholder="<?php esc_attr_e( 'Buscar pagina...', 'wppe-bridge' ); ?>"
					autocomplete="off"
				/>
			</p>

			<div
				id="wppe-bridge-pages-list"
				style="max-height:400px;overflow-y:auto;border:1px solid #ccd0d4;background:#fff;padding:10px 14px;"
			>
				<?php foreach ( $all_pages as $wppe_bridge_page ) : ?>
					<?php
					$wppe_bridge_id      = (int) $wppe_bridge_page->ID;
					$wppe_bridge_checked = in_array( $wppe_bridge_id, $selected_pages, true );
					?>
					<label
						class="wppe-bridge-page-row"
						data-title="<?php echo esc_attr( strtolower( (string) $wppe_bridge_page->post_title ) ); ?>"
						data-selected="<?php echo $wppe_bridge_checked ? '1' : '0'; ?>"
						style="display:block;padding:4px 0;"
					>
						<input
							type="checkbox"
							name="<?php echo esc_attr( $wppe_bridge_pixel_field ); ?>[]"
							value="<?php echo esc_attr( (string) $wppe_bridge_id ); ?>"
							<?php checked( $wppe_bridge_checked ); ?>
						/>
						<?php echo esc_html( $wppe_bridge_page->post_title ); ?>
						<span style="color:#888;font-size:11px;">
							(ID: <?php echo (int) $wppe_bridge_id; ?>)
						</span>
					</label>
				<?php endforeach; ?>
			</div>

			<script>
			(function(){
				var input = document.getElementById('wppe-bridge-pages-filter');
				var list  = document.getElementById('wppe-bridge-pages-list');
				if (!input || !list) { return; }
				input.addEventListener('input', function(){
					var q = this.value.toLowerCase().trim();
					var rows = list.querySelectorAll('.wppe-bridge-page-row');
					for (var i = 0; i < rows.length; i++) {
						var row = rows[i];
						// Las ya seleccionadas siempre visibles.
						if (row.getAttribute('data-selected') === '1') {
							row.style.display = 'block';
							continue;
						}
						var title = row.getAttribute('data-title') || '';
						row.style.display = (q === '' || title.indexOf(q) !== -1) ? 'block' : 'none';
					}
				});
			})();
			</script>
		<?php endif; ?>

		<?php submit_button(); ?>
	</form>
</div>
