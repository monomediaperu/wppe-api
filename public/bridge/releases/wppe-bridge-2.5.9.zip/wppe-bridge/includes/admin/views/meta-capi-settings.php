<?php
/**
 * Vista de configuracion Meta CAPI.
 *
 * @var string                $pixel_id
 * @var bool                  $has_token
 * @var string                $test_event_code
 * @var string                $event_name
 * @var array<int,string>     $allowed_events
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

$wppe_bridge_back = add_query_arg(
	array( 'page' => WPPE_Bridge_Admin_Menu::SLUG . '-modules' ),
	admin_url( 'admin.php' )
);
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Meta CAPI', 'wppe-bridge' ); ?></h1>

	<p>
		<a href="<?php echo esc_url( $wppe_bridge_back ); ?>" class="button">
			← <?php esc_html_e( 'Volver a Modulos', 'wppe-bridge' ); ?>
		</a>
	</p>

	<p class="description">
		<?php esc_html_e( 'Configura los datos de tu Meta Conversions API. Este modulo dispara un evento Lead a Meta cuando un lead se envia exitosamente a Sperant.', 'wppe-bridge' ); ?>
	</p>

	<form method="post" action="options.php">
		<?php settings_fields( WPPE_Bridge_Meta_Capi_Settings_Page::OPTION_GROUP ); ?>

		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row">
						<label for="<?php echo esc_attr( WPPE_Bridge_Module_Meta_Capi::OPTION_PIXEL_ID ); ?>">
							<?php esc_html_e( 'Pixel ID', 'wppe-bridge' ); ?>
						</label>
					</th>
					<td>
						<input
							type="text"
							id="<?php echo esc_attr( WPPE_Bridge_Module_Meta_Capi::OPTION_PIXEL_ID ); ?>"
							name="<?php echo esc_attr( WPPE_Bridge_Module_Meta_Capi::OPTION_PIXEL_ID ); ?>"
							class="regular-text"
							value="<?php echo esc_attr( $pixel_id ); ?>"
							placeholder="123456789012345"
						/>
						<p class="description">
							<?php esc_html_e( 'A.k.a. Dataset ID en Meta Events Manager. Solo digitos.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="<?php echo esc_attr( WPPE_Bridge_Module_Meta_Capi::OPTION_ACCESS_TOKEN ); ?>">
							<?php esc_html_e( 'Access Token', 'wppe-bridge' ); ?>
						</label>
					</th>
					<td>
						<input
							type="password"
							id="<?php echo esc_attr( WPPE_Bridge_Module_Meta_Capi::OPTION_ACCESS_TOKEN ); ?>"
							name="<?php echo esc_attr( WPPE_Bridge_Module_Meta_Capi::OPTION_ACCESS_TOKEN ); ?>"
							class="regular-text"
							autocomplete="new-password"
							placeholder="<?php echo $has_token ? esc_attr__( '(token configurado — dejar vacio para conservar)', 'wppe-bridge' ) : esc_attr__( '(sin configurar)', 'wppe-bridge' ); ?>"
						/>
						<p class="description">
							<?php
							if ( $has_token ) {
								echo '<span class="dashicons dashicons-yes-alt" style="color:#46b450"></span> ';
								esc_html_e( 'Token configurado. Dejar el campo vacio para conservar el actual.', 'wppe-bridge' );
							} else {
								echo '<span class="dashicons dashicons-warning" style="color:#dc3232"></span> ';
								esc_html_e( 'Token long-lived generado en Meta Events Manager.', 'wppe-bridge' );
							}
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="<?php echo esc_attr( WPPE_Bridge_Module_Meta_Capi::OPTION_EVENT_NAME ); ?>">
							<?php esc_html_e( 'Tipo de evento', 'wppe-bridge' ); ?>
						</label>
					</th>
					<td>
						<select
							id="<?php echo esc_attr( WPPE_Bridge_Module_Meta_Capi::OPTION_EVENT_NAME ); ?>"
							name="<?php echo esc_attr( WPPE_Bridge_Module_Meta_Capi::OPTION_EVENT_NAME ); ?>"
						>
							<?php foreach ( $allowed_events as $wppe_bridge_event_option ) : ?>
								<option value="<?php echo esc_attr( $wppe_bridge_event_option ); ?>" <?php selected( $event_name, $wppe_bridge_event_option ); ?>>
									<?php echo esc_html( $wppe_bridge_event_option ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description">
							<?php esc_html_e( 'Evento estandar de Meta a disparar. Se aplica tanto al server-side (Meta CAPI) como al browser (Thank You Pixel) — ambos lados deben coincidir para que Meta los deduplique correctamente.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="<?php echo esc_attr( WPPE_Bridge_Module_Meta_Capi::OPTION_TEST_EVENT_CODE ); ?>">
							<?php esc_html_e( 'Test Event Code', 'wppe-bridge' ); ?>
						</label>
					</th>
					<td>
						<input
							type="text"
							id="<?php echo esc_attr( WPPE_Bridge_Module_Meta_Capi::OPTION_TEST_EVENT_CODE ); ?>"
							name="<?php echo esc_attr( WPPE_Bridge_Module_Meta_Capi::OPTION_TEST_EVENT_CODE ); ?>"
							class="regular-text"
							value="<?php echo esc_attr( $test_event_code ); ?>"
							placeholder="TEST12345"
						/>
						<p class="description">
							<?php esc_html_e( 'Opcional. Si se setea, los eventos aparecen en la pestaña "Test Events" de Meta Events Manager. Vaciar para mandar a producción.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
			</tbody>
		</table>

		<?php submit_button(); ?>
	</form>
</div>
