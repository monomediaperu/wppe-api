<?php
/**
 * Vista de la pagina admin "Configuracion Odoo".
 *
 * Variables disponibles (provistas por WPPE_Bridge_Odoo_Settings_Page::render):
 *
 * @var string $base_url     URL base actual (string vacio si no configurada).
 * @var string $db           DB name actual (string vacio si no configurada).
 * @var string $login        Login email actual (string vacio si no configurado).
 * @var bool   $has_api_key  True si hay API key guardada.
 * @var string $default_type 'opportunity' | 'lead' (D-Odoo-8 default 'opportunity').
 * @var int    $uid_cached   UID cacheado (0 si nunca autenticado).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Configuracion Odoo', 'wppe-bridge' ); ?></h1>

	<div class="notice notice-info inline" style="margin-top:1em">
		<p>
			<?php
			echo wp_kses(
				sprintf(
					/* translators: %s: URL a Configuracion general */
					__( 'Esta sub-pagina configura solo los campos especificos de Odoo. Para cambiar de CRM, dedup TTL, country code o la zona de peligro, ir a <a href="%s">Configuracion</a>.', 'wppe-bridge' ),
					esc_url( admin_url( 'admin.php?page=wppe-bridge-config' ) )
				),
				array( 'a' => array( 'href' => true ) )
			);
			?>
		</p>
	</div>

	<form method="post" action="options.php">
		<?php settings_fields( WPPE_Bridge_Odoo_Settings_Page::OPTION_GROUP ); ?>

		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row">
						<label for="wppe_bridge_odoo_base_url">
							<?php esc_html_e( 'URL base', 'wppe-bridge' ); ?>
							<span style="color:#dc3232" title="<?php esc_attr_e( 'Obligatorio', 'wppe-bridge' ); ?>">*</span>
						</label>
					</th>
					<td>
						<input
							type="url"
							name="wppe_bridge_odoo_base_url"
							id="wppe_bridge_odoo_base_url"
							class="regular-text"
							value="<?php echo esc_attr( $base_url ); ?>"
							placeholder="https://mycompany.odoo.com"
						/>
						<p class="description">
							<?php esc_html_e( 'URL completa de la instancia Odoo (con scheme). Para Odoo Online: https://<dbname>.odoo.com. Para self-hosted: la URL publica con la que accedes al panel.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row">
						<label for="wppe_bridge_odoo_db">
							<?php esc_html_e( 'Database (db)', 'wppe-bridge' ); ?>
							<span style="color:#dc3232" title="<?php esc_attr_e( 'Obligatorio', 'wppe-bridge' ); ?>">*</span>
						</label>
					</th>
					<td>
						<input
							type="text"
							name="wppe_bridge_odoo_db"
							id="wppe_bridge_odoo_db"
							class="regular-text"
							value="<?php echo esc_attr( $db ); ?>"
							placeholder="mycompany"
							pattern="[a-zA-Z0-9_\-]{1,64}"
						/>
						<p class="description">
							<?php esc_html_e( 'Nombre de la base de datos. Para Odoo Online es el subdominio (mycompany de mycompany.odoo.com). Para self-hosted: lo eligio el sysadmin (suele estar en /etc/odoo/odoo.conf bajo db_name=).', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row">
						<label for="wppe_bridge_odoo_login">
							<?php esc_html_e( 'Login (email del usuario)', 'wppe-bridge' ); ?>
							<span style="color:#dc3232" title="<?php esc_attr_e( 'Obligatorio', 'wppe-bridge' ); ?>">*</span>
						</label>
					</th>
					<td>
						<input
							type="email"
							name="wppe_bridge_odoo_login"
							id="wppe_bridge_odoo_login"
							class="regular-text"
							value="<?php echo esc_attr( $login ); ?>"
							placeholder="ventas@miempresa.com"
						/>
						<p class="description">
							<?php esc_html_e( 'Email del usuario Odoo cuya API key vamos a usar. Debe tener al menos rol Sales / Salesperson para crear crm.lead.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row">
						<label for="wppe_bridge_odoo_api_key">
							<?php esc_html_e( 'API Key', 'wppe-bridge' ); ?>
							<span style="color:#dc3232" title="<?php esc_attr_e( 'Obligatorio', 'wppe-bridge' ); ?>">*</span>
						</label>
					</th>
					<td>
						<input
							type="password"
							name="wppe_bridge_odoo_api_key"
							id="wppe_bridge_odoo_api_key"
							class="regular-text"
							autocomplete="new-password"
							placeholder="<?php echo $has_api_key ? esc_attr__( '(API Key configurada — dejar vacio para conservar)', 'wppe-bridge' ) : esc_attr__( '(sin configurar) — obligatorio', 'wppe-bridge' ); ?>"
							<?php echo $has_api_key ? '' : 'required'; ?>
						/>
						<p class="description">
							<?php
							if ( $has_api_key ) {
								echo '<span class="dashicons dashicons-yes-alt" style="color:#46b450"></span> ';
								esc_html_e( 'API Key configurada. Dejar el campo vacio para conservar la actual.', 'wppe-bridge' );
							} else {
								esc_html_e( 'Generala en Odoo: Preferences &rarr; Account Security &rarr; New API Key. Solo se muestra una vez al generar — guardarla en 1Password antes de pegarla aqui.', 'wppe-bridge' );
							}
							?>
						</p>
						<?php if ( $uid_cached > 0 ) : ?>
							<p class="description" style="color:#666">
								<?php
								echo esc_html(
									sprintf(
										/* translators: %d: uid integer */
										__( 'UID autenticado actualmente: %d. Cualquier cambio en URL/db/login/API Key invalida este cache automaticamente.', 'wppe-bridge' ),
										$uid_cached
									)
								);
								?>
							</p>
						<?php endif; ?>
					</td>
				</tr>

				<tr>
					<th scope="row">
						<label for="wppe_bridge_odoo_default_type">
							<?php esc_html_e( 'Tipo del registro (default)', 'wppe-bridge' ); ?>
						</label>
					</th>
					<td>
						<select
							name="wppe_bridge_odoo_default_type"
							id="wppe_bridge_odoo_default_type"
						>
							<option value="opportunity" <?php selected( $default_type, 'opportunity' ); ?>>
								<?php esc_html_e( 'Opportunity (recomendado — aparece directo en Pipeline)', 'wppe-bridge' ); ?>
							</option>
							<option value="lead" <?php selected( $default_type, 'lead' ); ?>>
								<?php esc_html_e( 'Lead (requiere feature "Leads" activado en CRM Settings)', 'wppe-bridge' ); ?>
							</option>
						</select>
						<p class="description">
							<?php esc_html_e( 'Por D-Odoo-8 default es Opportunity: el lead aparece en el Pipeline (vista Kanban), listo para que un salesperson lo trabaje. Cambiar a Lead solo si tu equipo separa qualification (SDR) de closing (AE) y queres que pase por un paso manual antes del Pipeline.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
			</tbody>
		</table>

		<?php submit_button( __( 'Guardar configuracion Odoo', 'wppe-bridge' ) ); ?>
	</form>
</div>
