<?php
/**
 * Vista detalle de un queue item.
 *
 * Variables disponibles:
 *
 * @var object              $item              Row de queue.
 * @var array|null          $payload           Payload decodificado.
 * @var array|null          $destination_response  Response decodificada del CRM destino.
 * @var string              $retry_url         URL para retry individual.
 * @var array<int,object>   $lead_logs         Flujo completo del lead (logs por queue_id).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

$wppe_bridge_back = add_query_arg(
	array( 'page' => WPPE_Bridge_Admin_Menu::SLUG . '-logs' ),
	admin_url( 'admin.php' )
);

$wppe_bridge_flash = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
?>
<div class="wrap wppe-bridge-wrap">
	<h1>
		<?php
		printf(
			/* translators: %d = ID del lead. */
			esc_html__( 'WP.pe Bridge — Lead #%d', 'wppe-bridge' ),
			(int) $item->id
		);
		?>
	</h1>

	<p>
		<a href="<?php echo esc_url( $wppe_bridge_back ); ?>" class="button">
			← <?php esc_html_e( 'Volver al listado', 'wppe-bridge' ); ?>
		</a>
		<a href="<?php echo esc_url( $retry_url ); ?>" class="button button-primary" onclick="return confirm('<?php echo esc_js( __( 'Requeuear este lead? Se procesara en el proximo tick del worker.', 'wppe-bridge' ) ); ?>');">
			<?php esc_html_e( 'Requeue para reintento', 'wppe-bridge' ); ?>
		</a>
		<?php if ( ! empty( $has_nested_name ) ) : ?>
			<a href="<?php echo esc_url( $retry_rebuilt_url ); ?>" class="button" style="border-color:#dba617;color:#996800" onclick="return confirm('<?php echo esc_js( __( 'Reconstruir el payload aplanando los campos fname/lname y reintentar? Util para leads encolados antes de v1.2.5.', 'wppe-bridge' ) ); ?>');">
				🔧 <?php esc_html_e( 'Reconstruir payload y reintentar', 'wppe-bridge' ); ?>
			</a>
		<?php endif; ?>
	</p>

	<?php if ( ! empty( $has_nested_name ) ) : ?>
		<div class="notice notice-warning inline">
			<p>
				<strong><?php esc_html_e( 'Payload con campo Name nested detectado.', 'wppe-bridge' ); ?></strong>
				<?php esc_html_e( 'Este lead se encolo con una version del plugin anterior a v1.2.5 que entregaba el campo Name como objeto en lugar de string. Sperant rechaza este formato. Usa "Reconstruir payload y reintentar" para aplanarlo automaticamente.', 'wppe-bridge' ); ?>
			</p>
		</div>
	<?php endif; ?>

	<?php if ( 'retried' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Lead requeueado.', 'wppe-bridge' ); ?></p></div>
	<?php elseif ( 'rebuilt_and_retried' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Payload reconstruido y lead reagendado para reintento. El proximo tick del worker lo procesara con el formato correcto.', 'wppe-bridge' ); ?></p></div>
	<?php elseif ( 'retried_unchanged' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-info is-dismissible"><p><?php esc_html_e( 'El payload ya estaba en formato correcto. Lead reagendado para reintento.', 'wppe-bridge' ); ?></p></div>
	<?php elseif ( 'retry_failed' === $wppe_bridge_flash ) : ?>
		<div class="notice notice-error is-dismissible"><p><?php esc_html_e( 'No se pudo requeuear el lead.', 'wppe-bridge' ); ?></p></div>
	<?php endif; ?>

	<table class="form-table" role="presentation">
		<tbody>
			<tr><th><?php esc_html_e( 'Status', 'wppe-bridge' ); ?></th><td><code><?php echo esc_html( (string) $item->status ); ?></code></td></tr>
			<tr><th><?php esc_html_e( 'Fecha creacion', 'wppe-bridge' ); ?></th><td><?php echo esc_html( (string) $item->created_at ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Ultima actualizacion', 'wppe-bridge' ); ?></th><td><?php echo esc_html( (string) $item->updated_at ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Form', 'wppe-bridge' ); ?></th><td><?php echo esc_html( sprintf( '%s #%s', $item->form_plugin, $item->form_id ) ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Submission ID externo', 'wppe-bridge' ); ?></th><td><?php echo esc_html( (string) ( $item->submission_id_external ?? '' ) ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Hash', 'wppe-bridge' ); ?></th><td><code style="font-size:0.85em"><?php echo esc_html( (string) $item->hash ); ?></code></td></tr>
			<tr><th><?php esc_html_e( 'Intentos', 'wppe-bridge' ); ?></th><td><?php echo (int) $item->attempts; ?></td></tr>
			<tr><th><?php esc_html_e( 'Ultimo intento', 'wppe-bridge' ); ?></th><td><?php echo esc_html( (string) ( $item->last_attempt_at ?? '—' ) ); ?></td></tr>
			<tr><th><?php esc_html_e( 'Proximo retry', 'wppe-bridge' ); ?></th><td><?php echo esc_html( (string) ( $item->next_retry_at ?? '—' ) ); ?></td></tr>
		</tbody>
	</table>

	<h2><?php esc_html_e( 'Payload enviado', 'wppe-bridge' ); ?></h2>
	<pre style="background:#f6f7f7;padding:12px;border-radius:4px;max-width:900px;overflow:auto;font-size:12px"><?php echo esc_html( null !== $payload ? (string) wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) : '(vacio)' ); ?></pre>

	<h2><?php esc_html_e( 'Respuesta del CRM', 'wppe-bridge' ); ?></h2>
	<pre style="background:#f6f7f7;padding:12px;border-radius:4px;max-width:900px;overflow:auto;font-size:12px"><?php echo esc_html( null !== $destination_response ? (string) wp_json_encode( $destination_response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) : '(sin respuesta)' ); ?></pre>

	<h2><?php esc_html_e( 'Flujo completo del lead', 'wppe-bridge' ); ?></h2>
	<p class="description">
		<?php esc_html_e( 'Logs registrados durante el ciclo de vida de este lead, en orden cronologico. Util para troubleshooting cuando un lead "se pierde" o queda en pending sin progreso.', 'wppe-bridge' ); ?>
	</p>
	<?php if ( empty( $lead_logs ) ) : ?>
		<p><em><?php esc_html_e( 'No hay logs registrados para este queue_id (puede deberse a logs purgados por retencion, o que el lead se proceso antes de v1.2.1).', 'wppe-bridge' ); ?></em></p>
	<?php else : ?>
		<table class="widefat striped" style="max-width:1100px">
			<thead>
				<tr>
					<th style="width:160px"><?php esc_html_e( 'Fecha', 'wppe-bridge' ); ?></th>
					<th style="width:60px"><?php esc_html_e( 'Nivel', 'wppe-bridge' ); ?></th>
					<th style="width:240px"><?php esc_html_e( 'Mensaje', 'wppe-bridge' ); ?></th>
					<th><?php esc_html_e( 'Contexto', 'wppe-bridge' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php
				$wppe_bridge_level_colors = array(
					'info'  => '#2271b1',
					'warn'  => '#dba617',
					'error' => '#dc3232',
				);
				foreach ( $lead_logs as $wppe_bridge_log ) :
					$wppe_bridge_level       = (string) ( $wppe_bridge_log->level ?? '' );
					$wppe_bridge_color       = $wppe_bridge_level_colors[ $wppe_bridge_level ] ?? '#666';
					$wppe_bridge_ctx_decoded = is_string( $wppe_bridge_log->context ?? null ) ? json_decode( (string) $wppe_bridge_log->context, true ) : null;
					?>
					<tr>
						<td style="font-size:12px;color:#666"><?php echo esc_html( (string) ( $wppe_bridge_log->created_at ?? '' ) ); ?></td>
						<td>
							<span style="display:inline-block;padding:2px 8px;background:<?php echo esc_attr( $wppe_bridge_color ); ?>;color:#fff;font-size:11px;border-radius:3px;text-transform:uppercase">
								<?php echo esc_html( $wppe_bridge_level ); ?>
							</span>
						</td>
						<td><code><?php echo esc_html( (string) ( $wppe_bridge_log->message ?? '' ) ); ?></code></td>
						<td>
							<?php if ( null !== $wppe_bridge_ctx_decoded && ! empty( $wppe_bridge_ctx_decoded ) ) : ?>
								<pre style="margin:0;font-size:11px;background:#f6f7f7;padding:6px;border-radius:3px;max-width:500px;overflow:auto"><?php echo esc_html( (string) wp_json_encode( $wppe_bridge_ctx_decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ); ?></pre>
							<?php else : ?>
								<em style="color:#999">—</em>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>
