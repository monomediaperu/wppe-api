<?php
/**
 * Vista de la pagina admin "Configuracion Webhook".
 *
 * Variables disponibles (provistas por WPPE_Bridge_Webhook_Settings_Page::render):
 *
 * @var string $webhook_url   URL del receiver.
 * @var array  $headers       Map name=>value de headers custom.
 * @var string $default_type  'opportunity' | 'lead'.
 * @var array  $default_tags  Lista de tags default.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

$wppe_bridge_headers_text = WPPE_Bridge_Webhook_Settings_Page::headers_to_textarea( $headers );
$wppe_bridge_has_url      = '' !== $webhook_url;
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Configuracion Webhook', 'wppe-bridge' ); ?></h1>

	<div class="notice notice-info inline" style="margin-top:1em">
		<p>
			<?php
			echo wp_kses(
				sprintf(
					/* translators: %s: URL a Configuracion general */
					__( 'El destino Webhook envia el lead como JSON POST a la URL configurada. El receiver (Odoo Automation Rule, Make/Zapier/n8n catch hook, CRM custom, etc.) decide como procesarlo. Para cambiar de CRM, dedup TTL, country code o la zona de peligro, ir a <a href="%s">Configuracion</a>.', 'wppe-bridge' ),
					esc_url( admin_url( 'admin.php?page=wppe-bridge-config' ) )
				),
				array( 'a' => array( 'href' => true ) )
			);
			?>
		</p>
	</div>

	<form method="post" action="options.php">
		<?php settings_fields( WPPE_Bridge_Webhook_Settings_Page::OPTION_GROUP ); ?>

		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row">
						<label for="wppe_bridge_webhook_url">
							<?php esc_html_e( 'URL del webhook', 'wppe-bridge' ); ?>
							<span style="color:#dc3232" title="<?php esc_attr_e( 'Obligatorio', 'wppe-bridge' ); ?>">*</span>
						</label>
					</th>
					<td>
						<input
							type="url"
							name="wppe_bridge_webhook_url"
							id="wppe_bridge_webhook_url"
							class="regular-text code"
							value="<?php echo esc_attr( $webhook_url ); ?>"
							placeholder="https://hooks.example.com/wppe-bridge/abc123"
							required
						/>
						<p class="description">
							<?php
							if ( $wppe_bridge_has_url ) {
								echo '<span class="dashicons dashicons-yes-alt" style="color:#46b450"></span> ';
								esc_html_e( 'URL configurada. Al guardar, los leads se envian a esta URL como POST con JSON body.', 'wppe-bridge' );
							} else {
								esc_html_e( 'Solo HTTP/HTTPS. La URL la genera el destino: Odoo (Automation Rule "On Webhook"), Make/Zapier/n8n (catch hook), CRM custom propio, etc.', 'wppe-bridge' );
							}
							?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row">
						<label for="wppe_bridge_webhook_default_type">
							<?php esc_html_e( 'Tipo default del lead', 'wppe-bridge' ); ?>
						</label>
					</th>
					<td>
						<select name="wppe_bridge_webhook_default_type" id="wppe_bridge_webhook_default_type">
							<option value="opportunity" <?php selected( $default_type, 'opportunity' ); ?>>
								<?php esc_html_e( 'opportunity (recomendado)', 'wppe-bridge' ); ?>
							</option>
							<option value="lead" <?php selected( $default_type, 'lead' ); ?>>
								<?php esc_html_e( 'lead', 'wppe-bridge' ); ?>
							</option>
						</select>
						<p class="description">
							<?php esc_html_e( 'Se incluye como `type` en el JSON. Para Odoo: "opportunity" hace que el record aparezca directo en el Pipeline view del salesperson; "lead" requiere el feature "Leads" activado en CRM Settings + qualification step manual.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row">
						<label for="wppe_bridge_webhook_default_tags">
							<?php esc_html_e( 'Tags default (globales)', 'wppe-bridge' ); ?>
						</label>
					</th>
					<td>
						<input
							type="text"
							name="wppe_bridge_webhook_default_tags"
							id="wppe_bridge_webhook_default_tags"
							class="regular-text"
							value="<?php echo esc_attr( implode( ', ', $default_tags ) ); ?>"
							placeholder="lead-web, wppe-bridge"
						/>
						<p class="description">
							<?php esc_html_e( 'Tags separados por coma. Se incluyen en `tags[]` del JSON. El receiver decide como mapearlos a IDs en su CRM (Odoo: name_create idempotent, etc.).', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row">
						<label for="wppe_bridge_webhook_headers">
							<?php esc_html_e( 'Headers custom (opcional)', 'wppe-bridge' ); ?>
						</label>
					</th>
					<td>
						<textarea
							name="wppe_bridge_webhook_headers"
							id="wppe_bridge_webhook_headers"
							class="large-text code"
							rows="4"
							placeholder="Authorization: Bearer abc123&#10;X-API-Key: my-secret-key"
						><?php echo esc_textarea( $wppe_bridge_headers_text ); ?></textarea>
						<p class="description">
							<?php esc_html_e( 'Un header por linea, formato `Name: Value`. Util para Bearer auth, X-API-Key, etc. Headers reservados (Content-Type, Accept, Host, Content-Length) se ignoran silenciosamente — los maneja el plugin.', 'wppe-bridge' ); ?>
						</p>
					</td>
				</tr>
			</tbody>
		</table>

		<?php submit_button( __( 'Guardar configuracion Webhook', 'wppe-bridge' ) ); ?>
	</form>

	<hr/>

	<h2><?php esc_html_e( 'Estructura del JSON enviado', 'wppe-bridge' ); ?></h2>
	<p class="description">
		<?php esc_html_e( 'Cuando llega un lead al bridge, se hace POST a la URL con este JSON:', 'wppe-bridge' ); ?>
	</p>
	<pre style="background:#f6f7f7;padding:1em;border:1px solid #ccd0d4;overflow-x:auto"><code>{
	"name": "Web lead — Maria Lopez",
	"contact_name": "Maria Lopez",
	"first_name": "Maria",
	"last_name": "Lopez",
	"email_from": "maria@example.com",
	"phone": "+51999888777",
	"description": "Mensaje del form",
	"type": "opportunity",
	"utm_source": "google",
	"utm_medium": "cpc",
	"utm_campaign": "summer-2026",
	"utm_content": "ad-variant-a",
	"utm_term": "departamentos lima",
	"gclid": "EAIaIQ...",
	"fbclid": "IwAR...",
	"tags": ["lead-web", "wppe-bridge"],
	"landing_url": "https://wp.pe/bridge",
	"source": "wppe-bridge",
	"bridge_version": "2.3.0",
	"form_plugin": "fluent",
	"form_id": "42",
	"submission_id": "...",
	"client_ip": "1.2.3.4",
	"client_user_agent": "Mozilla/..."
}</code></pre>

	<p class="description">
		<?php
		echo wp_kses(
			__( 'Para modificar este shape, hookear el filter <code>wppe_bridge_webhook_body</code>. Las keys son compatibles con <code>crm.lead</code> de Odoo para que el mapping en Automation Rule sea trivial.', 'wppe-bridge' ),
			array( 'code' => array() )
		);
		?>
	</p>

	<h2><?php esc_html_e( 'Recetas rapidas', 'wppe-bridge' ); ?></h2>

	<h3><?php esc_html_e( 'Odoo v17+ via Automation Rule', 'wppe-bridge' ); ?></h3>
	<ol>
		<li><?php esc_html_e( 'En Odoo: Settings → Technical → Automation Rules → New.', 'wppe-bridge' ); ?></li>
		<li><?php esc_html_e( 'Trigger: "On Webhook". Modelo: "CRM Lead".', 'wppe-bridge' ); ?></li>
		<li><?php esc_html_e( 'Copiar la URL secreta que genera Odoo y pegarla arriba.', 'wppe-bridge' ); ?></li>
		<li><?php esc_html_e( 'Action "Update Record": mapear los campos del payload (name, email_from, phone, contact_name, type, utm_source, etc.) al record creado.', 'wppe-bridge' ); ?></li>
		<li><?php esc_html_e( 'Para Odoo v15/16 (sin Automation Rules), instalar el modulo Python en docs/odoo-webhook-receiver.py del repo.', 'wppe-bridge' ); ?></li>
	</ol>

	<h3><?php esc_html_e( 'Make / Zapier / n8n', 'wppe-bridge' ); ?></h3>
	<ol>
		<li><?php esc_html_e( 'Crear scenario/zap/workflow con trigger "Webhook → Catch hook".', 'wppe-bridge' ); ?></li>
		<li><?php esc_html_e( 'Copiar la URL generada y pegarla arriba.', 'wppe-bridge' ); ?></li>
		<li><?php esc_html_e( 'Mandar un lead de prueba para que la herramienta capture el shape del JSON.', 'wppe-bridge' ); ?></li>
		<li><?php esc_html_e( 'Agregar steps siguientes: tu CRM final, Slack, email, etc.', 'wppe-bridge' ); ?></li>
	</ol>
</div>
