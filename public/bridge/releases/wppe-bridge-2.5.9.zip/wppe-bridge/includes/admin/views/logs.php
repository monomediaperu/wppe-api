<?php
/**
 * Vista del listado paginado de queue items.
 *
 * Variables disponibles:
 *
 * @var WPPE_Bridge_Logs_List_Table $table         Lista preparada.
 * @var string                       $flash         Codigo de flash.
 * @var int                          $retried       Cuantos se requeuearon.
 * @var string                       $active_status Filtro activo.
 * @var array<string,int>            $counts        Conteos por status.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

$wppe_bridge_status_labels = array(
	''                                         => __( 'Todos', 'wppe-bridge' ),
	WPPE_Bridge_Queue::STATUS_PENDING          => __( 'Pendientes', 'wppe-bridge' ),
	WPPE_Bridge_Queue::STATUS_SENT             => __( 'Enviados', 'wppe-bridge' ),
	WPPE_Bridge_Queue::STATUS_FAILED_TEMP      => __( 'Fallidos (temp)', 'wppe-bridge' ),
	WPPE_Bridge_Queue::STATUS_FAILED_PERMANENT => __( 'Fallidos (perm)', 'wppe-bridge' ),
	WPPE_Bridge_Queue::STATUS_DEDUPED          => __( 'Deduplicados', 'wppe-bridge' ),
);
?>
<div class="wrap wppe-bridge-wrap">
	<h1><?php esc_html_e( 'WP.pe Bridge — Logs', 'wppe-bridge' ); ?></h1>

	<?php if ( 'retried' === $flash ) : ?>
		<div class="notice notice-success is-dismissible">
			<p>
				<?php
				printf(
					/* translators: %d = numero de items requeueados. */
					esc_html( _n( '%d lead requeueado para reintento.', '%d leads requeueados para reintento.', max( 1, $retried ), 'wppe-bridge' ) ),
					(int) $retried
				);
				?>
			</p>
		</div>
	<?php endif; ?>

	<ul class="subsubsub">
		<?php
		$wppe_bridge_first = true;
		foreach ( $wppe_bridge_status_labels as $wppe_bridge_skey => $wppe_bridge_slabel ) :
			$wppe_bridge_url     = add_query_arg(
				array(
					'page'   => WPPE_Bridge_Admin_Menu::SLUG . '-logs',
					'status' => $wppe_bridge_skey,
				),
				admin_url( 'admin.php' )
			);
			$wppe_bridge_count   = isset( $counts[ $wppe_bridge_skey ] ) ? (int) $counts[ $wppe_bridge_skey ] : 0;
			$wppe_bridge_classes = $active_status === $wppe_bridge_skey ? 'current' : '';
			?>
			<li>
				<?php
				if ( ! $wppe_bridge_first ) :
					?>
					| <?php endif; ?>
				<a href="<?php echo esc_url( $wppe_bridge_url ); ?>" class="<?php echo esc_attr( $wppe_bridge_classes ); ?>">
					<?php echo esc_html( $wppe_bridge_slabel ); ?>
					<span class="count">(<?php echo (int) $wppe_bridge_count; ?>)</span>
				</a>
			</li>
			<?php
			$wppe_bridge_first = false;
		endforeach;
		?>
	</ul>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="<?php echo esc_attr( WPPE_Bridge_Logs_Page::ACTION_BULK ); ?>"/>
		<?php wp_nonce_field( WPPE_Bridge_Logs_Page::NONCE_ACTION ); ?>
		<?php $table->display(); ?>
	</form>
</div>
