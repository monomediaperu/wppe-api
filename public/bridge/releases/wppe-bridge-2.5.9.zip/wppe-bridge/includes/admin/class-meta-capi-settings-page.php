<?php
/**
 * Sub-pagina admin oculta para configurar Meta CAPI.
 *
 * Accesible via link "Configurar" desde la lista de Modulos. No
 * aparece en el menu principal — solo es alcanzable cuando el modulo
 * Meta CAPI esta activado y el admin abre su configuracion avanzada.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sub-pagina de configuracion Meta CAPI.
 */
final class WPPE_Bridge_Meta_Capi_Settings_Page {

	/**
	 * Slug de la pagina (subpage de WP.pe Bridge).
	 */
	public const PAGE_SLUG = 'wppe-bridge-meta-capi';

	/**
	 * Settings group de WP Settings API.
	 */
	public const OPTION_GROUP = 'wppe_bridge_meta_capi_settings';

	/**
	 * Lista de option keys con sus sanitizers.
	 */
	public const OPTIONS = array(
		WPPE_Bridge_Module_Meta_Capi::OPTION_PIXEL_ID     => 'sanitize_pixel_id',
		WPPE_Bridge_Module_Meta_Capi::OPTION_ACCESS_TOKEN => 'sanitize_access_token',
		WPPE_Bridge_Module_Meta_Capi::OPTION_TEST_EVENT_CODE => 'sanitize_test_event_code',
		WPPE_Bridge_Module_Meta_Capi::OPTION_EVENT_NAME   => 'sanitize_event_name',
	);

	/**
	 * Registra hooks: settings + submenu oculto.
	 *
	 * @return void
	 */
	public static function register_settings(): void {
		foreach ( self::OPTIONS as $key => $cb ) {
			register_setting(
				self::OPTION_GROUP,
				$key,
				array( 'sanitize_callback' => array( self::class, $cb ) )
			);
		}
	}

	/**
	 * Renderiza la pagina.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$pixel_id        = (string) get_option( WPPE_Bridge_Module_Meta_Capi::OPTION_PIXEL_ID, '' );
		$has_token       = '' !== (string) get_option( WPPE_Bridge_Module_Meta_Capi::OPTION_ACCESS_TOKEN, '' );
		$test_event_code = (string) get_option( WPPE_Bridge_Module_Meta_Capi::OPTION_TEST_EVENT_CODE, '' );
		$event_name      = WPPE_Bridge_Module_Meta_Capi::get_event_name();
		$allowed_events  = WPPE_Bridge_Module_Meta_Capi::ALLOWED_EVENT_NAMES;

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/meta-capi-settings.php';
	}

	// ---------- sanitizers ----------

	/**
	 * Sanitiza Pixel ID: solo digitos.
	 *
	 * @param mixed $value Valor.
	 * @return string
	 */
	public static function sanitize_pixel_id( $value ): string {
		$clean = is_string( $value ) ? preg_replace( '/\D/', '', $value ) : '';
		return null === $clean ? '' : $clean;
	}

	/**
	 * Sanitiza Access Token: trim. Vacio conserva valor previo (D9).
	 *
	 * @param mixed $value Valor.
	 * @return string
	 */
	public static function sanitize_access_token( $value ): string {
		$new = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $new ) {
			return (string) get_option( WPPE_Bridge_Module_Meta_Capi::OPTION_ACCESS_TOKEN, '' );
		}
		return $new;
	}

	/**
	 * Sanitiza Test Event Code: trim, alfanumerico (Meta usa
	 * formato `TEST12345`).
	 *
	 * @param mixed $value Valor.
	 * @return string
	 */
	public static function sanitize_test_event_code( $value ): string {
		$s = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $s ) {
			return '';
		}
		$clean = preg_replace( '/[^A-Za-z0-9]/', '', $s );
		// Convencion Meta: TEST_EVENT_CODE en uppercase.
		return null === $clean ? '' : strtoupper( $clean );
	}

	/**
	 * Sanitiza event_name: solo permite valores del whitelist de Meta.
	 * Cualquier valor fuera del whitelist cae al default (`Lead`).
	 * Esta option se comparte con el modulo Thank You Pixel — el
	 * dedup nativo de Meta requiere que ambos lados disparen el
	 * mismo `event_name` con el mismo `event_id`.
	 *
	 * @param mixed $value Valor.
	 * @return string
	 */
	public static function sanitize_event_name( $value ): string {
		$s = is_string( $value ) ? trim( $value ) : '';
		if ( in_array( $s, WPPE_Bridge_Module_Meta_Capi::ALLOWED_EVENT_NAMES, true ) ) {
			return $s;
		}
		return WPPE_Bridge_Module_Meta_Capi::EVENT_NAME_DEFAULT;
	}
}
