<?php
/**
 * Pagina admin de mapeo de campos HubSpot.
 *
 * UI para configurar:
 *
 * 1. **Sincronizacion de catalogos HubSpot** (`owners`,
 *    `contact_properties`, `lifecyclestage_options`). Boton AJAX
 *    contra el endpoint `wppe_bridge_sync_hubspot_catalogs`.
 *
 * 2. **Por cada form Fluent/Gravity/Elementor**: mapeo de campos
 *    del form a properties HubSpot (`email`, `firstname`,
 *    `lastname`, `phone`, etc — native + custom descubiertas
 *    del catalogo). Persiste en `wppe_bridge_hubspot_field_mapping`.
 *
 * 3. **Override per-form de `lifecyclestage`** (`inherit` /
 *    cualquier value del enum dinamico, incluyendo custom stages).
 *    Si invalido, default `inherit` (usa el global de Configuracion
 *    HubSpot).
 *
 * **Scope PR-2:** Esta sub-pagina persiste todas las opciones pero
 * el Worker / Destination todavia NO inyecta el field mapping ni el
 * lifecyclestage override — eso llega en PR-3 (junto con UTMs como
 * `hs_analytics_source` y custom properties por-form). Aviso visible
 * en la UI: "configuracion lista para v2.6.0 (PR-3)".
 *
 * **Asimetria con Odoo:** HubSpot NO tiene "tags" nativos en
 * contacts (la categorizacion se hace via custom properties o Lists).
 * Por eso esta pagina NO tiene un bloque de tags como Odoo. Si un
 * cliente quiere "tagear" leads, mapea un form field a una custom
 * property tipo enum (ej. `lead_source_form` con options `web` /
 * `landing` / `webinar`).
 *
 * **Asimetria con globals de Odoo:** En Odoo, el Mapping_Page
 * persiste `default_team_id` / `default_user_id` (porque requieren
 * validacion contra catalogo). En HubSpot, el `default_owner_id` y
 * el `default_lifecyclestage` ya viven en `Hubspot_Settings_Page`
 * (PR-1). Para no duplicar, el Mapping_Page solo agrega la validacion
 * suave: "el owner_id configurado no existe en el catalogo
 * sincronizado" como warning, no edita el option desde aqui.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pagina admin de mapeo de campos del form a contact properties HubSpot.
 */
final class WPPE_Bridge_Hubspot_Mapping_Page {

	/**
	 * Slug de la sub-pagina admin.
	 */
	public const PAGE_SLUG = 'wppe-bridge-hubspot-mapping';

	/**
	 * Action del POST handler para mapeo de campos por-form.
	 */
	public const ACTION_SAVE_FORM_MAPPING = 'wppe_bridge_save_hubspot_form_mapping';

	/**
	 * Nonce action para mapeo por-form.
	 */
	public const NONCE_FORM_MAPPING = 'wppe_bridge_save_hubspot_form_mapping';

	/**
	 * Lista fallback de contact properties HubSpot que el admin puede
	 * mapear desde campos del form. Subset de las properties native
	 * mas usadas en formularios web inmobiliarios.
	 *
	 * Cuando el catalogo esta sincronizado, el Mapping_Page ofrece
	 * TODAS las properties (native + custom) descubiertas — esta lista
	 * es solo el fallback para cuentas recien instaladas que no han
	 * sincronizado todavia.
	 *
	 * @var array<int,string>
	 */
	public const PAYLOAD_KEYS_FALLBACK = array(
		'email',
		'firstname',
		'lastname',
		'phone',
		'mobilephone',
		'company',
		'website',
		'jobtitle',
		'address',
		'city',
		'state',
		'zip',
		'country',
		'message',
	);

	/**
	 * Property que aporta "identidad" minima al lead — `email` es el
	 * unico, porque HubSpot lo usa como `idProperty` para el upsert
	 * (D-HS-1). Sin email mapeado, el destination no puede ni
	 * crear el contact.
	 *
	 * Subset paralelo a IDENTITY_KEYS de Odoo, pero mas estricto
	 * porque la validacion de email del destination ya es bloqueante
	 * (Hubspot_Destination::send hace early-return permanente si
	 * email falta — ver PR-1). El Mapping_Page solo evita guardar
	 * un mapping invalido que despues fallaria todos los leads.
	 *
	 * @var array<int,string>
	 */
	public const IDENTITY_KEYS = array(
		'email',
	);

	/**
	 * Valor especial del toggle per-form `lifecyclestage` que
	 * significa "usar el default global de Configuracion HubSpot".
	 * Los demas valores aceptados son los del enum dinamico
	 * (catalogo `lifecyclestage_options`) o el fallback
	 * `WPPE_Hubspot_Destination::ALLOWED_LIFECYCLESTAGES`.
	 */
	public const LIFECYCLESTAGE_INHERIT = 'inherit';

	/**
	 * Registra los handlers admin_post_*.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_post_' . self::ACTION_SAVE_FORM_MAPPING, array( self::class, 'handle_save_form_mapping' ) );
	}

	/**
	 * Renderiza la pagina.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$discovery_result = WPPE_Bridge_Form_Discovery::discover_all_with_reasons();
		$discovered       = $discovery_result['forms'];

		$catalogs        = get_option( 'wppe_bridge_hubspot_catalogs', array() );
		$catalogs        = is_array( $catalogs ) ? $catalogs : array();
		$catalogs_errors = isset( $catalogs['_errors'] ) && is_array( $catalogs['_errors'] ) ? $catalogs['_errors'] : array();
		$synced_at       = isset( $catalogs['_synced_at'] ) ? (int) $catalogs['_synced_at'] : 0;

		$owners_count            = isset( $catalogs['owners'] ) && is_array( $catalogs['owners'] ) ? count( $catalogs['owners'] ) : 0;
		$properties_count        = isset( $catalogs['contact_properties'] ) && is_array( $catalogs['contact_properties'] ) ? count( $catalogs['contact_properties'] ) : 0;
		$lifecycle_options       = isset( $catalogs['lifecyclestage_options'] ) && is_array( $catalogs['lifecyclestage_options'] ) ? $catalogs['lifecyclestage_options'] : array();
		$lifecycle_options_count = count( $lifecycle_options );

		// Properties disponibles para el dropdown del field map: union
		// del catalogo sincronizado + el fallback hardcoded (asegura
		// que algunos valores comunes esten siempre disponibles aunque
		// el catalogo no se haya sincronizado todavia).
		$payload_keys = self::available_payload_keys( $catalogs );

		// Mapeo per-form actual.
		$mapping = get_option( 'wppe_bridge_hubspot_field_mapping', array() );
		$mapping = is_array( $mapping ) ? $mapping : array();

		// Validacion suave: el owner_id global configurado, ¿existe en
		// el catalogo? Si el admin lo cargo a mano antes de sync, o lo
		// agarro de la URL del panel HubSpot, podria estar desactualizado.
		$default_owner_id    = (string) get_option( 'wppe_bridge_hubspot_default_owner_id', '' );
		$owner_id_in_catalog = self::is_owner_in_catalog( $default_owner_id, $catalogs );

		// Lo mismo para lifecyclestage default — si el cliente customizo
		// stages y borro alguno, podria quedar el option apuntando a un
		// stage inexistente. Validacion suave.
		$default_lifecyclestage    = (string) get_option( 'wppe_bridge_hubspot_default_lifecyclestage', '' );
		$lifecyclestage_in_catalog = self::is_lifecyclestage_in_catalog( $default_lifecyclestage, $catalogs );

		$selected_plugin = isset( $_GET['plugin'] ) ? sanitize_key( wp_unslash( $_GET['plugin'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$selected_form   = isset( $_GET['form'] ) ? sanitize_text_field( wp_unslash( $_GET['form'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$selected_form_data = null;
		if ( '' !== $selected_form && '' !== $selected_plugin && isset( $discovered[ $selected_plugin ] ) ) {
			foreach ( $discovered[ $selected_plugin ] as $form ) {
				if ( (string) $form['id'] === $selected_form ) {
					$selected_form_data = $form;
					break;
				}
			}
		}

		$existing_mapping = array(
			'fields'         => array(),
			'lifecyclestage' => self::LIFECYCLESTAGE_INHERIT,
		);
		if ( '' !== $selected_plugin && '' !== $selected_form && isset( $mapping[ $selected_plugin ][ $selected_form ] ) ) {
			$existing_mapping = array_merge( $existing_mapping, (array) $mapping[ $selected_plugin ][ $selected_form ] );
		}

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/hubspot-mapping.php';
	}

	/**
	 * Lista combinada de payload_keys disponibles para el dropdown.
	 * Une el catalogo sincronizado (`contact_properties[].name`) con
	 * el fallback hardcoded, deduplica preservando orden, y descarta
	 * properties marcadas como `archived`.
	 *
	 * Si el catalogo esta vacio (recien instalado, sin sync), retorna
	 * solo PAYLOAD_KEYS_FALLBACK.
	 *
	 * @param array<string,mixed> $catalogs Catalogos cacheados.
	 * @return array<int,string>
	 */
	public static function available_payload_keys( array $catalogs ): array {
		$out  = array();
		$seen = array();

		// Properties del catalogo sincronizado primero (las del cliente).
		$properties = isset( $catalogs['contact_properties'] ) && is_array( $catalogs['contact_properties'] ) ? $catalogs['contact_properties'] : array();
		foreach ( $properties as $prop ) {
			if ( ! is_array( $prop ) ) {
				continue;
			}
			if ( ! empty( $prop['archived'] ) ) {
				continue;
			}
			$name = isset( $prop['name'] ) ? (string) $prop['name'] : '';
			if ( '' === $name || isset( $seen[ $name ] ) ) {
				continue;
			}
			$out[]         = $name;
			$seen[ $name ] = true;
		}

		// Fallback hardcoded (solo agrega los que NO estaban ya).
		foreach ( self::PAYLOAD_KEYS_FALLBACK as $name ) {
			if ( isset( $seen[ $name ] ) ) {
				continue;
			}
			$out[]         = $name;
			$seen[ $name ] = true;
		}

		return $out;
	}

	/**
	 * Lista de lifecyclestage values aceptados para el toggle per-form.
	 * Une el enum dinamico del catalogo con el fallback hardcoded
	 * (`WPPE_Hubspot_Destination::ALLOWED_LIFECYCLESTAGES`).
	 *
	 * `inherit` siempre esta primero (es el default).
	 *
	 * @param array<string,mixed> $catalogs Catalogos cacheados.
	 * @return array<int,string>
	 */
	public static function available_lifecyclestage_choices( array $catalogs ): array {
		$out  = array( self::LIFECYCLESTAGE_INHERIT );
		$seen = array( self::LIFECYCLESTAGE_INHERIT => true );

		$dynamic = isset( $catalogs['lifecyclestage_options'] ) && is_array( $catalogs['lifecyclestage_options'] ) ? $catalogs['lifecyclestage_options'] : array();
		foreach ( $dynamic as $opt ) {
			if ( ! is_array( $opt ) ) {
				continue;
			}
			$value = isset( $opt['value'] ) ? (string) $opt['value'] : '';
			if ( '' === $value || isset( $seen[ $value ] ) ) {
				continue;
			}
			$out[]          = $value;
			$seen[ $value ] = true;
		}

		foreach ( WPPE_Hubspot_Destination::ALLOWED_LIFECYCLESTAGES as $value ) {
			if ( isset( $seen[ $value ] ) ) {
				continue;
			}
			$out[]          = $value;
			$seen[ $value ] = true;
		}

		return $out;
	}

	/**
	 * Verifica si un owner_id (string con digitos) existe en el
	 * catalogo `owners`. Coerce a string para comparacion (los IDs
	 * HubSpot llegan como int o string segun el endpoint).
	 *
	 * Vacio se considera valido (significa "no inyectar — usar reglas
	 * de assignment del portal", D-HS-3 / sec PR-1).
	 *
	 * @param string              $owner_id Id propuesto.
	 * @param array<string,mixed> $catalogs Catalogos cacheados.
	 * @return bool
	 */
	public static function is_owner_in_catalog( string $owner_id, array $catalogs ): bool {
		if ( '' === $owner_id ) {
			return true;
		}
		$owners = isset( $catalogs['owners'] ) && is_array( $catalogs['owners'] ) ? $catalogs['owners'] : array();
		// Si el catalogo no esta sincronizado, no podemos validar — no
		// mostrar warning (asumimos OK; si esta mal, el destination
		// fallara con permanent en runtime).
		if ( empty( $owners ) ) {
			return true;
		}
		foreach ( $owners as $owner ) {
			if ( is_array( $owner ) && isset( $owner['id'] ) && (string) $owner['id'] === $owner_id ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Verifica si un lifecyclestage value existe en el enum dinamico
	 * del catalogo. Vacio o catalogo no sincronizado -> true (no
	 * podemos validar, asumimos OK).
	 *
	 * @param string              $value     Lifecyclestage value.
	 * @param array<string,mixed> $catalogs  Catalogos cacheados.
	 * @return bool
	 */
	public static function is_lifecyclestage_in_catalog( string $value, array $catalogs ): bool {
		if ( '' === $value ) {
			return true;
		}
		$options = isset( $catalogs['lifecyclestage_options'] ) && is_array( $catalogs['lifecyclestage_options'] ) ? $catalogs['lifecyclestage_options'] : array();
		if ( empty( $options ) ) {
			return true;
		}
		foreach ( $options as $opt ) {
			if ( is_array( $opt ) && isset( $opt['value'] ) && (string) $opt['value'] === $value ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Handler del POST que guarda el mapeo de un form especifico.
	 *
	 * @return void
	 */
	public static function handle_save_form_mapping(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_FORM_MAPPING );

		$post   = wp_unslash( $_POST );
		$plugin = isset( $post['plugin'] ) ? sanitize_key( $post['plugin'] ) : '';
		$form   = isset( $post['form'] ) ? sanitize_text_field( $post['form'] ) : '';

		if ( '' === $plugin || '' === $form ) {
			wp_safe_redirect( self::redirect_url( $plugin, $form, 'error_missing_form' ) );
			exit;
		}

		$entry = self::build_form_entry_from_post( is_array( $post ) ? $post : array() );

		// Validacion: el form debe mapear `email` (HubSpot lo necesita
		// como idProperty del upsert). Sin email, el destination falla
		// permanente — mejor bloquear desde la UI.
		$missing = self::validate_required_fields( $entry );
		if ( ! empty( $missing ) ) {
			wp_safe_redirect( self::redirect_url( $plugin, $form, 'error_required', $missing ) );
			exit;
		}

		$current = get_option( 'wppe_bridge_hubspot_field_mapping', array() );
		if ( ! is_array( $current ) ) {
			$current = array();
		}
		if ( ! isset( $current[ $plugin ] ) || ! is_array( $current[ $plugin ] ) ) {
			$current[ $plugin ] = array();
		}
		$current[ $plugin ][ $form ] = $entry;

		update_option( 'wppe_bridge_hubspot_field_mapping', $current );

		wp_safe_redirect( self::redirect_url( $plugin, $form, 'saved' ) );
		exit;
	}

	/**
	 * Valida que el form mapping tenga `email` mapeado. Sin email,
	 * el destination no puede hacer upsert (D-HS-1, idProperty=email).
	 *
	 * @param array{fields:array<string,string>} $entry Entry construido.
	 * @return array<int,string> Lista de keys faltantes (vacio si OK).
	 */
	public static function validate_required_fields( array $entry ): array {
		$fields = isset( $entry['fields'] ) && is_array( $entry['fields'] ) ? $entry['fields'] : array();
		foreach ( $fields as $payload_key ) {
			if ( in_array( $payload_key, self::IDENTITY_KEYS, true ) ) {
				return array();
			}
		}
		return self::IDENTITY_KEYS;
	}

	/**
	 * Construye la entrada `{fields, lifecyclestage}` del POST.
	 *
	 * - `fields`: mapeo `form_field => contact_property`. Solo
	 *   acepta payload_keys disponibles (catalogo + fallback) — un
	 *   form field mapeado a una property que no existe se descarta
	 *   silenciosamente.
	 * - `lifecyclestage`: `inherit` o un value del enum dinamico /
	 *   fallback. Si invalido, default `inherit`.
	 *
	 * @param array $post POST sanitizado.
	 * @return array{fields:array<string,string>,lifecyclestage:string}
	 */
	public static function build_form_entry_from_post( array $post ): array {
		$catalogs        = get_option( 'wppe_bridge_hubspot_catalogs', array() );
		$catalogs        = is_array( $catalogs ) ? $catalogs : array();
		$allowed_keys    = self::available_payload_keys( $catalogs );
		$allowed_choices = self::available_lifecyclestage_choices( $catalogs );

		$fields    = array();
		$field_map = isset( $post['field_map'] ) && is_array( $post['field_map'] ) ? $post['field_map'] : array();

		foreach ( $field_map as $form_field => $payload_key ) {
			$form_field  = sanitize_text_field( (string) $form_field );
			$payload_key = is_string( $payload_key ) ? trim( $payload_key ) : '';
			if ( '' === $form_field || '' === $payload_key ) {
				continue;
			}
			if ( ! in_array( $payload_key, $allowed_keys, true ) ) {
				continue;
			}
			$fields[ $form_field ] = $payload_key;
		}

		// Lifecyclestage override per-form.
		$lifecyclestage = isset( $post['form_lifecyclestage'] ) ? sanitize_text_field( (string) $post['form_lifecyclestage'] ) : self::LIFECYCLESTAGE_INHERIT;
		if ( ! in_array( $lifecyclestage, $allowed_choices, true ) ) {
			$lifecyclestage = self::LIFECYCLESTAGE_INHERIT;
		}

		return array(
			'fields'         => $fields,
			'lifecyclestage' => $lifecyclestage,
		);
	}

	/**
	 * Construye URL de redirect post-save con flash messages.
	 *
	 * @param string            $plugin  Plugin slug.
	 * @param string            $form    Form ID.
	 * @param string            $flash   Codigo de mensaje.
	 * @param array<int,string> $missing Identity keys faltantes.
	 * @return string
	 */
	private static function redirect_url( string $plugin, string $form, string $flash, array $missing = array() ): string {
		$args = array(
			'page'  => self::PAGE_SLUG,
			'flash' => $flash,
		);
		if ( '' !== $plugin ) {
			$args['plugin'] = $plugin;
		}
		if ( '' !== $form ) {
			$args['form'] = $form;
		}
		if ( ! empty( $missing ) ) {
			$args['missing'] = implode( ',', $missing );
		}
		$base = function_exists( 'admin_url' ) ? admin_url( 'admin.php' ) : 'admin.php';
		return add_query_arg( $args, $base );
	}
}
