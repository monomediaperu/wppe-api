<?php
/**
 * Handlers AJAX del panel admin.
 *
 * Cada handler:
 * - Verifica capability (manage_options).
 * - Verifica nonce (check_ajax_referer).
 * - Devuelve JSON via wp_send_json_success / wp_send_json_error.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Handlers AJAX del panel admin.
 */
final class WPPE_Bridge_Admin_Ajax {

	/**
	 * Action AJAX para sincronizar catalogos Sperant.
	 */
	public const ACTION_SYNC_CATALOGS = 'wppe_bridge_sync_catalogs';

	/**
	 * Action AJAX para importar un catalogo Sperant manualmente (paste de JSON).
	 */
	public const ACTION_IMPORT_CATALOG = 'wppe_bridge_import_catalog';

	/**
	 * Action AJAX para sincronizar catalogos GHL (pipelines, custom fields, tags).
	 * v2.1.0 PR-2.
	 */
	public const ACTION_SYNC_GHL_CATALOGS = 'wppe_bridge_sync_ghl_catalogs';

	/**
	 * Action AJAX para sincronizar catalogos Odoo (teams, users,
	 * utm.source/medium/campaign, crm.tag, res.country).
	 * v2.5.0 PR-2.
	 */
	public const ACTION_SYNC_ODOO_CATALOGS = 'wppe_bridge_sync_odoo_catalogs';

	/**
	 * Action AJAX para forzar un check de actualizaciones del plugin.
	 * Invalida ambos caches (manifest propio + update_plugins de WP) y
	 * devuelve el estado fresco para que la card "Estado del plugin" en
	 * Inicio se refresque sin recargar la pagina. v2.5.x.
	 */
	public const ACTION_CHECK_UPDATES = 'wppe_bridge_check_updates';

	/**
	 * Action AJAX para sincronizar catalogos HubSpot (owners,
	 * contact_properties, lifecyclestage enum dinamico). v2.6.0 PR-2.
	 */
	public const ACTION_SYNC_HUBSPOT_CATALOGS = 'wppe_bridge_sync_hubspot_catalogs';

	/**
	 * Nonce action.
	 */
	public const NONCE_ACTION = 'wppe_bridge_admin_nonce';

	/**
	 * Catalogos validos para import manual.
	 */
	public const VALID_CATALOG_KEYS = array(
		'input_channels',
		'sources',
		'interest_types',
		'projects',
	);

	/**
	 * Registra los handlers en el hook wp_ajax_*.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'wp_ajax_' . self::ACTION_SYNC_CATALOGS, array( self::class, 'sync_catalogs' ) );
		add_action( 'wp_ajax_' . self::ACTION_IMPORT_CATALOG, array( self::class, 'import_catalog' ) );
		add_action( 'wp_ajax_' . self::ACTION_SYNC_GHL_CATALOGS, array( self::class, 'sync_ghl_catalogs' ) );
		add_action( 'wp_ajax_' . self::ACTION_SYNC_ODOO_CATALOGS, array( self::class, 'sync_odoo_catalogs' ) );
		add_action( 'wp_ajax_' . self::ACTION_CHECK_UPDATES, array( self::class, 'check_updates' ) );
		add_action( 'wp_ajax_' . self::ACTION_SYNC_HUBSPOT_CATALOGS, array( self::class, 'sync_hubspot_catalogs' ) );
	}

	/**
	 * Handler: sincronizar catalogos contra Sperant. Persiste en
	 * wp_options['wppe_bridge_catalogs'].
	 *
	 * @return void
	 */
	public static function sync_catalogs(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'No tienes permisos.', 'wppe-bridge' ) ),
				403
			);
		}

		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		$token = (string) get_option( 'wppe_bridge_api_token', '' );
		if ( '' === $token ) {
			wp_send_json_error(
				array( 'message' => __( 'No hay token configurado. Guardalo en Settings primero.', 'wppe-bridge' ) ),
				400
			);
		}

		$existing = get_option( 'wppe_bridge_catalogs', array() );
		$existing = is_array( $existing ) ? $existing : array();
		$result   = WPPE_Sperant_Client::sync_catalogs();

		// Si un catalogo viene vacio del API (ej. sources HTTP 404)
		// PERO ya hay data manual para ese catalogo, preservar la
		// data manual. Solo sobrescribimos con datos reales del API.
		$existing_sources = isset( $existing['_sources'] ) && is_array( $existing['_sources'] ) ? $existing['_sources'] : array();
		foreach ( self::VALID_CATALOG_KEYS as $catalog_key ) {
			$api_failed = isset( $result['_errors'][ $catalog_key ] );
			$has_manual = 'manual' === ( $existing_sources[ $catalog_key ] ?? '' );
			if ( $api_failed && $has_manual && isset( $existing[ $catalog_key ] ) ) {
				$result[ $catalog_key ] = $existing[ $catalog_key ];
				// Mantener la marca manual.
				if ( ! isset( $result['_sources'] ) ) {
					$result['_sources'] = array();
				}
				$result['_sources'][ $catalog_key ] = 'manual';
				// Mantener el error registrado pero adicionar nota.
				$result['_errors'][ $catalog_key ] .= ' (preservando import manual)';
			}
		}

		update_option( 'wppe_bridge_catalogs', $result );

		// Conteo por catalogo.
		$counts = array();
		foreach ( array( 'input_channels', 'sources', 'interest_types', 'projects' ) as $k ) {
			$counts[ $k ] = isset( $result[ $k ] ) && is_array( $result[ $k ] ) ? count( $result[ $k ] ) : 0;
		}

		$has_errors = isset( $result['_errors'] ) && ! empty( $result['_errors'] );

		wp_send_json_success(
			array(
				'counts'     => $counts,
				'errors'     => $has_errors ? $result['_errors'] : new \stdClass(),
				'has_errors' => $has_errors,
			)
		);
	}

	/**
	 * Handler: importar un catalogo manualmente desde el JSON pegado
	 * por el admin (workaround para endpoints no expuestos en API
	 * publica v3, caso conocido: /v3/sources retorna 404).
	 *
	 * El admin abre el panel web del cliente Sperant en otro tab,
	 * visita la URL `<sub>.sperant.com/<catalog>.json`, copia el JSON
	 * y lo pega en el textarea correspondiente. Este handler valida
	 * el JSON, lo aplana usando flatten_jsonapi_collection (acepta
	 * shape plano y JSON:API) y persiste en wp_options.
	 *
	 * Espera POST:
	 * - nonce
	 * - catalog: 'input_channels' | 'sources' | 'interest_types' | 'projects'
	 * - json: string con el JSON pegado
	 *
	 * @return void
	 */
	public static function import_catalog(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'No tienes permisos.', 'wppe-bridge' ) ),
				403
			);
		}

		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		$post    = wp_unslash( $_POST );
		$catalog = isset( $post['catalog'] ) ? sanitize_key( $post['catalog'] ) : '';
		$json    = isset( $post['json'] ) && is_string( $post['json'] ) ? trim( $post['json'] ) : '';

		if ( ! in_array( $catalog, self::VALID_CATALOG_KEYS, true ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Catalogo invalido.', 'wppe-bridge' ) ),
				400
			);
		}

		if ( '' === $json ) {
			wp_send_json_error(
				array( 'message' => __( 'JSON vacio. Pega el contenido completo del endpoint del panel Sperant.', 'wppe-bridge' ) ),
				400
			);
		}

		$decoded = json_decode( $json, true );
		if ( null === $decoded && JSON_ERROR_NONE !== json_last_error() ) {
			wp_send_json_error(
				array(
					'message' => sprintf(
						/* translators: %s = error de parseo JSON */
						__( 'JSON invalido: %s', 'wppe-bridge' ),
						json_last_error_msg()
					),
				),
				400
			);
		}

		// Aplanar al shape uniforme [{id, name, ...}] usando el helper
		// del SperantClient (acepta shape plano y JSON:API).
		$flattened = WPPE_Sperant_Client::flatten_jsonapi_collection( $decoded );

		if ( empty( $flattened ) ) {
			wp_send_json_error(
				array( 'message' => __( 'El JSON no contiene items con `id`. Verifica que estes pegando el contenido correcto.', 'wppe-bridge' ) ),
				400
			);
		}

		// Persistir manteniendo el resto de los catalogos intactos.
		$current_catalogs = get_option( 'wppe_bridge_catalogs', array() );
		if ( ! is_array( $current_catalogs ) ) {
			$current_catalogs = array();
		}
		$current_catalogs[ $catalog ] = $flattened;

		// Si habia un error en _errors para este catalogo, limpiarlo
		// porque ahora tenemos data manual valida.
		if ( isset( $current_catalogs['_errors'] ) && is_array( $current_catalogs['_errors'] ) ) {
			unset( $current_catalogs['_errors'][ $catalog ] );
			if ( empty( $current_catalogs['_errors'] ) ) {
				unset( $current_catalogs['_errors'] );
			}
		}

		// Marcar este catalogo como "manual" para diferenciar del sync API.
		if ( ! isset( $current_catalogs['_sources'] ) || ! is_array( $current_catalogs['_sources'] ) ) {
			$current_catalogs['_sources'] = array();
		}
		$current_catalogs['_sources'][ $catalog ] = 'manual';

		update_option( 'wppe_bridge_catalogs', $current_catalogs );

		wp_send_json_success(
			array(
				'catalog' => $catalog,
				'count'   => count( $flattened ),
				'message' => sprintf(
					/* translators: 1: count, 2: catalog key */
					_n( '%1$d item importado en "%2$s".', '%1$d items importados en "%2$s".', count( $flattened ), 'wppe-bridge' ),
					count( $flattened ),
					$catalog
				),
			)
		);
	}

	/**
	 * Handler: sincronizar catalogos contra GHL. Persiste en
	 * wp_options['wppe_bridge_ghl_catalogs']. v2.1.0 PR-2.
	 *
	 * @return void
	 */
	public static function sync_ghl_catalogs(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'No tienes permisos.', 'wppe-bridge' ) ),
				403
			);
		}

		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		$token = (string) get_option( 'wppe_bridge_ghl_token', '' );
		if ( '' === $token ) {
			wp_send_json_error(
				array( 'message' => __( 'No hay PIT configurado. Guardalo en Configuracion GHL primero.', 'wppe-bridge' ) ),
				400
			);
		}

		$location_id = (string) get_option( 'wppe_bridge_ghl_location_id', '' );
		if ( '' === $location_id ) {
			wp_send_json_error(
				array( 'message' => __( 'No hay Location ID configurado. Guardalo en Configuracion GHL primero.', 'wppe-bridge' ) ),
				400
			);
		}

		$result = WPPE_Ghl_Client::sync_catalogs();

		update_option( 'wppe_bridge_ghl_catalogs', $result );

		$counts = array(
			'pipelines'     => is_array( $result['pipelines'] ?? null ) ? count( $result['pipelines'] ) : 0,
			'custom_fields' => is_array( $result['custom_fields'] ?? null ) ? count( $result['custom_fields'] ) : 0,
			'tags'          => is_array( $result['tags'] ?? null ) ? count( $result['tags'] ) : 0,
		);

		$has_errors = isset( $result['_errors'] ) && ! empty( $result['_errors'] );

		wp_send_json_success(
			array(
				'counts'     => $counts,
				'errors'     => $has_errors ? $result['_errors'] : new \stdClass(),
				'has_errors' => $has_errors,
				'synced_at'  => $result['_synced_at'] ?? 0,
			)
		);
	}

	/**
	 * Handler: sincronizar catalogos contra Odoo. Persiste en
	 * wp_options['wppe_bridge_odoo_catalogs']. v2.5.0 PR-2.
	 *
	 * Verifica las 4 credenciales (base_url/db/login/api_key) antes de
	 * llamar — sin alguna, retorna 400 con mensaje accionable. Si la
	 * llamada arranca pero algun catalogo falla parcialmente
	 * (ej. el cliente no tiene `utm` instalado y `utm.source` retorna
	 * AccessError), persiste igual los que funcionaron y reporta los
	 * errores parciales al frontend.
	 *
	 * @return void
	 */
	public static function sync_odoo_catalogs(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'No tienes permisos.', 'wppe-bridge' ) ),
				403
			);
		}

		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		// Las 4 credenciales son obligatorias. Mensaje preciso para que
		// el admin sepa cual le falta.
		$missing = array();
		foreach ( array( 'base_url', 'db', 'login', 'api_key' ) as $key ) {
			if ( '' === (string) get_option( 'wppe_bridge_odoo_' . $key, '' ) ) {
				$missing[] = $key;
			}
		}
		if ( ! empty( $missing ) ) {
			wp_send_json_error(
				array(
					'message' => sprintf(
						/* translators: %s: comma-separated list of missing credential keys */
						__( 'Faltan credenciales Odoo: %s. Cargalas en Configuracion Odoo primero.', 'wppe-bridge' ),
						implode( ', ', $missing )
					),
				),
				400
			);
		}

		$result = WPPE_Odoo_Client::sync_catalogs();

		update_option( 'wppe_bridge_odoo_catalogs', $result );

		$counts = array(
			'teams'         => is_array( $result['teams'] ?? null ) ? count( $result['teams'] ) : 0,
			'users'         => is_array( $result['users'] ?? null ) ? count( $result['users'] ) : 0,
			'utm_sources'   => is_array( $result['utm_sources'] ?? null ) ? count( $result['utm_sources'] ) : 0,
			'utm_mediums'   => is_array( $result['utm_mediums'] ?? null ) ? count( $result['utm_mediums'] ) : 0,
			'utm_campaigns' => is_array( $result['utm_campaigns'] ?? null ) ? count( $result['utm_campaigns'] ) : 0,
			'tags'          => is_array( $result['tags'] ?? null ) ? count( $result['tags'] ) : 0,
			'countries'     => is_array( $result['countries'] ?? null ) ? count( $result['countries'] ) : 0,
		);

		$has_errors = isset( $result['_errors'] ) && ! empty( $result['_errors'] );

		wp_send_json_success(
			array(
				'counts'     => $counts,
				'errors'     => $has_errors ? $result['_errors'] : new \stdClass(),
				'has_errors' => $has_errors,
				'synced_at'  => $result['_synced_at'] ?? 0,
			)
		);
	}

	/**
	 * Handler: forzar un check de actualizaciones del plugin (v2.5.x).
	 *
	 * Invalida el cache propio del Updater + el `update_plugins` site
	 * transient de WP (para que el badge "Update available" en
	 * wp-admin -> Plugins se refresque tambien), hace un fetch fresco
	 * del manifest, y devuelve el `Updater::get_status()` para que la
	 * card "Estado del plugin" se actualice sin recargar.
	 *
	 * El usuario tipico path: clickea "Buscar ahora" -> JS hace el AJAX
	 * -> server invalida ambos caches + re-fetcha -> JS re-renderiza
	 * el bloque con la version remota fresca + (eventualmente) badge
	 * de "hay actualizacion".
	 *
	 * @return void
	 */
	public static function check_updates(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'No tienes permisos.', 'wppe-bridge' ) ),
				403
			);
		}
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		WPPE_Bridge_Updater::force_refresh();
		$status = WPPE_Bridge_Updater::get_status();

		wp_send_json_success( $status );
	}

	/**
	 * Handler: sincronizar catalogos contra HubSpot (v2.6.0 PR-2).
	 * Persiste en `wp_options['wppe_bridge_hubspot_catalogs']` el shape:
	 *   { owners, contact_properties, lifecyclestage_options, _errors, _synced_at }.
	 *
	 * Mensaje preciso si el access_token falta. Si la llamada arranca
	 * pero algun catalogo falla parcialmente (caso clasico: cuenta
	 * HubSpot Free donde `/crm/v3/owners` retorna 403 — el de
	 * properties igual sincroniza), persiste los que funcionaron y
	 * reporta los errores al frontend.
	 *
	 * @return void
	 */
	public static function sync_hubspot_catalogs(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'No tienes permisos.', 'wppe-bridge' ) ),
				403
			);
		}

		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		$token = (string) get_option( 'wppe_bridge_hubspot_access_token', '' );
		if ( '' === $token ) {
			wp_send_json_error(
				array(
					'message' => __( 'Falta el Private App access token. Configuralo en Configuracion HubSpot primero.', 'wppe-bridge' ),
				),
				400
			);
		}

		$result = WPPE_Hubspot_Client::sync_catalogs();

		update_option( 'wppe_bridge_hubspot_catalogs', $result );

		$counts = array(
			'owners'                 => is_array( $result['owners'] ?? null ) ? count( $result['owners'] ) : 0,
			'contact_properties'     => is_array( $result['contact_properties'] ?? null ) ? count( $result['contact_properties'] ) : 0,
			'lifecyclestage_options' => is_array( $result['lifecyclestage_options'] ?? null ) ? count( $result['lifecyclestage_options'] ) : 0,
		);

		$has_errors = isset( $result['_errors'] ) && ! empty( $result['_errors'] );

		wp_send_json_success(
			array(
				'counts'     => $counts,
				'errors'     => $has_errors ? $result['_errors'] : new \stdClass(),
				'has_errors' => $has_errors,
				'synced_at'  => $result['_synced_at'] ?? 0,
			)
		);
	}
}
