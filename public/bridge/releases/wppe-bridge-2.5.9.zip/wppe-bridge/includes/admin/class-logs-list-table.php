<?php
/**
 * WP_List_Table para queue items en la pagina admin Logs.
 *
 * Muestra registros de wp_wppebridge_queue con paginacion, filtro
 * por status y bulk action de retry.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * List table de queue items.
 */
final class WPPE_Bridge_Logs_List_Table extends WP_List_Table {

	/**
	 * Default items per page.
	 */
	public const PER_PAGE_DEFAULT = 25;

	/**
	 * Status filter activo.
	 *
	 * @var string|null
	 */
	private ?string $filter_status = null;

	/**
	 * Constructor — inicializa labels singular/plural y modo no-AJAX.
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'wppe_bridge_queue_item',
				'plural'   => 'wppe_bridge_queue_items',
				'ajax'     => false,
			)
		);
	}

	/**
	 * Columns headers.
	 *
	 * @return array<string,string>
	 */
	public function get_columns(): array {
		// v2.4.0 (decisiones D-Logs C+E): agregadas `destination` (CRM
		// activo del momento) y `error` (mensaje truncado) para que el
		// admin no tenga que abrir cada lead para entender que paso.
		return array(
			'cb'          => '<input type="checkbox" />',
			'id'          => __( 'ID', 'wppe-bridge' ),
			'created'     => __( 'Fecha', 'wppe-bridge' ),
			'form'        => __( 'Form', 'wppe-bridge' ),
			'email'       => __( 'Email', 'wppe-bridge' ),
			'destination' => __( 'CRM', 'wppe-bridge' ),
			'status'      => __( 'Status', 'wppe-bridge' ),
			'attempts'    => __( 'Intentos', 'wppe-bridge' ),
			'error'       => __( 'Error', 'wppe-bridge' ),
		);
	}

	/**
	 * Bulk actions.
	 *
	 * @return array<string,string>
	 */
	public function get_bulk_actions(): array {
		return array(
			'retry' => __( 'Reintentar', 'wppe-bridge' ),
		);
	}

	/**
	 * Carga items para la pagina actual.
	 *
	 * @return void
	 */
	public function prepare_items(): void {
		$this->_column_headers = array( $this->get_columns(), array(), array() );

		$this->filter_status = isset( $_GET['status'] ) && is_string( $_GET['status'] ) && '' !== $_GET['status']  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			? sanitize_key( wp_unslash( $_GET['status'] ) )                                                          // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: null;

		$per_page     = self::PER_PAGE_DEFAULT;
		$current_page = $this->get_pagenum();

		$this->items = WPPE_Bridge_Queue::paginate(
			array(
				'status'   => $this->filter_status,
				'per_page' => $per_page,
				'page'     => $current_page,
			)
		);

		$total = WPPE_Bridge_Queue::count_by_status( $this->filter_status );

		$this->set_pagination_args(
			array(
				'total_items' => $total,
				'per_page'    => $per_page,
				'total_pages' => (int) ceil( $total / $per_page ),
			)
		);
	}

	/**
	 * Render del checkbox.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_cb( $item ): string {
		return sprintf( '<input type="checkbox" name="ids[]" value="%d" />', (int) $item->id );
	}

	/**
	 * Render columna ID con link a detalle + row actions inline
	 * (Ver / Reintentar / Pausar / Despausar) segun status del item.
	 *
	 * V2.4.0 D-Logs E: row actions inline para no obligar al admin a
	 * abrir el detalle para acciones comunes.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_id( $item ): string {
		$detail = add_query_arg(
			array(
				'page'   => WPPE_Bridge_Admin_Menu::SLUG . '-logs',
				'action' => 'view',
				'id'     => (int) $item->id,
			),
			admin_url( 'admin.php' )
		);

		$id_link = sprintf( '<a href="%s">#%d</a>', esc_url( $detail ), (int) $item->id );

		// Row actions inline.
		$actions      = $this->row_actions_for_item( $item );
		$actions_html = '';
		if ( ! empty( $actions ) ) {
			$actions_html = $this->row_actions( $actions );
		}

		return $id_link . $actions_html;
	}

	/**
	 * Construye row actions disponibles segun status del item.
	 *
	 * - Siempre: Ver detalle.
	 * - failed_temp: Pausar reintento, Reintentar ahora.
	 * - paused: Despausar (= reanudar reintentos), Reintentar ahora.
	 * - failed_permanent: Reintentar ahora (resetea status a pending).
	 * - pending/sent/deduped: solo Ver detalle.
	 *
	 * @param object $item Row de queue.
	 * @return array<string,string>
	 */
	private function row_actions_for_item( $item ): array {
		$id        = (int) $item->id;
		$status    = (string) $item->status;
		$nonce_url = static function ( string $action, int $qid ): string {
			return wp_nonce_url(
				add_query_arg(
					array(
						'action' => $action,
						'id'     => $qid,
					),
					admin_url( 'admin-post.php' )
				),
				WPPE_Bridge_Logs_Page::NONCE_ACTION
			);
		};

		$actions = array(
			'view' => sprintf(
				'<a href="%s">%s</a>',
				esc_url(
					add_query_arg(
						array(
							'page'   => WPPE_Bridge_Admin_Menu::SLUG . '-logs',
							'action' => 'view',
							'id'     => $id,
						),
						admin_url( 'admin.php' )
					)
				),
				esc_html__( 'Ver', 'wppe-bridge' )
			),
		);

		if ( WPPE_Bridge_Queue::STATUS_FAILED_TEMP === $status ) {
			$actions['retry_now'] = sprintf(
				'<a href="%s">%s</a>',
				esc_url( $nonce_url( WPPE_Bridge_Logs_Page::ACTION_RETRY, $id ) ),
				esc_html__( 'Reintentar ahora', 'wppe-bridge' )
			);
			$actions['pause']     = sprintf(
				'<a href="%s" style="color:#dba617">%s</a>',
				esc_url( $nonce_url( WPPE_Bridge_Logs_Page::ACTION_PAUSE, $id ) ),
				esc_html__( 'Pausar', 'wppe-bridge' )
			);
		} elseif ( WPPE_Bridge_Queue::STATUS_PAUSED === $status ) {
			$actions['resume']    = sprintf(
				'<a href="%s" style="color:#46b450">%s</a>',
				esc_url( $nonce_url( WPPE_Bridge_Logs_Page::ACTION_RESUME, $id ) ),
				esc_html__( 'Despausar', 'wppe-bridge' )
			);
			$actions['retry_now'] = sprintf(
				'<a href="%s">%s</a>',
				esc_url( $nonce_url( WPPE_Bridge_Logs_Page::ACTION_RETRY, $id ) ),
				esc_html__( 'Reintentar ahora', 'wppe-bridge' )
			);
		} elseif ( WPPE_Bridge_Queue::STATUS_FAILED_PERMANENT === $status ) {
			$actions['retry_now'] = sprintf(
				'<a href="%s" style="color:#2271b1">%s</a>',
				esc_url( $nonce_url( WPPE_Bridge_Logs_Page::ACTION_RETRY, $id ) ),
				esc_html__( 'Reintentar (resetea a pending)', 'wppe-bridge' )
			);
		}

		return $actions;
	}

	/**
	 * Render columna fecha.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_created( $item ): string {
		return esc_html( (string) $item->created_at );
	}

	/**
	 * Render columna form.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_form( $item ): string {
		return esc_html(
			sprintf( '%s #%s', $item->form_plugin, $item->form_id )
		);
	}

	/**
	 * Render columna email enmascarado.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_email( $item ): string {
		$payload = is_string( $item->payload ) ? json_decode( $item->payload, true ) : null;
		$email   = is_array( $payload ) && isset( $payload['email'] ) ? (string) $payload['email'] : '';
		return esc_html( WPPE_Bridge_Pii_Masker::mask_email( $email ) );
	}

	/**
	 * Render columna status como badge.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_status( $item ): string {
		$status    = (string) $item->status;
		$color_map = array(
			WPPE_Bridge_Queue::STATUS_PENDING          => '#dba617',
			WPPE_Bridge_Queue::STATUS_SENT             => '#46b450',
			WPPE_Bridge_Queue::STATUS_FAILED_TEMP      => '#dba617',
			WPPE_Bridge_Queue::STATUS_FAILED_PERMANENT => '#dc3232',
			WPPE_Bridge_Queue::STATUS_DEDUPED          => '#999',
			WPPE_Bridge_Queue::STATUS_PAUSED           => '#8a6d00',
		);
		$color     = $color_map[ $status ] ?? '#666';
		return sprintf(
			'<span style="color:%s;font-weight:600">%s</span>',
			esc_attr( $color ),
			esc_html( $status )
		);
	}

	/**
	 * Render columna "CRM" (destino activo del momento).
	 *
	 * Limitacion conocida: muestra el destino ACTIVO ahora del plugin,
	 * no el que estaba activo cuando se proceso el lead. La gran
	 * mayoria de los casos coinciden (los leads que llevan dias en la
	 * queue son raros). Si el cliente cambio de destino entre que se
	 * encolo y se procesa, el value puede no ser exacto. Para historico
	 * preciso necesitariamos columna `destination` en la tabla queue
	 * — overhead que no vale para v2.4.0.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_destination( $item ): string {
		unset( $item );
		$slug = class_exists( 'WPPE_Bridge_Destination_Factory' )
			? WPPE_Bridge_Destination_Factory::active_slug()
			: '';
		if ( '' === $slug ) {
			return '<em>—</em>';
		}
		return '<code>' . esc_html( $slug ) . '</code>';
	}

	/**
	 * Render columna "Error" (mensaje truncado del ultimo error).
	 *
	 * Lee del `destination_response['body']['message']` o `error_class`
	 * si el response esta poblado. Si no hay response (lead todavia no
	 * se proceso), muestra dash.
	 *
	 * v2.4.0 D-Logs C: critico para que el admin entienda al vistazo
	 * que paso con un lead sin abrir el detalle.
	 *
	 * V2.5.8: campo renombrado `sperant_response` → `destination_response`
	 * (rebrand agnostico al CRM).
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_error( $item ): string {
		$response = is_string( $item->destination_response )
			? json_decode( $item->destination_response, true )
			: null;

		if ( ! is_array( $response ) ) {
			return '<em>—</em>';
		}

		// Prioridad: message del body > error_class.
		$message = '';
		if ( isset( $response['body']['message'] ) ) {
			$msg = $response['body']['message'];
			if ( is_string( $msg ) ) {
				$message = $msg;
			} elseif ( is_array( $msg ) ) {
				$flat    = array_filter(
					$msg,
					static function ( $item ) {
						return is_string( $item ) && '' !== $item;
					}
				);
				$message = implode( '; ', $flat );
			}
		}
		if ( '' === $message && isset( $response['error_class'] ) ) {
			$message = (string) $response['error_class'];
		}
		if ( '' === $message ) {
			$status  = isset( $response['status'] ) ? (int) $response['status'] : 0;
			$message = $status > 0 ? sprintf( 'HTTP %d', $status ) : '';
		}

		if ( '' === $message ) {
			return '<em>—</em>';
		}

		// Truncar a 80 chars con ellipsis.
		$truncated = mb_strlen( $message ) > 80
			? mb_substr( $message, 0, 80 ) . '…'
			: $message;

		return '<span title="' . esc_attr( $message ) . '" style="color:#dc3232">' . esc_html( $truncated ) . '</span>';
	}

	/**
	 * Render columna intentos.
	 *
	 * @param object $item Row de queue.
	 * @return string
	 */
	protected function column_attempts( $item ): string {
		return (string) (int) $item->attempts;
	}

	/**
	 * Default column render (fallback).
	 *
	 * @param object $item        Row.
	 * @param string $column_name Nombre de columna.
	 * @return string
	 */
	protected function column_default( $item, $column_name ): string {
		return isset( $item->{$column_name} ) ? esc_html( (string) $item->{$column_name} ) : '';
	}

	/**
	 * Mensaje cuando no hay items.
	 *
	 * @return void
	 */
	public function no_items(): void {
		esc_html_e( 'No hay leads en la cola.', 'wppe-bridge' );
	}
}
