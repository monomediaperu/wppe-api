<?php
/**
 * Pagina admin de configuracion del Webhook generico.
 *
 * Persiste:
 *  - wppe_bridge_webhook_url            : URL del receiver
 *  - wppe_bridge_webhook_headers        : array name=>value de headers custom
 *  - wppe_bridge_webhook_default_type   : 'opportunity' (default) | 'lead'
 *  - wppe_bridge_webhook_default_tags   : array de strings
 *
 * Solo visible en el menu cuando active_destination = 'webhook'
 * (mismo patron que Sperant/GHL — Camino A asimetria aceptada).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pagina admin de configuracion especifica de Webhook.
 */
final class WPPE_Bridge_Webhook_Settings_Page {

	public const PAGE_SLUG       = 'wppe-bridge-webhook-config';
	public const OPTION_GROUP    = 'wppe_bridge_webhook_settings';
	public const SECTION_GENERAL = 'wppe_bridge_webhook_section_general';

	/**
	 * Lista de option keys que registramos para WP Settings API.
	 *
	 * @var array<string,string>
	 */
	public const OPTIONS = array(
		'wppe_bridge_webhook_url'          => 'sanitize_url',
		'wppe_bridge_webhook_headers'      => 'sanitize_headers',
		'wppe_bridge_webhook_default_type' => 'sanitize_default_type',
		'wppe_bridge_webhook_default_tags' => 'sanitize_default_tags',
	);

	/**
	 * Headers reservados que NO permitimos override (los seteamos
	 * nosotros desde Webhook_Destination::build_headers).
	 *
	 * @var array<int,string>
	 */
	public const RESERVED_HEADERS = array(
		'content-type',
		'accept',
		'host',
		'content-length',
	);

	/**
	 * Bootstrap.
	 *
	 * @return void
	 */
	public static function register_settings(): void {
		foreach ( self::OPTIONS as $option_key => $sanitize_cb ) {
			register_setting(
				self::OPTION_GROUP,
				$option_key,
				array(
					'sanitize_callback' => array( self::class, $sanitize_cb ),
				)
			);
		}
	}

	/**
	 * Renderiza la pagina.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$webhook_url  = (string) get_option( 'wppe_bridge_webhook_url', '' );
		$headers      = get_option( 'wppe_bridge_webhook_headers', array() );
		$headers      = is_array( $headers ) ? $headers : array();
		$default_type = (string) get_option( 'wppe_bridge_webhook_default_type', 'opportunity' );
		$default_tags = get_option( 'wppe_bridge_webhook_default_tags', array() );
		$default_tags = is_array( $default_tags ) ? $default_tags : array();

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/webhook-settings.php';
	}

	// ---------- sanitizers ----------

	/**
	 * Sanitiza la URL del webhook. Acepta solo HTTP/HTTPS. Si llega
	 * vacio y NO hay valor previo, registra settings_error porque sin
	 * URL el destino no puede enviar nada.
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_url( $value ): string {
		$raw = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $raw ) {
			$previous = (string) get_option( 'wppe_bridge_webhook_url', '' );
			if ( '' === $previous && function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_webhook_url',
					'wppe_bridge_webhook_url_required',
					__( 'La URL del webhook es obligatoria. Sin URL configurado, los leads no se enviaran al receiver.', 'wppe-bridge' )
				);
			}
			return $previous;
		}

		// Validar esquema HTTP/HTTPS y forma minima.
		$parts = wp_parse_url( $raw );
		if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			if ( function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_webhook_url',
					'wppe_bridge_webhook_url_invalid',
					__( 'URL invalida. Debe ser una URL completa con esquema (https://example.com/webhook).', 'wppe-bridge' )
				);
			}
			return (string) get_option( 'wppe_bridge_webhook_url', '' );
		}

		$scheme = strtolower( (string) $parts['scheme'] );
		if ( ! in_array( $scheme, array( 'http', 'https' ), true ) ) {
			if ( function_exists( 'add_settings_error' ) ) {
				add_settings_error(
					'wppe_bridge_webhook_url',
					'wppe_bridge_webhook_url_invalid_scheme',
					__( 'URL invalida. Solo se aceptan esquemas http:// y https://.', 'wppe-bridge' )
				);
			}
			return (string) get_option( 'wppe_bridge_webhook_url', '' );
		}

		// esc_url_raw para canonicalizar (sin escape de entidades HTML).
		return function_exists( 'esc_url_raw' ) ? (string) esc_url_raw( $raw ) : $raw;
	}

	/**
	 * Sanitiza headers custom desde el textarea (formato `Header: Value`
	 * por linea). Devuelve array name=>value listo para wp_remote_post.
	 *
	 * Reglas defensivas:
	 *  - Sin newlines en values (header injection prevention).
	 *  - Sin headers reservados (Content-Type, Accept, Host, Content-Length).
	 *  - Lineas sin `:` se ignoran silenciosamente.
	 *  - Lineas vacias se ignoran.
	 *
	 * @param mixed $value Textarea raw o array (legacy).
	 * @return array<string,string>
	 */
	public static function sanitize_headers( $value ): array {
		// Si llega array (caso legacy donde ya estaba persistido), se
		// re-aplana a textarea-like para sanitizar uniformemente.
		if ( is_array( $value ) ) {
			$lines = array();
			foreach ( $value as $name => $val ) {
				if ( is_string( $name ) && is_string( $val ) ) {
					$lines[] = $name . ': ' . $val;
				}
			}
			$value = implode( "\n", $lines );
		}
		if ( ! is_string( $value ) ) {
			return array();
		}

		$out = array();
		foreach ( preg_split( '/\r?\n/', $value ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, ':' ) ) {
				continue;
			}
			list( $name, $val ) = array_map( 'trim', explode( ':', $line, 2 ) );
			if ( '' === $name || '' === $val ) {
				continue;
			}
			// Header name: solo printable ASCII sin separadores HTTP.
			if ( ! preg_match( '/^[A-Za-z0-9!#$%&\'*+\-.^_`|~]+$/', $name ) ) {
				continue;
			}
			// Reservados: skipear silenciosamente.
			if ( in_array( strtolower( $name ), self::RESERVED_HEADERS, true ) ) {
				continue;
			}
			// Value: stripear cualquier control character (incluye \r, \n).
			$val = preg_replace( '/[\x00-\x1F\x7F]/', '', $val );
			if ( '' === $val ) {
				continue;
			}
			$out[ $name ] = $val;
		}
		return $out;
	}

	/**
	 * Sanitiza el toggle de tipo default ('opportunity' o 'lead').
	 *
	 * @param mixed $value Valor del input.
	 * @return string
	 */
	public static function sanitize_default_type( $value ): string {
		$value = is_string( $value ) ? trim( strtolower( $value ) ) : '';
		if ( in_array( $value, array( 'opportunity', 'lead' ), true ) ) {
			return $value;
		}
		return 'opportunity';
	}

	/**
	 * Sanitiza tags default (CSV o array).
	 *
	 * @param mixed $value Valor del input.
	 * @return array<int,string>
	 */
	public static function sanitize_default_tags( $value ): array {
		if ( is_string( $value ) ) {
			$value = array_map( 'trim', explode( ',', $value ) );
		}
		if ( ! is_array( $value ) ) {
			return array();
		}
		$out = array();
		foreach ( $value as $tag ) {
			if ( ! is_string( $tag ) ) {
				continue;
			}
			$tag = sanitize_text_field( trim( $tag ) );
			if ( '' !== $tag ) {
				$out[] = $tag;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Helper: convierte el array de headers a formato textarea para
	 * mostrar en la vista.
	 *
	 * @param array<string,string> $headers Headers persistidos.
	 * @return string
	 */
	public static function headers_to_textarea( array $headers ): string {
		$lines = array();
		foreach ( $headers as $name => $value ) {
			if ( is_string( $name ) && is_string( $value ) ) {
				$lines[] = $name . ': ' . $value;
			}
		}
		return implode( "\n", $lines );
	}
}
