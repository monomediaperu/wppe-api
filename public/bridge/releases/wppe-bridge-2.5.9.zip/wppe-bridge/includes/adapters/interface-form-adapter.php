<?php
/**
 * Interface de adapter de formulario.
 *
 * Cada adapter (Fluent Forms, Gravity Forms, Elementor) implementa
 * esta interface. Su responsabilidad: suscribirse al hook del plugin
 * de forms y traducir la submission a un payload normalizado para la
 * cola interna.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

interface WPPE_Bridge_Form_Adapter_Interface {

	/**
	 * Identificador del plugin de forms ('fluent', 'gravity', 'elementor').
	 */
	public static function plugin_slug(): string;

	/**
	 * Devuelve true si el plugin de forms esta activo en este WP.
	 */
	public static function is_available(): bool;

	/**
	 * Suscribe los hooks del plugin de forms. Idempotente.
	 */
	public static function register(): void;
}
