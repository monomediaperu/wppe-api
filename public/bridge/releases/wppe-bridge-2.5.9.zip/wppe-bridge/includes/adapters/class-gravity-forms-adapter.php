<?php
/**
 * Adapter para Gravity Forms.
 *
 * Hook nativo: `gform_after_submission`.
 * Args del callback: ($entry, $form).
 *
 * El `$entry` de Gravity es un array donde las keys son los IDs de
 * field (numericos como '1', '1.3', '2'). El `$form['fields']` trae
 * la metadata de cada field. Para que el mapping sea humanamente
 * legible, traducimos via `adminLabel` o `label` del field a un
 * "form field name" antes de delegar al base.
 *
 * Si el cliente prefiere mapear por ID numerico de Gravity, puede
 * configurar el `wppe_bridge_field_mapping` con esos IDs y deshabilitar
 * la traduccion via filter `wppe_bridge_gravity_resolve_field_name`.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Adapter para Gravity Forms.
 */
final class WPPE_Bridge_Gravity_Forms_Adapter extends WPPE_Bridge_Form_Adapter_Base {

	/**
	 * Slug del plugin de forms.
	 *
	 * @return string
	 */
	public static function plugin_slug(): string {
		return 'gravity';
	}

	/**
	 * Detecta si Gravity Forms esta activo.
	 *
	 * @return bool
	 */
	public static function is_available(): bool {
		$detected = class_exists( 'GFForms' );
		/**
		 * Filtra la deteccion de Gravity Forms. Permite a tests (o
		 * integraciones de tercero) forzar el resultado.
		 *
		 * @param bool $detected Resultado de la deteccion automatica.
		 */
		return (bool) apply_filters( 'wppe_bridge_gravity_is_available', $detected );
	}

	/**
	 * Suscribe el hook nativo de Gravity Forms.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'gform_after_submission', array( self::class, 'on_submission' ), 10, 2 );
	}

	/**
	 * Auto-registro condicional.
	 *
	 * @return void
	 */
	public static function maybe_register(): void {
		if ( self::is_available() ) {
			self::register();
		}
	}

	/**
	 * Callback del hook `gform_after_submission`.
	 *
	 * @param array $entry Datos de submission (key=field_id numerico).
	 * @param array $form  Definicion del form (incluye `fields[]`).
	 * @return void
	 */
	public static function on_submission( $entry, $form ): void {
		if ( ! is_array( $entry ) || ! is_array( $form ) ) {
			return;
		}

		$form_id  = isset( $form['id'] ) ? (string) $form['id'] : '';
		$entry_id = isset( $entry['id'] ) ? (string) $entry['id'] : '';

		// Traduccion de field IDs (numericos) a nombres legibles
		// usando adminLabel/label de la definicion del form.
		$form_data = self::resolve_field_names( $entry, $form );

		self::handle_submission( $form_data, $entry_id, $form_id );
	}

	/**
	 * Convierte el `$entry` de Gravity (keys = field_id numerico) a
	 * `field_name => value`. Prioriza `adminLabel` sobre `label`.
	 *
	 * @param array $entry Entry de Gravity.
	 * @param array $form  Definicion del form.
	 * @return array
	 */
	private static function resolve_field_names( array $entry, array $form ): array {
		$result = array();
		$fields = isset( $form['fields'] ) && is_array( $form['fields'] ) ? $form['fields'] : array();

		foreach ( $fields as $field ) {
			$field = is_array( $field ) ? $field : (array) $field;
			$id    = isset( $field['id'] ) ? (string) $field['id'] : '';
			if ( '' === $id ) {
				continue;
			}
			$name = '';
			if ( ! empty( $field['adminLabel'] ) && is_string( $field['adminLabel'] ) ) {
				$name = $field['adminLabel'];
			} elseif ( ! empty( $field['label'] ) && is_string( $field['label'] ) ) {
				$name = $field['label'];
			}
			if ( '' === $name ) {
				$name = 'field_' . $id;
			}

			/**
			 * Permite reemplazar la resolucion del nombre del field.
			 *
			 * @param string $name  Nombre resuelto.
			 * @param array  $field Definicion del field.
			 * @param array  $entry Entry completo.
			 */
			$name = apply_filters( 'wppe_bridge_gravity_resolve_field_name', $name, $field, $entry );

			if ( array_key_exists( $id, $entry ) ) {
				$result[ $name ] = $entry[ $id ];
			}
		}

		return $result;
	}
}
