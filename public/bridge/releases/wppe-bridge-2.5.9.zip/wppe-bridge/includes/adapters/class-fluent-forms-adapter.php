<?php
/**
 * Adapter para Fluent Forms Pro.
 *
 * Hook nativo: `fluentform/submission_inserted`.
 * Args del callback: ($entry_id, $form_data, $form).
 *
 * Decision D2 del CLAUDE.md: nunca leer la tabla interna del plugin.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Adapter para Fluent Forms Pro.
 */
final class WPPE_Bridge_Fluent_Forms_Adapter extends WPPE_Bridge_Form_Adapter_Base {

	/**
	 * Slug del plugin de forms.
	 *
	 * @return string
	 */
	public static function plugin_slug(): string {
		return 'fluent';
	}

	/**
	 * Detecta si Fluent Forms esta activo.
	 *
	 * Chequeo: constante `FLUENTFORM` (Pro y Free la definen) o la
	 * clase `FluentForm\Framework\Foundation\Application` (presente
	 * en versiones <5.x; en 5.x el namespace puede haber cambiado,
	 * pero la constante permanece).
	 *
	 * Filter `wppe_bridge_fluent_is_available` permite a tests (o
	 * integraciones de tercero) forzar el resultado. En produccion
	 * el filter no se intercepta y se retorna la deteccion real.
	 *
	 * @return bool
	 */
	public static function is_available(): bool {
		$detected = defined( 'FLUENTFORM' ) || class_exists( 'FluentForm\\Framework\\Foundation\\Application' );
		/**
		 * Filtra la deteccion de Fluent Forms.
		 *
		 * @param bool $detected Resultado de la deteccion automatica.
		 */
		return (bool) apply_filters( 'wppe_bridge_fluent_is_available', $detected );
	}

	/**
	 * Suscribe el hook nativo de Fluent Forms.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'fluentform/submission_inserted', array( self::class, 'on_submission' ), 10, 3 );
	}

	/**
	 * Auto-registro condicional.
	 *
	 * @return void
	 */
	public static function maybe_register(): void {
		if ( self::is_available() ) {
			self::register();
		}
	}

	/**
	 * Callback del hook `fluentform/submission_inserted`.
	 *
	 * @param int|string $entry_id   ID de la submission en Fluent.
	 * @param array      $form_data  Field name => value.
	 * @param object     $form       Objeto form de Fluent (al menos ->id).
	 * @return void
	 */
	public static function on_submission( $entry_id, $form_data, $form ): void {
		$form_id = '';
		if ( is_object( $form ) && isset( $form->id ) ) {
			$form_id = (string) $form->id;
		} elseif ( is_array( $form ) && isset( $form['id'] ) ) {
			$form_id = (string) $form['id'];
		}

		self::handle_submission(
			is_array( $form_data ) ? $form_data : array(),
			(string) $entry_id,
			$form_id
		);
	}
}
