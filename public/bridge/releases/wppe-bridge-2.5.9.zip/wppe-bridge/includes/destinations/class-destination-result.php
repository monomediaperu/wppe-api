<?php
/**
 * Resultado uniforme de un Destination::send().
 *
 * Value object inmutable que cualquier Destination debe retornar al
 * Worker. Aisla al Worker de los detalles de cada CRM — el Worker
 * solo lee `success` / `permanent` para decidir status y retry.
 *
 * Compat: `to_legacy_array()` devuelve el shape antiguo
 * `{status, body, raw, error_class}` que los hooks del plugin
 * exponen externamente (modulos Meta CAPI etc).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Resultado uniforme de un envio a CRM.
 */
final class WPPE_Bridge_Destination_Result {

	/**
	 * Constructor con readonly properties (PHP 8.1+).
	 *
	 * @param bool        $success    True si el CRM acepto el lead.
	 * @param int         $http_code  HTTP status code (0 si error de red).
	 * @param array       $response   Body parseado de la respuesta.
	 * @param string|null $error      Mensaje legible si fallo (null si exito).
	 * @param bool        $permanent  True = no reintentar (4xx no-429),
	 *                                false = reintentar (429, 5xx, network).
	 */
	public function __construct(
		public readonly bool $success,
		public readonly int $http_code,
		public readonly array $response,
		public readonly ?string $error,
		public readonly bool $permanent
	) {}

	/**
	 * Adapta el result al shape legacy `{status, body, raw, error_class}`
	 * que el Worker pasa a los hooks publicos del plugin
	 * (wppe_bridge_lead_sent, wppe_bridge_lead_failed). Mantener
	 * estable este shape preserva compat con modulos externos
	 * (Meta CAPI etc) que ya consumen esos hooks.
	 *
	 * @return array{status:int,body:array,raw:string,error_class:string}
	 */
	public function to_legacy_array(): array {
		if ( $this->success ) {
			$class = 'success';
		} elseif ( $this->permanent ) {
			$class = 'permanent';
		} else {
			$class = 'transient';
		}
		return array(
			'status'      => $this->http_code,
			'body'        => $this->response,
			'raw'         => '',
			'error_class' => $class,
		);
	}
}
