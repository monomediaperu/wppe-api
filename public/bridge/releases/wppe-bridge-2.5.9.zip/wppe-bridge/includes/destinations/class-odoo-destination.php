<?php
/**
 * Destino: Odoo CRM (modulo `crm.lead`).
 *
 * Envuelve `WPPE_Odoo_Client::create_lead()` (capa HTTP JSON-RPC) y
 * traduce su retorno al `Destination_Result` uniforme.
 *
 * **Scope v2.5.0 (PR-1 + PR-2 + PR-3):**
 *  - `type` ('opportunity'|'lead') desde la option global (default
 *    'opportunity' por D-Odoo-8) con override per-form (PR-3).
 *  - `name` (obligatorio en Odoo): si el payload no lo trae, lo
 *    derivamos del contact_name / email para que la creacion no
 *    rompa con ValidationError.
 *  - `team_id`/`user_id` desde options globales (PR-3).
 *  - `tag_ids` mergeando defaults globales + per-form, auto-creando
 *    tags faltantes en `crm.tag` (PR-3, best-effort).
 *  - `source_id`/`medium_id`/`campaign_id` matcheando UTMs flat del
 *    visitante contra catalogos `utm.source`/`utm.medium`/
 *    `utm.campaign` por nombre case-insensitive (PR-3).
 *  - `country_id` matcheando un value del form contra `res.country`
 *    primero por ISO code, luego por nombre case-insensitive con
 *    accent-strip (PR-3). `state_id` queda como TODO v2.5.x (Odoo
 *    necesita sync per-country; no vale la pena para LatAm en v2.5.0).
 *
 * Strippea keys upstream de otros destinos (fname/lname/source_id/...
 * de Sperant, locationId/pipelineId/... de GHL) para que Odoo no
 * reciba campos desconocidos. Odoo es estricto: si llega una key que
 * no existe en `crm.lead`, retorna `ValidationError` permanente.
 *
 * Naming sec 4.3 CLAUDE.md: clase `WPPE_Odoo_Destination` (no
 * `WPPE_Bridge_Odoo_Destination`) — mismo patron que `WPPE_Ghl_Destination`,
 * sin tocar Sperant_Destination.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Destination que envia leads a Odoo CRM via JSON-RPC.
 */
final class WPPE_Odoo_Destination implements WPPE_Bridge_Destination_Interface {

	public const SLUG  = 'odoo';
	public const LABEL = 'Odoo';

	/**
	 * Tipo default del registro `crm.lead` cuando el cliente no
	 * configuro la option (D-Odoo-8: 'opportunity' default).
	 *
	 * - `opportunity`: aparece directo en Pipeline view del salesperson.
	 * - `lead`: requiere feature "Leads" activado en CRM Settings + paso
	 *   manual de qualification antes de pipeline.
	 */
	public const DEFAULT_TYPE = 'opportunity';

	/**
	 * Valores aceptados por Odoo en `crm.lead.type`. Whitelist usado
	 * tanto por el sanitizer del settings page como por la inyeccion.
	 *
	 * @var array<int,string>
	 */
	public const ALLOWED_TYPES = array( 'opportunity', 'lead' );

	/**
	 * Slug unico del destino.
	 *
	 * @return string
	 */
	public static function slug(): string {
		return self::SLUG;
	}

	/**
	 * Label legible del destino para el dropdown admin.
	 *
	 * @return string
	 */
	public static function label(): string {
		return self::LABEL;
	}

	/**
	 * Envia el lead a Odoo via `WPPE_Odoo_Client::create_lead`.
	 *
	 * @param array $payload Payload ya normalizado por el adapter.
	 * @return WPPE_Bridge_Destination_Result
	 */
	public function send( array $payload ): WPPE_Bridge_Destination_Result {
		$values = self::map_payload_to_lead_values( $payload );

		$response = WPPE_Odoo_Client::create_lead( $values );

		$success   = WPPE_Odoo_Client::ERROR_CLASS_SUCCESS === $response['error_class'];
		$permanent = WPPE_Odoo_Client::ERROR_CLASS_PERMANENT === $response['error_class'];
		$error     = $success ? null : self::error_message_from_response( $response );

		return new WPPE_Bridge_Destination_Result(
			$success,
			(int) $response['status'],
			is_array( $response['body'] ) ? $response['body'] : array(),
			$error,
			$permanent
		);
	}

	/**
	 * Mapea el payload normalizado del bridge al shape esperado por
	 * `crm.lead` Odoo. v2.5.0 (PR-3 cierra el ciclo Odoo):
	 *
	 *  1. Capturar form context (`_form_plugin`/`_form_id`) y lookup
	 *     keys (`utm_*`, `country`) ANTES del strip — son keys que el
	 *     bridge usa para mapeo pero que Odoo no entiende, asi que
	 *     desaparecen del payload final pero si las leemos primero.
	 *  2. Strippear keys upstream de otros destinos (Sperant/GHL/CAPI)
	 *     + las lookup keys del paso 1.
	 *  3. Resolver `name` (obligatorio en Odoo) con cascada de fallbacks.
	 *  4. Resolver `type` con override per-form (PR-3) o global (PR-1).
	 *  5. Inyectar `team_id`/`user_id` desde options.
	 *  6. Inyectar `tag_ids` (mergea global + per-form, auto-crea
	 *     tags faltantes via `crm.tag/create`, formato `[[6,0,[ids]]]`).
	 *  7. Inyectar `source_id`/`medium_id`/`campaign_id` por matching
	 *     name-based contra catalogos UTM cacheados.
	 *  8. Inyectar `country_id` (ISO code primero, luego name con
	 *     accent strip).
	 *
	 * Catalogos vienen de `wppe_bridge_odoo_catalogs` (poblada por el
	 * sync de PR-2). Si el catalogo no esta sincronizado, los pasos 5-8
	 * se skippean silenciosamente — el lead se crea con lo que tenemos
	 * (name + identity + type) y queda como TODO en CRM para que el
	 * vendedor complete manualmente.
	 *
	 * @param array $payload Payload pre-clean.
	 * @return array<string,mixed> Values listos para `crm.lead.create`.
	 */
	public static function map_payload_to_lead_values( array $payload ): array {
		// Paso 1: capturar antes del strip.
		$form_plugin   = isset( $payload['_form_plugin'] ) ? (string) $payload['_form_plugin'] : '';
		$form_id       = isset( $payload['_form_id'] ) ? (string) $payload['_form_id'] : '';
		$utm_source    = isset( $payload['utm_source'] ) ? (string) $payload['utm_source'] : '';
		$utm_medium    = isset( $payload['utm_medium'] ) ? (string) $payload['utm_medium'] : '';
		$utm_campaign  = isset( $payload['utm_campaign'] ) ? (string) $payload['utm_campaign'] : '';
		$country_value = isset( $payload['country'] ) ? (string) $payload['country'] : '';

		$catalogs = self::get_catalogs();

		// Paso 2: strip.
		$values = self::strip_internal_and_other_destination_keys( $payload );

		// Pasos 3-4: name + type.
		$values['name'] = self::resolve_lead_name( $values, $payload );
		$values['type'] = self::resolve_type( $form_plugin, $form_id );

		// Pasos 5-8: inyecciones.
		self::inject_team_user( $values );
		self::inject_tags( $values, $form_plugin, $form_id, $catalogs );
		self::inject_utm_fks( $values, $utm_source, $utm_medium, $utm_campaign, $catalogs );
		self::inject_country( $values, $country_value, $catalogs );

		return $values;
	}

	/**
	 * Lee los catalogos cacheados en `wppe_bridge_odoo_catalogs` (poblados
	 * por el sync de PR-2). Defensivo: array vacio si la option no existe
	 * o no es array.
	 *
	 * @return array<string,mixed>
	 */
	private static function get_catalogs(): array {
		$catalogs = get_option( 'wppe_bridge_odoo_catalogs', array() );
		return is_array( $catalogs ) ? $catalogs : array();
	}

	/**
	 * Lee el field_mapping per-form persistido en
	 * `wppe_bridge_odoo_field_mapping` (PR-2). Devuelve el entry del form
	 * solicitado, con defaults seguros.
	 *
	 * @param string $form_plugin `fluent`/`gravity`/`elementor`.
	 * @param string $form_id     ID del form como string.
	 * @return array{fields:array<string,string>,tags:array<int,string>,type:string}
	 */
	private static function get_form_mapping_entry( string $form_plugin, string $form_id ): array {
		$default = array(
			'fields' => array(),
			'tags'   => array(),
			'type'   => 'inherit',
		);
		if ( '' === $form_plugin || '' === $form_id ) {
			return $default;
		}
		$mapping = get_option( 'wppe_bridge_odoo_field_mapping', array() );
		if ( ! is_array( $mapping ) ) {
			return $default;
		}
		$entry = $mapping[ $form_plugin ][ $form_id ] ?? null;
		if ( ! is_array( $entry ) ) {
			return $default;
		}
		return array(
			'fields' => is_array( $entry['fields'] ?? null ) ? $entry['fields'] : array(),
			'tags'   => is_array( $entry['tags'] ?? null ) ? array_values( $entry['tags'] ) : array(),
			'type'   => is_string( $entry['type'] ?? null ) ? $entry['type'] : 'inherit',
		);
	}

	/**
	 * Determina el nombre del lead. Cascada:
	 *  1. `name` del payload (si admin lo mapeo en PR-2).
	 *  2. `"Web lead - {contact_name}"` si hay contact_name.
	 *  3. `"Web lead - {email_from}"` si hay email_from.
	 *  4. `"Web lead - {fecha}"` (fallback). Garantiza que Odoo nunca
	 *     reciba name vacio (ValidationError).
	 *
	 * @param array $values  Payload post-strip (ya limpio de keys de
	 *                       otros destinos).
	 * @param array $payload Payload pre-strip (puede tener fname/lname
	 *                       Sperant-shape si el adapter no los mapeo
	 *                       a contact_name).
	 * @return string
	 */
	private static function resolve_lead_name( array $values, array $payload ): string {
		// Fast path: el admin ya configuro un name explicito.
		if ( isset( $values['name'] ) && is_string( $values['name'] ) && '' !== trim( $values['name'] ) ) {
			return trim( $values['name'] );
		}

		$contact_name = isset( $values['contact_name'] ) ? trim( (string) $values['contact_name'] ) : '';
		if ( '' !== $contact_name ) {
			return 'Web lead - ' . $contact_name;
		}

		// Fallback al fname/lname Sperant-shape pre-strip, por si el
		// adapter dejo esos en el payload pero no contact_name.
		$first = isset( $payload['fname'] ) ? trim( (string) $payload['fname'] ) : '';
		$last  = isset( $payload['lname'] ) ? trim( (string) $payload['lname'] ) : '';
		$full  = trim( $first . ' ' . $last );
		if ( '' !== $full ) {
			return 'Web lead - ' . $full;
		}

		$email = isset( $values['email_from'] ) ? trim( (string) $values['email_from'] ) : '';
		if ( '' === $email && isset( $payload['email'] ) ) {
			$email = trim( (string) $payload['email'] );
		}
		if ( '' !== $email ) {
			return 'Web lead - ' . $email;
		}

		return 'Web lead - ' . gmdate( 'Y-m-d H:i:s' );
	}

	/**
	 * Lee la option `wppe_bridge_odoo_default_type` con whitelist.
	 * Default 'opportunity' (D-Odoo-8). Cualquier valor fuera de
	 * `ALLOWED_TYPES` cae al default — defensivo.
	 *
	 * @return string
	 */
	public static function resolve_default_type(): string {
		$value = (string) get_option( 'wppe_bridge_odoo_default_type', self::DEFAULT_TYPE );
		if ( in_array( $value, self::ALLOWED_TYPES, true ) ) {
			return $value;
		}
		return self::DEFAULT_TYPE;
	}

	/**
	 * Resuelve `type` con cascada per-form -> global (PR-3).
	 *
	 * Lee el override per-form persistido en
	 * `wppe_bridge_odoo_field_mapping[plugin][form_id][type]`:
	 *  - `inherit` (default) -> usa el global (`resolve_default_type`).
	 *  - `opportunity` / `lead` -> override directo.
	 *  - cualquier otro -> defensivo, cae al global.
	 *
	 * Caso de uso: el global esta en `opportunity` (la mayoria de leads
	 * van directo al pipeline) pero un form de "auditoria gratis" se
	 * setea como `lead` para que pase por SDR antes de ir al AE.
	 *
	 * @param string $form_plugin `fluent`/`gravity`/`elementor`. Vacio
	 *                            si el payload no trae context (legacy).
	 * @param string $form_id     ID del form como string.
	 * @return string `opportunity` o `lead`.
	 */
	public static function resolve_type( string $form_plugin, string $form_id ): string {
		$entry = self::get_form_mapping_entry( $form_plugin, $form_id );
		$type  = $entry['type'];
		if ( in_array( $type, self::ALLOWED_TYPES, true ) ) {
			return $type;
		}
		// 'inherit' o invalido -> global.
		return self::resolve_default_type();
	}

	/**
	 * Lista de keys que Odoo NO entiende y que llegan al payload
	 * porque otros destinos las usan. Tres categorias:
	 *  - Meta keys del bridge (`_form_*`, `_submission_id`).
	 *  - Sperant-specific (input_channel_id, source_id, interest_type_id,
	 *    project_id, fname, lname, document).
	 *  - GHL-specific (locationId, pipelineId, firstName, lastName,
	 *    customFields, tags).
	 *  - Meta CAPI-only (client_ip, client_user_agent, fbp, fbclid,
	 *    landing_url, gclid).
	 *  - UTM flat — PR-3 las inyectara como utm.source_id/medium_id/
	 *    campaign_id (FK a modelos catalogo). En PR-1 se strippean.
	 *
	 * Critico: si Odoo recibe una key inexistente en `crm.lead`,
	 * retorna `ValidationError: Invalid field 'X'` permanente.
	 *
	 * @return array<int,string>
	 */
	public static function get_strippable_keys(): array {
		return array(
			// Meta keys del bridge.
			'_form_plugin',
			'_form_id',
			'_submission_id',
			// Sperant-specific.
			'input_channel_id',
			'source_id',
			'interest_type_id',
			'project_id',
			'fname',
			'lname',
			'document',
			// GHL-specific.
			'locationId',
			'pipelineId',
			'firstName',
			'lastName',
			'customFields',
			'tags',
			// UTM flat (PR-3 las inyecta como FK ids).
			'utm_source',
			'utm_medium',
			'utm_campaign',
			'utm_term',
			'utm_content',
			'gclid',
			'fbclid',
			'fbp',
			'landing_url',
			// Meta CAPI-only.
			'client_ip',
			'client_user_agent',
			// `email` plano (Odoo usa `email_from`). El adapter o el
			// mapping page de PR-2 mapea email -> email_from. Si quedo
			// en el payload, Odoo lo va a rechazar.
			'email',
			// Lookup keys del bridge (PR-3): se leen ANTES del strip
			// para inyectar como FK ids (`country_id`), pero la key
			// flat NO debe llegar al POST a Odoo — no es un campo
			// literal de `crm.lead` y rechazaria con ValidationError.
			'country',
			'state',
		);
	}

	/**
	 * Quita las keys de `get_strippable_keys()` del payload.
	 *
	 * @param array $payload Payload pre-clean.
	 * @return array
	 */
	private static function strip_internal_and_other_destination_keys( array $payload ): array {
		foreach ( self::get_strippable_keys() as $key ) {
			unset( $payload[ $key ] );
		}
		return $payload;
	}

	/**
	 * Pasos de setup especificos de Odoo para la pagina "Inicio".
	 *
	 * @return array<int,array{key:string,title:string,description:string,action_url:?string,action_label:?string}>
	 */
	public static function setup_guide(): array {
		$config_url = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=wppe-bridge-odoo-config' ) : '';
		return array(
			array(
				'key'          => 'odoo_api_key',
				'title'        => __( 'Como obtener la API Key de Odoo', 'wppe-bridge' ),
				'description'  => __( 'En el panel Odoo del cliente: <strong>Preferences (icono usuario) &rarr; Account Security &rarr; New API Key</strong>. Asignar un nombre descriptivo (ej. "WP.pe Bridge"). El usuario que genera la key debe tener al menos rol Sales / Salesperson para poder crear `crm.lead`. La key solo se muestra una vez al generarla — Mono Media la guarda en 1Password antes de pegarla aqui (D9 CLAUDE.md). Si la key se rota, basta con actualizarla en Configuracion Odoo y el plugin re-autentica solo.', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Ir a Configuracion Odoo', 'wppe-bridge' ),
			),
			array(
				'key'          => 'odoo_db_name',
				'title'        => __( 'Como saber el nombre de la base de datos (db)', 'wppe-bridge' ),
				'description'  => __( 'Para Odoo Online (SaaS): es el subdominio. Si tu URL es <code>https://mycompany.odoo.com</code>, el db es <code>mycompany</code>. Para self-hosted: lo eligio el sysadmin al crear la instancia (suele estar en `/etc/odoo/odoo.conf` bajo `db_name=`, o en la URL del selector si tenes multi-db). Sin db correcto, `authenticate` retorna 0 y todos los leads van a fallar con permanente.', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Ir a Configuracion Odoo', 'wppe-bridge' ),
			),
			array(
				'key'          => 'odoo_lead_vs_opportunity',
				'title'        => __( 'Lead vs Opportunity: que diferencia hay', 'wppe-bridge' ),
				'description'  => __( '<strong>Opportunity</strong> (default): el lead aparece directo en el Pipeline (vista Kanban), listo para que un salesperson lo trabaje. Es lo que la mayoria de inmobiliarias quieren.<br><br><strong>Lead</strong>: requiere activar el feature "Leads" en CRM Settings &rarr; CRM &rarr; Leads. Pasa por una etapa de qualification manual antes de convertirse en Opportunity. Tiene sentido si tu equipo separa SDR (qualification) de AE (closing). Cambiable desde Configuracion Odoo. Override por-form llegara en una version futura.', 'wppe-bridge' ),
				'action_url'   => null,
				'action_label' => null,
			),
			array(
				'key'          => 'odoo_verify_lead',
				'title'        => __( 'Como verificar un lead en el panel Odoo', 'wppe-bridge' ),
				'description'  => __( 'Despues de un lead de prueba con prefijo <code>__BRIDGE_TEST__</code>:<br><br>1. Login al panel Odoo del cliente.<br>2. Ir a <strong>CRM &rarr; Pipeline</strong> (Opportunities) o <strong>CRM &rarr; Leads</strong>, segun el tipo configurado.<br>3. Buscar por contact_name conteniendo <code>__BRIDGE_TEST__</code> o por email <code>bridge-test-*@mono.media</code>.<br>4. Verificar que el lead aparezca con email_from, phone y description correctos.<br><br>Si no aparece, revisar los Logs del plugin: error AccessDenied = api_key/login mal o usuario sin permisos CRM, ValidationError = payload con campo invalido (ej. una key strippeada que se filtro).', 'wppe-bridge' ),
				'action_url'   => null,
				'action_label' => null,
			),
			array(
				'key'          => 'odoo_no_dedup',
				'title'        => __( 'Odoo no dedupea leads automaticamente', 'wppe-bridge' ),
				'description'  => __( 'A diferencia de Sperant (que dedupea por email/documento) y GHL (cuando usas /contacts/upsert), <code>crm.lead.create</code> de Odoo siempre crea un registro nuevo. La defensa contra duplicados es la dedup local del bridge: hash + TTL 60s previene reenvios del mismo form (D4 CLAUDE.md). Para prevenir multiples leads del mismo prospecto a lo largo del tiempo, configura las "Lead deduplication" rules del propio Odoo: CRM Settings &rarr; CRM &rarr; Lead deduplication.', 'wppe-bridge' ),
				'action_url'   => null,
				'action_label' => null,
			),
		);
	}

	/**
	 * Construye un mensaje legible a partir del response (solo cuando
	 * fallo). JSON-RPC clasico de Odoo retorna `error.data.message`
	 * (string legible) y `error.data.name` (clase Python). Preferimos
	 * `message` para mostrar al admin, fallback al `name`.
	 *
	 * @param array $response Response uniforme del OdooClient.
	 * @return string
	 */
	private static function error_message_from_response( array $response ): string {
		$body = is_array( $response['body'] ?? null ) ? $response['body'] : array();

		if ( isset( $body['error'] ) && is_array( $body['error'] ) ) {
			$err = $body['error'];
			if ( isset( $err['data']['message'] ) && is_string( $err['data']['message'] ) && '' !== $err['data']['message'] ) {
				return $err['data']['message'];
			}
			if ( isset( $err['data']['name'] ) && is_string( $err['data']['name'] ) && '' !== $err['data']['name'] ) {
				return $err['data']['name'];
			}
			if ( isset( $err['message'] ) && is_string( $err['message'] ) && '' !== $err['message'] ) {
				return $err['message'];
			}
		}

		// Caso "auth fallo internamente": el client retorna error_name
		// 'WPPE_OdooAuthFailed' sin body. Mensaje explicito para el admin.
		$error_name = (string) ( $response['error_name'] ?? '' );
		if ( 'WPPE_OdooAuthFailed' === $error_name ) {
			return 'Auth con Odoo fallo. Verificar base_url, db, login y api_key en Configuracion Odoo.';
		}

		$status = (int) ( $response['status'] ?? 0 );
		if ( 0 === $status ) {
			return 'Network error or timeout';
		}
		return sprintf( 'HTTP %d', $status );
	}

	// =============================================================
	// PR-3 — Inyeccion de FK ids al payload de `crm.lead`.
	// =============================================================

	/**
	 * Inyecta `team_id` y `user_id` desde las options globales
	 * (`wppe_bridge_odoo_default_team_id` / `_default_user_id`,
	 * persistidas y validadas contra catalogo en PR-2).
	 *
	 * Si la option es vacia, NO se inyecta — Odoo aplica su propio
	 * default (generalmente: team_id segun reglas de assignment, user_id
	 * = round-robin del Sales Team). Esto es deseable: el cliente puede
	 * dejar `user_id` vacio para que Odoo distribuya leads entre el equipo.
	 *
	 * @param array $values Values del lead (mutado por referencia).
	 * @return void
	 */
	private static function inject_team_user( array &$values ): void {
		$team = (string) get_option( 'wppe_bridge_odoo_default_team_id', '' );
		$user = (string) get_option( 'wppe_bridge_odoo_default_user_id', '' );

		if ( '' !== $team && ctype_digit( $team ) ) {
			$values['team_id'] = (int) $team;
		}
		if ( '' !== $user && ctype_digit( $user ) ) {
			$values['user_id'] = (int) $user;
		}
	}

	/**
	 * Inyecta `tag_ids` mergando defaults globales + per-form, dedup
	 * preservando orden, resolviendo names a ids del catalogo, y formato
	 * Odoo-flavored `[[6, 0, [id1, id2, ...]]]` (set/replace command).
	 *
	 * Si un tag configurado por nombre no esta en el catalogo cacheado:
	 *  1. Llama a `Odoo_Client::create_tag($name)` (best-effort).
	 *  2. Si crea exitoso, persiste el nuevo {id, name} de vuelta en
	 *     `wppe_bridge_odoo_catalogs.tags` para no recrear en proximos
	 *     leads.
	 *  3. Si crea falla (network/permisos), loggea `info` y omite el
	 *     tag — el lead se crea sin el. Mejor que abortar todo el lead.
	 *
	 * @param array  $values      Values del lead (mutado).
	 * @param string $form_plugin Form context.
	 * @param string $form_id     Form context.
	 * @param array  $catalogs    Catalogos cacheados (`tags`).
	 * @return void
	 */
	private static function inject_tags( array &$values, string $form_plugin, string $form_id, array $catalogs ): void {
		$global_tags = get_option( 'wppe_bridge_odoo_default_tags', array() );
		$global_tags = is_array( $global_tags ) ? array_values( $global_tags ) : array();
		$form_entry  = self::get_form_mapping_entry( $form_plugin, $form_id );
		$per_form    = $form_entry['tags'];

		$merged = array();
		foreach ( array_merge( $global_tags, $per_form ) as $name ) {
			$name = trim( (string) $name );
			if ( '' !== $name && ! in_array( $name, $merged, true ) ) {
				$merged[] = $name;
			}
		}

		if ( empty( $merged ) ) {
			return;
		}

		$ids = self::ensure_tag_ids( $merged, $catalogs );
		if ( empty( $ids ) ) {
			return;
		}

		// Odoo command 6 = set/replace many2many. Triple bracket es a
		// proposito: outer es lista de comandos, inner es el comando
		// `[6, 0, [id1, id2]]`.
		$values['tag_ids'] = array( array( 6, 0, $ids ) );
	}

	/**
	 * Resuelve nombres de tags a ids. Para cada name:
	 *  1. Busca en catalogo cacheado (case-insensitive con trim).
	 *  2. Si no esta, llama `create_tag($name)` (best-effort).
	 *  3. Si crea OK, persiste el nuevo entry de vuelta al option
	 *     `wppe_bridge_odoo_catalogs.tags` para acelerar proximos
	 *     envios.
	 *  4. Si crea falla, skip + log info.
	 *
	 * @param array<int,string>   $names    Tag names a resolver.
	 * @param array<string,mixed> $catalogs Catalogos cacheados.
	 * @return array<int,int> Lista de ids resueltos (orden preservado;
	 *                         puede ser mas corta que `$names` si auto-create
	 *                         fallo para algunos).
	 */
	private static function ensure_tag_ids( array $names, array $catalogs ): array {
		$tags_catalog = isset( $catalogs['tags'] ) && is_array( $catalogs['tags'] ) ? $catalogs['tags'] : array();
		$resolved     = array();
		$created_any  = false;

		foreach ( $names as $name ) {
			$id = self::find_id_by_name_ci( $name, $tags_catalog );
			if ( null !== $id ) {
				$resolved[] = $id;
				continue;
			}
			// Auto-create best-effort.
			$response = WPPE_Odoo_Client::create_tag( $name );
			if ( WPPE_Odoo_Client::ERROR_CLASS_SUCCESS !== $response['error_class'] || ! is_int( $response['result'] ?? null ) ) {
				WPPE_Bridge_Logger::log(
					'info',
					'odoo: auto-create de crm.tag fallo, lead seguira sin este tag.',
					array(
						'tag_name'    => $name,
						'error_class' => (string) $response['error_class'],
						'error_name'  => (string) ( $response['error_name'] ?? '' ),
					)
				);
				continue;
			}
			$new_id         = (int) $response['result'];
			$resolved[]     = $new_id;
			$tags_catalog[] = array(
				'id'   => $new_id,
				'name' => $name,
			);
			$created_any    = true;
		}

		if ( $created_any ) {
			// Persistir back al cache para futuros leads.
			$catalogs['tags'] = $tags_catalog;
			update_option( 'wppe_bridge_odoo_catalogs', $catalogs );
		}

		return $resolved;
	}

	/**
	 * Inyecta `source_id`/`medium_id`/`campaign_id` matcheando los UTMs
	 * flat del visitante contra los catalogos `utm.source`/`utm.medium`/
	 * `utm.campaign` cacheados. Matching name-based case-insensitive con
	 * trim.
	 *
	 * Strict matching (D-Odoo PR-3 decision): si el visitante trae
	 * `utm_source=foobar` y no existe un record `utm.source` con ese
	 * nombre, NO se inyecta `source_id`. Auto-creacion de utm.* queda
	 * fuera de scope v2.5.0 (a diferencia de tags) — los catalogos UTM
	 * los curan los marketers, no se quieren ensuciar con typos del
	 * visitante o bots.
	 *
	 * @param array  $values    Values del lead (mutado).
	 * @param string $source    Value flat de `utm_source`.
	 * @param string $medium    Value flat de `utm_medium`.
	 * @param string $campaign  Value flat de `utm_campaign`.
	 * @param array  $catalogs  Catalogos cacheados.
	 * @return void
	 */
	private static function inject_utm_fks( array &$values, string $source, string $medium, string $campaign, array $catalogs ): void {
		$pairs = array(
			'source_id'   => array( $source, 'utm_sources' ),
			'medium_id'   => array( $medium, 'utm_mediums' ),
			'campaign_id' => array( $campaign, 'utm_campaigns' ),
		);
		foreach ( $pairs as $payload_key => $tuple ) {
			list( $value, $catalog_key ) = $tuple;
			if ( '' === trim( $value ) ) {
				continue;
			}
			$items = isset( $catalogs[ $catalog_key ] ) && is_array( $catalogs[ $catalog_key ] ) ? $catalogs[ $catalog_key ] : array();
			$id    = self::find_id_by_name_ci( $value, $items );
			if ( null !== $id ) {
				$values[ $payload_key ] = $id;
			}
		}
	}

	/**
	 * Inyecta `country_id` matcheando contra `res.country`.
	 *
	 * Heuristica:
	 *  1. Si el value matchea `^[A-Za-z]{2}$`, comparar contra `code` ISO
	 *     del catalogo (uppercase). Es la coincidencia mas confiable.
	 *  2. Si no matchea ISO o no se encontro id, comparar contra `name`
	 *     case-insensitive con accent-strip ("peru" matchea "Perú",
	 *     "PERU", "Perú " todos OK).
	 *
	 * Si nada matchea, NO se inyecta. Defensivo: mejor lead sin pais que
	 * lead con pais incorrecto.
	 *
	 * `state_id` queda como TODO v2.5.x (requiere sync de
	 * `res.country.state` per pais, demasiado para v2.5.0).
	 *
	 * @param array  $values   Values del lead (mutado).
	 * @param string $value    Value flat del field "country" del form.
	 * @param array  $catalogs Catalogos cacheados.
	 * @return void
	 */
	private static function inject_country( array &$values, string $value, array $catalogs ): void {
		$value = trim( $value );
		if ( '' === $value ) {
			return;
		}
		$countries = isset( $catalogs['countries'] ) && is_array( $catalogs['countries'] ) ? $catalogs['countries'] : array();
		if ( empty( $countries ) ) {
			return;
		}

		// Paso 1: ISO code si parece serlo.
		if ( 1 === preg_match( '/^[A-Za-z]{2}$/', $value ) ) {
			$code = strtoupper( $value );
			foreach ( $countries as $country ) {
				if ( ! is_array( $country ) ) {
					continue;
				}
				$country_code = isset( $country['code'] ) ? strtoupper( (string) $country['code'] ) : '';
				if ( '' !== $country_code && $country_code === $code && isset( $country['id'] ) ) {
					$values['country_id'] = (int) $country['id'];
					return;
				}
			}
		}

		// Paso 2: nombre case-insensitive con accent strip.
		$id = self::find_id_by_name_ci( $value, $countries, true );
		if ( null !== $id ) {
			$values['country_id'] = $id;
		}
	}

	/**
	 * Busca un `id` en una lista de `[{id, name, ...}]` por match
	 * case-insensitive del campo `name`. Defensivo contra entries
	 * malformados.
	 *
	 * @param string $needle           Value a buscar.
	 * @param array  $haystack         Lista de records (debe tener id+name).
	 * @param bool   $strip_accents_ok Si true, normaliza ambos lados
	 *                                  con `strip_accents` antes de comparar.
	 * @return int|null Id si match, null si no.
	 */
	private static function find_id_by_name_ci( string $needle, array $haystack, bool $strip_accents_ok = false ): ?int {
		$needle = trim( $needle );
		if ( '' === $needle ) {
			return null;
		}
		$lc_needle = self::normalize_for_match( $needle, $strip_accents_ok );

		foreach ( $haystack as $item ) {
			if ( ! is_array( $item ) || ! isset( $item['id'], $item['name'] ) ) {
				continue;
			}
			$candidate = self::normalize_for_match( (string) $item['name'], $strip_accents_ok );
			if ( $candidate === $lc_needle ) {
				return (int) $item['id'];
			}
		}
		return null;
	}

	/**
	 * Normaliza un string para comparacion: trim + lowercase. Si
	 * `$strip_accents_ok`, tambien strippea acentos comunes (Latin1
	 * range — Spanish/Portuguese/French) usando un strtr inline para
	 * no depender de `remove_accents` (WP) o `iconv//TRANSLIT` (locale).
	 *
	 * @param string $str              Input.
	 * @param bool   $strip_accents_ok Si true, normaliza acentos Latin1.
	 * @return string
	 */
	private static function normalize_for_match( string $str, bool $strip_accents_ok ): string {
		// `mb_strtolower` con UTF-8 explicito — `strtolower` byte-level
		// no maneja "Ú"/"Ñ" y romperia el matching para countries con
		// acentos en el value del visitante.
		$str = function_exists( 'mb_strtolower' ) ? mb_strtolower( trim( $str ), 'UTF-8' ) : strtolower( trim( $str ) );
		if ( ! $strip_accents_ok ) {
			return $str;
		}
		$map = array(
			'á' => 'a',
			'à' => 'a',
			'ä' => 'a',
			'â' => 'a',
			'ã' => 'a',
			'å' => 'a',
			'é' => 'e',
			'è' => 'e',
			'ë' => 'e',
			'ê' => 'e',
			'í' => 'i',
			'ì' => 'i',
			'ï' => 'i',
			'î' => 'i',
			'ó' => 'o',
			'ò' => 'o',
			'ö' => 'o',
			'ô' => 'o',
			'õ' => 'o',
			'ú' => 'u',
			'ù' => 'u',
			'ü' => 'u',
			'û' => 'u',
			'ñ' => 'n',
			'ç' => 'c',
		);
		return strtr( $str, $map );
	}
}
