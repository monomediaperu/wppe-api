<?php
/**
 * Destino: HubSpot CRM (objeto `Contacts`).
 *
 * Envuelve `WPPE_Hubspot_Client::upsert_contact()` (capa HTTP) y
 * traduce su retorno al `Destination_Result` uniforme.
 *
 * **Scope v2.6.0 PR-1 (D-HS-1/2/3):** mapeo minimo. Inyecta:
 *  - `lifecyclestage` desde la option global (default 'lead' por
 *    convencion HubSpot, override per-form llega en PR-3).
 *  - `hubspot_owner_id` desde la option global (string id del owner).
 *  - `email` (obligatorio en HubSpot para upsert via `idProperty`).
 *
 * Strippea keys upstream de otros destinos (fname/lname/source_id/...
 * de Sperant, locationId/pipelineId/... de GHL, type/team_id/... de
 * Odoo) para que HubSpot no reciba properties que no entiende. HubSpot
 * es relativamente permisivo (acepta custom properties que no existen
 * todavia, las crea on-the-fly), pero por higiene mantenemos el strip.
 *
 * Catalogos (owners, pipelines, lifecyclestage enum, custom properties)
 * y mapeo per-form son scope de PR-2/PR-3.
 *
 * Naming sec 4.3 CLAUDE.md: clase `WPPE_Hubspot_Destination` (no
 * `WPPE_Bridge_Hubspot_Destination`) — mismo patron que
 * `WPPE_Ghl_Destination` y `WPPE_Odoo_Destination`.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Destination que envia leads a HubSpot CRM via Contacts API v3.
 */
final class WPPE_Hubspot_Destination implements WPPE_Bridge_Destination_Interface {

	public const SLUG  = 'hubspot';
	public const LABEL = 'HubSpot';

	/**
	 * Lifecyclestage default cuando el cliente no configuro la option.
	 * 'lead' es el siguiente estado despues de 'subscriber' en el funnel
	 * estandar de HubSpot — apropiado para alguien que llena un form
	 * pero todavia no esta calificado.
	 */
	public const DEFAULT_LIFECYCLESTAGE = 'lead';

	/**
	 * Whitelist de lifecyclestage values aceptados por HubSpot.
	 * Validado contra docs HubSpot 2026-05.
	 *
	 * @var array<int,string>
	 */
	public const ALLOWED_LIFECYCLESTAGES = array(
		'subscriber',
		'lead',
		'marketingqualifiedlead',
		'salesqualifiedlead',
		'opportunity',
		'customer',
		'evangelist',
		'other',
	);

	/**
	 * Slug unico del destino.
	 *
	 * @return string
	 */
	public static function slug(): string {
		return self::SLUG;
	}

	/**
	 * Label legible del destino para el dropdown admin.
	 *
	 * @return string
	 */
	public static function label(): string {
		return self::LABEL;
	}

	/**
	 * Envia el lead a HubSpot via `WPPE_Hubspot_Client::upsert_contact`.
	 *
	 * @param array $payload Payload ya normalizado por el adapter.
	 * @return WPPE_Bridge_Destination_Result
	 */
	public function send( array $payload ): WPPE_Bridge_Destination_Result {
		$properties = self::map_payload_to_properties( $payload );

		// HubSpot requiere `email` para upsert (lo usamos como idProperty).
		// Si no llega, fallar permanente — Worker no reintentara, alerta
		// al admin para que ajuste el field mapping.
		if ( ! isset( $properties['email'] ) || '' === trim( (string) $properties['email'] ) ) {
			return new WPPE_Bridge_Destination_Result(
				false,
				0,
				array(),
				__( 'HubSpot requiere `email` en el payload (se usa como id natural para upsert). Mapea un campo del form a `email` en Mapeo HubSpot.', 'wppe-bridge' ),
				true
			);
		}

		$response = WPPE_Hubspot_Client::upsert_contact( $properties );

		$success   = WPPE_Hubspot_Client::ERROR_CLASS_SUCCESS === $response['error_class'];
		$permanent = WPPE_Hubspot_Client::ERROR_CLASS_PERMANENT === $response['error_class'];
		$error     = $success ? null : self::error_message_from_response( $response );

		return new WPPE_Bridge_Destination_Result(
			$success,
			(int) $response['status'],
			is_array( $response['body'] ) ? $response['body'] : array(),
			$error,
			$permanent
		);
	}

	/**
	 * Mapea el payload normalizado del bridge al shape de HubSpot
	 * Contacts (`{properties: {firstname, lastname, email, phone, ...}}`).
	 *
	 * Pasos:
	 *  1. Strip de keys upstream de otros destinos (Sperant/GHL/Odoo/CAPI/UTM).
	 *  2. Mapeo de Sperant-shape (`fname`/`lname`) -> HubSpot-shape
	 *     (`firstname`/`lastname`) si el adapter no los renombro ya.
	 *  3. Inyeccion de defaults globales: `lifecyclestage`,
	 *     `hubspot_owner_id`.
	 *
	 * Properties HubSpot que sobreviven: `email`, `firstname`, `lastname`,
	 * `phone`, `mobilephone`, `company`, `website`, `jobtitle`, `address`,
	 * `city`, `state`, `zip`, `country`, `message` (custom property
	 * comun para forms de contacto).
	 *
	 * @param array $payload Payload pre-clean.
	 * @return array<string,mixed>
	 */
	public static function map_payload_to_properties( array $payload ): array {
		$values = self::strip_internal_and_other_destination_keys( $payload );

		// Mapeo Sperant-shape -> HubSpot-shape (defensivo, por si el
		// adapter no lo hizo).
		if ( isset( $payload['fname'] ) && ! isset( $values['firstname'] ) ) {
			$values['firstname'] = trim( (string) $payload['fname'] );
		}
		if ( isset( $payload['lname'] ) && ! isset( $values['lastname'] ) ) {
			$values['lastname'] = trim( (string) $payload['lname'] );
		}

		// Defaults globales.
		$lifecyclestage = self::resolve_default_lifecyclestage();
		if ( '' !== $lifecyclestage && ! isset( $values['lifecyclestage'] ) ) {
			$values['lifecyclestage'] = $lifecyclestage;
		}

		$owner_id = (string) get_option( 'wppe_bridge_hubspot_default_owner_id', '' );
		if ( '' !== $owner_id && ! isset( $values['hubspot_owner_id'] ) ) {
			$values['hubspot_owner_id'] = $owner_id;
		}

		return $values;
	}

	/**
	 * Lee la option `wppe_bridge_hubspot_default_lifecyclestage` con
	 * whitelist. Default 'lead'. Cualquier valor fuera de
	 * `ALLOWED_LIFECYCLESTAGES` cae al default — defensivo.
	 *
	 * Caso especial: si la option esta vacia (admin no la configuro
	 * todavia), NO inyectamos lifecyclestage — HubSpot lo deja en su
	 * default de la portal config. Esto es distinto a Odoo donde
	 * SIEMPRE inyectamos `type`.
	 *
	 * @return string Vacio si no hay configuracion; un value valido si si.
	 */
	public static function resolve_default_lifecyclestage(): string {
		$value = (string) get_option( 'wppe_bridge_hubspot_default_lifecyclestage', '' );
		if ( '' === $value ) {
			return '';
		}
		if ( in_array( $value, self::ALLOWED_LIFECYCLESTAGES, true ) ) {
			return $value;
		}
		return self::DEFAULT_LIFECYCLESTAGE;
	}

	/**
	 * Lista de keys que HubSpot NO entiende y que llegan al payload
	 * porque otros destinos las usan o porque son meta del bridge.
	 * Categorias:
	 *  - Meta keys del bridge (`_form_*`, `_submission_id`).
	 *  - Sperant-specific (input_channel_id, source_id, interest_type_id,
	 *    project_id, fname, lname, document).
	 *  - GHL-specific (locationId, pipelineId, customFields, tags).
	 *  - Odoo-specific (contact_name, partner_name, type, team_id,
	 *    user_id, tag_ids, source_id, medium_id, campaign_id, country_id,
	 *    function, email_from, description, street).
	 *  - Meta CAPI-only (client_ip, client_user_agent, fbp, fbclid,
	 *    landing_url, gclid).
	 *  - UTM flat — PR-3 las inyectara como `hs_analytics_*` properties.
	 *    En PR-1 las strippeamos.
	 *
	 * Las que se preservan (van al shape `properties` HubSpot):
	 *  email, firstname, lastname, phone, mobilephone, company,
	 *  website, jobtitle, address, city, state, zip, country, message,
	 *  lifecyclestage, hubspot_owner_id, hs_lead_status.
	 *
	 * @return array<int,string>
	 */
	public static function get_strippable_keys(): array {
		return array(
			// Meta keys del bridge.
			'_form_plugin',
			'_form_id',
			'_submission_id',
			// Sperant-specific.
			'input_channel_id',
			'source_id',
			'interest_type_id',
			'project_id',
			'fname',
			'lname',
			'document',
			// GHL-specific.
			'locationId',
			'pipelineId',
			'pipelineStageId',
			'customFields',
			'tags',
			// Odoo-specific.
			'type',
			'team_id',
			'user_id',
			'tag_ids',
			'medium_id',
			'campaign_id',
			'country_id',
			'function',
			'email_from',
			'contact_name',
			'partner_name',
			'description',
			'street',
			// UTM flat (PR-3 las inyectara como hs_analytics_*).
			'utm_source',
			'utm_medium',
			'utm_campaign',
			'utm_term',
			'utm_content',
			'gclid',
			'fbclid',
			'fbp',
			'landing_url',
			// Meta CAPI-only.
			'client_ip',
			'client_user_agent',
		);
	}

	/**
	 * Quita las keys de `get_strippable_keys()` del payload.
	 *
	 * @param array $payload Payload pre-clean.
	 * @return array
	 */
	private static function strip_internal_and_other_destination_keys( array $payload ): array {
		foreach ( self::get_strippable_keys() as $key ) {
			unset( $payload[ $key ] );
		}
		return $payload;
	}

	/**
	 * Pasos de setup especificos de HubSpot para la pagina "Inicio".
	 *
	 * @return array<int,array{key:string,title:string,description:string,action_url:?string,action_label:?string}>
	 */
	public static function setup_guide(): array {
		$config_url = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=wppe-bridge-hubspot-config' ) : '';
		return array(
			array(
				'key'          => 'hubspot_private_app',
				'title'        => __( 'Como crear el Private App access token', 'wppe-bridge' ),
				'description'  => __( 'En el panel HubSpot del cliente: <strong>Settings (icono engranaje) &rarr; Integrations &rarr; Private Apps &rarr; Create a private app</strong>. Asignar un nombre descriptivo (ej. "WP.pe Bridge"). Scopes minimos: <code>crm.objects.contacts.read</code>, <code>crm.objects.contacts.write</code>, <code>crm.schemas.contacts.read</code>. Crear y copiar el access token (se muestra solo una vez — Mono Media lo guarda en 1Password antes de pegarlo aqui, D9 CLAUDE.md).', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Ir a Configuracion HubSpot', 'wppe-bridge' ),
			),
			array(
				'key'          => 'hubspot_lifecyclestage',
				'title'        => __( 'Configurar lifecyclestage default', 'wppe-bridge' ),
				'description'  => __( 'Cuando un visitante llena un form, su contact en HubSpot se crea con el lifecyclestage que configures aqui. <code>lead</code> es lo apropiado para la mayoria de los casos (alguien interesado pero no calificado todavia). Para campanas mas avanzadas pueden usarse <code>marketingqualifiedlead</code> o <code>salesqualifiedlead</code> directamente. Override per-form llegara en una version futura.', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Ir a Configuracion HubSpot', 'wppe-bridge' ),
			),
			array(
				'key'          => 'hubspot_owner_id',
				'title'        => __( 'Asignar un Owner por default (opcional)', 'wppe-bridge' ),
				'description'  => __( 'Si quieres que todos los leads del web caigan asignados a un vendedor especifico, ingresa su <strong>Owner ID</strong> aqui. Se obtiene de <strong>Settings &rarr; Users &amp; Teams &rarr; Users</strong> (el ID aparece en la URL al editar el usuario). Si lo dejas vacio, HubSpot aplica las reglas de assignment configuradas en el portal (round-robin, territorio, etc).', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Ir a Configuracion HubSpot', 'wppe-bridge' ),
			),
			array(
				'key'          => 'hubspot_verify_lead',
				'title'        => __( 'Como verificar un lead en el panel HubSpot', 'wppe-bridge' ),
				'description'  => __( 'Despues de un lead de prueba con prefijo <code>__BRIDGE_TEST__</code>:<br><br>1. Login al panel HubSpot del cliente.<br>2. Ir a <strong>Contacts &rarr; All contacts</strong>.<br>3. Buscar por email <code>bridge-test-*@mono.media</code>.<br>4. Verificar que el contact aparezca con email, firstname, lastname, phone correctos, y lifecyclestage = lead.<br><br>HubSpot dedupea automaticamente por email (gracias a `idProperty=email` en el upsert) — un mismo email reenviado 5 veces resulta en UN contact con la ultima data, no 5 contacts.', 'wppe-bridge' ),
				'action_url'   => null,
				'action_label' => null,
			),
		);
	}

	/**
	 * Construye un mensaje legible a partir del response (solo cuando
	 * fallo). HubSpot retorna errores con shape:
	 *   { status: "error", category: "VALIDATION_ERROR", message: "...", correlationId: "..." }
	 * Preferimos `message` para mostrar al admin, fallback a `category`,
	 * fallback a HTTP status.
	 *
	 * Caso especial: el batch endpoint puede retornar 200/207 con
	 * `errors[].message` cuando algun input fallo. Lo manejamos tambien.
	 *
	 * @param array $response Response uniforme del HubspotClient.
	 * @return string
	 */
	private static function error_message_from_response( array $response ): string {
		$body = is_array( $response['body'] ?? null ) ? $response['body'] : array();

		// Errores top-level (4xx clasicos).
		if ( isset( $body['message'] ) && is_string( $body['message'] ) && '' !== $body['message'] ) {
			return $body['message'];
		}

		// Errores parciales del batch endpoint.
		if ( isset( $body['errors'] ) && is_array( $body['errors'] ) && ! empty( $body['errors'] ) ) {
			$first = $body['errors'][0];
			if ( is_array( $first ) && isset( $first['message'] ) && is_string( $first['message'] ) ) {
				return $first['message'];
			}
		}

		// Fallback a category.
		if ( isset( $body['category'] ) && is_string( $body['category'] ) && '' !== $body['category'] ) {
			return $body['category'];
		}

		$status = (int) ( $response['status'] ?? 0 );
		if ( 0 === $status ) {
			return 'Network error or timeout';
		}
		return sprintf( 'HTTP %d', $status );
	}
}
