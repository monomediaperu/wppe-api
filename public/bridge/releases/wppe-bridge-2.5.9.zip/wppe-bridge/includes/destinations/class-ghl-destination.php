<?php
/**
 * Destino: GoHighLevel (HighLevel) CRM.
 *
 * Envuelve `WPPE_Ghl_Client::upsert_contact()` (capa HTTP de bajo
 * nivel) y traduce su retorno al `Destination_Result` uniforme.
 *
 * **v2.1.0 (PR-3):** flujo completo de envio:
 *  1. Resuelve `tags[]` (default global + override por-form deduplicados).
 *  2. Resuelve `customFields[]` (UTMs del payload upstream mapeados a CF
 *     IDs segun la option `wppe_bridge_ghl_utm_field_mapping`).
 *  3. Limpia keys internas y UTMs flat del payload (no son fields GHL).
 *  4. Hace `POST /contacts/upsert` con el payload final.
 *  5. Si toggle Opportunity ON (D-GHL-2 default ON) y hay `pipelineId`
 *     configurado: hace `POST /opportunities/` con el `contact.id`
 *     retornado.
 *  6. Manejo de fallo parcial (D-PR3-2): si Contact OK + Opportunity
 *     fail, retorna failure con error_class del 2do POST. Worker
 *     reintenta toda la row — el upsert es idempotente via email/phone
 *     (segunda llamada devuelve `new=false` con mismo `contact.id`).
 *  7. Si toggle Opportunity ON pero pipeline_id vacio (D-PR3-5):
 *     skip Opportunity, log warning, marca Contact como success.
 *
 * Naming sec 4.3 CLAUDE.md: clase `WPPE_Ghl_Destination` (no
 * `WPPE_Ghl_Destination_Ghl`) — la doc dice "WPPE_Ghl_Destination
 * al lado, sin tocar Sperant_Destination". Sperant_Destination tiene
 * sufijo doble por evolucion historica del rebrand v2.0.0.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Destination que envia leads a GoHighLevel CRM.
 */
final class WPPE_Ghl_Destination implements WPPE_Bridge_Destination_Interface {

	public const SLUG  = 'ghl';
	public const LABEL = 'GoHighLevel';

	/**
	 * Status default de la Opportunity al crearla. GHL acepta:
	 * open|won|lost|abandoned|all. Para leads nuevos web siempre
	 * arrancan en `open`.
	 */
	public const OPPORTUNITY_DEFAULT_STATUS = 'open';

	/**
	 * Slug unico del destino.
	 *
	 * @return string
	 */
	public static function slug(): string {
		return self::SLUG;
	}

	/**
	 * Label legible del destino para el dropdown admin.
	 *
	 * @return string
	 */
	public static function label(): string {
		return self::LABEL;
	}

	/**
	 * Envia el lead a GHL via upsert + (opcional) opportunity.
	 *
	 * @param array $payload Payload ya normalizado.
	 * @return WPPE_Bridge_Destination_Result
	 */
	public function send( array $payload ): WPPE_Bridge_Destination_Result {
		// Inyeccion de campos GHL desde options.
		$location_id = (string) get_option( 'wppe_bridge_ghl_location_id', '' );
		if ( '' !== $location_id && ! isset( $payload['locationId'] ) ) {
			$payload['locationId'] = $location_id;
		}

		$tags = self::resolve_tags( $payload );
		if ( ! empty( $tags ) ) {
			$payload['tags'] = $tags;
		}

		$cfs = self::resolve_custom_fields( $payload );
		if ( ! empty( $cfs ) ) {
			$payload['customFields'] = $cfs;
		}

		// Snapshot del payload pre-clean para usar en el name de la
		// Opportunity (que usa firstName/lastName antes de limpiar).
		$payload_for_opp = $payload;

		// Limpieza de keys internas (`_form_*`) y UTMs flat
		// (utm_source, utm_medium, etc.) que NO son fields GHL validos
		// — ya los procesamos arriba como customFields/tags.
		$payload = self::strip_internal_and_utm_keys( $payload );

		// 1) Upsert Contact.
		$response = WPPE_Ghl_Client::upsert_contact( $payload );

		$success   = WPPE_Ghl_Client::ERROR_CLASS_SUCCESS === $response['error_class'];
		$permanent = WPPE_Ghl_Client::ERROR_CLASS_PERMANENT === $response['error_class'];

		if ( ! $success ) {
			return new WPPE_Bridge_Destination_Result(
				false,
				(int) $response['status'],
				is_array( $response['body'] ) ? $response['body'] : array(),
				self::error_message_from_response( $response ),
				$permanent
			);
		}

		// 2) Opportunity (si toggle ON y pipeline configurado).
		if ( self::should_create_opportunity() ) {
			$contact_id  = self::extract_contact_id( $response['body'] ?? array() );
			$pipeline_id = (string) get_option( 'wppe_bridge_ghl_default_pipeline_id', '' );

			if ( '' === $pipeline_id ) {
				// D-PR3-5: skip Opportunity, log warning, marcar Contact
				// como success. No bloquear el flujo entero — al menos
				// guardamos el contact, que es lo critico.
				if ( class_exists( 'WPPE_Bridge_Logger' ) ) {
					WPPE_Bridge_Logger::warn(
						'ghl_opportunity_skipped_no_pipeline',
						array(
							'contact_id' => $contact_id,
							'reason'     => 'wppe_bridge_ghl_create_opportunity esta ON pero default_pipeline_id esta vacio. Configura pipeline en Mapeo GHL.',
						)
					);
				}
			} elseif ( '' !== $contact_id ) {
				$opp_response = self::create_opportunity_for( $contact_id, $pipeline_id, $payload_for_opp, $location_id );
				$opp_success  = WPPE_Ghl_Client::ERROR_CLASS_SUCCESS === $opp_response['error_class'];

				if ( ! $opp_success ) {
					// D-PR3-2: Contact OK + Opportunity fail =>
					// marcar la row como failed_temp/permanent segun
					// el error de Opportunity. Worker reintenta toda
					// la row. El upsert es idempotente via email/phone.
					return new WPPE_Bridge_Destination_Result(
						false,
						(int) $opp_response['status'],
						is_array( $opp_response['body'] ) ? $opp_response['body'] : array(),
						sprintf(
							'Opportunity create failed (contact %s creado OK): %s',
							$contact_id,
							self::error_message_from_response( $opp_response )
						),
						WPPE_Ghl_Client::ERROR_CLASS_PERMANENT === $opp_response['error_class']
					);
				}
			}
		}

		// Contact OK + (Opportunity OK o no requerida).
		return new WPPE_Bridge_Destination_Result(
			true,
			(int) $response['status'],
			is_array( $response['body'] ) ? $response['body'] : array(),
			null,
			false
		);
	}

	/**
	 * Resuelve los tags finales para el payload del upsert.
	 *
	 * Combina (en este orden, deduplicado preservando primer match):
	 *  1. Tags default globales (`wppe_bridge_ghl_default_tags`).
	 *  2. Tags override por-form (`wppe_bridge_ghl_field_mapping[plugin][form_id]['tags']`),
	 *     resueltos via `_form_plugin` y `_form_id` del payload.
	 *
	 * Si ninguna fuente trae tags, retorna array vacio (Destination::send
	 * omite la key `tags` del payload final).
	 *
	 * @param array $payload Payload con `_form_plugin` y `_form_id` (puestos por adapters).
	 * @return array<int,string>
	 */
	public static function resolve_tags( array $payload ): array {
		$tags = array();

		// 1. Default global.
		$default = get_option( 'wppe_bridge_ghl_default_tags', array() );
		if ( is_array( $default ) ) {
			foreach ( $default as $tag ) {
				if ( is_string( $tag ) && '' !== trim( $tag ) ) {
					$tags[] = trim( $tag );
				}
			}
		}

		// 2. Override por-form.
		$plugin  = isset( $payload['_form_plugin'] ) ? (string) $payload['_form_plugin'] : '';
		$form_id = isset( $payload['_form_id'] ) ? (string) $payload['_form_id'] : '';
		if ( '' !== $plugin && '' !== $form_id ) {
			$mapping   = get_option( 'wppe_bridge_ghl_field_mapping', array() );
			$form_tags = $mapping[ $plugin ][ $form_id ]['tags'] ?? array();
			if ( is_array( $form_tags ) ) {
				foreach ( $form_tags as $tag ) {
					if ( is_string( $tag ) && '' !== trim( $tag ) ) {
						$tags[] = trim( $tag );
					}
				}
			}
		}

		// Dedup preservando orden (primer match gana).
		return array_values( array_unique( $tags ) );
	}

	/**
	 * Resuelve `customFields[]` desde los UTMs del payload upstream.
	 *
	 * El payload normalizado por los adapters trae UTMs flat (`utm_source`,
	 * `utm_medium`, etc.). Si la option `wppe_bridge_ghl_utm_field_mapping`
	 * tiene un CF id mapeado para esa UTM, se construye un item:
	 *   { id: '<cf_id>', field_value: '<utm value>' }
	 *
	 * Si la UTM no esta en el payload o tiene valor vacio, se omite.
	 * Si la option no la tiene mapeada, se omite (silencioso).
	 *
	 * @param array $payload Payload con utm_* flat.
	 * @return array<int,array{id:string,field_value:string}>
	 */
	public static function resolve_custom_fields( array $payload ): array {
		$mapping = get_option( 'wppe_bridge_ghl_utm_field_mapping', array() );
		if ( ! is_array( $mapping ) || empty( $mapping ) ) {
			return array();
		}

		$cfs = array();
		foreach ( $mapping as $utm_key => $cf_id ) {
			if ( ! is_string( $utm_key ) || ! is_string( $cf_id ) || '' === $cf_id ) {
				continue;
			}
			$value = $payload[ $utm_key ] ?? '';
			if ( ! is_scalar( $value ) || '' === (string) $value ) {
				continue;
			}
			$cfs[] = array(
				'id'          => $cf_id,
				'field_value' => (string) $value,
			);
		}
		return $cfs;
	}

	/**
	 * Determina si el toggle "Crear Opportunity" esta ON.
	 *
	 * Default = true (D-GHL-2: toggle ON por default). El admin puede
	 * apagarlo desde Configuracion GHL si todavia no configuro pipelines.
	 *
	 * @return bool
	 */
	public static function should_create_opportunity(): bool {
		$value = get_option( 'wppe_bridge_ghl_create_opportunity', '1' );
		return '1' === (string) $value || 1 === $value || true === $value;
	}

	/**
	 * Crea la Opportunity asociada al contact recien upserteado.
	 *
	 * Construye el `name` de la opportunity a partir de firstName +
	 * lastName del payload (fallback al email si no hay nombre — caso
	 * raro porque el form mapping bloquea save sin firstName).
	 *
	 * @param string $contact_id  ID retornado por upsert.
	 * @param string $pipeline_id Default pipeline (validado en sanitizer).
	 * @param array  $payload     Payload pre-strip con firstName/lastName/email.
	 * @param string $location_id Location ID actual.
	 * @return array Response uniforme del GhlClient.
	 */
	private static function create_opportunity_for( string $contact_id, string $pipeline_id, array $payload, string $location_id ): array {
		$first = isset( $payload['firstName'] ) ? (string) $payload['firstName'] : '';
		$last  = isset( $payload['lastName'] ) ? (string) $payload['lastName'] : '';
		$email = isset( $payload['email'] ) ? (string) $payload['email'] : '';

		$name = trim( $first . ' ' . $last );
		if ( '' === $name ) {
			$name = '' !== $email ? $email : ( 'Lead web ' . $contact_id );
		}

		$body = array(
			'locationId' => $location_id,
			'pipelineId' => $pipeline_id,
			'contactId'  => $contact_id,
			'name'       => $name,
			'status'     => self::OPPORTUNITY_DEFAULT_STATUS,
		);

		$stage_id = (string) get_option( 'wppe_bridge_ghl_default_pipeline_stage_id', '' );
		if ( '' !== $stage_id ) {
			$body['pipelineStageId'] = $stage_id;
		}

		return WPPE_Ghl_Client::create_opportunity( $body );
	}

	/**
	 * Extrae el `contact.id` del body retornado por upsert.
	 *
	 * Shape esperado: `{ new: bool, contact: {id, ...}, traceId: ... }`.
	 *
	 * @param array $body Body parseado del response.
	 * @return string ID o string vacio si no se encuentra.
	 */
	private static function extract_contact_id( array $body ): string {
		if ( isset( $body['contact']['id'] ) && is_string( $body['contact']['id'] ) ) {
			return $body['contact']['id'];
		}
		return '';
	}

	/**
	 * Lista de keys que `Destination::send()` quita del payload final
	 * antes de mandar a GHL. Tres categorias:
	 *  - Meta keys del bridge (`_form_plugin`, `_form_id`, etc.).
	 *  - UTMs flat (`utm_source`, ...) — ya las pasamos via customFields.
	 *  - Campos del flujo Sperant que GHL no entiende
	 *    (`input_channel_id`, `source_id`, `interest_type_id`, `project_id`).
	 *  - Datos del request (`client_ip`, `client_user_agent`, `landing_url`,
	 *    `fbp`) que son para Meta CAPI no para GHL.
	 *
	 * Critico: GHL es mas estricto que Sperant con campos desconocidos —
	 * algunos retornan 422 "additional properties not allowed".
	 *
	 * @return array<int,string>
	 */
	public static function get_strippable_keys(): array {
		return array(
			// Meta keys del bridge.
			'_form_plugin',
			'_form_id',
			'_submission_id',
			// UTMs flat (ya van a customFields si estan mapeadas).
			'utm_source',
			'utm_medium',
			'utm_campaign',
			'utm_term',
			'utm_content',
			'gclid',
			'fbclid',
			'fbp',
			'landing_url',
			// Campos Sperant que no aplican a GHL.
			'input_channel_id',
			'source_id',
			'interest_type_id',
			'project_id',
			'fname',
			'lname',
			'document',
			// Request data para Meta CAPI.
			'client_ip',
			'client_user_agent',
		);
	}

	/**
	 * Quita las keys de `get_strippable_keys()` del payload.
	 *
	 * @param array $payload Payload pre-clean.
	 * @return array
	 */
	private static function strip_internal_and_utm_keys( array $payload ): array {
		foreach ( self::get_strippable_keys() as $key ) {
			unset( $payload[ $key ] );
		}
		return $payload;
	}

	/**
	 * Pasos de setup especificos de GHL para la pagina "Inicio".
	 *
	 * @return array<int,array{key:string,title:string,description:string,action_url:?string,action_label:?string}>
	 */
	public static function setup_guide(): array {
		$config_url  = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=wppe-bridge-config' ) : '';
		$mapping_url = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=wppe-bridge-ghl-mapping' ) : '';
		return array(
			array(
				'key'          => 'ghl_pit_token',
				'title'        => __( 'Como obtener el Private Integration Token (PIT)', 'wppe-bridge' ),
				'description'  => __( 'En el panel GHL del cliente: <strong>Settings &rarr; Private Integrations &rarr; Create New Integration</strong>. Asigna scopes minimos: <code>contacts.write</code>, <code>contacts.readonly</code>, <code>locations.readonly</code>, <code>opportunities.write</code>, <code>opportunities.readonly</code>. Importante: los scopes <strong>no se pueden agregar despues</strong>, hay que regenerar el token. Mono Media lo guarda en 1Password antes de cargarlo aqui (D9 CLAUDE.md).', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Ir a Configuracion', 'wppe-bridge' ),
			),
			array(
				'key'          => 'ghl_location_id',
				'title'        => __( 'Como obtener el Location ID', 'wppe-bridge' ),
				'description'  => __( 'Dos formas: (1) URL del panel sub-account: <code>app.gohighlevel.com/v2/location/&lt;LOCATION_ID&gt;/...</code>. (2) Settings &rarr; Business Profile, esta visible al final de la pagina. Es un string alfanumerico de ~24 caracteres. Sin location_id, todas las requests van a fallar con 422.', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Ir a Configuracion', 'wppe-bridge' ),
			),
			array(
				'key'          => 'ghl_sync_and_map',
				'title'        => __( 'Sincronizar catalogos y mapear campos', 'wppe-bridge' ),
				'description'  => __( 'En la sub-pagina <strong>Mapeo GHL</strong>: (1) pulsa "Sincronizar catalogos GHL" para traer pipelines, custom fields y tags desde la sub-account. (2) Configura pipeline + stage default si activas la creacion de Opportunity. (3) Si queres trackear UTMs, mapea los Custom Fields de GHL (creados previamente como tipo TEXT) a las UTM keys (utm_source, utm_medium, etc). (4) Por cada form WP, mapea los campos del form a fields GHL (firstName, email, phone, etc.) y opcionalmente agrega tags por-form.', 'wppe-bridge' ),
				'action_url'   => $mapping_url,
				'action_label' => __( 'Ir a Mapeo GHL', 'wppe-bridge' ),
			),
			array(
				'key'          => 'ghl_attribution_limitation',
				'title'        => __( 'Limitacion: UTMs no llegan a Attribution Source nativa', 'wppe-bridge' ),
				'description'  => __( 'La API publica de GHL <strong>no acepta</strong> escribir en <code>attributionSource</code>. Los UTMs del visitante se guardan via Custom Fields (workaround estandar — el plugin lo hace automaticamente si configuraste el mapeo). Esto significa que la seccion "Attribution" del contacto en GHL aparece vacia, y los reportes nativos "Source/Medium" de GHL no van a contar los leads del bridge. Para reportar por UTM, arma Smart List filtrando por el Custom Field correspondiente.', 'wppe-bridge' ),
				'action_url'   => null,
				'action_label' => null,
			),
			array(
				'key'          => 'ghl_verify_lead',
				'title'        => __( 'Como verificar un lead en el panel GHL', 'wppe-bridge' ),
				'description'  => __( 'Despues de un lead de prueba con prefijo <code>__BRIDGE_TEST__</code>:<br><br>1. Login al panel GHL del cliente.<br>2. Ir a <strong>Contacts &rarr; Smart Lists &rarr; All Contacts</strong>.<br>3. Buscar por nombre <code>__BRIDGE_TEST__</code> o por email <code>bridge-test-*@mono.media</code>.<br>4. Verificar que el contacto aparezca con los campos correctos (nombre, email, phone, tags, custom fields con UTMs).<br>5. Si activaste Opportunity, ir a <strong>Opportunities</strong> y verificar que aparezca en el pipeline default.<br><br>Si no aparece, revisar los Logs del plugin para ver si hubo error en el envio (401 = token mal o sin scope, 422 = payload invalido).', 'wppe-bridge' ),
				'action_url'   => null,
				'action_label' => null,
			),
		);
	}

	/**
	 * Construye un mensaje legible a partir del response (solo cuando
	 * fallo). GHL tipicamente devuelve `{message: string}` o
	 * `{message: [string, ...]}` en el body. Sin body util, fallback
	 * a el HTTP status.
	 *
	 * @param array $response Response uniforme del GhlClient.
	 * @return string
	 */
	private static function error_message_from_response( array $response ): string {
		$body = is_array( $response['body'] ?? null ) ? $response['body'] : array();

		if ( isset( $body['message'] ) ) {
			$message = $body['message'];
			if ( is_string( $message ) && '' !== $message ) {
				return $message;
			}
			if ( is_array( $message ) ) {
				$flat = array_filter(
					$message,
					static function ( $item ) {
						return is_string( $item ) && '' !== $item;
					}
				);
				if ( ! empty( $flat ) ) {
					return implode( '; ', $flat );
				}
			}
		}

		$status = (int) ( $response['status'] ?? 0 );
		if ( 0 === $status ) {
			return 'Network error or timeout';
		}
		return sprintf( 'HTTP %d', $status );
	}
}
