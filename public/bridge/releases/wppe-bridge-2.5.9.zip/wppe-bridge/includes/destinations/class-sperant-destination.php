<?php
/**
 * Destino: Sperant CRM.
 *
 * Envuelve `WPPE_Sperant_Client::create_client()` (capa HTTP de bajo
 * nivel) y traduce su retorno al `Destination_Result` uniforme.
 *
 * El cliente HTTP se mantiene aislado en `class-sperant-client.php`
 * para que sea testeable independientemente y para que la API
 * publica para modulos opcionales (que aun puedan necesitar acceder
 * a Sperant directamente, ej. catalogos) siga disponible.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Destination que envia leads a Sperant CRM.
 */
final class WPPE_Sperant_Destination_Sperant implements WPPE_Bridge_Destination_Interface {

	public const SLUG  = 'sperant';
	public const LABEL = 'Sperant';

	/**
	 * Slug unico del destino.
	 *
	 * @return string
	 */
	public static function slug(): string {
		return self::SLUG;
	}

	/**
	 * Label legible del destino para el dropdown admin.
	 *
	 * @return string
	 */
	public static function label(): string {
		return self::LABEL;
	}

	/**
	 * Envia el lead a Sperant via `WPPE_Sperant_Client::create_client`.
	 *
	 * @param array $payload Payload ya normalizado.
	 * @return WPPE_Bridge_Destination_Result
	 */
	public function send( array $payload ): WPPE_Bridge_Destination_Result {
		$response = WPPE_Sperant_Client::create_client( $payload );

		$success   = WPPE_Sperant_Client::ERROR_CLASS_SUCCESS === $response['error_class'];
		$permanent = WPPE_Sperant_Client::ERROR_CLASS_PERMANENT === $response['error_class'];
		$error     = $success ? null : self::error_message_from_response( $response );

		return new WPPE_Bridge_Destination_Result(
			$success,
			(int) $response['status'],
			is_array( $response['body'] ) ? $response['body'] : array(),
			$error,
			$permanent
		);
	}

	/**
	 * Pasos de setup especificos de Sperant para la pagina "Inicio".
	 * Cubre: como obtener token, workaround para /v3/sources 404,
	 * IDs tipicos de inmobiliaria, como verificar lead en panel.
	 *
	 * @return array<int,array{key:string,title:string,description:string,action_url:?string,action_label:?string}>
	 */
	public static function setup_guide(): array {
		$config_url = function_exists( 'admin_url' ) ? admin_url( 'admin.php?page=wppe-bridge-config' ) : '';
		return array(
			array(
				'key'          => 'sperant_token',
				'title'        => __( 'Como obtener el token Sperant del cliente', 'wppe-bridge' ),
				'description'  => __( 'El cliente debe pedir su token a su contacto en Sperant. Es una cadena estatica que NO caduca a menos que la revoquen manualmente. Mono Media lo guarda en 1Password antes de cargarlo aqui (D9: nunca en repo, nunca en .env compartido). Si el token cambia, el cliente Sperant puede regenerarlo desde su panel y vos lo actualizas en Configuracion.', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Ir a Configuracion', 'wppe-bridge' ),
			),
			array(
				'key'          => 'sperant_sources_workaround',
				'title'        => __( 'Catalogo de Fuentes (sources) — workaround para /v3/sources 404', 'wppe-bridge' ),
				'description'  => __( 'La API publica v3 de Sperant <strong>NO expone el endpoint <code>/v3/sources</code></strong> (retorna 404). Confirmado al inspeccionar el panel web de Sperant. Workaround: en Configuracion, scroll a "Importar catalogos manualmente" y pega el JSON desde <code>&lt;cliente&gt;.sperant.com/sources.json</code> (estando logueado en el panel del cliente). Los demas catalogos (canales, intereses, proyectos) si se sincronizan automaticamente con el boton "Sincronizar catalogos".', 'wppe-bridge' ),
				'action_url'   => $config_url,
				'action_label' => __( 'Importar catalogos', 'wppe-bridge' ),
			),
			array(
				'key'          => 'sperant_typical_ids',
				'title'        => __( 'IDs tipicos de cliente inmobiliario', 'wppe-bridge' ),
				'description'  => __( 'Los IDs especificos varian por cliente, pero hay patrones comunes:<br><br><strong>Para form de Contacto generico (trafico web organico):</strong><br>• <code>input_channel_id</code>: buscar "pagina web" en el dropdown.<br>• <code>source_id</code>: buscar "pagina web" en Fuentes.<br>• <code>interest_type_id</code>: buscar "alto" (es lo que el cliente espera por default para leads web).<br>• <code>project_id</code>: dejar sin default si el form es generico, o asignar al proyecto especifico si el form vive en una landing de proyecto.<br><br><strong>Pro tip:</strong> los IDs reales los obtienes navegando los catalogos sincronizados en Configuracion, o pegando el JSON del panel del cliente como manual.', 'wppe-bridge' ),
				'action_url'   => null,
				'action_label' => null,
			),
			array(
				'key'          => 'sperant_verify_lead',
				'title'        => __( 'Como verificar un lead en el panel Sperant del cliente', 'wppe-bridge' ),
				'description'  => __( 'Despues de un lead de prueba con prefijo <code>__BRIDGE_TEST__</code>:<br><br>1. Login al panel del cliente (ej. <code>&lt;cliente&gt;.sperant.com</code>).<br>2. Ir a "Clientes" o "Leads" (el menu varia por instancia).<br>3. Buscar por nombre <code>__BRIDGE_TEST__</code> o por email <code>bridge-test-*@mono.media</code>.<br>4. Verificar que el cliente nuevo aparezca con los IDs correctos: canal de entrada, fuente, tipo de interes, proyecto.<br><br>Si <strong>no aparece</strong>, revisar primero los Logs del plugin (sub-pagina Logs) para ver si hubo error en el envio.', 'wppe-bridge' ),
				'action_url'   => null,
				'action_label' => null,
			),
		);
	}

	/**
	 * Construye un mensaje legible a partir del response (solo cuando
	 * fallo). Sperant tipicamente devuelve `{message, errors}` en el
	 * body, lo aprovechamos. Sin body util, fallback a el HTTP status.
	 *
	 * @param array $response Response uniforme del SperantClient.
	 * @return string
	 */
	private static function error_message_from_response( array $response ): string {
		$body = is_array( $response['body'] ?? null ) ? $response['body'] : array();

		if ( isset( $body['message'] ) && is_string( $body['message'] ) && '' !== $body['message'] ) {
			return $body['message'];
		}

		$status = (int) ( $response['status'] ?? 0 );
		if ( 0 === $status ) {
			return 'Network error or timeout';
		}
		return sprintf( 'HTTP %d', $status );
	}
}
