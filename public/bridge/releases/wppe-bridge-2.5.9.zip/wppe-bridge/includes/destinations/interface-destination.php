<?php
/**
 * Contrato comun de un destino CRM.
 *
 * Cada destino concreto (Sperant, GHL, Pipedrive en el futuro)
 * implementa este interface y se registra en
 * `WPPE_Bridge_Destination_Factory::registry()` con su slug.
 *
 * El Worker NO conoce destinos concretos — solo llama
 * `Destination_Factory::get()->send($payload)` y reacciona al
 * `Destination_Result` uniforme.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Interface que cada destino CRM debe implementar.
 */
interface WPPE_Bridge_Destination_Interface {

	/**
	 * Slug unico del destino (`sperant`, `ghl`, `pipedrive`, ...).
	 * Debe coincidir con el valor que se guarda en la option
	 * `wppe_bridge_active_destination`.
	 *
	 * @return string
	 */
	public static function slug(): string;

	/**
	 * Label legible del destino (para el dropdown admin).
	 *
	 * @return string
	 */
	public static function label(): string;

	/**
	 * Envia el lead al CRM. Implementaciones deben:
	 * 1. Aplicar la auth especifica del CRM (header, query string, OAuth).
	 * 2. Mapear el payload normalizado al shape del CRM.
	 * 3. Manejar errores HTTP/red traduciendolos a un Destination_Result.
	 *
	 * NO debe disparar hooks ni tocar la queue — eso es responsabilidad
	 * del Worker tras leer el result.
	 *
	 * @param array $payload Payload normalizado (D6 del CLAUDE.md).
	 * @return WPPE_Bridge_Destination_Result
	 */
	public function send( array $payload ): WPPE_Bridge_Destination_Result;

	/**
	 * Lista de pasos de setup especificos del CRM, mostrados en la
	 * pagina "Inicio" del admin (desde v1.0.5). Cada paso es una
	 * "tarjeta de ayuda" — texto explicativo + link contextual a la
	 * sub-pagina relevante.
	 *
	 * Estructura de cada paso:
	 * [
	 *   'key'         => string,        // identificador unico
	 *   'title'       => string,        // titulo visible
	 *   'description' => string,        // texto, puede tener HTML simple (a, code, strong, em).
	 *   'action_url'  => string|null,   // URL relativa o null (ej. admin.php?page=...)
	 *   'action_label'=> string|null,   // label del boton si action_url no es null
	 * ]
	 *
	 * El core renderiza estos pasos junto con los pasos genericos
	 * del plugin (instalacion, mapeo, modulos). Ver Help_Page.
	 *
	 * @return array<int,array{key:string,title:string,description:string,action_url:?string,action_label:?string}>
	 */
	public static function setup_guide(): array;
}
