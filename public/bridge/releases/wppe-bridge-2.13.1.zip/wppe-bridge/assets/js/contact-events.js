/**
 * Eventos del camino de contacto.
 *
 * Avisa al `dataLayer` (GTM, GA4, Google Ads) y al pixel de Meta de lo
 * que pasa en los formularios conectados y en el Widget de Contacto:
 *
 *   wppe_widget_open     el visitante abre el widget
 *   wppe_form_start      empieza a llenar un formulario
 *   wppe_lead            su lead entro a la cola (la conversion)
 *   wppe_contact         sale del widget a WhatsApp o a llamar
 *   wppe_schedule        programa una llamada desde el widget
 *   wppe_contact_click   toca un enlace suelto de WhatsApp o telefono
 *
 * Ningun evento lleva datos personales.
 *
 * `wppe_lead` no depende de una pagina de gracias ni del plugin de
 * formularios: el servidor deja una cookie con el identificador del
 * evento solo cuando el lead realmente entro a la cola, y este script
 * la lee. Sin cookie no hay conversion (lead duplicado, form sin mapeo).
 * Ese identificador es el mismo que el servidor envia a Meta, asi que
 * la plataforma cuenta una sola conversion.
 *
 * @package WPPE_Bridge
 */
( function () {
	'use strict';

	var cfg = window.wppeBridgeEvents || {};
	var ID_PATTERN = /^wppe-[a-f0-9]{24}$/;
	var FORM_SELECTOR = '.wpcf7 form, form.frm-fluent-form, form[id^="gform_"], form.elementor-form, [data-wppe-cw] form';
	var POLL_MS = 500;
	var POLL_MAX_MS = 15000;
	var usePixel = '1' === String( cfg.metaPixel );
	var started = [];
	var polling = false;

	function readCookie( name ) {
		var parts = ( '; ' + document.cookie ).split( '; ' + name + '=' );
		return 2 === parts.length ? decodeURIComponent( parts.pop().split( ';' ).shift() ) : '';
	}

	function stored( key ) {
		try {
			return window.localStorage.getItem( key );
		} catch ( e ) {
			return null;
		}
	}

	function store( key, value ) {
		try {
			window.localStorage.setItem( key, value );
		} catch ( e ) {
			// Modo privado u otra restriccion: se pierde solo la proteccion
			// contra repetir el evento en una recarga.
		}
	}

	function push( name, params ) {
		var data = { event: name };
		var key;
		for ( key in params ) {
			if ( Object.prototype.hasOwnProperty.call( params, key ) ) {
				data[ key ] = params[ key ];
			}
		}
		window.dataLayer = window.dataLayer || [];
		window.dataLayer.push( data );
	}

	function pixel( method, name, options ) {
		if ( ! usePixel || 'function' !== typeof window.fbq ) {
			return false;
		}
		if ( options ) {
			window.fbq( method, name, {}, options );
		} else {
			window.fbq( method, name );
		}
		return true;
	}

	/**
	 * Dispara la conversion si hay un lead recien encolado de este
	 * visitante. Devuelve true si habia un identificador valido.
	 */
	function checkLead( source ) {
		var id = readCookie( cfg.cookie );
		if ( ! ID_PATTERN.test( id ) ) {
			return false;
		}
		var adsAllowed = '1' !== readCookie( cfg.noAdsCookie );

		if ( stored( cfg.dataLayerKey ) !== id ) {
			store( cfg.dataLayerKey, id );
			push( 'wppe_lead', {
				event_id: id,
				lead_source: source || 'form',
				ad_consent: adsAllowed ? 'granted' : 'denied'
			} );
		}

		// El pixel comparte marca con el modulo Thank You Pixel: el que
		// llegue primero dispara y el otro no repite.
		if ( adsAllowed && stored( cfg.pixelKey ) !== id && pixel( 'track', cfg.metaEvent || 'Lead', { eventID: id } ) ) {
			store( cfg.pixelKey, id );
		}
		return true;
	}

	/**
	 * Tras un envio, espera a que llegue la cookie del lead. Cubre a
	 * cualquier plugin de formularios, tenga o no evento propio de exito.
	 */
	function pollLead( source ) {
		if ( polling ) {
			return;
		}
		polling = true;
		var waited = 0;
		var before = readCookie( cfg.cookie );
		var timer = window.setInterval( function () {
			waited += POLL_MS;
			var now = readCookie( cfg.cookie );
			if ( ( now && now !== before && checkLead( source ) ) || waited >= POLL_MAX_MS ) {
				window.clearInterval( timer );
				polling = false;
			}
		}, POLL_MS );
	}

	function describeForm( form ) {
		var plugin = 'other';
		var id = '';
		var holder = form.closest( '.wpcf7' );
		if ( form.closest( '[data-wppe-cw]' ) ) {
			plugin = 'widget';
		} else if ( holder ) {
			plugin = 'cf7';
			id = ( holder.id || '' ).replace( /^wpcf7-f(\d+).*/, '$1' );
		} else if ( form.classList.contains( 'frm-fluent-form' ) ) {
			plugin = 'fluent';
			id = form.getAttribute( 'data-form_id' ) || '';
		} else if ( 0 === ( form.id || '' ).indexOf( 'gform_' ) ) {
			plugin = 'gravity';
			id = form.id.replace( 'gform_', '' );
		} else if ( form.classList.contains( 'elementor-form' ) ) {
			plugin = 'elementor';
			id = form.getAttribute( 'name' ) || '';
		}
		return { form_plugin: plugin, form_id: id };
	}

	function trackedForm( target ) {
		return target && target.closest ? target.closest( FORM_SELECTOR ) : null;
	}

	// --- Empieza a llenar un formulario (una vez por formulario) ---
	document.addEventListener( 'input', function ( event ) {
		var form = trackedForm( event.target );
		if ( ! form || -1 !== started.indexOf( form ) ) {
			return;
		}
		started.push( form );
		push( 'wppe_form_start', describeForm( form ) );
		pixel( 'trackCustom', 'FormStart' );
	}, true );

	// --- Envio: esperar la cookie del lead ---
	document.addEventListener( 'submit', function ( event ) {
		var form = trackedForm( event.target );
		if ( form ) {
			pollLead( 'widget' === describeForm( form ).form_plugin ? 'widget' : 'form' );
		}
	}, true );

	// CF7 avisa por evento propio: se revisa de inmediato. `mailfailed`
	// tambien, porque el lead entra al CRM aunque falle el correo de aviso.
	[ 'wpcf7mailsent', 'wpcf7mailfailed' ].forEach( function ( name ) {
		document.addEventListener( name, function () {
			checkLead( 'form' );
		} );
	} );

	// --- Widget de Contacto ---
	document.addEventListener( 'wppe_bridge_widget', function ( event ) {
		var detail = event.detail || {};
		if ( 'open' === detail.action ) {
			push( 'wppe_widget_open', {} );
			pixel( 'trackCustom', 'WidgetOpen' );
		} else if ( 'contact' === detail.action ) {
			checkLead( 'widget' );
			push( 'wppe_contact', { channel: detail.channel || '' } );
			pixel( 'track', 'Contact' );
		} else if ( 'schedule' === detail.action ) {
			checkLead( 'widget' );
			push( 'wppe_schedule', {} );
			pixel( 'track', 'Schedule' );
		}
	} );

	// --- Enlaces sueltos de WhatsApp o telefono (fuera del widget) ---
	document.addEventListener( 'click', function ( event ) {
		var link = event.target && event.target.closest ? event.target.closest( 'a[href]' ) : null;
		if ( ! link || link.closest( '[data-wppe-cw]' ) ) {
			return;
		}
		var href = link.getAttribute( 'href' ) || '';
		var channel = '';
		if ( /^tel:/i.test( href ) ) {
			channel = 'phone';
		} else if ( /^whatsapp:/i.test( href ) || /\/\/(wa\.me|api\.whatsapp\.com|web\.whatsapp\.com)\//i.test( href ) ) {
			channel = 'whatsapp';
		}
		if ( channel ) {
			push( 'wppe_contact_click', { channel: channel } );
			pixel( 'track', 'Contact' );
		}
	}, true );

	// --- Al cargar: cubre la llegada a una pagina de gracias ---
	checkLead( 'form' );
}() );
