<?php
/**
 * Registro del menu admin del plugin.
 *
 * Top-level menu "WP.pe Bridge" con submenus: Settings, Mapping, Logs.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registra el menu admin top-level y los submenus.
 */
final class WPPE_Bridge_Admin_Menu {

	public const SLUG       = 'wppe-bridge';
	public const CAPABILITY = 'manage_options';

	/**
	 * Registra el menu top-level y submenus.
	 *
	 * Orden del menu (desde v1.0.5):
	 *   Inicio (landing) | Configuracion | Mapeo | Modulos | Logs
	 *
	 * El top-level apunta a la pagina "Inicio" (Help_Page) para que
	 * sea lo primero que ve un usuario que abre el plugin. Configuracion
	 * pasa a slug `-config` (antes era el slug principal).
	 *
	 * @return void
	 */
	public static function register(): void {
		add_menu_page(
			__( 'WP.pe Bridge', 'wppe-bridge' ),
			__( 'WP.pe Bridge', 'wppe-bridge' ),
			self::CAPABILITY,
			self::SLUG,
			array( 'WPPE_Bridge_Help_Page', 'render' ),
			'dashicons-admin-links',
			58
		);

		add_submenu_page(
			self::SLUG,
			__( 'Inicio', 'wppe-bridge' ),
			__( 'Inicio', 'wppe-bridge' ),
			self::CAPABILITY,
			self::SLUG,
			array( 'WPPE_Bridge_Help_Page', 'render' )
		);

		add_submenu_page(
			self::SLUG,
			__( 'Configuracion', 'wppe-bridge' ),
			__( 'Configuracion', 'wppe-bridge' ),
			self::CAPABILITY,
			self::SLUG . '-config',
			array( 'WPPE_Bridge_Settings_Page', 'render' )
		);

		add_submenu_page(
			self::SLUG,
			__( 'Mapeo de campos', 'wppe-bridge' ),
			__( 'Mapeo de campos', 'wppe-bridge' ),
			self::CAPABILITY,
			self::SLUG . '-mapping',
			array( 'WPPE_Bridge_Mapping_Page', 'render' )
		);

		// Sub-paginas especificas de GHL: solo visibles cuando el destino
		// activo es ghl. Permite configurar PIT/Location ID y mapeo
		// sin contaminar las paginas de Sperant. Asimetria intencional
		// con Sperant (Camino A, sec 12 CLAUDE.md).
		$wppe_bridge_active = WPPE_Bridge_Destination_Factory::active_slug();
		if ( WPPE_Ghl_Destination::SLUG === $wppe_bridge_active ) {
			add_submenu_page(
				self::SLUG,
				__( 'Configuracion GHL', 'wppe-bridge' ),
				__( 'Configuracion GHL', 'wppe-bridge' ),
				self::CAPABILITY,
				WPPE_Bridge_Ghl_Settings_Page::PAGE_SLUG,
				array( 'WPPE_Bridge_Ghl_Settings_Page', 'render' )
			);
			add_submenu_page(
				self::SLUG,
				__( 'Mapeo GHL', 'wppe-bridge' ),
				__( 'Mapeo GHL', 'wppe-bridge' ),
				self::CAPABILITY,
				WPPE_Bridge_Ghl_Mapping_Page::PAGE_SLUG,
				array( 'WPPE_Bridge_Ghl_Mapping_Page', 'render' )
			);
		}

		// Sub-pagina Webhook: solo visible cuando active = webhook.
		if ( WPPE_Bridge_Webhook_Destination::SLUG === $wppe_bridge_active ) {
			add_submenu_page(
				self::SLUG,
				__( 'Configuracion Webhook', 'wppe-bridge' ),
				__( 'Configuracion Webhook', 'wppe-bridge' ),
				self::CAPABILITY,
				WPPE_Bridge_Webhook_Settings_Page::PAGE_SLUG,
				array( 'WPPE_Bridge_Webhook_Settings_Page', 'render' )
			);
		}

		// Sub-paginas Odoo: solo visibles cuando active = odoo. PR-1
		// expuso Configuracion Odoo (auth + default_type). PR-2 agrega
		// Mapeo Odoo (catalog sync + global config + per-form mapping).
		if ( WPPE_Odoo_Destination::SLUG === $wppe_bridge_active ) {
			add_submenu_page(
				self::SLUG,
				__( 'Configuracion Odoo', 'wppe-bridge' ),
				__( 'Configuracion Odoo', 'wppe-bridge' ),
				self::CAPABILITY,
				WPPE_Bridge_Odoo_Settings_Page::PAGE_SLUG,
				array( 'WPPE_Bridge_Odoo_Settings_Page', 'render' )
			);
			add_submenu_page(
				self::SLUG,
				__( 'Mapeo Odoo', 'wppe-bridge' ),
				__( 'Mapeo Odoo', 'wppe-bridge' ),
				self::CAPABILITY,
				WPPE_Bridge_Odoo_Mapping_Page::PAGE_SLUG,
				array( 'WPPE_Bridge_Odoo_Mapping_Page', 'render' )
			);
		}

		// Sub-paginas HubSpot: solo visibles cuando active = hubspot.
		// PR-1 expuso Configuracion HubSpot (token + lifecyclestage +
		// owner_id default). PR-2 agrega Mapeo HubSpot (catalog sync +
		// validacion suave de globals + per-form field mapping).
		if ( WPPE_Hubspot_Destination::SLUG === $wppe_bridge_active ) {
			add_submenu_page(
				self::SLUG,
				__( 'Configuracion HubSpot', 'wppe-bridge' ),
				__( 'Configuracion HubSpot', 'wppe-bridge' ),
				self::CAPABILITY,
				WPPE_Bridge_Hubspot_Settings_Page::PAGE_SLUG,
				array( 'WPPE_Bridge_Hubspot_Settings_Page', 'render' )
			);
			add_submenu_page(
				self::SLUG,
				__( 'Mapeo HubSpot', 'wppe-bridge' ),
				__( 'Mapeo HubSpot', 'wppe-bridge' ),
				self::CAPABILITY,
				WPPE_Bridge_Hubspot_Mapping_Page::PAGE_SLUG,
				array( 'WPPE_Bridge_Hubspot_Mapping_Page', 'render' )
			);
		}

		add_submenu_page(
			self::SLUG,
			__( 'Modulos', 'wppe-bridge' ),
			__( 'Modulos', 'wppe-bridge' ),
			self::CAPABILITY,
			self::SLUG . '-modules',
			array( 'WPPE_Bridge_Modules_Page', 'render' )
		);

		// Lead Scoring (v2.12.0): pagina propia porque aplica a TODAS
		// las fuentes de leads, no solo al Widget de Contacto.
		add_submenu_page(
			self::SLUG,
			__( 'Lead Scoring', 'wppe-bridge' ),
			__( 'Lead Scoring', 'wppe-bridge' ),
			self::CAPABILITY,
			WPPE_Bridge_Scoring_Page::PAGE_SLUG,
			array( 'WPPE_Bridge_Scoring_Page', 'render' )
		);

		add_submenu_page(
			self::SLUG,
			__( 'Logs', 'wppe-bridge' ),
			__( 'Logs', 'wppe-bridge' ),
			self::CAPABILITY,
			self::SLUG . '-logs',
			array( 'WPPE_Bridge_Logs_Page', 'render' )
		);

		// Sub-paginas ocultas de configuracion avanzada por modulo: se
		// registran sin padre (parent_slug vacio) para que no aparezcan
		// en el menu pero si se puedan abrir via URL directa.
		foreach ( self::hidden_pages() as $slug => $page ) {
			$hook = add_submenu_page(
				'',
				$page['title'],
				$page['title'],
				self::CAPABILITY,
				$slug,
				$page['callback']
			);

			// Una pagina sin padre no esta en `$submenu`, asi que
			// `get_admin_page_title()` devuelve null: la pestana del
			// navegador queda sin nombre y `admin-header.php` dispara
			// `strip_tags(): Passing null` en PHP 8.1+. Se fija el
			// titulo en `load-{hook}`, que corre antes del header.
			if ( is_string( $hook ) && '' !== $hook ) {
				$title = $page['title'];
				add_action(
					'load-' . $hook,
					static function () use ( $title ): void {
						self::set_page_title( $title );
					}
				);
			}
		}
	}

	/**
	 * Sub-paginas ocultas del plugin: slug => titulo y callback.
	 *
	 * @return array<string,array{title:string,callback:callable}>
	 */
	public static function hidden_pages(): array {
		return array(
			WPPE_Bridge_Meta_Capi_Settings_Page::PAGE_SLUG => array(
				'title'    => __( 'Meta CAPI', 'wppe-bridge' ),
				'callback' => array( 'WPPE_Bridge_Meta_Capi_Settings_Page', 'render' ),
			),
			WPPE_Bridge_Thank_You_Pixel_Settings_Page::PAGE_SLUG => array(
				'title'    => __( 'Thank You Pixel', 'wppe-bridge' ),
				'callback' => array( 'WPPE_Bridge_Thank_You_Pixel_Settings_Page', 'render' ),
			),
			WPPE_Bridge_Widget_Settings_Page::PAGE_SLUG    => array(
				'title'    => __( 'Widget de Contacto', 'wppe-bridge' ),
				'callback' => array( 'WPPE_Bridge_Widget_Settings_Page', 'render' ),
			),
		);
	}

	/**
	 * Fija el titulo de la pantalla admin actual.
	 *
	 * WordPress lee el global `$title` en `get_admin_page_title()`
	 * antes de buscar en el menu; es la via soportada para paginas
	 * que no tienen entrada de menu.
	 *
	 * @param string $title Titulo a mostrar.
	 * @return void
	 */
	public static function set_page_title( string $title ): void {
		// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Intencional: unica via para titular una pagina admin sin entrada de menu.
		$GLOBALS['title'] = $title;
	}
}
