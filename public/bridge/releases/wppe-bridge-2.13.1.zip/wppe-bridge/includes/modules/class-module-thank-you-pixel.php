<?php
/**
 * Modulo opcional Thank You Pixel (D4.4).
 *
 * Inyecta el snippet del browser pixel de Meta via `wp_footer` solo
 * en las paginas marcadas como "thank you" desde la sub-pagina admin.
 * Sincroniza `event_id` con el modulo Meta CAPI server-side via la
 * cookie de `WPPE_Bridge_Event_Id`, que se setea en el request del
 * envio. El snippet la lee **en el navegador**: el HTML es identico
 * para todos los visitantes y la pagina de gracias se puede cachear.
 *
 * Configuracion (en sub-pagina `WP.pe Bridge > Thank You Pixel`):
 * - Multi-select de paginas WP a tratar como "thank you".
 *
 * El Pixel ID y el `event_name` se leen del modulo Meta CAPI (option
 * compartida) — un solo Pixel = un solo punto de configuracion.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Modulo Thank You Pixel: dispara browser pixel en thank you pages.
 */
final class WPPE_Bridge_Module_Thank_You_Pixel {

	public const SLUG = 'thank_you_pixel';

	public const OPTION_ENABLED = 'wppe_bridge_module_thank_you_pixel_enabled';
	public const OPTION_PAGES   = 'wppe_bridge_thank_you_pixel_pages';

	/**
	 * Clave de localStorage donde el navegador anota el ultimo evento
	 * ya disparado, para no repetirlo si el visitante recarga la pagina.
	 */
	public const FIRED_STORAGE_KEY = 'wppe_bridge_event_fired';

	/**
	 * Lee si el modulo esta enabled.
	 *
	 * @return bool
	 */
	public static function is_enabled(): bool {
		return (bool) get_option( self::OPTION_ENABLED, false );
	}

	/**
	 * Lee la lista de page IDs configurados como thank you pages.
	 *
	 * @return array<int,int>
	 */
	public static function get_pages(): array {
		$raw = get_option( self::OPTION_PAGES, array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$ids = array();
		foreach ( $raw as $value ) {
			$id = (int) $value;
			if ( $id > 0 ) {
				$ids[] = $id;
			}
		}
		return $ids;
	}

	/**
	 * Suscribe el render al hook `wp_footer` y el setter de cookie
	 * al action `wppe_bridge_lead_queued` (lo dispara Queue::enqueue).
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		add_action( 'wp_footer', array( self::class, 'render_pixel' ), 99 );
		WPPE_Bridge_Event_Id::register_cookie_hook();
	}

	/**
	 * Entrega al navegador el identificador de evento del lead recien
	 * encolado. Hookeado desde register() solo si el modulo esta enabled.
	 *
	 * @param int $queue_id ID del queue item.
	 * @return void
	 */
	public static function set_event_id_cookie( $queue_id ): void {
		WPPE_Bridge_Event_Id::set_cookie( $queue_id );
	}

	/**
	 * Decide si la page actual califica para inyectar el pixel.
	 *
	 * Aislado en metodo publico para testeabilidad.
	 *
	 * @param int            $current_page_id ID de la page actual.
	 * @param array<int,int> $configured_ids  IDs configurados.
	 * @return bool
	 */
	public static function should_inject( int $current_page_id, array $configured_ids ): bool {
		if ( $current_page_id <= 0 || empty( $configured_ids ) ) {
			return false;
		}
		return in_array( $current_page_id, $configured_ids, true );
	}

	/**
	 * Renderiza el snippet del pixel via wp_footer.
	 *
	 * Guards (defensa en profundidad):
	 * - Pixel ID configurado en Meta CAPI.
	 * - Pagina actual ∈ OPTION_PAGES.
	 *
	 * @return void
	 */
	public static function render_pixel(): void {
		$pixel_id = (string) get_option( WPPE_Bridge_Module_Meta_Capi::OPTION_PIXEL_ID, '' );
		if ( '' === $pixel_id ) {
			return;
		}

		$page_id = (int) get_queried_object_id();
		if ( ! self::should_inject( $page_id, self::get_pages() ) ) {
			return;
		}

		$event_name = WPPE_Bridge_Module_Meta_Capi::get_event_name();

		// El snippet es identico para todos los visitantes: el
		// identificador del evento se lee de la cookie en el navegador.
		// Hasta v2.12 se resolvia en PHP y quedaba escrito en el HTML;
		// con cache de pagina ese valor se congelaba y se repetia para
		// todos, y Meta descartaba conversiones reales como duplicadas.
		//
		// Solo dispara si hay un lead reciente de este visitante (cookie
		// presente y valida) y una sola vez por lead: recargar la pagina
		// o entrar directo a la URL ya no cuenta una conversion.
		//
		// `fbq` se asume cargado por el snippet base del Pixel del
		// cliente. Si no esta, falla silente — preferible a duplicar la
		// inyeccion del init.
		?>
<!-- WP.pe Bridge — Thank You Pixel -->
<script>
(function(){
	if (typeof fbq !== 'function') { return; }
	var m = document.cookie.match(/(?:^|; )<?php echo esc_js( WPPE_Bridge_Event_Id::COOKIE_NAME ); ?>=([^;]*)/);
	var id = m ? decodeURIComponent(m[1]) : '';
	if (!/^wppe-[a-f0-9]{24}$/.test(id)) { return; }
	if (/(?:^|; )<?php echo esc_js( WPPE_Bridge_Event_Id::NO_ADS_COOKIE_NAME ); ?>=1/.test(document.cookie)) { return; }
	var key = <?php echo wp_json_encode( self::FIRED_STORAGE_KEY ); ?>;
	try { if (window.localStorage.getItem(key) === id) { return; } } catch (e) {}
	fbq('track', <?php echo wp_json_encode( $event_name ); ?>, {}, { eventID: id });
	try { window.localStorage.setItem(key, id); } catch (e) {}
})();
</script>
		<?php
	}
}
