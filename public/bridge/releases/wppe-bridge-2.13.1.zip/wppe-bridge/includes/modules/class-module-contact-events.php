<?php
/**
 * Modulo opcional Eventos de Contacto (D4.4).
 *
 * Avisa al `dataLayer` (GTM, GA4, Google Ads) y al pixel de Meta de lo
 * que pasa en los formularios conectados y en el Widget de Contacto:
 * abrir el widget, empezar un formulario, la conversion del lead, salir
 * a WhatsApp o a llamar, programar una llamada y tocar un enlace suelto
 * de WhatsApp o telefono.
 *
 * La conversion (`wppe_lead`) no depende de una pagina de gracias: el
 * servidor deja una cookie con el identificador del evento solo cuando
 * el lead entro a la cola, y el script del navegador la lee. Asi
 * funciona igual con formularios que muestran el mensaje en la misma
 * pagina y con el widget.
 *
 * El HTML que emite es identico para todos los visitantes (una config
 * estatica por sitio), compatible con cache de pagina.
 *
 * @package WPPE_Bridge
 * @since 2.13.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Modulo Eventos de Contacto: eventos del navegador hacia dataLayer y pixel.
 */
final class WPPE_Bridge_Module_Contact_Events {

	public const SLUG = 'contact_events';

	public const OPTION_ENABLED = 'wppe_bridge_module_contact_events_enabled';

	public const ASSET_HANDLE = 'wppe-bridge-contact-events';

	/**
	 * Nombre del objeto global con la config del script.
	 */
	public const JS_CONFIG_NAME = 'wppeBridgeEvents';

	/**
	 * Clave de localStorage donde el script anota el ultimo lead ya
	 * enviado al dataLayer, para no repetirlo en una recarga.
	 */
	public const DATALAYER_STORAGE_KEY = 'wppe_bridge_event_dl';

	/**
	 * Lee si el modulo esta enabled.
	 *
	 * @return bool
	 */
	public static function is_enabled(): bool {
		return (bool) get_option( self::OPTION_ENABLED, false );
	}

	/**
	 * Suscribe el enqueue del script y la cookie del identificador de
	 * evento.
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue_frontend' ) );
		WPPE_Bridge_Event_Id::register_cookie_hook();
	}

	/**
	 * Enqueua el script en todas las paginas del frontend: un enlace
	 * suelto de WhatsApp o un formulario puede estar en cualquiera.
	 *
	 * @return void
	 */
	public static function enqueue_frontend(): void {
		wp_enqueue_script(
			self::ASSET_HANDLE,
			WPPE_BRIDGE_PLUGIN_URL . 'assets/js/contact-events.js',
			array(),
			WPPE_BRIDGE_VERSION,
			true
		);
		wp_localize_script( self::ASSET_HANDLE, self::JS_CONFIG_NAME, self::script_config() );
	}

	/**
	 * Config estatica del script: nombres de cookies y claves, y el
	 * evento de Meta configurado. No depende del visitante.
	 *
	 * @return array<string,string>
	 */
	public static function script_config(): array {
		return array(
			'cookie'       => WPPE_Bridge_Event_Id::COOKIE_NAME,
			'noAdsCookie'  => WPPE_Bridge_Event_Id::NO_ADS_COOKIE_NAME,
			'dataLayerKey' => self::DATALAYER_STORAGE_KEY,
			// Compartida con Thank You Pixel: si ambos modulos estan
			// encendidos, el pixel dispara una sola vez por lead.
			'pixelKey'     => WPPE_Bridge_Module_Thank_You_Pixel::FIRED_STORAGE_KEY,
			'metaEvent'    => WPPE_Bridge_Module_Meta_Capi::get_event_name(),
			'metaPixel'    => '1',
		);
	}
}
