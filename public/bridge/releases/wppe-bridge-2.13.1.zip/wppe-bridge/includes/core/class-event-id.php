<?php
/**
 * Identificador de evento de conversion de un lead.
 *
 * El mismo identificador viaja por dos caminos: el servidor lo envia a
 * la plataforma (Meta CAPI) y el navegador lo envia con el pixel. La
 * plataforma los reconoce como un solo evento porque coinciden.
 *
 * Hasta v2.12 el identificador era `wppe-bridge-{queue_id}` y llegaba
 * al navegador en una cookie con el `queue_id` en claro. El `queue_id`
 * es secuencial: quien enviara dos formularios podia estimar cuantos
 * leads recibe el sitio. Aca se deriva con HMAC, igual que el codigo de
 * referencia del Widget de Contacto.
 *
 * @package WPPE_Bridge
 * @since 2.13.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Deriva, valida y entrega al navegador el identificador de evento.
 */
final class WPPE_Bridge_Event_Id {

	/**
	 * Cookie con el identificador del ultimo lead del visitante. La lee
	 * el JS del navegador, por eso no es HttpOnly.
	 */
	public const COOKIE_NAME = 'wppe_bridge_event_id';

	/**
	 * Vida de la cookie en segundos: alcanza para que el visitante
	 * llegue a la pagina de gracias; despues ya no hay evento que
	 * emparejar.
	 */
	public const COOKIE_TTL_SECONDS = 300;

	/**
	 * Cookie que acompana a la anterior cuando el lead rechazo el uso
	 * publicitario de sus datos: el navegador no debe enviar ese evento
	 * al pixel.
	 */
	public const NO_ADS_COOKIE_NAME = 'wppe_bridge_event_noads';

	/**
	 * Evita enganchar dos veces el hook de la cookie.
	 *
	 * @var bool
	 */
	private static bool $hook_registered = false;

	/**
	 * Prefijo del identificador.
	 */
	private const PREFIX = 'wppe-';

	/**
	 * Largo de la parte hexadecimal.
	 */
	private const HASH_LENGTH = 24;

	/**
	 * Identificador de evento para un item de la queue.
	 *
	 * Determinista: el Worker (minutos u horas despues) obtiene el
	 * mismo valor que se le entrego al navegador al enviar el form.
	 *
	 * @param int $queue_id ID del item en la queue.
	 * @return string
	 */
	public static function for_queue( int $queue_id ): string {
		$secret = function_exists( 'wp_salt' ) ? wp_salt( 'wppe_bridge_event' ) : 'wppe-bridge-fallback-salt';
		return self::PREFIX . substr( hash_hmac( 'sha256', (string) $queue_id, $secret ), 0, self::HASH_LENGTH );
	}

	/**
	 * Valida el formato de un identificador de evento.
	 *
	 * @param mixed $value Valor a validar.
	 * @return bool
	 */
	public static function is_valid( $value ): bool {
		return is_string( $value )
			&& 1 === preg_match( '/\A' . self::PREFIX . '[a-f0-9]{' . self::HASH_LENGTH . '}\z/', $value );
	}

	/**
	 * Engancha la entrega de la cookie al momento en que un lead entra
	 * a la queue. Idempotente: varios modulos la necesitan (Thank You
	 * Pixel, Eventos de Contacto) y debe engancharse una sola vez.
	 *
	 * @return void
	 */
	public static function register_cookie_hook(): void {
		if ( self::$hook_registered ) {
			return;
		}
		self::$hook_registered = true;
		add_action( 'wppe_bridge_lead_queued', array( self::class, 'on_lead_queued' ), 10, 2 );
	}

	/**
	 * Callback de `wppe_bridge_lead_queued`.
	 *
	 * @param mixed $queue_id ID del item en la queue.
	 * @param mixed $payload  Payload normalizado del lead.
	 * @return void
	 */
	public static function on_lead_queued( $queue_id, $payload = array() ): void {
		$refused = is_array( $payload )
			&& class_exists( 'WPPE_Bridge_Consent' )
			&& WPPE_Bridge_Consent::advertising_refused( $payload );

		self::set_cookie( $queue_id, ! $refused );
	}

	/**
	 * Entrega al navegador el identificador del lead recien encolado.
	 *
	 * Se llama dentro del request del envio del formulario: la cookie
	 * viaja en esa respuesta, que nunca sale de cache.
	 *
	 * Si el lead rechazo el uso publicitario de sus datos se agrega una
	 * segunda cookie: el navegador registra la conversion para medicion
	 * propia pero no la envia al pixel, igual que el servidor no la
	 * envia a Meta CAPI.
	 *
	 * @param mixed $queue_id    ID del item en la queue.
	 * @param bool  $ads_allowed False si el lead rechazo el uso publicitario.
	 * @return void
	 */
	public static function set_cookie( $queue_id, bool $ads_allowed = true ): void {
		$id = (int) $queue_id;
		if ( $id <= 0 ) {
			return;
		}
		// Si ya se mandaron headers (output prematuro o tests), no se
		// puede setear la cookie — fallar silente.
		if ( headers_sent() ) {
			return;
		}
		$options = array(
			'expires'  => time() + self::COOKIE_TTL_SECONDS,
			'path'     => '/',
			'secure'   => is_ssl(),
			'httponly' => false, // El JS del navegador la necesita leer.
			'samesite' => 'Lax',
		);
		setcookie( self::COOKIE_NAME, self::for_queue( $id ), $options );

		// Se setea siempre, en uno u otro sentido: un lead anterior del
		// mismo visitante pudo dejarla y no debe heredarse.
		$no_ads            = $options;
		$no_ads['expires'] = $ads_allowed ? time() - self::COOKIE_TTL_SECONDS : $options['expires'];
		setcookie( self::NO_ADS_COOKIE_NAME, $ads_allowed ? '' : '1', $no_ads );
	}
}
