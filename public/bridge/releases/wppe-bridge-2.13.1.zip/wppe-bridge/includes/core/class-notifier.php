<?php
/**
 * Notifier de errores por email (v2.4.0).
 *
 * Cuando un lead se marca como `failed_permanent` (D5: 4xx no-429 ->
 * permanente, o se agotaron los reintentos), avisa por email con un
 * resumen batched que explica cada falla en lenguaje llano.
 *
 * **Por que batched (D-Notif-2):** sin throttle, una caida de 30 min
 * del CRM destino enviaria 50+ emails (uno por cada lead que agoto sus
 * reintentos). Con throttle 15 min, todos esos quedan acumulados en un
 * solo email.
 *
 * **Mecanismo:**
 *  1. El action `wppe_bridge_lead_failed` (que dispara el Worker al
 *     marcar un lead como permanente) acumula el queue_id, el codigo
 *     HTTP y el detalle del error en el transient
 *     `wppe_bridge_pending_notifications` (sin TTL, persistente hasta
 *     que se vacie al enviar).
 *  2. Cron `wppe_bridge_notify_tick` corre cada 5 min:
 *     - Si el buffer esta vacio: nada.
 *     - Si esta poblado y NO existe transient `wppe_bridge_email_throttle`
 *       (TTL 15 min): construye email con resumen, lo manda con
 *       `wp_mail`, setea throttle, vacia buffer.
 *     - Si esta poblado pero throttle activo: espera el siguiente tick.
 *  3. Resultado: un solo email cada 15 min con todos los fallos
 *     acumulados, no uno por lead.
 *
 * **Direccion email (D-Notif-1, revisada 2026-11):** por defecto el
 * buzon de soporte de Mono Media (`DEFAULT_RECIPIENT`), que es quien
 * opera la integracion. Override configurable en la option
 * `wppe_bridge_notification_email` (campo en Ajustes). Una sola
 * direccion.
 *
 * **Solo failed_permanent (D-Notif-3):** los `failed_temp` se reintentan
 * solos y suelen recuperarse. No spameamos por blips transitorios.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Notifier de errores por email batched.
 */
final class WPPE_Bridge_Notifier {

	/**
	 * Transient que acumula los leads fallidos pendientes de notificar.
	 * Sin TTL — se vacia explicitamente al enviar email.
	 *
	 * Shape: `array<int queue_id, array{status:int,class:string,error:string}>`.
	 */
	public const BUFFER_KEY = 'wppe_bridge_pending_notifications';

	/**
	 * Transient que indica que ya se envio un email recientemente.
	 * TTL 15 min (D-Notif-2). Mientras esta seteado, el cron tick no
	 * envia aunque el buffer tenga items — los acumula para el siguiente.
	 */
	public const THROTTLE_KEY = 'wppe_bridge_email_throttle';

	/**
	 * TTL del throttle (15 min, D-Notif-2).
	 */
	public const THROTTLE_TTL_SECONDS = 15 * MINUTE_IN_SECONDS;

	/**
	 * Hook cron del tick de notificacion. Schedule `wppebridge_5min`
	 * (registrado en Activator).
	 */
	public const CRON_HOOK_TICK = 'wppe_bridge_notify_tick';

	/**
	 * Maximo de leads que mantenemos en el buffer. Si el buffer crece
	 * mas que esto (caso patologico: CRM caido por horas), los mas
	 * antiguos se descartan del buffer pero el lead sigue en la tabla
	 * queue como `failed_permanent`. Defensa contra que el transient
	 * crezca sin limite.
	 */
	public const BUFFER_MAX_SIZE = 100;

	/**
	 * Option con la direccion que reemplaza al destinatario por defecto.
	 */
	public const OPTION_RECIPIENT = 'wppe_bridge_notification_email';

	/**
	 * Destinatario por defecto: soporte de Mono Media, que opera la
	 * integracion en los sitios WP.pe.
	 */
	public const DEFAULT_RECIPIENT = 'soporte@mono.media';

	/**
	 * Largo maximo del detalle de error que se guarda y se envia.
	 */
	public const ERROR_DETAIL_MAX_LENGTH = 200;

	/**
	 * Cantidad minima de digitos seguidos que se enmascaran en el
	 * detalle del error (telefonos y documentos).
	 */
	private const MIN_DIGITS_TO_MASK = 7;

	/**
	 * Detalle generico que algunos destinos devuelven cuando el CRM no
	 * manda un `message`: no explica nada, asi que se busca algo mejor
	 * en el body de la respuesta.
	 */
	private const GENERIC_ERROR_PATTERN = '/\AHTTP \d{3}\z/';

	/**
	 * Claves del body del CRM que suelen traer el motivo del rechazo.
	 */
	private const BODY_MESSAGE_KEYS = array( 'message', 'detail', 'error_description', 'error', 'title' );

	/**
	 * Maximo de errores de una lista (`errors`, `fields`) que se citan.
	 */
	private const MAX_LISTED_ERRORS = 3;

	/**
	 * Argumentos que entrega el action `wppe_bridge_lead_failed`:
	 * payload, queue_id y respuesta.
	 */
	private const HOOK_ACCEPTED_ARGS = 3;

	private const HTTP_BAD_REQUEST       = 400;
	private const HTTP_UNAUTHORIZED      = 401;
	private const HTTP_FORBIDDEN         = 403;
	private const HTTP_NOT_FOUND         = 404;
	private const HTTP_UNPROCESSABLE     = 422;
	private const HTTP_TOO_MANY_REQUESTS = 429;
	private const HTTP_SERVER_ERROR_MIN  = 500;

	/**
	 * Clase de error con la que el Worker marca un rechazo definitivo.
	 */
	private const ERROR_CLASS_PERMANENT = 'permanent';

	/**
	 * Bootstrap. Llamado desde Plugin::register_hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		// Acumular en buffer cuando un lead falla permanente.
		add_action( 'wppe_bridge_lead_failed', array( self::class, 'on_lead_failed' ), 10, self::HOOK_ACCEPTED_ARGS );

		// Cron tick: chequea buffer + throttle, envia email.
		add_action( self::CRON_HOOK_TICK, array( self::class, 'tick' ) );
	}

	/**
	 * Handler del action `wppe_bridge_lead_failed`. Recibe los argumentos
	 * en el orden en que el Worker los entrega.
	 *
	 * @param mixed $payload  Payload del lead (no se usa: los datos
	 *                        personales no entran al buffer).
	 * @param mixed $queue_id ID del item que fallo.
	 * @param mixed $response Respuesta uniforme `{status, body, raw,
	 *                        error_class, error}`.
	 * @return void
	 */
	public static function on_lead_failed( $payload, $queue_id = 0, $response = array() ): void {
		unset( $payload );
		$response = is_array( $response ) ? $response : array();

		$error = isset( $response['error'] ) && is_string( $response['error'] ) ? trim( $response['error'] ) : '';
		if ( '' === $error || 1 === preg_match( self::GENERIC_ERROR_PATTERN, $error ) ) {
			$from_body = self::detail_from_body( isset( $response['body'] ) && is_array( $response['body'] ) ? $response['body'] : array() );
			$error     = '' !== $from_body ? $from_body : $error;
		}

		self::enqueue_notification(
			is_numeric( $queue_id ) ? (int) $queue_id : 0,
			isset( $response['status'] ) ? (int) $response['status'] : 0,
			isset( $response['error_class'] ) && is_string( $response['error_class'] ) ? $response['error_class'] : '',
			$error
		);
	}

	/**
	 * Busca el motivo del rechazo en el body que devolvio el CRM. Cubre
	 * las formas habituales: un texto en `message`/`error`/`detail`, una
	 * lista `errors` (texto o `{detail|title|message}`) y un mapa
	 * `fields` de campo => motivo.
	 *
	 * @param array $body Body decodificado de la respuesta.
	 * @return string Cadena vacia si no encuentra nada legible.
	 */
	public static function detail_from_body( array $body ): string {
		$parts = array();

		foreach ( self::BODY_MESSAGE_KEYS as $key ) {
			if ( isset( $body[ $key ] ) && is_string( $body[ $key ] ) && '' !== trim( $body[ $key ] ) ) {
				$parts[] = trim( $body[ $key ] );
				break;
			}
		}

		foreach ( array( 'errors', 'fields' ) as $list_key ) {
			if ( ! isset( $body[ $list_key ] ) || ! is_array( $body[ $list_key ] ) ) {
				continue;
			}
			$listed = 0;
			foreach ( $body[ $list_key ] as $name => $item ) {
				if ( $listed >= self::MAX_LISTED_ERRORS ) {
					break;
				}
				$text = is_array( $item ) ? self::detail_from_body( $item ) : ( is_scalar( $item ) ? trim( (string) $item ) : '' );
				if ( '' === $text ) {
					continue;
				}
				$parts[] = is_string( $name ) ? $name . ': ' . $text : $text;
				++$listed;
			}
		}

		return implode( '; ', $parts );
	}

	/**
	 * Acumula un lead fallido en el buffer. Idempotente: si el id ya
	 * esta, no se duplica.
	 *
	 * @param int    $queue_id    ID del item que fallo.
	 * @param int    $http_status Codigo HTTP del ultimo intento (0 si no
	 *                            hubo respuesta).
	 * @param string $error_class Clase del error (`permanent`, `transient`).
	 * @param string $error       Detalle legible del error.
	 * @return void
	 */
	public static function enqueue_notification( int $queue_id, int $http_status = 0, string $error_class = '', string $error = '' ): void {
		if ( $queue_id <= 0 ) {
			return;
		}

		$buffer = self::normalize_buffer( get_transient( self::BUFFER_KEY ) );

		// Idempotente: no duplicar.
		if ( isset( $buffer[ $queue_id ] ) ) {
			return;
		}

		$buffer[ $queue_id ] = array(
			'status' => $http_status,
			'class'  => $error_class,
			'error'  => self::sanitize_error_detail( $error ),
		);

		// Cap defensivo (caso patologico: CRM caido por horas, miles
		// de fallos). Se descartan los mas antiguos.
		if ( count( $buffer ) > self::BUFFER_MAX_SIZE ) {
			$buffer = array_slice( $buffer, -self::BUFFER_MAX_SIZE, null, true );
		}

		// Sin TTL — se vacia al enviar email.
		set_transient( self::BUFFER_KEY, $buffer, 0 );
	}

	/**
	 * Lleva el buffer al shape `queue_id => detalle`. Acepta tambien la
	 * lista plana de ids que guardaban las versiones anteriores.
	 *
	 * @param mixed $buffer Valor crudo del transient.
	 * @return array<int,array{status:int,class:string,error:string}>
	 */
	public static function normalize_buffer( $buffer ): array {
		if ( ! is_array( $buffer ) ) {
			return array();
		}

		$normalized = array();
		foreach ( $buffer as $key => $value ) {
			$queue_id = is_array( $value ) ? (int) $key : (int) $value;
			if ( $queue_id <= 0 ) {
				continue;
			}
			$detail                  = is_array( $value ) ? $value : array();
			$normalized[ $queue_id ] = array(
				'status' => isset( $detail['status'] ) ? (int) $detail['status'] : 0,
				'class'  => isset( $detail['class'] ) ? (string) $detail['class'] : '',
				'error'  => isset( $detail['error'] ) ? (string) $detail['error'] : '',
			);
		}
		return $normalized;
	}

	/**
	 * Tick del cron. Llamado cada 5 min via WP-Cron.
	 *
	 * Si hay buffer + no esta throttled, envia email batched.
	 *
	 * @return void
	 */
	public static function tick(): void {
		$buffer = get_transient( self::BUFFER_KEY );
		if ( ! is_array( $buffer ) || empty( $buffer ) ) {
			return; // Nada que notificar.
		}

		if ( false !== get_transient( self::THROTTLE_KEY ) ) {
			return; // Throttle activo, esperar siguiente tick.
		}

		$sent = self::send_email( $buffer );

		if ( $sent ) {
			// Setear throttle 15 min.
			set_transient( self::THROTTLE_KEY, time(), self::THROTTLE_TTL_SECONDS );
			// Vaciar buffer.
			delete_transient( self::BUFFER_KEY );

			if ( class_exists( 'WPPE_Bridge_Logger' ) ) {
				WPPE_Bridge_Logger::info(
					'notifier_email_sent',
					array(
						'count' => count( $buffer ),
						'to'    => self::recipient(),
					)
				);
			}
		} elseif ( class_exists( 'WPPE_Bridge_Logger' ) ) {
			// Si fallo el envio (wp_mail returned false), no setear
			// throttle ni vaciar — reintentaremos en el siguiente tick.
			WPPE_Bridge_Logger::warn(
				'notifier_email_failed',
				array( 'count' => count( $buffer ) )
			);
		}
	}

	/**
	 * Construye y envia el email con resumen de leads fallidos.
	 *
	 * @param array $buffer Buffer de leads fallidos (cualquier shape que
	 *                      acepte `normalize_buffer`).
	 * @return bool True si wp_mail retorno true, false si no.
	 */
	public static function send_email( array $buffer ): bool {
		$to      = self::recipient();
		$count   = count( self::normalize_buffer( $buffer ) );
		$subject = sprintf(
			/* translators: %d: count of failed leads */
			_n(
				'[WP.pe Bridge] %d lead fallo al enviar al CRM',
				'[WP.pe Bridge] %d leads fallaron al enviar al CRM',
				$count,
				'wppe-bridge'
			),
			$count
		);

		$body = self::build_email_body( $buffer );

		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
		);

		// wp_mail puede retornar false en SMTP roto.
		return (bool) wp_mail( $to, $subject, $body, $headers );
	}

	/**
	 * Construye el body HTML del email.
	 *
	 * @param array $buffer Buffer de leads fallidos (cualquier shape que
	 *                      acepte `normalize_buffer`).
	 * @return string HTML del email.
	 */
	public static function build_email_body( array $buffer ): string {
		$entries     = self::normalize_buffer( $buffer );
		$count       = count( $entries );
		$logs_url    = function_exists( 'admin_url' )
			? admin_url( 'admin.php?page=wppe-bridge-logs&status=failed_permanent' )
			: '';
		$site_url    = function_exists( 'home_url' ) ? home_url() : '';
		$site_label  = function_exists( 'get_bloginfo' ) ? (string) get_bloginfo( 'name' ) : 'WordPress site';
		$destination = class_exists( 'WPPE_Bridge_Destination_Factory' )
			? WPPE_Bridge_Destination_Factory::active_slug()
			: 'unknown';

		$cell      = 'border:1px solid #ccd0d4;vertical-align:top';
		$rows_html = '';
		foreach ( $entries as $qid => $entry ) {
			$item = class_exists( 'WPPE_Bridge_Queue' ) ? WPPE_Bridge_Queue::find( (int) $qid ) : null;
			if ( null === $item ) {
				$rows_html .= sprintf(
					'<tr><td style="%s">#%d</td><td style="%s" colspan="4"><em>%s</em></td></tr>',
					esc_attr( $cell ),
					(int) $qid,
					esc_attr( $cell ),
					esc_html__( 'No encontrado (eliminado?)', 'wppe-bridge' )
				);
				continue;
			}

			$payload = is_string( $item->payload ) ? json_decode( $item->payload, true ) : null;
			$email   = is_array( $payload ) && isset( $payload['email'] ) ? (string) $payload['email'] : '';
			$masked  = class_exists( 'WPPE_Bridge_Pii_Masker' )
				? WPPE_Bridge_Pii_Masker::mask_email( $email )
				: '';

			$stored = self::failure_from_row( $item );
			$status = 0 !== $entry['status'] ? $entry['status'] : $stored['status'];
			$class  = '' !== $entry['class'] ? $entry['class'] : $stored['class'];
			$detail = '' !== $entry['error'] ? $entry['error'] : $stored['error'];

			$rows_html .= sprintf(
				'<tr><td style="%1$s">#%2$d</td><td style="%1$s">%3$s</td><td style="%1$s">%4$s</td><td style="%1$s">%5$s</td><td style="%1$s">%6$s<br/><span style="color:#666;font-size:12px">%7$s %8$s</span></td></tr>',
				esc_attr( $cell ),
				(int) $item->id,
				esc_html( (string) $item->created_at ),
				esc_html( $masked ),
				esc_html( self::status_label( $status ) ),
				esc_html( self::explain( $status, $class ) ),
				esc_html__( 'Detalle del CRM:', 'wppe-bridge' ),
				esc_html( '' !== $detail ? $detail : __( 'sin detalle', 'wppe-bridge' ) )
			);
		}

		$site_label_h  = esc_html( $site_label );
		$site_url_h    = esc_url( $site_url );
		$logs_url_h    = esc_url( $logs_url );
		$destination_h = esc_html( $destination );

		return <<<HTML
<!DOCTYPE html>
<html><body style="font-family:system-ui,sans-serif;max-width:760px;margin:0 auto;padding:1em">
	<h2 style="color:#dc3232">WP.pe Bridge — leads fallidos</h2>
	<p>
		El plugin WP.pe Bridge en <strong><a href="{$site_url_h}">{$site_label_h}</a></strong>
		marc&oacute; <strong>{$count} lead(s)</strong> como <code>failed_permanent</code> al
		enviarlos al CRM destino (<code>{$destination_h}</code>).
	</p>
	<p>
		Los leads en este estado <strong>no se reintentan</strong> autom&aacute;ticamente.
		La tabla explica qu&eacute; pas&oacute; con cada uno y qu&eacute; hacer. Una vez
		corregida la causa, se reintentan desde la p&aacute;gina de Logs.
	</p>
	<table cellpadding="6" cellspacing="0" style="border-collapse:collapse;border:1px solid #ccd0d4;width:100%">
		<thead style="background:#f0f0f1">
			<tr>
				<th style="border:1px solid #ccd0d4;text-align:left">ID</th>
				<th style="border:1px solid #ccd0d4;text-align:left">Fecha (UTC)</th>
				<th style="border:1px solid #ccd0d4;text-align:left">Email</th>
				<th style="border:1px solid #ccd0d4;text-align:left">C&oacute;digo</th>
				<th style="border:1px solid #ccd0d4;text-align:left">Qu&eacute; pas&oacute; y qu&eacute; hacer</th>
			</tr>
		</thead>
		<tbody>
			{$rows_html}
		</tbody>
	</table>
	<p style="margin-top:1.5em">
		<a href="{$logs_url_h}" style="background:#2271b1;color:#fff;padding:8px 16px;text-decoration:none;border-radius:3px;display:inline-block">
			Ver logs completos &rarr;
		</a>
	</p>
	<hr style="margin:2em 0;border:0;border-top:1px solid #ccd0d4"/>
	<p style="color:#666;font-size:12px">
		Este email se envia con throttle de 15 minutos para evitar spam.
		Si recibes muchos seguidos, probablemente el CRM destino esta caido.
	</p>
</body></html>
HTML;
	}

	/**
	 * Explica una falla en lenguaje llano: que paso y que hacer.
	 *
	 * @param int    $http_status Codigo HTTP del ultimo intento (0 si no
	 *                            hubo respuesta).
	 * @param string $error_class Clase del error (`permanent`, `transient`).
	 * @return string
	 */
	public static function explain( int $http_status, string $error_class = '' ): string {
		if ( 0 === $http_status ) {
			if ( self::ERROR_CLASS_PERMANENT === $error_class ) {
				return __( 'El envío no llegó a salir del sitio: falta un dato o la configuración del destino es inválida. El detalle indica cuál. Corregirlo y reintentar desde Logs.', 'wppe-bridge' );
			}
			return __( 'El CRM no respondió en ninguno de los intentos (sin conexión o tiempo agotado). El lead pudo haber llegado igual: verificarlo en el CRM antes de reintentar desde Logs, para no duplicarlo.', 'wppe-bridge' );
		}

		if ( $http_status >= self::HTTP_SERVER_ERROR_MIN ) {
			return __( 'El CRM respondió con un error interno en todos los intentos. Es un problema del lado del CRM: reintentar desde Logs cuando vuelva a operar.', 'wppe-bridge' );
		}

		switch ( $http_status ) {
			case self::HTTP_UNAUTHORIZED:
				return __( 'El CRM rechazó el token: está mal copiado, vencido o fue revocado. Volver a ingresarlo en Ajustes y reintentar desde Logs. Mientras no se corrija, todos los leads fallarán igual.', 'wppe-bridge' );
			case self::HTTP_FORBIDDEN:
				return __( 'El token es válido pero no tiene permiso para crear contactos. Revisar los permisos de ese usuario o token en el CRM.', 'wppe-bridge' );
			case self::HTTP_NOT_FOUND:
				return __( 'El CRM no encontró la dirección de la API o un ID configurado (proyecto, canal, etapa). Revisar Ajustes, volver a sincronizar los catálogos y revisar el Mapeo.', 'wppe-bridge' );
			case self::HTTP_UNPROCESSABLE:
			case self::HTTP_BAD_REQUEST:
				return __( 'El CRM rechazó los datos del lead: falta un campo obligatorio, un valor tiene formato inválido o un ID del Mapeo ya no existe. El detalle indica el campo. Corregir el Mapeo de ese formulario y reintentar desde Logs.', 'wppe-bridge' );
			case self::HTTP_TOO_MANY_REQUESTS:
				return __( 'El CRM limitó la cantidad de envíos y los reintentos se agotaron. Reintentar desde Logs más tarde.', 'wppe-bridge' );
		}

		return __( 'El CRM rechazó el lead. Revisar el detalle y la página de Logs para identificar la causa antes de reintentar.', 'wppe-bridge' );
	}

	/**
	 * Etiqueta corta del codigo de respuesta para la tabla del email.
	 *
	 * @param int $http_status Codigo HTTP (0 si no hubo respuesta).
	 * @return string
	 */
	public static function status_label( int $http_status ): string {
		if ( 0 === $http_status ) {
			return __( 'Sin respuesta', 'wppe-bridge' );
		}
		return sprintf( 'HTTP %d', $http_status );
	}

	/**
	 * Limpia el detalle de un error antes de guardarlo o enviarlo: sin
	 * HTML, con emails, telefonos y documentos enmascarados, y acotado
	 * a `ERROR_DETAIL_MAX_LENGTH`.
	 *
	 * @param string $error Detalle crudo.
	 * @return string
	 */
	public static function sanitize_error_detail( string $error ): string {
		$clean = trim( (string) preg_replace( '/\s+/', ' ', wp_strip_all_tags( $error ) ) );
		if ( '' === $clean ) {
			return '';
		}

		$clean = (string) preg_replace_callback(
			'/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i',
			static function ( array $matches ): string {
				return WPPE_Bridge_Pii_Masker::mask_email( $matches[0] );
			},
			$clean
		);

		$clean = (string) preg_replace_callback(
			'/\+?\d{' . self::MIN_DIGITS_TO_MASK . ',}/',
			static function ( array $matches ): string {
				return WPPE_Bridge_Pii_Masker::mask_phone( $matches[0] );
			},
			$clean
		);

		return function_exists( 'mb_substr' )
			? mb_substr( $clean, 0, self::ERROR_DETAIL_MAX_LENGTH )
			: substr( $clean, 0, self::ERROR_DETAIL_MAX_LENGTH );
	}

	/**
	 * Lee codigo, clase y detalle de la respuesta guardada en la fila de
	 * la cola. Respaldo para entradas del buffer sin detalle.
	 *
	 * La columna guarda dos shapes: el body del CRM tal cual (rechazo
	 * 4xx) o `{status, body, raw, error_class}` (reintentos agotados).
	 *
	 * @param object $item Fila de la cola.
	 * @return array{status:int,class:string,error:string}
	 */
	private static function failure_from_row( object $item ): array {
		$stored = isset( $item->destination_response ) && is_string( $item->destination_response )
			? json_decode( $item->destination_response, true )
			: null;
		if ( ! is_array( $stored ) ) {
			return array(
				'status' => 0,
				'class'  => '',
				'error'  => '',
			);
		}

		$is_uniform = isset( $stored['error_class'] );
		if ( $is_uniform ) {
			$body = isset( $stored['body'] ) && is_array( $stored['body'] ) ? $stored['body'] : array();
		} else {
			$body = $stored;
		}

		return array(
			'status' => $is_uniform && isset( $stored['status'] ) ? (int) $stored['status'] : 0,
			'class'  => $is_uniform ? (string) $stored['error_class'] : '',
			'error'  => self::sanitize_error_detail( self::detail_from_body( $body ) ),
		);
	}

	/**
	 * Direccion email destinataria (D-Notif-1).
	 *
	 * Default: soporte de Mono Media. Override: option
	 * `wppe_bridge_notification_email` si esta configurada y es valida.
	 *
	 * @return string
	 */
	public static function recipient(): string {
		$override = (string) get_option( self::OPTION_RECIPIENT, '' );
		if ( '' !== $override && is_email( $override ) ) {
			return $override;
		}
		return self::DEFAULT_RECIPIENT;
	}
}
