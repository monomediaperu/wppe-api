<?php
/**
 * Consentimiento del titular en los formularios conectados.
 *
 * Hasta v2.12 solo el Widget de Contacto validaba y registraba el
 * consentimiento. Los adaptadores de formularios (Fluent, Gravity,
 * Elementor, CF7) no miraban la casilla de aceptacion: el lead entraba
 * al CRM igual y no quedaba evidencia.
 *
 * Esta clase define como se mapea, interpreta y registra la casilla de
 * aceptacion de un formulario. **Informa, no bloquea**: un lead sin
 * consentimiento marcado entra al CRM igual y queda senalado en el log
 * (decision de producto 2026-11-23). Bloquear haria que un formulario
 * mal armado dejara de generar leads sin que el cliente lo note.
 *
 * Dos finalidades, porque la Ley 29733 exige consentimiento separado
 * para las finalidades adicionales:
 *  - contacto: tratar los datos para responder la consulta.
 *  - publicidad: usarlos con fines publicitarios (incluye enviarlos a
 *    plataformas como Meta).
 *
 * @package WPPE_Bridge
 * @since 2.13.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Mapeo, interpretacion y registro del consentimiento de un lead.
 */
final class WPPE_Bridge_Consent {

	/**
	 * Key del payload: consentimiento para ser contactado.
	 *
	 * El prefijo `wppe_` evita chocar con un campo custom `consent` que
	 * un cliente ya tuviera mapeado hacia su CRM.
	 */
	public const KEY_CONTACT = 'wppe_consent';

	/**
	 * Key del payload: consentimiento para fines publicitarios.
	 */
	public const KEY_MARKETING = 'wppe_consent_marketing';

	/**
	 * Valores que un plugin de formularios puede enviar para una casilla
	 * NO marcada. Cualquier otro valor no vacio cuenta como marcada
	 * (cada plugin usa el suyo: `on`, `1`, `yes`, o el texto de la
	 * propia casilla).
	 */
	private const DENIED_VALUES = array( '0', 'false', 'no', 'off', 'null' );

	/**
	 * Keys de consentimiento.
	 *
	 * @return array<int,string>
	 */
	public static function keys(): array {
		return array( self::KEY_CONTACT, self::KEY_MARKETING );
	}

	/**
	 * Etiquetas para la pantalla de Mapeo: key => texto visible.
	 *
	 * @return array<string,string>
	 */
	public static function labels(): array {
		return array(
			self::KEY_CONTACT   => __( 'Casilla de aceptación: política de privacidad', 'wppe-bridge' ),
			self::KEY_MARKETING => __( 'Casilla de aceptación: fines publicitarios', 'wppe-bridge' ),
		);
	}

	/**
	 * Interpreta el valor crudo de una casilla de aceptacion.
	 *
	 * @param mixed $value Valor que entrego el plugin de formularios.
	 * @return bool True si la casilla llego marcada.
	 */
	public static function is_granted( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_int( $value ) || is_float( $value ) ) {
			return 0.0 !== (float) $value;
		}
		if ( is_array( $value ) ) {
			// Casillas que llegan como lista de opciones marcadas.
			foreach ( $value as $item ) {
				if ( self::is_granted( $item ) ) {
					return true;
				}
			}
			return false;
		}
		if ( ! is_string( $value ) ) {
			return false;
		}
		$normalized = strtolower( trim( $value ) );
		return '' !== $normalized && ! in_array( $normalized, self::DENIED_VALUES, true );
	}

	/**
	 * Deja las keys de consentimiento del payload como 1 / 0.
	 *
	 * Una casilla sin marcar no viaja en el envio del formulario, asi
	 * que "mapeada pero ausente" se registra como 0. Una key que el
	 * formulario no tiene mapeada se elimina: su ausencia significa
	 * "este formulario no declara esa finalidad", que no es lo mismo que
	 * un rechazo.
	 *
	 * @param array               $payload        Payload en construccion.
	 * @param array<string,mixed> $mapping_fields Mapeo `campo del form => key`.
	 * @return array
	 */
	public static function normalize_payload( array $payload, array $mapping_fields ): array {
		$mapped = array_intersect( self::keys(), array_map( 'strval', array_values( $mapping_fields ) ) );

		foreach ( self::keys() as $key ) {
			if ( ! in_array( $key, $mapped, true ) ) {
				unset( $payload[ $key ] );
				continue;
			}
			$payload[ $key ] = self::is_granted( $payload[ $key ] ?? null ) ? 1 : 0;
		}
		return $payload;
	}

	/**
	 * Estado de una finalidad en el payload de un lead.
	 *
	 * @param array  $payload Payload del lead.
	 * @param string $key     KEY_CONTACT o KEY_MARKETING.
	 * @return bool|null True/false si el formulario la declara; null si
	 *                   el formulario no tiene esa casilla mapeada.
	 */
	public static function status( array $payload, string $key ): ?bool {
		if ( ! array_key_exists( $key, $payload ) ) {
			return null;
		}
		return 1 === (int) $payload[ $key ];
	}

	/**
	 * Indica si el lead rechazo de forma explicita el uso publicitario
	 * de sus datos.
	 *
	 * Solo un rechazo explicito cuenta:
	 *  - la casilla de fines publicitarios existe y llego sin marcar, o
	 *  - no hay casilla de fines publicitarios y la de politica de
	 *    privacidad llego sin marcar.
	 *
	 * Un formulario sin casillas mapeadas devuelve false ("no se sabe"):
	 * para esos leads se conserva el comportamiento previo a v2.13.0.
	 *
	 * @param array $payload Payload del lead.
	 * @return bool
	 */
	public static function advertising_refused( array $payload ): bool {
		$marketing = self::status( $payload, self::KEY_MARKETING );
		if ( null !== $marketing ) {
			return false === $marketing;
		}
		return false === self::status( $payload, self::KEY_CONTACT );
	}

	/**
	 * Indica si un mapeo de formulario declara la casilla de aceptacion
	 * de contacto.
	 *
	 * @param mixed $entry Entrada `{fields, defaults}` del mapeo.
	 * @return bool
	 */
	public static function mapping_has_contact_consent( $entry ): bool {
		if ( ! is_array( $entry ) || ! isset( $entry['fields'] ) || ! is_array( $entry['fields'] ) ) {
			return false;
		}
		return in_array( self::KEY_CONTACT, array_map( 'strval', array_values( $entry['fields'] ) ), true );
	}

	/**
	 * Registra en el log la evidencia del consentimiento de un lead.
	 *
	 * Misma practica que el Widget de Contacto: IP pseudonimizada con
	 * HMAC (nunca en claro) y el momento lo aporta `created_at` del log.
	 * No registra nada si el formulario no tiene casillas mapeadas.
	 *
	 * @param array  $payload     Payload normalizado del lead.
	 * @param int    $queue_id    ID del item en la queue.
	 * @param string $form_plugin Slug del plugin de formularios.
	 * @param string $form_id     ID del formulario.
	 * @return void
	 */
	public static function record( array $payload, int $queue_id, string $form_plugin, string $form_id ): void {
		$contact   = self::status( $payload, self::KEY_CONTACT );
		$marketing = self::status( $payload, self::KEY_MARKETING );

		if ( null === $contact && null === $marketing ) {
			return;
		}

		$context = array(
			'form_plugin' => $form_plugin,
			'form_id'     => $form_id,
			'contact'     => $contact,
			'marketing'   => $marketing,
		);

		$ip = isset( $payload['client_ip'] ) && is_string( $payload['client_ip'] ) ? $payload['client_ip'] : '';
		if ( '' !== $ip && class_exists( 'WPPE_Bridge_Widget_Controller' ) ) {
			$context['ip_hash'] = WPPE_Bridge_Widget_Controller::hash_ip( $ip );
		}

		if ( false === $contact ) {
			// La casilla existe y llego sin marcar: el lead entra igual
			// (informa, no bloquea) pero queda visible como advertencia.
			WPPE_Bridge_Logger::warn( 'form_consent_missing', $context, $queue_id );
			return;
		}

		WPPE_Bridge_Logger::info( 'form_consent_recorded', $context, $queue_id );
	}
}
