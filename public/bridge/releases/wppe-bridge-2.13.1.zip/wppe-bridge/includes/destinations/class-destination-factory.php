<?php
/**
 * Factory de destinos CRM.
 *
 * Lee la option `wppe_bridge_active_destination` y retorna una
 * instancia del destino correspondiente. Si la option no existe o
 * tiene un valor fuera del whitelist, cae a Sperant (default
 * defensivo — el plugin nacio Sperant-only y queremos preservar
 * ese comportamiento ante configuraciones invalidas).
 *
 * Para agregar un destino nuevo (ej. Pipedrive en el futuro):
 * 1. Crear `class-pipedrive-destination.php` que implemente el interface.
 * 2. Agregar entry en `registry()` con su clase.
 * 3. (opcional) Crear sub-pagina admin de su config especifica.
 *
 * GHL fue agregado en v2.1.0 (PR-1 de su ciclo). Webhook generico en
 * v2.3.0. Odoo nativo en v2.5.0 (3 PRs estilo GHL: PR-1 backbone,
 * PR-2 catalogos+mapeo, PR-3 inyeccion+release). HubSpot nativo en
 * v2.6.0 (mismo patron de 3 PRs). Pipedrive sigue como coming_soon
 * hasta que aparezca demanda.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Factory: selecciona el destino activo via option.
 */
final class WPPE_Bridge_Destination_Factory {

	/**
	 * Option que guarda el slug del destino activo.
	 */
	public const OPTION_ACTIVE = 'wppe_bridge_active_destination';

	/**
	 * Default cuando la option no esta seteada o tiene valor invalido.
	 */
	public const DEFAULT_SLUG = WPPE_Sperant_Destination_Sperant::SLUG;

	/**
	 * Whitelist de destinos disponibles. Map slug -> class.
	 *
	 * @return array<string,class-string<WPPE_Bridge_Destination_Interface>>
	 */
	public static function registry(): array {
		return array(
			WPPE_Sperant_Destination_Sperant::SLUG => WPPE_Sperant_Destination_Sperant::class,
			WPPE_Ghl_Destination::SLUG             => WPPE_Ghl_Destination::class,
			WPPE_Odoo_Destination::SLUG            => WPPE_Odoo_Destination::class,
			WPPE_Hubspot_Destination::SLUG         => WPPE_Hubspot_Destination::class,
			WPPE_Bridge_Webhook_Destination::SLUG  => WPPE_Bridge_Webhook_Destination::class,
		);
	}

	/**
	 * Lista de destinos "coming soon" — visibles en el dropdown
	 * admin pero deshabilitados (no seleccionables, no persistibles).
	 * Sirven como roadmap visible para el usuario. El sanitizer los
	 * rechaza por whitelist, defensa adicional.
	 *
	 * @return array<string,string>
	 */
	public static function coming_soon(): array {
		return array(
			'_coming_pipedrive' => __( 'Pipedrive — proximamente', 'wppe-bridge' ),
		);
	}

	/**
	 * Lista de destinos para el dropdown admin (slug -> label).
	 * Incluye los coming_soon al final para visibilidad de roadmap.
	 *
	 * @return array<string,string>
	 */
	public static function available(): array {
		$out = array();
		foreach ( self::registry() as $slug => $class ) {
			$out[ $slug ] = $class::label();
		}
		foreach ( self::coming_soon() as $slug => $label ) {
			$out[ $slug ] = $label;
		}
		return $out;
	}

	/**
	 * Retorna el destino activo segun la option, con fallback a
	 * Sperant si la option esta vacia o tiene un valor desconocido.
	 *
	 * @return WPPE_Bridge_Destination_Interface
	 */
	public static function get(): WPPE_Bridge_Destination_Interface {
		$slug     = self::active_slug();
		$registry = self::registry();
		$class    = $registry[ $slug ] ?? $registry[ self::DEFAULT_SLUG ];
		return new $class();
	}

	/**
	 * Lee el slug del destino activo desde la option, validandolo
	 * contra el whitelist. Aislado para testeo y para que el dropdown
	 * pueda mostrar el valor actual.
	 *
	 * V2.5.6: si la option NO esta seteada (fresh install), retorna
	 * string vacio — distinto de "esta seteada pero con valor invalido"
	 * (que cae al DEFAULT_SLUG defensivo). Esto permite que la UI
	 * distinga "el user no eligio nada todavia" vs "el user eligio
	 * algo valido" y muestre el banner "Selecciona un CRM". Tambien
	 * permite que el Worker (via `is_configured`) decida no procesar
	 * la queue en ese estado.
	 *
	 * @return string Slug del destino activo, o vacio si fresh install.
	 */
	public static function active_slug(): string {
		// Sentinel para distinguir "option no existe" de "option = ''".
		$raw = get_option( self::OPTION_ACTIVE, '__wppe_unset__' );
		if ( '__wppe_unset__' === $raw ) {
			return '';
		}
		$value = (string) $raw;
		if ( '' === $value ) {
			return '';
		}
		// Option existe con valor — si invalido, cae al default (defensa
		// contra rows manualmente corrompidas en wp_options).
		return isset( self::registry()[ $value ] ) ? $value : self::DEFAULT_SLUG;
	}

	/**
	 * True si el user ya eligio un destino valido. v2.5.6.
	 *
	 * Usado por el Worker para early-return cuando no hay destino
	 * configurado (los leads quedan en queue pending hasta que el
	 * user elija) y por la vista para mostrar el banner "Selecciona
	 * un CRM destino" en fresh installs.
	 *
	 * Defensivo: aunque `active_slug()` ya valida contra el registry,
	 * re-chequeamos aqui para no depender del comportamiento interno.
	 *
	 * @return bool
	 */
	public static function is_configured(): bool {
		$slug = self::active_slug();
		if ( '' === $slug ) {
			return false;
		}
		return isset( self::registry()[ $slug ] );
	}
}
