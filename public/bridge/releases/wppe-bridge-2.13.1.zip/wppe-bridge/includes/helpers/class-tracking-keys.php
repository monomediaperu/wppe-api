<?php
/**
 * Catalogo unico de los datos de atribucion publicitaria que captura
 * el plugin.
 *
 * Antes cada pieza (JS de captura, adapter, destinos) llevaba su propia
 * lista de keys. Cada destino CRM mantiene ademas una lista de keys que
 * NO debe enviar; agregar un identificador nuevo obligaba a tocarlas
 * todas, y olvidar una dejaba leads rechazados (Odoo responde
 * `Invalid field` permanente ante una key desconocida).
 *
 * Este helper es la fuente unica: quien necesite la lista, la pide aca.
 *
 * @package WPPE_Bridge
 * @since 2.13.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Keys de atribucion: de donde salen y a quien le sirven.
 */
final class WPPE_Bridge_Tracking_Keys {

	/**
	 * Largo maximo de un identificador de clic o valor de cookie. Son
	 * datos 100% controlados por el visitante.
	 */
	public const MAX_VALUE_LENGTH = 300;

	/**
	 * Key del payload con el momento real del envio del formulario
	 * (epoch UTC). La inyecta el Worker desde `created_at` de la queue
	 * para que las integraciones de medicion no usen la hora en que el
	 * CRM respondio.
	 */
	public const SUBMITTED_AT_KEY = 'submitted_at';

	/**
	 * Identificadores de clic que llegan en la URL del anuncio.
	 *
	 * - `gclid`: Google Ads.
	 * - `gbraid` / `wbraid`: Google Ads en iOS, cuando no puede enviar
	 *   `gclid` (campanas de app y web respectivamente).
	 * - `fbclid`: Meta.
	 * - `ttclid`: TikTok.
	 *
	 * @return array<int,string>
	 */
	public static function click_id_keys(): array {
		return array( 'gclid', 'gbraid', 'wbraid', 'fbclid', 'ttclid' );
	}

	/**
	 * Cookies first-party que dejan los pixeles en el navegador:
	 * key del payload => nombre de la cookie.
	 *
	 * - `fbp`: identificador de navegador de Meta.
	 * - `fbc`: clic de Meta con su fecha real (preferible a reconstruirlo
	 *   desde `fbclid` al momento del envio).
	 * - `ttp`: identificador de navegador de TikTok.
	 *
	 * @return array<string,string>
	 */
	public static function platform_cookies(): array {
		return array(
			'fbp' => '_fbp',
			'fbc' => '_fbc',
			'ttp' => '_ttp',
		);
	}

	/**
	 * Keys que solo le sirven a una plataforma publicitaria y que un
	 * CRM no tiene donde guardar. Todo destino CRM las quita antes de
	 * enviar; siguen disponibles en el payload de la queue y en el hook
	 * `wppe_bridge_lead_sent` para las integraciones de medicion.
	 *
	 * `gclid`, `fbclid` y `fbp` no estan aca a proposito: cada destino
	 * ya decidia que hacer con ellas antes de v2.13.0 y ese
	 * comportamiento se conserva.
	 *
	 * @return array<int,string>
	 */
	public static function ad_platform_only_keys(): array {
		return array( 'gbraid', 'wbraid', 'ttclid', 'fbc', 'ttp' );
	}

	/**
	 * Keys del payload que ningun destino CRM debe recibir: las de
	 * plataformas publicitarias, las internas de medicion y las de
	 * consentimiento (evidencia que guarda el plugin, no un campo del CRM).
	 *
	 * Es la lista que los destinos fusionan con la suya. Una key nueva
	 * de medicion se declara aca y queda excluida en todos.
	 *
	 * @return array<int,string>
	 */
	public static function crm_excluded_keys(): array {
		return array_merge(
			self::ad_platform_only_keys(),
			array( self::SUBMITTED_AT_KEY ),
			WPPE_Bridge_Consent::keys()
		);
	}

	/**
	 * Valida un identificador de clic o valor de cookie de plataforma.
	 *
	 * Acepta solo el juego de caracteres que usan estos identificadores
	 * (alfanumerico, punto, guion y guion bajo). Cualquier otra cosa se
	 * descarta: el valor viaja a APIs de terceros y a logs.
	 *
	 * @param mixed $value Valor crudo.
	 * @return string Valor limpio, o cadena vacia si no es valido.
	 */
	public static function sanitize_identifier( $value ): string {
		if ( ! is_string( $value ) ) {
			return '';
		}
		$value = trim( $value );
		if ( '' === $value || strlen( $value ) > self::MAX_VALUE_LENGTH ) {
			return '';
		}
		return 1 === preg_match( '/\A[A-Za-z0-9._-]+\z/', $value ) ? $value : '';
	}

	/**
	 * Lee las cookies de plataforma del request actual.
	 *
	 * Se leen en el servidor al recibir el formulario (son first-party y
	 * viajan con el envio), no al aterrizar: el pixel suele crear `_fbp`
	 * despues de que la pagina cargo, y un visitante sin UTMs nunca
	 * disparaba la captura en el navegador.
	 *
	 * @return array<string,string> key del payload => valor validado.
	 */
	public static function read_platform_cookies(): array {
		$out = array();
		foreach ( self::platform_cookies() as $key => $cookie ) {
			if ( ! isset( $_COOKIE[ $cookie ] ) ) {
				continue;
			}
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitize_identifier valida charset y largo.
			$value = self::sanitize_identifier( wp_unslash( $_COOKIE[ $cookie ] ) );
			if ( '' === $value ) {
				continue;
			}
			// Las cookies de Meta siempre empiezan con `fb.`; otro
			// prefijo es una cookie ajena o manipulada.
			if ( in_array( $key, array( 'fbp', 'fbc' ), true ) && 0 !== strpos( $value, 'fb.' ) ) {
				continue;
			}
			$out[ $key ] = $value;
		}
		return $out;
	}
}
