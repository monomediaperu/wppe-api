<?php
/**
 * Registro del menu admin del plugin.
 *
 * Top-level menu "WP.pe Bridge" con submenus: Settings, Mapping, Logs.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registra el menu admin top-level y los submenus.
 */
final class WPPE_Bridge_Admin_Menu {

	public const SLUG       = 'wppe-bridge';
	public const CAPABILITY = 'manage_options';

	/**
	 * Registra el menu top-level y submenus.
	 *
	 * Orden del menu (desde v1.0.5):
	 *   Inicio (landing) | Configuracion | Mapeo | Modulos | Logs
	 *
	 * El top-level apunta a la pagina "Inicio" (Help_Page) para que
	 * sea lo primero que ve un usuario que abre el plugin. Configuracion
	 * pasa a slug `-config` (antes era el slug principal).
	 *
	 * @return void
	 */
	public static function register(): void {
		add_menu_page(
			__( 'WP.pe Bridge', 'wppe-bridge' ),
			__( 'WP.pe Bridge', 'wppe-bridge' ),
			self::CAPABILITY,
			self::SLUG,
			array( 'WPPE_Bridge_Help_Page', 'render' ),
			'dashicons-admin-links',
			58
		);

		add_submenu_page(
			self::SLUG,
			__( 'Inicio', 'wppe-bridge' ),
			__( 'Inicio', 'wppe-bridge' ),
			self::CAPABILITY,
			self::SLUG,
			array( 'WPPE_Bridge_Help_Page', 'render' )
		);

		add_submenu_page(
			self::SLUG,
			__( 'Configuracion', 'wppe-bridge' ),
			__( 'Configuracion', 'wppe-bridge' ),
			self::CAPABILITY,
			self::SLUG . '-config',
			array( 'WPPE_Bridge_Settings_Page', 'render' )
		);

		add_submenu_page(
			self::SLUG,
			__( 'Mapeo de campos', 'wppe-bridge' ),
			__( 'Mapeo de campos', 'wppe-bridge' ),
			self::CAPABILITY,
			self::SLUG . '-mapping',
			array( 'WPPE_Bridge_Mapping_Page', 'render' )
		);

		// Sub-paginas especificas de GHL: solo visibles cuando el destino
		// activo es ghl. Permite configurar PIT/Location ID y mapeo
		// sin contaminar las paginas de Sperant. Asimetria intencional
		// con Sperant (Camino A, sec 12 CLAUDE.md).
		$wppe_bridge_active = WPPE_Bridge_Destination_Factory::active_slug();
		if ( WPPE_Ghl_Destination::SLUG === $wppe_bridge_active ) {
			add_submenu_page(
				self::SLUG,
				__( 'Configuracion GHL', 'wppe-bridge' ),
				__( 'Configuracion GHL', 'wppe-bridge' ),
				self::CAPABILITY,
				WPPE_Bridge_Ghl_Settings_Page::PAGE_SLUG,
				array( 'WPPE_Bridge_Ghl_Settings_Page', 'render' )
			);
			add_submenu_page(
				self::SLUG,
				__( 'Mapeo GHL', 'wppe-bridge' ),
				__( 'Mapeo GHL', 'wppe-bridge' ),
				self::CAPABILITY,
				WPPE_Bridge_Ghl_Mapping_Page::PAGE_SLUG,
				array( 'WPPE_Bridge_Ghl_Mapping_Page', 'render' )
			);
		}

		// Sub-pagina Webhook: solo visible cuando active = webhook.
		if ( WPPE_Bridge_Webhook_Destination::SLUG === $wppe_bridge_active ) {
			add_submenu_page(
				self::SLUG,
				__( 'Configuracion Webhook', 'wppe-bridge' ),
				__( 'Configuracion Webhook', 'wppe-bridge' ),
				self::CAPABILITY,
				WPPE_Bridge_Webhook_Settings_Page::PAGE_SLUG,
				array( 'WPPE_Bridge_Webhook_Settings_Page', 'render' )
			);
		}

		// Sub-paginas Odoo: solo visibles cuando active = odoo. PR-1
		// expuso Configuracion Odoo (auth + default_type). PR-2 agrega
		// Mapeo Odoo (catalog sync + global config + per-form mapping).
		if ( WPPE_Odoo_Destination::SLUG === $wppe_bridge_active ) {
			add_submenu_page(
				self::SLUG,
				__( 'Configuracion Odoo', 'wppe-bridge' ),
				__( 'Configuracion Odoo', 'wppe-bridge' ),
				self::CAPABILITY,
				WPPE_Bridge_Odoo_Settings_Page::PAGE_SLUG,
				array( 'WPPE_Bridge_Odoo_Settings_Page', 'render' )
			);
			add_submenu_page(
				self::SLUG,
				__( 'Mapeo Odoo', 'wppe-bridge' ),
				__( 'Mapeo Odoo', 'wppe-bridge' ),
				self::CAPABILITY,
				WPPE_Bridge_Odoo_Mapping_Page::PAGE_SLUG,
				array( 'WPPE_Bridge_Odoo_Mapping_Page', 'render' )
			);
		}

		add_submenu_page(
			self::SLUG,
			__( 'Modulos', 'wppe-bridge' ),
			__( 'Modulos', 'wppe-bridge' ),
			self::CAPABILITY,
			self::SLUG . '-modules',
			array( 'WPPE_Bridge_Modules_Page', 'render' )
		);

		add_submenu_page(
			self::SLUG,
			__( 'Logs', 'wppe-bridge' ),
			__( 'Logs', 'wppe-bridge' ),
			self::CAPABILITY,
			self::SLUG . '-logs',
			array( 'WPPE_Bridge_Logs_Page', 'render' )
		);

		// Sub-paginas ocultas de configuracion avanzada por modulo.
		// Se registran sin entry en el menu (parent_slug=null) para
		// que no aparezcan pero si se puedan abrir via URL directa.
		add_submenu_page(
			'',
			__( 'Meta CAPI', 'wppe-bridge' ),
			__( 'Meta CAPI', 'wppe-bridge' ),
			self::CAPABILITY,
			WPPE_Bridge_Meta_Capi_Settings_Page::PAGE_SLUG,
			array( 'WPPE_Bridge_Meta_Capi_Settings_Page', 'render' )
		);

		add_submenu_page(
			'',
			__( 'Thank You Pixel', 'wppe-bridge' ),
			__( 'Thank You Pixel', 'wppe-bridge' ),
			self::CAPABILITY,
			WPPE_Bridge_Thank_You_Pixel_Settings_Page::PAGE_SLUG,
			array( 'WPPE_Bridge_Thank_You_Pixel_Settings_Page', 'render' )
		);
	}
}
