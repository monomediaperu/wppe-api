<?php
/**
 * Comando WP-CLI: wp wppe-bridge queue ...
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Comandos de queue.
 */
final class WPPE_Bridge_Cli_Queue_Command {

	/**
	 * Lista items de la queue.
	 *
	 * ## OPTIONS
	 *
	 * [--status=<status>]
	 * : Filtra por status (pending, sent, failed_temp, failed_permanent, deduped).
	 *
	 * [--limit=<n>]
	 * : Cuantos a traer. Default: 25.
	 *
	 * [--format=<format>]
	 * : table | json | csv. Default: table.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - json
	 *   - csv
	 * ---
	 *
	 * ## EXAMPLES
	 *
	 *     wp wppe-bridge queue list
	 *     wp wppe-bridge queue list --status=failed_permanent --limit=50
	 *     wp wppe-bridge queue list --format=json
	 *
	 * @param array $args       Args posicionales.
	 * @param array $assoc_args Args asociativos.
	 * @return void
	 */
	public function list( $args, $assoc_args ) {
		unset( $args );
		$status = isset( $assoc_args['status'] ) ? (string) $assoc_args['status'] : null;
		$limit  = isset( $assoc_args['limit'] ) ? max( 1, (int) $assoc_args['limit'] ) : 25;
		$format = isset( $assoc_args['format'] ) ? (string) $assoc_args['format'] : 'table';

		$rows = WPPE_Bridge_Queue::paginate(
			array(
				'status'   => $status,
				'per_page' => $limit,
				'page'     => 1,
			)
		);

		if ( empty( $rows ) ) {
			\WP_CLI::log( 'No hay items.' );
			return;
		}

		$items = array();
		foreach ( $rows as $row ) {
			$payload = is_string( $row->payload ) ? json_decode( $row->payload, true ) : null;
			$email   = is_array( $payload ) && isset( $payload['email'] ) ? (string) $payload['email'] : '';
			$items[] = array(
				'id'         => (int) $row->id,
				'created_at' => (string) $row->created_at,
				'form'       => sprintf( '%s#%s', $row->form_plugin, $row->form_id ),
				'email'      => WPPE_Bridge_Pii_Masker::mask_email( $email ),
				'status'     => (string) $row->status,
				'attempts'   => (int) $row->attempts,
			);
		}

		\WP_CLI\Utils\format_items( $format, $items, array( 'id', 'created_at', 'form', 'email', 'status', 'attempts' ) );
	}

	/**
	 * Reencola un item especifico.
	 *
	 * ## OPTIONS
	 *
	 * <id>
	 * : ID del queue item.
	 *
	 * ## EXAMPLES
	 *
	 *     wp wppe-bridge queue retry 42
	 *
	 * @param array $args       [id].
	 * @param array $assoc_args (no uso).
	 * @return void
	 */
	public function retry( $args, $assoc_args ) {
		unset( $assoc_args );
		$id = isset( $args[0] ) ? (int) $args[0] : 0;
		if ( $id <= 0 ) {
			\WP_CLI::error( 'Falta <id>.' );
		}

		if ( WPPE_Bridge_Queue::queue_for_retry( $id ) ) {
			\WP_CLI::success( sprintf( 'Item #%d marcado para reintento.', $id ) );
		} else {
			\WP_CLI::error( sprintf( 'No se pudo reencolar #%d (existe?).', $id ) );
		}
	}

	/**
	 * Reencola todos los items en estado failed_temp y failed_permanent.
	 *
	 * ## OPTIONS
	 *
	 * [--limit=<n>]
	 * : Cuantos reencolar como maximo. Default: 100.
	 *
	 * [--yes]
	 * : Saltea la confirmacion.
	 *
	 * ## EXAMPLES
	 *
	 *     wp wppe-bridge queue retry-failed
	 *     wp wppe-bridge queue retry-failed --yes
	 *     wp wppe-bridge queue retry-failed --limit=10
	 *
	 * @subcommand retry-failed
	 * @param array $args       (no uso).
	 * @param array $assoc_args [limit, yes].
	 * @return void
	 */
	public function retry_failed( $args, $assoc_args ) {
		unset( $args );
		$limit = isset( $assoc_args['limit'] ) ? max( 1, (int) $assoc_args['limit'] ) : 100;

		$count_temp = WPPE_Bridge_Queue::count_by_status( WPPE_Bridge_Queue::STATUS_FAILED_TEMP );
		$count_perm = WPPE_Bridge_Queue::count_by_status( WPPE_Bridge_Queue::STATUS_FAILED_PERMANENT );
		$total      = $count_temp + $count_perm;

		if ( 0 === $total ) {
			\WP_CLI::log( 'No hay items fallidos.' );
			return;
		}

		\WP_CLI::confirm(
			sprintf(
				'Reencolar hasta %d items fallidos (%d temp + %d perm)?',
				min( $limit, $total ),
				$count_temp,
				$count_perm
			),
			$assoc_args
		);

		$retried = 0;
		foreach ( array( WPPE_Bridge_Queue::STATUS_FAILED_TEMP, WPPE_Bridge_Queue::STATUS_FAILED_PERMANENT ) as $status ) {
			if ( $retried >= $limit ) {
				break;
			}
			$rows = WPPE_Bridge_Queue::paginate(
				array(
					'status'   => $status,
					'per_page' => $limit - $retried,
					'page'     => 1,
				)
			);
			foreach ( $rows as $row ) {
				if ( WPPE_Bridge_Queue::queue_for_retry( (int) $row->id ) ) {
					++$retried;
				}
			}
		}

		\WP_CLI::success( sprintf( '%d items reencolados.', $retried ) );
	}
}
