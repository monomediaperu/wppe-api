<?php
/**
 * Deactivator del plugin.
 *
 * Limpia cron schedules. NO borra tablas ni opciones (eso es uninstall.php).
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Deactivator — métodos estáticos invocados por register_deactivation_hook.
 */
final class WPPE_Bridge_Deactivator {

	/**
	 * Punto de entrada.
	 */
	public static function deactivate(): void {
		wp_clear_scheduled_hook( WPPE_Bridge_Activator::CRON_HOOK );
		wp_clear_scheduled_hook( WPPE_Bridge_Activator::CRON_HOOK_LOGS_CLEANUP );
	}
}
