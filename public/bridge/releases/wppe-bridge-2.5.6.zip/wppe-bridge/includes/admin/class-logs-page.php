<?php
/**
 * Pagina admin de logs (queue items).
 *
 * Renderiza WP_List_Table con queue items, filtro por status,
 * bulk action de retry y vista detalle individual con JSON pretty
 * printed. PII (email/phone) enmascarada en el listado; visible en
 * detalle solo cuando el admin abre el item explicitamente.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pagina admin de visualizacion de logs (queue + eventos).
 */
final class WPPE_Bridge_Logs_Page {

	/**
	 * Action del POST handler para bulk retry.
	 */
	public const ACTION_BULK = 'wppe_bridge_logs_bulk';

	/**
	 * Action para retry individual.
	 */
	public const ACTION_RETRY = 'wppe_bridge_retry_lead';

	/**
	 * Action para retry con payload reconstruido (aplana nested name)
	 * — v1.2.6 para leads legacy que se encolaron con plugin <1.2.5.
	 */
	public const ACTION_RETRY_REBUILT = 'wppe_bridge_retry_rebuilt';

	/**
	 * Action para pausar un lead individual (v2.4.0).
	 */
	public const ACTION_PAUSE = 'wppe_bridge_pause_lead';

	/**
	 * Action para despausar un lead individual (v2.4.0).
	 */
	public const ACTION_RESUME = 'wppe_bridge_resume_lead';

	/**
	 * Nonce action.
	 */
	public const NONCE_ACTION = 'wppe_bridge_logs_nonce';

	/**
	 * Registra los handlers admin_post_*.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_post_' . self::ACTION_BULK, array( self::class, 'handle_bulk_action' ) );
		add_action( 'admin_post_' . self::ACTION_RETRY, array( self::class, 'handle_single_retry' ) );
		add_action( 'admin_post_' . self::ACTION_RETRY_REBUILT, array( self::class, 'handle_retry_rebuilt' ) );
		add_action( 'admin_post_' . self::ACTION_PAUSE, array( self::class, 'handle_pause' ) );
		add_action( 'admin_post_' . self::ACTION_RESUME, array( self::class, 'handle_resume' ) );
	}

	/**
	 * Renderiza la pagina (listado o detalle).
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '';  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$id     = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;                                   // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( 'view' === $action && $id > 0 ) {
			self::render_detail( $id );
			return;
		}

		self::render_list();
	}

	/**
	 * Renderiza el listado paginado.
	 *
	 * @return void
	 */
	private static function render_list(): void {
		$table = new WPPE_Bridge_Logs_List_Table();
		$table->prepare_items();

		$flash   = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$retried = isset( $_GET['retried'] ) ? (int) $_GET['retried'] : 0;                     // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$active_status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$counts        = self::status_counts();

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/logs.php';
	}

	/**
	 * Renderiza la vista detalle de un queue item.
	 *
	 * @param int $id ID del queue item.
	 * @return void
	 */
	private static function render_detail( int $id ): void {
		$item = WPPE_Bridge_Queue::find( $id );
		if ( null === $item ) {
			echo '<div class="wrap"><h1>' . esc_html__( 'Lead no encontrado', 'wppe-bridge' ) . '</h1></div>';
			return;
		}

		$payload          = is_string( $item->payload ) ? json_decode( $item->payload, true ) : null;
		$sperant_response = is_string( $item->sperant_response ) ? json_decode( $item->sperant_response, true ) : null;

		// Detectar si el payload tiene fname/lname como objeto nested
		// (caso legacy pre-v1.2.5). Habilita el boton "Reconstruir
		// payload y reintentar" en la UI.
		$has_nested_name = false;
		if ( is_array( $payload ) ) {
			foreach ( array( 'fname', 'lname' ) as $wppe_bridge_k ) {
				if ( isset( $payload[ $wppe_bridge_k ] ) && is_array( $payload[ $wppe_bridge_k ] ) ) {
					$has_nested_name = true;
					break;
				}
			}
		}

		$retry_url = wp_nonce_url(
			add_query_arg(
				array(
					'action' => self::ACTION_RETRY,
					'id'     => $id,
				),
				admin_url( 'admin-post.php' )
			),
			self::NONCE_ACTION
		);

		// URL del retry "reconstruido" (v1.2.6) — solo se renderiza el
		// boton si has_nested_name. Reusa el mismo nonce action.
		$retry_rebuilt_url = wp_nonce_url(
			add_query_arg(
				array(
					'action' => self::ACTION_RETRY_REBUILT,
					'id'     => $id,
				),
				admin_url( 'admin-post.php' )
			),
			self::NONCE_ACTION
		);

		// Flujo completo del lead (v1.2.1): logs en orden cronologico
		// para entender que paso desde que entro al adapter hasta el
		// estado actual.
		$lead_logs = WPPE_Bridge_Logger::recent_for_queue( $id, 100 );

		include WPPE_BRIDGE_PLUGIN_DIR . 'includes/admin/views/logs-detail.php';
	}

	/**
	 * Cuenta items por cada status posible. Para mostrar contadores
	 * en la barra de filtros.
	 *
	 * @return array<string,int>
	 */
	public static function status_counts(): array {
		return array(
			''                                         => WPPE_Bridge_Queue::count_by_status( null ),
			WPPE_Bridge_Queue::STATUS_PENDING          => WPPE_Bridge_Queue::count_by_status( WPPE_Bridge_Queue::STATUS_PENDING ),
			WPPE_Bridge_Queue::STATUS_SENT             => WPPE_Bridge_Queue::count_by_status( WPPE_Bridge_Queue::STATUS_SENT ),
			WPPE_Bridge_Queue::STATUS_FAILED_TEMP      => WPPE_Bridge_Queue::count_by_status( WPPE_Bridge_Queue::STATUS_FAILED_TEMP ),
			WPPE_Bridge_Queue::STATUS_FAILED_PERMANENT => WPPE_Bridge_Queue::count_by_status( WPPE_Bridge_Queue::STATUS_FAILED_PERMANENT ),
			WPPE_Bridge_Queue::STATUS_DEDUPED          => WPPE_Bridge_Queue::count_by_status( WPPE_Bridge_Queue::STATUS_DEDUPED ),
			WPPE_Bridge_Queue::STATUS_PAUSED           => WPPE_Bridge_Queue::count_by_status( WPPE_Bridge_Queue::STATUS_PAUSED ),
		);
	}

	/**
	 * Handler del bulk action: requeue cada item seleccionado.
	 *
	 * @return void
	 */
	public static function handle_bulk_action(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_ACTION );

		$ids = isset( $_POST['ids'] ) && is_array( $_POST['ids'] ) ? array_map( 'intval', wp_unslash( $_POST['ids'] ) ) : array();
		$ids = array_values( array_filter( $ids, static fn ( $i ) => $i > 0 ) );

		$retried = 0;
		foreach ( $ids as $queue_id ) {
			if ( WPPE_Bridge_Queue::queue_for_retry( $queue_id ) ) {
				++$retried;
			}
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => WPPE_Bridge_Admin_Menu::SLUG . '-logs',
					'flash'   => 'retried',
					'retried' => $retried,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Handler del retry individual desde la vista detalle.
	 *
	 * @return void
	 */
	public static function handle_single_retry(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_ACTION );

		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		$ok = $id > 0 && WPPE_Bridge_Queue::queue_for_retry( $id );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'   => WPPE_Bridge_Admin_Menu::SLUG . '-logs',
					'action' => 'view',
					'id'     => $id,
					'flash'  => $ok ? 'retried' : 'retry_failed',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Handler del retry con payload reconstruido (v1.2.6).
	 * Aplana fname/lname si son arrays nested (caso legacy de leads
	 * encolados con plugin <1.2.5) antes de re-encolar.
	 *
	 * @return void
	 */
	public static function handle_retry_rebuilt(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_ACTION );

		$id     = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		$result = $id > 0
			? WPPE_Bridge_Queue::rebuild_payload_and_retry( $id )
			: array(
				'ok'       => false,
				'modified' => false,
				'reason'   => 'invalid_id',
			);

		$flash = 'retry_failed';
		if ( ! empty( $result['ok'] ) ) {
			$flash = ! empty( $result['modified'] ) ? 'rebuilt_and_retried' : 'retried_unchanged';
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'   => WPPE_Bridge_Admin_Menu::SLUG . '-logs',
					'action' => 'view',
					'id'     => $id,
					'flash'  => $flash,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Handler: pausa un lead individual (v2.4.0). Cambia status
	 * `failed_temp` -> `paused`. El Worker lo ignora hasta resume.
	 *
	 * @return void
	 */
	public static function handle_pause(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_ACTION );

		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		$ok = $id > 0 && WPPE_Bridge_Queue::pause( $id );

		// Si pausamos un failed_permanent, igual invalidar el cache del
		// notice (defensivo — pause solo aplica a failed_temp pero el
		// admin podria entrar al detalle de un permanent y querer
		// silenciar). Pause() retorna false si el item no esta en
		// failed_temp; en ese caso $ok = false, no hace nada.
		if ( $ok && class_exists( 'WPPE_Bridge_Admin_Notice' ) ) {
			WPPE_Bridge_Admin_Notice::invalidate_cache();
		}

		wp_safe_redirect( self::redirect_back( $id, $ok ? 'paused' : 'pause_failed' ) );
		exit;
	}

	/**
	 * Handler: despausa un lead individual (v2.4.0). Cambia status
	 * `paused` -> `failed_temp` para que el Worker vuelva a procesarlo
	 * en el siguiente tick (segun next_retry_at).
	 *
	 * @return void
	 */
	public static function handle_resume(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos.', 'wppe-bridge' ) );
		}
		check_admin_referer( self::NONCE_ACTION );

		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		$ok = $id > 0 && WPPE_Bridge_Queue::resume( $id );

		if ( $ok && class_exists( 'WPPE_Bridge_Admin_Notice' ) ) {
			WPPE_Bridge_Admin_Notice::invalidate_cache();
		}

		wp_safe_redirect( self::redirect_back( $id, $ok ? 'resumed' : 'resume_failed' ) );
		exit;
	}

	/**
	 * Helper: arma URL de redirect post-action manteniendo contexto
	 * (volver al detalle si el id viene del detalle, sino al listado).
	 *
	 * @param int    $id    Queue ID.
	 * @param string $flash Codigo de mensaje flash.
	 * @return string
	 */
	private static function redirect_back( int $id, string $flash ): string {
		$args = array(
			'page'  => WPPE_Bridge_Admin_Menu::SLUG . '-logs',
			'flash' => $flash,
		);
		if ( $id > 0 ) {
			$args['action'] = 'view';
			$args['id']     = $id;
		}
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}
}
