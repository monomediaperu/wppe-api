<?php
/**
 * Notifier de errores por email (v2.4.0).
 *
 * Cuando un lead se marca como `failed_permanent` (D5: 4xx no-429 ->
 * permanente, o se agotaron los reintentos), notifica al admin por
 * email con un resumen batched.
 *
 * **Por que batched (D-Notif-2):** sin throttle, una caida de 30 min
 * del CRM destino enviaria 50+ emails al admin (uno por cada lead que
 * agoto sus reintentos). Con throttle 15 min, todos esos quedan
 * acumulados en un solo email.
 *
 * **Mecanismo:**
 *  1. El action `wppe_bridge_lead_failed` (que dispara el Worker al
 *     marcar un lead como permanente) acumula el queue_id en transient
 *     `wppe_bridge_pending_notifications` (sin TTL, persistente hasta
 *     que se vacie al enviar).
 *  2. Cron `wppe_bridge_notify_tick` corre cada 5 min:
 *     - Si el buffer esta vacio: nada.
 *     - Si esta poblado y NO existe transient `wppe_bridge_email_throttle`
 *       (TTL 15 min): construye email con resumen, lo manda con
 *       `wp_mail`, setea throttle, vacia buffer.
 *     - Si esta poblado pero throttle activo: espera el siguiente tick.
 *  3. Resultado: un solo email cada 15 min con todos los fallos
 *     acumulados, no uno por lead.
 *
 * **Direccion email (D-Notif-1, D-Notif-4):** default `admin_email` de
 * WordPress. Override configurable en option `wppe_bridge_notification_email`
 * (campo nuevo en Settings_Page). Una sola direccion (la "global" del
 * panel WP era el Admin_Notice, no el email).
 *
 * **Solo failed_permanent (D-Notif-3):** los `failed_temp` se reintentan
 * solos y suelen recuperarse. No spameamos por blips transitorios.
 *
 * @package WPPE_Bridge
 */

defined( 'ABSPATH' ) || exit;

/**
 * Notifier de errores por email batched.
 */
final class WPPE_Bridge_Notifier {

	/**
	 * Transient que acumula queue_ids de leads fallidos pendientes de
	 * notificar. Sin TTL — se vacia explicitamente al enviar email.
	 */
	public const BUFFER_KEY = 'wppe_bridge_pending_notifications';

	/**
	 * Transient que indica que ya se envio un email recientemente.
	 * TTL 15 min (D-Notif-2). Mientras esta seteado, el cron tick no
	 * envia aunque el buffer tenga items — los acumula para el siguiente.
	 */
	public const THROTTLE_KEY = 'wppe_bridge_email_throttle';

	/**
	 * TTL del throttle (15 min, D-Notif-2).
	 */
	public const THROTTLE_TTL_SECONDS = 15 * MINUTE_IN_SECONDS;

	/**
	 * Hook cron del tick de notificacion. Schedule `wppebridge_5min`
	 * (registrado en Activator).
	 */
	public const CRON_HOOK_TICK = 'wppe_bridge_notify_tick';

	/**
	 * Maximo de queue_ids que mantenemos en el buffer. Si el buffer
	 * crece mas que esto (caso patologico: CRM caido por horas), los
	 * mas antiguos se descartan del buffer pero el lead sigue en la
	 * tabla queue como `failed_permanent`. Ev_email muestra un mensaje
	 * "y N mas". Defensa contra que el option crezca sin limite.
	 */
	public const BUFFER_MAX_SIZE = 100;

	/**
	 * Bootstrap. Llamado desde Plugin::register_hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		// Acumular en buffer cuando un lead falla permanente.
		add_action( 'wppe_bridge_lead_failed', array( self::class, 'enqueue_notification' ), 10, 2 );

		// Cron tick: chequea buffer + throttle, envia email.
		add_action( self::CRON_HOOK_TICK, array( self::class, 'tick' ) );
	}

	/**
	 * Handler del action `wppe_bridge_lead_failed`. Acumula el queue_id
	 * en el buffer del transient. Idempotente: si el id ya esta, no se
	 * duplica.
	 *
	 * @param int   $queue_id ID del item que fallo.
	 * @param mixed $context  Contexto del fallo (no usado aca, lo deja
	 *                        para extension futura).
	 * @return void
	 */
	public static function enqueue_notification( int $queue_id, $context = null ): void {
		unset( $context );
		if ( $queue_id <= 0 ) {
			return;
		}

		$buffer = get_transient( self::BUFFER_KEY );
		if ( ! is_array( $buffer ) ) {
			$buffer = array();
		}

		// Idempotente: no duplicar.
		if ( in_array( $queue_id, $buffer, true ) ) {
			return;
		}

		$buffer[] = $queue_id;

		// Cap defensivo (caso patologico: CRM caido por horas, miles
		// de fallos). El buffer no crece sin limite.
		if ( count( $buffer ) > self::BUFFER_MAX_SIZE ) {
			// Descartar los mas antiguos, mantener los ultimos.
			$buffer = array_slice( $buffer, -self::BUFFER_MAX_SIZE );
		}

		// Sin TTL — se vacia al enviar email.
		set_transient( self::BUFFER_KEY, $buffer, 0 );
	}

	/**
	 * Tick del cron. Llamado cada 5 min via WP-Cron.
	 *
	 * Si hay buffer + no esta throttled, envia email batched.
	 *
	 * @return void
	 */
	public static function tick(): void {
		$buffer = get_transient( self::BUFFER_KEY );
		if ( ! is_array( $buffer ) || empty( $buffer ) ) {
			return; // Nada que notificar.
		}

		if ( false !== get_transient( self::THROTTLE_KEY ) ) {
			return; // Throttle activo, esperar siguiente tick.
		}

		$sent = self::send_email( $buffer );

		if ( $sent ) {
			// Setear throttle 15 min.
			set_transient( self::THROTTLE_KEY, time(), self::THROTTLE_TTL_SECONDS );
			// Vaciar buffer.
			delete_transient( self::BUFFER_KEY );

			if ( class_exists( 'WPPE_Bridge_Logger' ) ) {
				WPPE_Bridge_Logger::info(
					'notifier_email_sent',
					array(
						'count' => count( $buffer ),
						'to'    => self::recipient(),
					)
				);
			}
		} elseif ( class_exists( 'WPPE_Bridge_Logger' ) ) {
			// Si fallo el envio (wp_mail returned false), no setear
			// throttle ni vaciar — reintentaremos en el siguiente tick.
			WPPE_Bridge_Logger::warn(
				'notifier_email_failed',
				array( 'count' => count( $buffer ) )
			);
		}
	}

	/**
	 * Construye y envia el email con resumen de leads fallidos.
	 *
	 * @param array<int,int> $queue_ids Lista de queue IDs en el buffer.
	 * @return bool True si wp_mail retorno true, false si no.
	 */
	public static function send_email( array $queue_ids ): bool {
		$to      = self::recipient();
		$count   = count( $queue_ids );
		$subject = sprintf(
			/* translators: %d: count of failed leads */
			_n(
				'[WP.pe Bridge] %d lead fallo al enviar al CRM',
				'[WP.pe Bridge] %d leads fallaron al enviar al CRM',
				$count,
				'wppe-bridge'
			),
			$count
		);

		$body = self::build_email_body( $queue_ids );

		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
		);

		// wp_mail puede retornar false en SMTP roto.
		return (bool) wp_mail( $to, $subject, $body, $headers );
	}

	/**
	 * Construye el body HTML del email.
	 *
	 * @param array<int,int> $queue_ids Buffer de IDs.
	 * @return string HTML del email.
	 */
	public static function build_email_body( array $queue_ids ): string {
		$count       = count( $queue_ids );
		$logs_url    = function_exists( 'admin_url' )
			? admin_url( 'admin.php?page=wppe-bridge-logs&status=failed_permanent' )
			: '';
		$site_url    = function_exists( 'home_url' ) ? home_url() : '';
		$site_label  = function_exists( 'get_bloginfo' ) ? (string) get_bloginfo( 'name' ) : 'WordPress site';
		$destination = class_exists( 'WPPE_Bridge_Destination_Factory' )
			? WPPE_Bridge_Destination_Factory::active_slug()
			: 'unknown';

		$rows_html = '';
		foreach ( $queue_ids as $qid ) {
			$item = class_exists( 'WPPE_Bridge_Queue' ) ? WPPE_Bridge_Queue::find( (int) $qid ) : null;
			if ( null === $item ) {
				$rows_html .= sprintf(
					'<tr><td>#%d</td><td colspan="3"><em>%s</em></td></tr>',
					(int) $qid,
					esc_html__( 'No encontrado (eliminado?)', 'wppe-bridge' )
				);
				continue;
			}

			$payload = is_string( $item->payload ) ? json_decode( $item->payload, true ) : null;
			$email   = is_array( $payload ) && isset( $payload['email'] ) ? (string) $payload['email'] : '';
			$masked  = class_exists( 'WPPE_Bridge_Pii_Masker' )
				? WPPE_Bridge_Pii_Masker::mask_email( $email )
				: $email;

			$response = is_string( $item->sperant_response ) ? json_decode( $item->sperant_response, true ) : null;
			$error    = is_array( $response ) && isset( $response['body']['message'] )
				? (string) $response['body']['message']
				: ( is_array( $response ) && isset( $response['error_class'] )
					? (string) $response['error_class']
					: __( 'Sin detalle', 'wppe-bridge' ) );

			$rows_html .= sprintf(
				'<tr><td>#%d</td><td>%s</td><td>%s</td><td>%s</td></tr>',
				(int) $item->id,
				esc_html( (string) $item->created_at ),
				esc_html( $masked ),
				esc_html( substr( $error, 0, 200 ) )
			);
		}

		$site_label_h  = esc_html( $site_label );
		$site_url_h    = esc_url( $site_url );
		$logs_url_h    = esc_url( $logs_url );
		$destination_h = esc_html( $destination );

		return <<<HTML
<!DOCTYPE html>
<html><body style="font-family:system-ui,sans-serif;max-width:680px;margin:0 auto;padding:1em">
	<h2 style="color:#dc3232">WP.pe Bridge — leads fallidos</h2>
	<p>
		El plugin WP.pe Bridge en <strong><a href="{$site_url_h}">{$site_label_h}</a></strong>
		marc&oacute; <strong>{$count} lead(s)</strong> como <code>failed_permanent</code> al
		enviarlos al CRM destino (<code>{$destination_h}</code>).
	</p>
	<p>
		Los leads en este estado <strong>no se reintentan</strong> automaticamente. Para
		recuperarlos: revisar el detalle, identificar la causa (token revocado, payload
		invalido, CRM caido por largo tiempo), y reintentar manualmente desde la pagina
		de Logs.
	</p>
	<table cellpadding="6" cellspacing="0" style="border-collapse:collapse;border:1px solid #ccd0d4;width:100%">
		<thead style="background:#f0f0f1">
			<tr>
				<th style="border:1px solid #ccd0d4;text-align:left">ID</th>
				<th style="border:1px solid #ccd0d4;text-align:left">Fecha</th>
				<th style="border:1px solid #ccd0d4;text-align:left">Email</th>
				<th style="border:1px solid #ccd0d4;text-align:left">Error</th>
			</tr>
		</thead>
		<tbody>
			{$rows_html}
		</tbody>
	</table>
	<p style="margin-top:1.5em">
		<a href="{$logs_url_h}" style="background:#2271b1;color:#fff;padding:8px 16px;text-decoration:none;border-radius:3px;display:inline-block">
			Ver logs completos &rarr;
		</a>
	</p>
	<hr style="margin:2em 0;border:0;border-top:1px solid #ccd0d4"/>
	<p style="color:#666;font-size:12px">
		Este email se envia con throttle de 15 minutos para evitar spam.
		Si recibes muchos seguidos, probablemente el CRM destino esta caido.
		Para silenciar mientras lo resuelves, podes pausar reintentos
		individualmente desde la pagina de Logs.
	</p>
</body></html>
HTML;
	}

	/**
	 * Direccion email destinataria (D-Notif-1).
	 *
	 * Default: `admin_email` de WP. Override: option
	 * `wppe_bridge_notification_email` si esta configurada y es valida.
	 *
	 * @return string
	 */
	public static function recipient(): string {
		$override = (string) get_option( 'wppe_bridge_notification_email', '' );
		if ( '' !== $override && is_email( $override ) ) {
			return $override;
		}
		return (string) get_option( 'admin_email', '' );
	}
}
